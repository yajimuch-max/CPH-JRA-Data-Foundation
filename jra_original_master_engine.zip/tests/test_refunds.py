import json,tempfile,unittest
from pathlib import Path
from dataclasses import replace
from unittest.mock import patch
from jra_master import refunds
from jra_master.store import Store
from jra_master.model import ParsedRace,RaceEntry,RaceResult

RID='2024-04-14-中山-11'
def body(text):return ('<html>'+text+'</html>').encode('cp932')
class RefundTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.s=Store(Path(self.tmp.name)/'MASTER.sqlite3');self.s.meta('year',2024)
  e=RaceEntry(16,8,'2021100001','TEST','牡3',57.,None,'騎手',None,'調教師',500,None)
  self.parsed=ParsedRace('2024-04-14','中山','3回中山8日',11,'皐月賞','芝',2000,'芝右','15:40','晴','良','GⅠ',[e],[RaceResult(16,'除外',None,None,None)])
  with self.s.c:
   self.s.c.execute('insert into races values(?,?,?,?,?,?)',(RID,'2024-04-14','中山',11,'FLAT','{}'))
   self.s.c.execute('insert into horses values(?,?)',(e.horse_id,e.horse_name))
   self.s.c.execute('insert into runners values(?,?,?,?)',(RID,16,e.horse_id,'{"jockey_name":"騎手"}'))
   self.s.c.execute('insert into results values(?,?,?)',(RID,16,'{"finish_status":"除外"}'))
   self.s.c.execute('insert into payouts values(?,?,?,?)',(RID,'WIN',1,'{"payout_yen":480}'))
 def tearDown(self):self.s.c.close();self.tmp.cleanup()
 def test_official_text_and_fullwidth(self):
  for text in ['<dl><dt>返還</dt><dd>返還馬番　16番</dd></dl>','<table><tr><th>返還</th><td><span>返還馬番</span><b>１６番、１番</b> 返還同枠 ８枠</td></tr></table>']:
   rows=refunds.parse_refunds(body(text));self.assertIn(16,rows[0]['refund_horse_numbers']);self.assertIsNone(rows[0]['payout_yen'])
  self.assertEqual(rows[0]['refund_frame_numbers'],[8]);self.assertEqual(rows[0]['refund_horse_numbers'],[1,16])
 def test_absent_is_not_generic_footer(self):
  self.assertEqual(refunds.parse_refunds(body('<p>返還の対象となります</p>')),[])
 def test_malformed_is_not_none(self):
  for text in ['<dl><dt>返還</dt><dd>不明</dd></dl>','<p>返還馬番 不明</p>','<p>返還馬番 99番</p>']:
   with self.assertRaises(ValueError):refunds.parse_refunds(body(text))
 def test_finished_runner_refund_rejected(self):
  with self.assertRaisesRegex(ValueError,'CANCELLED'):
   refunds.validate(replace(self.parsed,results=[RaceResult(16,'FINISHED',1,'2:00.0',None)]),refunds.parse_refunds(body('<p>返還馬番16番</p>')))
 def test_repair_is_idempotent_preserves_learning_and_normal_payout(self):
  before={t:[tuple(x) for x in self.s.c.execute('select * from '+t)] for t in ['races','horses','runners','results']}
  b=body('<p>返還馬番16番</p>')
  refunds.apply(self.s,self.parsed,b,None,'https://www.jra.go.jp/JRADB/accessS.html?CNAME=TEST')
  refunds.apply(self.s,self.parsed,b,None,'https://www.jra.go.jp/JRADB/accessS.html?CNAME=TEST')
  for t,rows in before.items():self.assertEqual(rows,[tuple(x) for x in self.s.c.execute('select * from '+t)])
  self.assertEqual(self.s.c.execute("select payload_json from payouts where bet_type='WIN'").fetchone()[0],'{"payout_yen":480}')
  self.assertEqual(self.s.c.execute('select count(*) from revisions').fetchone()[0],0)
  self.assertEqual(refunds.audit(self.s.c,2024)['status'],'PASS')
 def test_wrong_horse_and_status_do_not_write(self):
  for parsed in [replace(self.parsed,entries=[replace(self.parsed.entries[0],horse_id='OTHER')]),replace(self.parsed,results=[replace(self.parsed.results[0],finish_status='取消')])]:
   with self.assertRaises(ValueError):refunds.apply(self.s,parsed,body('<p>返還馬番16番</p>'),None,None)
  self.assertEqual(self.s.c.execute('select count(*) from payouts').fetchone()[0],1)
 def test_existing_refund_not_silently_deleted(self):
  refunds.apply(self.s,self.parsed,body('<p>返還馬番16番</p>'),None,None)
  with self.assertRaises(ValueError):refunds.apply(self.s,self.parsed,body('<p>none</p>'),None,None)
 def test_absence_receipt_and_missing_coverage(self):
  self.assertEqual(refunds.audit(self.s.c,2024)['remaining'],1)
  refunds.apply(self.s,self.parsed,body('<p>none</p>'),None,None)
  self.assertEqual(refunds.audit(self.s.c,2024)['status'],'PASS')
 def test_resumes_only_unverified_pages(self):
  url='https://www.jra.go.jp/JRADB/accessS.html?CNAME=OBSERVED';b=body('<p>返還馬番16番</p>')
  class Client:
   def request(self,*a):return b,None,None
  with patch('jra_master.person_repair.result_url',return_value=url),patch('jra_master.refunds.parse_result',return_value=self.parsed):
   x=refunds.run(self.s,Client(),2024,self.tmp.name);y=refunds.run(self.s,Client(),2024,self.tmp.name)
  self.assertEqual(x['checked_this_run'],1);self.assertEqual(y['checked_this_run'],0);self.assertEqual(y['remaining'],0)

 def test_modified_data_invalidates_receipt(self):
  refunds.apply(self.s,self.parsed,body('<p>返還馬番16番</p>'),None,None)
  self.s.c.execute("delete from payouts where bet_type='REFUND'")
  self.assertEqual(refunds.audit(self.s.c,2024)['receipt_data_mismatches'],1)
 def test_split_horse_frame_nodes(self):
  row=refunds.parse_refunds(body('<dl><dt>返還</dt><dd><strong>返還馬番16番</strong><strong>返還同枠8枠</strong></dd></dl>'))[0]
  self.assertEqual(row['refund_frame_numbers'],[8])

 def test_normal_collection_parses_refund_and_stores_receipt(self):
  from jra_master.racing import integrate_result
  html=body('<table><thead><th class="place">着順</th></thead><tbody><tr><td class="num">16</td><td class="horse">TEST</td></tr></tbody></table><dl><dt>返還</dt><dd>返還馬番16番</dd></dl>')
  sid=self.s.source(dict(service='JRA',role='RESULT_HTML',url='https://www.jra.go.jp/JRADB/accessS.html'));self.s.c.commit()
  with patch('jra_master.racing.parse_result',return_value=self.parsed):integrate_result(self.s,html,sid,RID)
  self.assertEqual(refunds.audit(self.s.c,2024)['status'],'PASS')
  self.assertEqual(self.s.c.execute("select count(*) from payouts where bet_type='REFUND'").fetchone()[0],1)
