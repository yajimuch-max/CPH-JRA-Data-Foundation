# GitHub差分更新・運用手順（JRA HTML統一原本 v0.7.1.1）

## 配置とバックアップ

1. GitHubリポジトリ直下の既存 `jra_original_master_engine.zip` をバックアップ（Release等）し、本セットの同名ZIPへ**置き換える**。
2. `.github/workflows/jra_original_master.yml` は **現在のv0.7.1対応のままで変更しない**。
3. 既存の `jra-original-state-YYYY`、`YYYY_JRA_MASTER.zip`、過去の監査JSONを削除しない。**途中のstateが最重要チェックポイント**。
4. 更新後、Actionsの `オフライン自己検査` が合格したことを先に確認する。

## 2019年の差分修復（まずこれ）

Actions → 既存ワークフロー → Run workflow:

- `year=2019`
- `mode=update`
- `reset_from_release=false`
- `resume_run_id=` 空欄（最新stateを自動復元）
- `refresh=false` （既に正常なHTMLを再取得しない）
- `with_official=true`, `with_track=true`, `with_pedigree=true`
- `max_html_pages=2200`（不足2,015レースのため。制限時間に達したら同じ指定で再実行）
- 年間 `start_date`, `end_date`, `months` は現在の2019年の設定と同様。取り込んだ日付を再生成しない。

期待するHTML動作：既存の **1,437件は検証済み証跡をそのまま再利用**、欠けている **2,015件だけ本物の公式HTMLを取得またはハッシュ一致キャッシュを再解析**。元HTMLと照合できない場合はPASS不可。完了まで複数回走らせてよい。`official_html_audit_2019.json` の `field_coverage` を確認する。

**重要**：2019年の元stateには古い含水率PDF解析由来の4開催日不足が残っていた。HTML修正と別問題。`track_audit_2019.json` がまだ PARTIAL / `missing_race_track_days>0` なら、`mode=track` + `refresh=true` で公式PDFだけ再照合し、その後 `mode=update` + `refresh=false` で統合監査・認証を試す。PDF再解析で解決しなければ、取得記録・未充足日を確認してそこで止める。`state` 以外の小さなmaster監査JSONだけを完成原本として扱わない。

## 2018年

HTMLは従来3,454/3,454件揃っているため全件の取り直し不要。元stateに阪神の含水率2日不足が残っていれば、まず `mode=track` + `refresh=true` でPDF再照合し、後に `mode=update` + `refresh=false` で認証を試す。2018年クッション値は公表対象外。A/B/C/Dを補填しない。PDF処理で日付が補えないときは `NOT_CERTIFIED` を維持し、無根拠で書き込まない。

## 2020年以降・2026年を毎週更新

通常は `year=対象年度`, `mode=update`, `reset_from_release=false`, `refresh=false`, `with_official=true`, `with_track=true`, `with_pedigree=true`。`months` / `start_date` / `end_date` は追加対象に合わせる。stateの更新済みレースや血統・HTMLを再取得しない設定を維持。公開後に訂正されたPDFの再検証が必要な時だけ別途 `mode=track`, `refresh=true` を選ぶ。

2026年の**まだ開催されていない競馬や、後日の最終オッズ・結果を取得済みとは判定しない**。このパイプラインの歴史的なレース結果HTMLは発走前時点の観測データではない。

## 正式に保存するもの

- `jra-original-state-YYYY` Artifact：SQLite取得・監査の途中/完全チェックポイント。次回差分更新に必須。Actions保持期限に注意し、定期的にバックアップ。
- `YYYY_JRA_MASTER.zip`：監査 `CERTIFIED`、ZIP実在、manifest とSHAが正常なときだけ **正式原本** として保存。
- `unified_audit_YYYY.json`、`official_html_audit_YYYY.json`、`track_audit_YYYY.json`：監査証跡。

**正式原本には採用しないもの**：A/B/C/Dコース、馬主・生産者・生産地、旧式PDFのレース結果派生項目、根拠のないブリンカー非着用、未公表の含水率/クッション値、レース前観測でないデータをレース前実測値として扱うこと。使用可能な上がり3F/4Fは従来の `race_sectionals` 派生ビュー。クッション値・含水率は2018年以降の `official_track_daily` と非空 `track_measurements` ビュー。

**検証未済**：今回のPythonテストと原本を使ったオフラインドライランはPASS。GitHub Actionsの新コードでの実通信・JRAのHTML本文再照合・PDFの欠落復旧は**まだ未実施**。外部取得で失敗したものは無理に `CERTIFIED` にしない。
