#!/usr/bin/env bash
set -Eeuo pipefail
if [[ $# -ne 2 || ! "$1" =~ ^[0-9]{4}$ || ! "$2" =~ ^(0[1-9]|1[0-2])$ ]]; then
  echo "Usage: $0 YYYY MM" >&2; exit 64
fi
target_year="$1"; target_month="$2"
workspace_root="${GITHUB_WORKSPACE:-$(pwd)}"
engine_root="$(cd "$(dirname "$0")/.." && pwd)"
data_root="$workspace_root/run_data"
reports_root="$workspace_root/run_reports/${target_year}-${target_month}"
delivery_root="$workspace_root/delivery"
status="FAIL"
mkdir -p "$data_root" "$reports_root" "$delivery_root"
finalize() {
  exit_code=$?; if [[ $exit_code -eq 0 ]]; then status="PASS"; fi
  python "$engine_root/scripts/package_period_result.py" \
    --year "$target_year" --period "${target_month}月まで" --status "$status" \
    --data-root "$data_root" --reports-root "$workspace_root/run_reports" \
    --delivery-root "$delivery_root" || true
}
trap finalize EXIT
cd "$engine_root"
python run_data_foundation.py --root "$data_root" --workers 4 year-discover \
  --year "$target_year" --output "$reports_root/JRA_${target_year}_年次開催日Manifest.json" \
  | tee "$reports_root/01_year_discover.json"
python run_data_foundation.py --root "$data_root" --workers 4 collect-month \
  --year "$target_year" --month "$((10#$target_month))" --max-dates-this-run 31 --retry-failed \
  | tee "$reports_root/02_month_collection.json"
python run_data_foundation.py --root "$data_root" month-audit \
  --year "$target_year" --month "$((10#$target_month))" \
  | tee "$reports_root/03_month_audit.json"
python - "$data_root/cph_jra_df.sqlite3" <<'PY' | tee "$reports_root/04_sqlite_audit.json"
import json, sqlite3, sys
conn = sqlite3.connect(sys.argv[1])
integrity = conn.execute("PRAGMA integrity_check").fetchone()[0]
foreign_keys = conn.execute("PRAGMA foreign_key_check").fetchall()
conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
conn.close()
result = {"integrity_check": integrity, "foreign_key_violation_count": len(foreign_keys),
          "status": "PASS" if integrity == "ok" and not foreign_keys else "FAIL"}
print(json.dumps(result, ensure_ascii=False, indent=2))
if result["status"] != "PASS": raise SystemExit(2)
PY
