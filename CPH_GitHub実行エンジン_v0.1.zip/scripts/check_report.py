from __future__ import annotations

import argparse
import json
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("year", "seed", "day", "reparse", "audit", "plan"))
    parser.add_argument("report")
    args = parser.parse_args()
    payload = json.loads(Path(args.report).read_text(encoding="utf-8"))

    passed = False
    if args.mode in {"year", "day", "reparse"}:
        passed = payload.get("status") == "PASS"
    elif args.mode == "seed":
        passed = payload.get("audit_status") == "PASS" and payload.get("failed_this_run") == 0
    elif args.mode == "audit":
        latest = payload.get("latest_pipeline_run") or {}
        passed = (
            latest.get("status") == "PASS"
            and payload.get("sqlite_integrity") == "ok"
            and payload.get("foreign_key_violation_count") == 0
        )
    elif args.mode == "plan":
        passed = payload.get("audit_status") == "PASS" and payload.get("fail_count") == 0

    if not passed:
        print(json.dumps({"report_check": "FAIL", "mode": args.mode, "report": args.report}, ensure_ascii=False))
        return 2
    print(json.dumps({"report_check": "PASS", "mode": args.mode}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
