"""JRA's four profile fields only; no recursive ancestors or external service."""
import re,json,unicodedata
from urllib.parse import urlencode,urlparse,parse_qs
from bs4 import BeautifulSoup
from .jra_parser import decode_jra
from .store import encode,now
from .network import Deferred
FIELDS={'父':'S','母':'M','母の父':'MS','母の母':'MM'}
def norm(x):return re.sub(r'\s+','',unicodedata.normalize('NFKC',x))
def parse(body,horse_id,expected_name,observed_cname):
 soup=BeautifulSoup(decode_jra(body),'lxml');title=soup.find('title')
 if not title or '競走馬情報' not in title.get_text():raise ValueError('NOT_JRA_HORSE_PROFILE')
 # Verify target ID from the exact official link observed in a result page.
 match=re.search(r'pw01dud(?:00|10)(\d{10})',observed_cname or '')
 if not match or match[1]!=horse_id:raise ValueError('OBSERVED_PROFILE_LINK_ID_MISMATCH')
 heading=soup.select_one('h1 .txt')
 if heading is None:raise ValueError('HORSE_PROFILE_HEADING_MISSING')
 heading=BeautifulSoup(str(heading),'lxml')
 for node in heading.select('.opt,.name_en,.icon'):node.decompose()
 observed_name=norm(heading.get_text(' ',strip=True))
 expected=norm(expected_name)
 # Status badges are not part of a horse's registered name. Remove only a
 # complete, recognised suffix; never accept a prefix/substring name match.
 if observed_name!=expected:
  status_suffixes=['放牧','入厩','抹消','登録抹消','競走馬登録抹消','現役']
  accepted={expected+x for x in status_suffixes}|{expected+'('+x+')' for x in status_suffixes}
  if observed_name not in accepted:raise ValueError('HORSE_PROFILE_NAME_MISMATCH: expected='+expected+' observed='+observed_name)
 rows=[];birth=None;profile={}
 for dt in soup.find_all('dt'):
  label=dt.get_text(strip=True);dd=dt.find_next_sibling('dd')
  if dd is None:continue
  if label=='生年月日':birth=dd.get_text(' ',strip=True)
  if label not in FIELDS:continue
  path=FIELDS[label]
  value=BeautifulSoup(str(dd),'lxml')
  for control in value.find_all('a'):
   if control.get_text(strip=True)=='産駒':control.decompose()
  dd=value.find('dd');a=dd.find('a');name=dd.get_text(' ',strip=True);ancestor_id=None;href=None
  if a:
   href=a.get('href','')+a.get('onclick','');m=re.search(r'pw01dud(?:00|10)(\d{10})',href)
   if m:ancestor_id=m[1]
  if name in ['','－','-','不明','未登録']:name=None
  rows.append({'path':path,'generation':len(path),'ancestor_id':ancestor_id,'ancestor_name':name,'birth_year':None,'status':'KNOWN' if name else 'NOT_PROVIDED'})
  profile[path]={'field':label,'official_name':name,'observed_ancestor_link':href}
 if len(rows)!=4 or {r['path'] for r in rows}!=set(FIELDS.values()):raise ValueError('JRA_PROFILE_FOUR_FIELDS_INCOMPLETE')
 return rows,{'horse_id':horse_id,'horse_name':expected_name,'birth_date_raw':birth,'fields':profile}

def collect(s,client,limit=500):
 from .profile_links import supplement
 added=supplement(s)
 if added:print("OFFICIAL_PROFILE_LINKS_SUPPLEMENTED",added,flush=True)
 for receipt in s.c.execute("SELECT p.horse_id,m.value FROM pedigree_receipts p JOIN metadata m ON m.key='horse_identity_'||p.horse_id WHERE p.status='PASS_WITH_SOURCE_MISSING'").fetchall():
  fields=json.loads(receipt['value']).get('fields',{})
  if any(f.get('official_name') is None and 'pj01snk' in (f.get('observed_ancestor_link') or '') for f in fields.values()):
   s.c.execute("UPDATE pedigree_receipts SET status='NEEDS_REPARSE' WHERE horse_id=?",(receipt['horse_id'],))
 s.c.commit()
 rows=s.c.execute("SELECT h.* FROM horses h LEFT JOIN pedigree_receipts p USING(horse_id) WHERE p.horse_id IS NULL OR p.status='NEEDS_REPARSE' ORDER BY h.horse_id LIMIT ?",(limit,)).fetchall();completed=0;missing_links=0;consecutive_errors=0
 for h in rows:
  hid=h['horse_id'];key='JRA_PEDIGREE_'+hid;link=s.c.execute('SELECT value FROM metadata WHERE key=?',('horse_profile_'+hid,)).fetchone()
  if not link:
   s.task(key,'PENDING','No observed JRA profile link; reaudit saved result RAW or update official results first.');missing_links+=1;continue
  url=json.loads(link[0]);cname=(parse_qs(urlparse(url).query).get('CNAME') or [None])[0]
  if not cname:s.task(key,'FAIL','OBSERVED_CNAME_MISSING');continue
  try:
   body,sid,p=client.request('https://www.jra.go.jp/JRADB/accessU.html','JRA_PEDIGREE_FOUR_FIELDS',urlencode({'cname':cname}))
   expected=h['horse_name']
   verified_names={('2002190009','ウルトラファンタジ'):'ウルトラファンタジー',('2006190006','フィフティープルー'):'フィフティープルーフ',('2004190008','ミッションアプルー'):'ミッションアプルーヴド',('2005190008','ビューティーフラッ'):'ビューティーフラッシュ',('2005190012','キャプテンオブヴィ'):'キャプテンオブヴィアス',('2020190007','ファストネットワー'):'ファストネットワーク',('2018190002','ロマンチックウォリ'):'ロマンチックウォリアー',('2020190004','ファンタスティック'):'ファンタスティックムーン',('2012190005','ウエスタンエクスプ'):'ウエスタンエクスプレス',('2011190004','ビューティーオンリ'):'ビューティーオンリー',('2010190001','アップウィズザバー'):'アップウィズザバーズ',('2010190002','トレーディングレザ'):'トレーディングレザー',('2005190013','ブラックステアマウ'):'ブラックステアマウンテン'}
   expected=verified_names.get((hid,expected),expected)
   facts,identity=parse(body,hid,expected,cname)
   if expected!=h['horse_name']:
    with s.c:
     s.put('horses',['horse_id'],{'horse_id':hid,'horse_name':expected},sid,'OFFICIAL_PROFILE_VERIFIED_TRUNCATED_NAME')
     for runner in s.c.execute('SELECT * FROM runners WHERE horse_id=?',(hid,)).fetchall():
      for table in ['runners','results','win_odds']:
       item=s.c.execute('SELECT * FROM '+table+' WHERE race_id=? AND horse_number=?',(runner['race_id'],runner['horse_number'])).fetchone()
       if item:
        row=dict(item);payload=json.loads(row['payload_json'])
        if payload.get('horse_name')==h['horse_name']:
         payload['horse_name']=expected;row['payload_json']=encode(payload);s.put(table,['race_id','horse_number'],row,sid,'OFFICIAL_PROFILE_VERIFIED_TRUNCATED_NAME')
   with s.c:
    for r in facts:s.put('pedigree',['horse_id','path'],{'horse_id':hid,**r,'source_id':sid},sid,'JRA_FOUR_PROFILE_FIELDS_VERIFIED')
    s.c.execute('INSERT OR REPLACE INTO pedigree_receipts VALUES (?,?,?,?)',(hid,sid,4,'PASS' if all(r['status']=='KNOWN' for r in facts) else 'PASS_WITH_SOURCE_MISSING'))
    s.c.execute('INSERT OR REPLACE INTO metadata VALUES (?,?)',('horse_identity_'+hid,encode(identity)))
   client.valid(sid,p);s.task(key,'PASS');s.resolve(key);completed+=1;consecutive_errors=0
   if completed%100==0:print('PEDIGREE_PROGRESS',completed,flush=True)
  except Deferred as e:s.task(key,'DEFERRED',str(e));break
  except Exception as e:
   s.task(key,'FAIL',str(e));s.issue(key,'JRA_PEDIGREE_FETCH_OR_VALIDATION',{'error':str(e),'observed_url':url});consecutive_errors+=1
   print('PEDIGREE_FAILED',hid,str(e),flush=True)
   if consecutive_errors>=3:
    print('PEDIGREE_CHECKPOINT: three consecutive failures; stopping batch',flush=True);break
 return {'completed':completed,'missing_observed_profile_links':missing_links,'pending_horses':s.c.execute('SELECT count(*) FROM horses h LEFT JOIN pedigree_receipts p USING(horse_id) WHERE p.horse_id IS NULL OR p.status="NEEDS_REPARSE"').fetchone()[0]}
