import unittest,tempfile,json,gzip,hashlib
from pathlib import Path
from unittest.mock import patch
from jra_master.card_probe import probe,observed_card_links
from jra_master.store import Store
from jra_master.cli import main
from test_discovery_diagnostics import FakeClient
ENTRY=b'<title>\xe5\x87\xba\xe9\xa6\xac\xe8\xa1\xa8</title><a href="pw01drl10052026040120261003/AA">meeting</a>'
# CP932 avoids ambiguity in the official decode order.
CARD='<title>出馬表 JRA</title>'.encode('cp932')
MENU=b'<a href="pw01dde0105202604010120261003/BB">card</a><a href="pw01sde1005202604010120261003/CC">result</a>'
class CardProbeTests(unittest.TestCase):
 def setUp(self):self.t=tempfile.TemporaryDirectory();self.p=Path(self.t.name);self.s=Store(self.p/'MASTER.sqlite3')
 def tearDown(self):self.s.c.close();self.t.cleanup()
 def test_only_observed_card_links_no_result_fetch(self):
  c=FakeClient(self.s,self.p/'raw',bodies=[ENTRY,MENU,CARD]);r=probe(c,2026,self.p/'out');self.assertEqual(r['race_card_candidates'],1);self.assertEqual(len(c.calls),3);self.assertTrue(all('/accessD.html' in v[0] for v in c.calls));self.assertFalse(r['live_pre_race_capability_verified']);self.assertFalse(r['predictions_run']);self.assertFalse(r['existing_MASTER_changed'])
 def test_http200_parameter_error_kept(self):
  b='<title>パラメータエラー JRA</title>'.encode('cp932');c=FakeClient(self.s,self.p/'raw',bodies=[b]);r=probe(c,2026,self.p/'out');self.assertEqual(r['status'],'CAPTURE_ERROR');self.assertEqual(gzip.decompress((self.p/'out/000_card_page.bin.gz').read_bytes()),b)
 def test_empty_is_not_live_pass(self):
  c=FakeClient(self.s,self.p/'raw',bodies=[b'<title>No meetings</title>']);r=probe(c,2026,self.p/'out');self.assertEqual(r['status'],'NO_RACE_CARD_CAPTURED');self.assertEqual(r['race_card_candidates'],0)
 def test_source_limit_bounds_requests(self):
  c=FakeClient(self.s,self.p/'raw',bodies=[ENTRY]);r=probe(c,2026,self.p/'out',limit=1);self.assertEqual(len(c.calls),1);self.assertEqual(r['remaining_links'],1)
 def test_network_failure_summary_written(self):
  c=FakeClient(self.s,self.p/'raw',bodies=[RuntimeError('timeout')]);r=probe(c,2026,self.p/'out');self.assertEqual(r['status'],'CAPTURE_ERROR');self.assertTrue((self.p/'out/SUMMARY.json').exists())
 def test_cli_preserves_existing_MASTER(self):
  self.s.c.commit();before=hashlib.sha256((self.p/'MASTER.sqlite3').read_bytes()).hexdigest()
  with patch('jra_master.cli.Client',side_effect=lambda store,raw,*args:FakeClient(store,raw,bodies=[ENTRY,MENU,CARD])),patch('jra_master.cli.pedigree.collect') as pedigree:
   status=main(['--mode','cardprobe','--year','2026','--db',str(self.p/'MASTER.sqlite3'),'--with-pedigree','--output',str(self.p/'delivery')])
  self.assertEqual(status,0);pedigree.assert_not_called();self.assertEqual(before,hashlib.sha256((self.p/'MASTER.sqlite3').read_bytes()).hexdigest())
if __name__=='__main__':unittest.main()
