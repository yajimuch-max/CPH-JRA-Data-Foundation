# JRA原本MASTER 全部まとめて差分更新 v0.3.0

## まず最初の１回（GitHubで２ファイルを上書き）

1. 既存のmaster/stateと今の２ファイルは念のためバックアップ。
2. ZIP内の `jra_original_master_engine.zip` をリポジトリ直下に同名で上書き。
3. ZIP内の `.github/workflows/jra_original_master.yml` を同じパスに上書きしてCommit。
4. 以前のstate、原本ZIP、過去のActions履歴は消さない。

## 毎週これだけ（１回）

GitHub → Actions → **JRA 原本MASTER・全部まとめて差分更新** → **Run workflow**

- `year` = `2026`（更新する年に変更）
- `mode` = `update`（既定）
- `with_pedigree` = ON（既定）
- `with_track` = ON（既定）
- `refresh` = OFF（既定）
- `start_date` / `end_date` / `months` = 普通は空欄。対象期間を絞りたい場合のみ日付を指定
- `resume_run_id` / `base_release_tag` / `base_asset_name` = 正常にstateを復元できている場合は空欄
- その他の項目も通常は変更不要

出力Artifacts：
- `jra-original-master-2026`：納品用。中の `2026_JRA公式データ_原本MASTER.zip` が最新原本。
- `jra-original-state-2026`：再開用。次回自動復元される。念のため自分でも保存。
- `jra-track-audit-2026`：馬場データの取得／PDF解析／未取得開催日を監査。

### 何をするか

`update` １回で順に実行：
1. JRAレース・結果・単勝オッズなどの差分取得
2. JRA血統４項目（取得済みの馬は原則スキップ）
3. JRA公式の過去開催PDFから馬場データを取得・追加
4. 既存masterを維持して再出力。公式訂正は履歴を保持。

PDFはmaster ZIPに入れません。古い成功済みPDFは原則再取得せず、競馬場ごとの直近２開催PDFだけ再確認します。`refresh` ON のときは全件を再確認するため時間がかかります。

### 特に注意

- **公式の過去開催PDFは、原則開催終了後の翌木曜日に更新されます。** 開催直後の `update` では馬場の最新値がまだPDFにない場合があります。次回実行で追加を試みます。
- 過去PDFから得られる数値は、当日9:30ちょうどに観測した証拠ではありません。測定時刻と公表時刻は区別し、実公表時刻は不明として保持。
- `馬場状態` は原本の公式結果の馬場状態であり、9:30の状態と混同しません。
- 2018年7月より前は公式含水率公表なし、2020年9月より前は公式クッション値公表なし。未公表値は作りません。
- `track_audit` に `PARTIAL` / `ERROR` があれば、馬場部分は完了扱いにしません。旧PDF形式はパーサーが解析できない場合があります。
- インターネット上の全JRA PDFを使ったGitHub Actions本番成功はまだ検証していません。125件のオフラインテストおよび2026年原本での模擬PDF追加・二重取り込み防止・ZIP出力を確認済み。
- Actionsのstateが期限切れで復元できないとき、**空の状態でupdateしないで**ください。保存済み最新masterをGitHub Releaseに置き、従来のbootstrap復元が必要です。
- 2010〜2017年は含水率・クッション値のJRA公式掲載範囲外です。過去年度を更新する場合、`with_track` OFFを推奨。
