from __future__ import annotations

import hashlib
import gzip
import sqlite3
import subprocess
import tempfile
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import unquote, urlparse

from . import FETCHER_VERSION


class FetchFailure(RuntimeError):
    pass


@dataclass(frozen=True)
class Snapshot:
    snapshot_id: int
    request_url: str
    final_url: str
    path: Path
    sha256: str
    byte_count: int
    http_status: int
    content_type: str | None
    content_encoding: str | None
    requested_at: str
    responded_at: str
    from_cache: bool


def read_snapshot_bytes(snapshot: Snapshot) -> bytes:
    stored = snapshot.path.read_bytes()
    return gzip.decompress(stored) if snapshot.path.suffix == ".gz" else stored


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="microseconds")


def cache_key(url: str) -> str:
    return hashlib.sha256(canonical_url(url).encode("utf-8")).hexdigest()


def request_cache_key(url: str, method: str, body: str | None) -> str:
    if method == "GET" and body is None:
        return cache_key(url)
    value = f"{method}\n{canonical_url(url)}\n{body or ''}".encode("utf-8")
    return hashlib.sha256(value).hexdigest()


def canonical_url(url: str) -> str:
    # JRA links may encode the slash inside CNAME as %2F; it is the same resource.
    return unquote(url)


def _official_url(url: str) -> bool:
    host = (urlparse(url).hostname or "").lower()
    return host == "jra.go.jp" or host == "www.jra.go.jp" or host.endswith(".jra.go.jp")


def cached_snapshot(conn: sqlite3.Connection, root: Path, url: str, method: str = "GET",
                    body: str | None = None) -> Snapshot | None:
    row = conn.execute("SELECT * FROM raw_snapshots WHERE cache_key=? ORDER BY snapshot_id DESC LIMIT 1",
                       (request_cache_key(url, method, body),)).fetchone()
    if row is None:
        return None
    path = root / row["relative_path"]
    if not path.is_file():
        raise FetchFailure("CACHE_METADATA_WITHOUT_FILE")
    stored = path.read_bytes()
    body = gzip.decompress(stored) if path.suffix == ".gz" else stored
    actual = hashlib.sha256(body).hexdigest()
    if actual != row["entity_sha256"] or len(body) != row["entity_bytes"]:
        raise FetchFailure("CACHE_INTEGRITY_MISMATCH")
    return Snapshot(row["snapshot_id"], row["request_url"], row["final_url"], path, actual, len(body),
                    row["http_status"], row["content_type"], row["content_encoding"],
                    row["requested_at"], row["responded_at"], True)


def fetch(conn: sqlite3.Connection, root: Path, url: str, source_role: str, cache_only: bool = False) -> Snapshot:
    return _fetch_request(conn, root, url, source_role, cache_only, "GET", None)


def fetch_post_form(conn: sqlite3.Connection, root: Path, url: str, source_role: str,
                    form_body: str, cache_only: bool = False) -> Snapshot:
    return _fetch_request(conn, root, url, source_role, cache_only, "POST", form_body)


def _fetch_request(conn: sqlite3.Connection, root: Path, url: str, source_role: str,
                   cache_only: bool, method: str, request_body: str | None) -> Snapshot:
    if not _official_url(url):
        raise FetchFailure("NON_JRA_OFFICIAL_URL")
    url = canonical_url(url)
    cached = cached_snapshot(conn, root, url, method, request_body)
    if cached is not None:
        return cached
    if cache_only:
        raise FetchFailure("CACHE_MISS")
    requested_at = utc_now()
    with tempfile.TemporaryDirectory(prefix="cph_jra_fetch_") as tmp:
        body_path = Path(tmp) / "body.bin"
        header_path = Path(tmp) / "headers.txt"
        command = [
            "/usr/bin/curl", "--compressed", "--location", "--silent", "--show-error",
            "--max-time", "45", "--retry", "1", "--retry-delay", "1",
            "--retry-max-time", "95", "--user-agent", "CPH-JRA-Data-Foundation/0.1",
            "--dump-header", str(header_path), "--output", str(body_path),
            "--write-out", "%{http_code}\n%{url_effective}\n%{content_type}\n", url,
        ]
        if method == "POST":
            command[-1:-1] = ["--request", "POST", "--data-raw", request_body or ""]
        result = subprocess.run(command, capture_output=True, text=True, check=False)
        responded_at = utc_now()
        if result.returncode != 0:
            raise FetchFailure(f"CURL_FAILURE:{result.returncode}:{result.stderr.strip()}")
        lines = result.stdout.splitlines()
        if len(lines) < 2:
            raise FetchFailure("CURL_METADATA_MISSING")
        status = int(lines[0])
        final_url = lines[1]
        content_type = lines[2] if len(lines) > 2 and lines[2] else None
        if status != 200:
            raise FetchFailure(f"HTTP_STATUS_{status}")
        if not _official_url(final_url):
            raise FetchFailure("REDIRECTED_OUTSIDE_JRA")
        body = body_path.read_bytes()
        if not body:
            raise FetchFailure("EMPTY_ENTITY")
        sha = hashlib.sha256(body).hexdigest()
        headers = header_path.read_text(encoding="latin-1", errors="replace")
        encoding = None
        for line in headers.splitlines():
            if line.lower().startswith("content-encoding:"):
                encoding = line.split(":", 1)[1].strip()
        stored = gzip.compress(body, compresslevel=9, mtime=0)
        storage_sha = hashlib.sha256(stored).hexdigest()
        req_key = request_cache_key(url, method, request_body)
        rel = Path("raw") / source_role.lower() / f"{req_key}_{sha}.bin.gz"
        destination = root / rel
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(stored)
    conn.execute(
        "INSERT INTO raw_snapshots(request_url,final_url,requested_at,responded_at,http_status,content_type,content_encoding,entity_bytes,entity_sha256,storage_encoding,stored_bytes,storage_sha256,relative_path,fetcher_version,source_role,cache_key,request_method,request_body,request_body_sha256) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (url, final_url, requested_at, responded_at, status, content_type, encoding, len(body), sha,
         "gzip", len(stored), storage_sha, rel.as_posix(), FETCHER_VERSION, source_role, req_key,
         method, request_body, hashlib.sha256((request_body or "").encode("utf-8")).hexdigest() if request_body is not None else None),
    )
    snapshot_id = int(conn.execute("SELECT last_insert_rowid()").fetchone()[0])
    conn.commit()
    return Snapshot(snapshot_id, url, final_url, destination, sha, len(body), status, content_type,
                    encoding, requested_at, responded_at, False)


def fetch_many(conn: sqlite3.Connection, root: Path, items: list[tuple[str, str]],
               cache_only: bool = False, workers: int = 4) -> dict[str, Snapshot]:
    """Bounded parallel fetch using isolated SQLite connections per worker."""
    workers = max(1, min(int(workers), 4))
    db_path = conn.execute("PRAGMA database_list").fetchone()[2]

    def one(url: str, role: str) -> tuple[str, Snapshot]:
        worker_conn = sqlite3.connect(db_path, timeout=60)
        worker_conn.row_factory = sqlite3.Row
        worker_conn.execute("PRAGMA foreign_keys=ON")
        worker_conn.execute("PRAGMA busy_timeout=60000")
        try:
            return url, fetch(worker_conn, root, url, role, cache_only)
        finally:
            worker_conn.close()

    output: dict[str, Snapshot] = {}
    with ThreadPoolExecutor(max_workers=workers, thread_name_prefix="jra-fetch") as pool:
        futures = [pool.submit(one, url, role) for url, role in items]
        for future in as_completed(futures):
            url, snapshot = future.result()
            output[url] = snapshot
    return output
