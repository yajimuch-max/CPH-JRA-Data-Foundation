from __future__ import annotations

import html
import re
from pathlib import Path
from urllib.parse import urljoin

from bs4 import BeautifulSoup

from .model import ParsedRace, RaceEntry, RaceResult, ScheduleRace


class ParseFailure(RuntimeError):
    pass


TRACK_CODE = {
    "01": "札幌", "02": "函館", "03": "福島", "04": "新潟", "05": "東京",
    "06": "中山", "07": "中京", "08": "京都", "09": "阪神", "10": "小倉",
}


def decode_jra(body: bytes) -> str:
    for encoding in ("cp932", "shift_jis", "utf-8"):
        try:
            return body.decode(encoding)
        except UnicodeDecodeError:
            pass
    raise ParseFailure("CHARSET_DECODE_FAILURE")


def compact_text(node) -> str:
    return re.sub(r"\s+", " ", node.get_text(" ", strip=True)).strip()


def parse_schedule(body: bytes, expected_date: str) -> list[ScheduleRace]:
    text = decode_jra(body)
    soup = BeautifulSoup(text, "lxml")
    jp_date = f"{int(expected_date[:4])}年{int(expected_date[5:7])}月{int(expected_date[8:10])}日"

    # Historical JRA calendar layouts can have an empty
    # page <h1>.  The exact expected date must still be present in the official
    # document; only the DOM location of that date is allowed to differ.
    if jp_date not in compact_text(soup):
        raise ParseFailure("SCHEDULE_DATE_MISMATCH")

    races: list[ScheduleRace] = []

    # Modern layout.
    modern_tables = soup.select("table.basic")
    if modern_tables:
        for table in modern_tables:
            caption_main = table.select_one("caption .main")
            if caption_main is None:
                continue
            meeting = compact_text(caption_main)
            track_match = re.search(r"(札幌|函館|福島|新潟|東京|中山|中京|京都|阪神|小倉)", meeting)
            if not track_match:
                continue
            track = track_match.group(1)
            for tr in table.select("tbody tr"):
                no_cell = tr.select_one("th.num")
                name_cell = tr.select_one("td.name")
                time_cell = tr.select_one("td.time")
                dist_cell = tr.select_one("span.dist")
                type_cell = tr.select_one("span.type")
                if not all((no_cell, name_cell, time_cell, dist_cell, type_cell)):
                    continue
                no_match = re.search(r"\d+", compact_text(no_cell))
                if not no_match:
                    continue
                race_no = int(no_match.group())
                stakes = name_cell.select_one("p.stakes strong")
                race_class = name_cell.select_one("p.race_class")
                race_name = compact_text(stakes or race_class or name_cell)
                distance_m = int(re.sub(r"\D", "", compact_text(dist_cell)))
                type_text = compact_text(type_cell)
                surface = "障害" if "障害" in race_name or "障" in type_text else "ダート" if "ダ" in type_text else "芝" if "芝" in type_text else "不明"
                if surface == "不明":
                    raise ParseFailure(f"SCHEDULE_SURFACE_UNKNOWN:{track}:{race_no}")
                post = compact_text(time_cell)
                hm = re.search(r"(\d+)時(\d+)分", post)
                if not hm:
                    raise ParseFailure(f"SCHEDULE_POST_TIME_INVALID:{track}:{race_no}")
                races.append(ScheduleRace(
                    expected_date, track, meeting, race_no, race_name, surface,
                    distance_m, f"{int(hm.group(1)):02d}:{int(hm.group(2)):02d}",
                    surface != "障害",
                ))

    # Legacy layout used on JRA's 2019 racing-calendar pages before the layout
    # transition.  This is an explicit parser, not a permissive fallback.
    else:
        for detail in soup.select("table.race-detail"):
            meeting_table = detail.find_previous("table", class_="cal-racec")
            meeting_cell = meeting_table.select_one("td.cal-racec-cell") if meeting_table else None
            if meeting_cell is None:
                continue
            meeting = compact_text(meeting_cell)
            track_match = re.search(r"(札幌|函館|福島|新潟|東京|中山|中京|京都|阪神|小倉)", meeting)
            if not track_match:
                continue
            track = track_match.group(1)

            for tr in detail.select("tr"):
                no_cell = tr.find("th")
                name_cell = tr.select_one("td.race-namecond")
                time_cell = tr.select_one("td.race-time")
                if not all((no_cell, name_cell, time_cell)):
                    continue

                no_match = re.search(r"(\d+)\s*R", compact_text(no_cell), re.I)
                if not no_match:
                    continue
                race_no = int(no_match.group(1))

                parts = list(name_cell.stripped_strings)
                cell_text = " ".join(parts)
                strong = name_cell.find("strong")
                if strong is not None:
                    race_name = compact_text(strong)
                else:
                    # First textual line is the class/name in the legacy table.
                    race_name = parts[0] if parts else cell_text

                # In legacy calendars, the race name can contain text
                # such as "（ダービートライアル）".  Surface must therefore be
                # read ONLY from the condition token immediately following the
                # distance, never from arbitrary "(ダ..." text in the race name.
                condition_match = re.search(r"([0-9,]{3,5})\s*（\s*(芝|ダ)", cell_text)
                if condition_match:
                    distance_m = int(condition_match.group(1).replace(",", ""))
                    surface = "ダート" if condition_match.group(2) == "ダ" else "芝"
                elif "障害" in cell_text:
                    distance_only = re.search(r"([0-9,]{3,5})", cell_text)
                    if not distance_only:
                        raise ParseFailure(f"SCHEDULE_DISTANCE_UNKNOWN:{track}:{race_no}")
                    distance_m = int(distance_only.group(1).replace(",", ""))
                    surface = "障害"
                else:
                    raise ParseFailure(f"SCHEDULE_SURFACE_UNKNOWN:{track}:{race_no}")

                post = compact_text(time_cell)
                hm = re.search(r"(\d+)時(\d+)分", post)
                if not hm:
                    raise ParseFailure(f"SCHEDULE_POST_TIME_INVALID:{track}:{race_no}")

                races.append(ScheduleRace(
                    expected_date, track, meeting, race_no, race_name, surface,
                    distance_m, f"{int(hm.group(1)):02d}:{int(hm.group(2)):02d}",
                    surface != "障害",
                ))

    if not races:
        raise ParseFailure("SCHEDULE_EMPTY")
    keys = [r.race_key for r in races]
    if len(keys) != len(set(keys)):
        raise ParseFailure("SCHEDULE_DUPLICATE_RACE_KEY")
    return sorted(races, key=lambda r: (r.track, r.race_no))


RESULT_URL_RE = re.compile(r"(?:https?://(?:www\.)?jra\.go\.jp)?(/JRADB/accessS\.html\?CNAME=pw01sde10(?P<track>\d{2})(?P<year>\d{4})(?P<meeting>\d{2})(?P<day>\d{2})(?P<race>\d{2})(?P<date>\d{8})/(?P<token>[0-9A-F]{2}))", re.I)


def discover_result_urls(body: bytes, expected_date: str) -> dict[str, str]:
    text = html.unescape(decode_jra(body))
    ymd = expected_date.replace("-", "")
    found: dict[str, str] = {}
    for match in RESULT_URL_RE.finditer(text):
        if match.group("date") != ymd or match.group("year") != expected_date[:4]:
            continue
        track = TRACK_CODE.get(match.group("track"))
        if not track:
            continue
        race_no = int(match.group("race"))
        key = f"{expected_date}-{track}-{race_no:02d}"
        found[key] = urljoin("https://www.jra.go.jp", match.group(1))
    return found


def _id_from_href(href: str | None, marker: str) -> str | None:
    if not href:
        return None
    m = re.search(marker + r"[^0-9]*(\d{4,})", href)
    return m.group(1) if m else None


def _number(text: str) -> int | None:
    m = re.search(r"-?\d+", text)
    return int(m.group()) if m else None


def _float(text: str) -> float | None:
    m = re.search(r"\d+(?:\.\d+)?", text)
    return float(m.group()) if m else None


def parse_result(body: bytes, expected_date: str | None = None) -> ParsedRace:
    text = decode_jra(body)
    soup = BeautifulSoup(text, "lxml")
    title = soup.find("title")
    if title is None or "レース結果" not in compact_text(title):
        raise ParseFailure("NOT_A_RESULT_PAGE")
    date_cell = soup.select_one(".race_header .date, .race_header .cell.date")
    time_cell = soup.select_one(".race_header .time strong")
    race_img = soup.select_one(".race_number img[alt]")
    race_name_node = soup.select_one(".race_title .race_name")
    course_node = soup.select_one(".race_title .course")
    if not all((date_cell, time_cell, race_img, race_name_node, course_node)):
        raise ParseFailure("RACE_HEADER_INCOMPLETE")
    header = compact_text(date_cell)
    dm = re.search(r"(\d{4})年(\d+)月(\d+)日.*?(\d+回)?(札幌|函館|福島|新潟|東京|中山|中京|京都|阪神|小倉)(\d+日)", header)
    if not dm:
        raise ParseFailure("RACE_DATE_TRACK_PARSE_FAILURE")
    race_date = f"{int(dm.group(1)):04d}-{int(dm.group(2)):02d}-{int(dm.group(3)):02d}"
    if expected_date and race_date != expected_date:
        raise ParseFailure("RESULT_DATE_MISMATCH")
    track = dm.group(5)
    meeting_label = header.split("）")[-1].strip()
    race_no_match = re.search(r"(\d+)レース", race_img.get("alt", ""))
    if not race_no_match:
        raise ParseFailure("RACE_NUMBER_PARSE_FAILURE")
    race_no = int(race_no_match.group(1))
    race_name = compact_text(race_name_node)
    grade_img = race_name_node.select_one(".grade_icon img[alt]")
    grade = html.unescape(grade_img.get("alt")) if grade_img else None
    course_text = compact_text(course_node)
    distance_match = re.search(r"([\d,]+).*?メートル", course_text)
    if not distance_match:
        raise ParseFailure("RACE_DISTANCE_PARSE_FAILURE")
    distance_m = int(distance_match.group(1).replace(",", ""))
    surface = "ダート" if "ダート" in course_text else "芝" if "芝" in course_text else "障害" if "障" in course_text else "不明"
    if surface not in {"芝", "ダート"}:
        raise ParseFailure("NON_FLAT_OR_UNKNOWN_RESULT")
    tm = re.search(r"(\d+)時(\d+)分", compact_text(time_cell))
    if not tm:
        raise ParseFailure("RESULT_POST_TIME_INVALID")
    weather_node = soup.select_one(".race_header .weather .txt")
    condition_node = soup.select_one(".race_header .turf .txt, .race_header .dirt .txt")
    result_table = None
    for table in soup.find_all("table"):
        if table.select_one("thead th.place") and table.select_one("tbody td.horse"):
            result_table = table
            break
    if result_table is None:
        raise ParseFailure("RESULT_TABLE_NOT_FOUND")
    entries: list[RaceEntry] = []
    results: list[RaceResult] = []
    for tr in result_table.select("tbody tr"):
        horse_cell = tr.select_one("td.horse")
        num_cell = tr.select_one("td.num")
        place_cell = tr.select_one("td.place")
        if not horse_cell or not num_cell or not place_cell:
            continue
        horse_no = _number(compact_text(num_cell))
        horse_link = horse_cell.find("a", href=True)
        if horse_no is None or horse_link is None:
            continue
        horse_id = _id_from_href(horse_link.get("href"), "pw01dud10")
        if horse_id is None:
            raise ParseFailure(f"HORSE_ID_MISSING:{race_no}:{horse_no}")
        waku_img = tr.select_one("td.waku img[alt]")
        frame_no = _number(waku_img.get("alt", "")) if waku_img else None
        jockey_link = tr.select_one("td.jockey a")
        trainer_link = tr.select_one("td.trainer a")
        weight_cell = tr.select_one("td.weight")
        h_weight_cell = tr.select_one("td.h_weight")
        body_text = compact_text(h_weight_cell) if h_weight_cell else ""
        body_match = re.search(r"(\d+)(?:\s*\(([+-]?\d+)\))?", body_text)
        place_text = compact_text(place_cell)
        finish_position = int(place_text) if place_text.isdigit() else None
        status = "FINISHED" if finish_position is not None else (place_text or "UNKNOWN")
        corner_cell = tr.select_one("td.corner")
        corners = [int(x) for x in re.findall(r"\d+", compact_text(corner_cell))] if corner_cell else []
        entries.append(RaceEntry(
            horse_no, frame_no, horse_id, compact_text(horse_link),
            compact_text(tr.select_one("td.age")) if tr.select_one("td.age") else None,
            _float(compact_text(weight_cell)) if weight_cell else None,
            _id_from_href(jockey_link.get("onclick") if jockey_link else None, "pw04kmk00"),
            compact_text(jockey_link) if jockey_link else None,
            _id_from_href(trainer_link.get("onclick") if trainer_link else None, "pw05cmk00"),
            compact_text(trainer_link) if trainer_link else None,
            int(body_match.group(1)) if body_match else None,
            int(body_match.group(2)) if body_match and body_match.group(2) is not None else None,
        ))
        time_node = tr.select_one("td.time")
        margin_node = tr.select_one("td.margin")
        final_node = tr.select_one("td.f_time")
        results.append(RaceResult(
            horse_no, status, finish_position,
            compact_text(time_node) or None if time_node else None,
            compact_text(margin_node) or None if margin_node else None,
            corners, _float(compact_text(final_node)) if final_node else None,
        ))
    if not entries:
        raise ParseFailure("RESULT_RUNNERS_EMPTY")
    return ParsedRace(
        race_date, track, meeting_label, race_no, race_name, surface, distance_m, course_text,
        f"{int(tm.group(1)):02d}:{int(tm.group(2)):02d}",
        compact_text(weather_node) if weather_node else None,
        compact_text(condition_node) if condition_node else None,
        grade, entries, results,
    )
