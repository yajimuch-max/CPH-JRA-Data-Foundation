# JRA ORIGINAL MASTER v0.7.1.8 — 2025年馬場PDF形式切替の修正

## 2025年の不足原因

2025年のstateには3455レース・47884頭分の出走/単勝オッズ・公式HTML照合3455件が保存済みでした。
一方、JRA公式の含水率・クッション値PDF36本がすべて「PDF parser could not verify rows」でFAILEDとなり、
`official_track_daily` が0件、対象288開催単位が未収録でした。

原因：公式PDFの2025年分が「1行に日付・クッション値・含水率が横並び」の形式になっていたのに、
旧エンジンはその解析を2026年以降にしか有効化していませんでした。

## 修正内容

- `jra_master/track_enrichment.py`: 横並び表の解析対象を2025年以降に拡張。
- PDFの格子状テーブル抽出が失敗・部分欠落した場合、日付/曜日/時刻/5数値が完全な1行のみテキストから救済。
- 両手法が同じ日付に異なる数値を出したらエラー停止。日付や数値の補完・捏造なし。
- 2018〜2024年の従来グループ式PDF、2021年の限定特殊PDF処理、2024年の外国馬照合、state復元処理はそのまま維持。
- A/B/C/Dコースは既存方針どおりCERTIFIEDエクスポートの対象外。
- 原本内のエンジンバージョン表示を0.7.1.7に更新。

## GitHubへ置き換えるファイル

**`jra_original_master_engine.zip`**（バージョン番号なしの固定ファイル名）。
GitHub上の既存同名ファイルへ上書き。YMLは変更しない。

## GitHub Actions の入力

- `year`: `2025`
- `mode`: `update`
- `with_track`: `true`
- `with_official`: `true`
- `refresh`: `false`
- `reset_from_release`: `false`
- `resume_run_id`: 空欄

過去の `jra-original-state-2025.zip` から自動復元する。stateとReleaseを削除しないこと。

## 実行後に確認すること

1. `track_enrichment_audit.status == PASS`
2. `pdf_total == 36`, `pdf_errors == []`
3. `missing_race_track_days == 0`（対象288開催単位）
4. `official_track_pdf_receipts` が36本ともPASS
5. メイン原本が `CERTIFIED` になったこと
6. 取得済み3455レース・47884頭分の出走/単勝オッズ・血統を維持したこと

**オフライン検証の限界：** 公式PDFの全36本を実ファイルとしてローカル再解析はしていません。
掲載例から作成したテスト入力と、2025年の実stateをコピーした差分更新の模擬テストはPASS。
したがって現段階で2025年の原本は**未CERTIFIED**。GitHubの実通信後に改めて監査してください。

公式出典例：
- https://www.jra.go.jp/keiba/baba/archive/2025pdf/chukyo01.pdf
- https://www.jra.go.jp/keiba/baba/archive/2025pdf/nakayama01.pdf
- https://www.jra.go.jp/keiba/baba/archive/2025pdf/fukushima03.pdf
- https://www.jra.go.jp/keiba/baba/archive/2025pdf/chukyo05.pdf

## v0.7.1.8 自己検査の依存関係修正

- `tests/test_2025_modern_archive_v0717.py` のpytest専用テスト8件を標準ライブラリ `unittest` に完全移植（テスト対象ロジックと検査条件は変更なし）。
- `tests/test_runner_stdlib_v0718.py` で、テスト群に `pytest` の依存がないことを検査。
- GitHub Actionsの既存 `python -m unittest discover` で検査できるように変更。YML/requirements変更なし。
- v0.7.1.7 の2025年馬場PDF解析、2018〜2024年対応、state復元、取得/保存処理は一切変更なし。
- GitHubでの2025年公式PDF36本の実走行はまだ未確認。
