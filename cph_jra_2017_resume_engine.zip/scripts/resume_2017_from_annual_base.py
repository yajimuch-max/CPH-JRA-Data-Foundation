from __future__ import annotations
import argparse, json
from datetime import datetime, timezone
from pathlib import Path

from cph_jra_df.month_collection import MonthCollector
from cph_jra_df.pipeline import Pipeline

def now():
    return datetime.now(timezone.utc).isoformat(timespec="microseconds")

def main() -> int:
    p=argparse.ArgumentParser()
    p.add_argument("--data-root", required=True)
    p.add_argument("--year", type=int, default=2017)
    p.add_argument("--report", required=True)
    a=p.parse_args()

    root=Path(a.data_root).resolve()
    pipe=Pipeline(root, workers=4)
    try:
        # The previous run died on an uncaught NameError, leaving pipeline rows
        # in RUNNING state. Preserve them as historical failures rather than delete them.
        stamp=now()
        stale=pipe.conn.execute(
            "SELECT COUNT(*) FROM pipeline_runs "
            "WHERE status='RUNNING' AND substr(race_date,1,4)=?",
            (str(a.year),),
        ).fetchone()[0]
        pipe.conn.execute(
            "UPDATE pipeline_runs SET status='FAIL',completed_at=?,reason_codes_json=? "
            "WHERE status='RUNNING' AND substr(race_date,1,4)=?",
            (stamp, json.dumps(["INTERRUPTED_NAMEERROR_RECOVERED"]), str(a.year)),
        )
        pipe.conn.commit()

        day_count=pipe.conn.execute(
            "SELECT COUNT(*) FROM year_race_days WHERE substr(race_date,1,4)=?",
            (str(a.year),),
        ).fetchone()[0]
        seed_count=pipe.conn.execute(
            "SELECT COUNT(*) FROM result_seed_urls WHERE substr(race_date,1,4)=?",
            (str(a.year),),
        ).fetchone()[0]
        if day_count != 111 or seed_count != 111:
            raise SystemExit(f"ANNUAL_BASE_PREREQUISITE_MISMATCH:days={day_count}:seeds={seed_count}")

        collector=MonthCollector(pipe)
        month_reports=[]
        for month in range(1,13):
            result=collector.run(
                a.year, month, max_dates_this_run=31,
                cache_only=False, retry_failed=True,
            )
            month_reports.append(result)
            if result["pass_count"] != result["expected_dates"] or result["fail_count"] != 0:
                Path(a.report).write_text(json.dumps({
                    "status":"FAIL",
                    "stale_running_closed":stale,
                    "month_reports":month_reports,
                },ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
                return 1

        # Full-year no-network parser proof.
        reparse_pass=0
        reparse_failures=[]
        for row in pipe.conn.execute(
            "SELECT race_date FROM year_race_days "
            "WHERE substr(race_date,1,4)=? ORDER BY race_date",
            (str(a.year),),
        ).fetchall():
            try:
                r=pipe.reparse(row["race_date"])
                if r.get("status")=="PASS":
                    reparse_pass+=1
                else:
                    reparse_failures.append({"date":row["race_date"],"result":r})
            except Exception as exc:
                reparse_failures.append({"date":row["race_date"],"error":str(exc)})

        report={
            "status":"PASS" if reparse_pass==day_count and not reparse_failures else "FAIL",
            "year":a.year,
            "starting_point":"uploaded annual-base",
            "stale_running_closed":stale,
            "race_days":day_count,
            "seed_urls":seed_count,
            "month_reports":month_reports,
            "reparse_pass":reparse_pass,
            "reparse_failures":reparse_failures,
        }
        Path(a.report).write_text(
            json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8"
        )
        return 0 if report["status"]=="PASS" else 1
    finally:
        pipe.close()

if __name__=="__main__":
    raise SystemExit(main())
