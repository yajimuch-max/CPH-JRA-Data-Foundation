import unittest
from jra_master.racing import _official_odds_name_matches
from jra_master.track_enrichment import SPAN_RE,s,extract_legacy_text_fallback

class StubPage:
    def __init__(self,t):self.t=t
    def extract_text(self):return self.t

class RepairTests(unittest.TestCase):
    def test_verified_display_only(self):
        self.assertTrue(_official_odds_name_matches('2012190005','ウエスタンエクスプレス','ウエスタンエクスプ'))
        self.assertTrue(_official_odds_name_matches('2012190005','ウエスタンエクスプレス','ウエスタンエクスプレス'))
        self.assertFalse(_official_odds_name_matches('2012190006','ウエスタンエクスプレス','ウエスタンエクスプ'))
        self.assertFalse(_official_odds_name_matches('2012190005','ウエスタンエクスプレス','ウエスタン'))
    def test_jra_2018_sapporo_date_form(self):
        a=SPAN_RE.search(s('2018年7月27日（金）から29日（日）'))
        self.assertEqual((a['year'],a['m'],a['d'],a['d2']),('2018','7','27','29'))
    def test_jra_2018_sapporo_fallback(self):
        page=StubPage('2018年 第1回札幌競馬\u3000含水率\n第１日・第２日の含水率\n2018年7月27日（金）から29日（日）\n場所 金曜日 土曜日 日曜日\n芝コース含水率 ゴール前 11.7 12.6 12.4\n（パーセント） ４コーナー 10.8 13.4 11.9\nダートコース含水率 ゴール前 2.8 2.8 2.3\n（パーセント） ４コーナー 2.3 2.6 2.8\n第３日・第４日の含水率\n2018年8月3日（金）から5日（日）\n場所 金曜日 土曜日 日曜日\n芝コース含水率 ゴール前 13.2 13.7 12.6\n（パーセント） ４コーナー 13.6 14.2 12.7\nダートコース含水率 ゴール前 2.1 3.1 2.5\n（パーセント） ４コーナー 1.9 3.0 2.3\n第５日・第６日の含水率\n2018年8月10日（金）から12日（日）\n場所 金曜日 土曜日 日曜日\n芝コース含水率 ゴール前 14.5 16.5 14.0\n（パーセント） ４コーナー 13.8 15.8 13.0\nダートコース含水率 ゴール前 8.2 17.7 13.6\n（パーセント） ４コーナー 7.8 17.8 14.4')
        rows=extract_legacy_text_fallback(page,2018,'札幌','https://www.jra.go.jp/keiba/baba/archive/2018pdf/sapporo01.pdf','hash',1)
        self.assertEqual(len(rows),9)
        self.assertEqual(next(x for x in rows if x['date']=='2018-07-28')['turf_goal'],12.6)
        self.assertEqual(next(x for x in rows if x['date']=='2018-08-12')['dirt_fourth'],14.4)
    def test_incomplete_group_rejected(self):
        rows=extract_legacy_text_fallback(StubPage('2018年7月27日（金）から29日（日）\n場所 金曜日 土曜日 日曜日\n芝コース含水率 ゴール前 11.7 12.6 12.4'),2018,'札幌','url','h',1)
        self.assertEqual(rows,[])

if __name__=='__main__': unittest.main()
