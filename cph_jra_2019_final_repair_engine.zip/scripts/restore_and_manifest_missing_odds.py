from __future__ import annotations
import argparse, csv, sqlite3
from pathlib import Path

WIN_ODDS_SCHEMA = """
CREATE TABLE IF NOT EXISTS win_odds (
  race_key TEXT NOT NULL,
  horse_no INTEGER NOT NULL,
  final_win_odds REAL,
  status TEXT NOT NULL,
  result_url TEXT NOT NULL,
  odds_cname TEXT NOT NULL,
  raw_sha256 TEXT NOT NULL,
  fetched_at_utc TEXT NOT NULL,
  PRIMARY KEY (race_key, horse_no),
  FOREIGN KEY (race_key, horse_no)
    REFERENCES race_entries_pre_race(race_key, horse_no)
);
CREATE INDEX IF NOT EXISTS idx_win_odds_value ON win_odds(final_win_odds);
"""

def main() -> int:
    p=argparse.ArgumentParser()
    p.add_argument("--db", required=True)
    p.add_argument("--output", required=True)
    a=p.parse_args()
    con=sqlite3.connect(a.db)
    con.execute("PRAGMA foreign_keys=ON")
    con.executescript(WIN_ODDS_SCHEMA)

    # Restore all rows from the previously completed 12-month odds collection.
    con.execute("""
      INSERT INTO win_odds
      SELECT b.* FROM repair_win_odds_backup b
      JOIN race_entries_pre_race e
        ON e.race_key=b.race_key AND e.horse_no=b.horse_no
    """)
    con.commit()

    rows=con.execute("""
      SELECT
        CAST(substr(r.race_date,1,4) AS INTEGER),
        CAST(substr(r.race_date,6,2) AS INTEGER),
        r.race_key,r.race_date,r.track,r.race_no,s.final_url,COUNT(e.horse_no)
      FROM races_pre_race r
      JOIN race_entries_pre_race e ON e.race_key=r.race_key
      JOIN raw_snapshots s ON s.snapshot_id=r.source_snapshot_id
      LEFT JOIN win_odds o ON o.race_key=r.race_key AND o.horse_no=e.horse_no
      WHERE substr(r.race_date,1,4)='2019' AND o.race_key IS NULL
      GROUP BY r.race_key
      ORDER BY r.race_date,r.track,r.race_no
    """).fetchall()

    out=Path(a.output)
    with out.open("w",encoding="utf-8",newline="") as fh:
        w=csv.writer(fh)
        w.writerow(["year","month","race_key","race_date","track","race_no","result_url","expected_horses"])
        w.writerows(rows)

    print(f"restored_rows={con.execute('SELECT COUNT(*) FROM win_odds').fetchone()[0]}")
    print(f"missing_races={len(rows)}")
    con.close()
    return 0

if __name__=="__main__":
    raise SystemExit(main())
