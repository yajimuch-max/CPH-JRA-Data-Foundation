JRA ORIGINAL MASTER HTML UNIFIED v0.7.0

See README_JA.md in the distribution bundle. This version provides a strict, cleaned, single annual MASTER export.
