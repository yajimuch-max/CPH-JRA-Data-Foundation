"""Capture only official search/index pages; never integrate races or fetch pedigree."""
from pathlib import Path
import gzip,json,re
from .racing import links,form
from .jra_parser import decode_jra
from .store import sha,now

def diagnose(client,year,months,start,end,output):
 out=Path(output);out.mkdir(parents=True,exist_ok=True)
 report={'diagnostic_only':True,'year':year,'start':start,'end':end,'started_at':now(),'completed_race_rows_changed':False,'pedigree_fetched':False,'months':[],'pages':[],'errors':[]}
 def capture(label,url,role,cname):
  body,sid,path=client.request(url,role,form(cname))
  name=label+'.bin.gz';(out/name).write_bytes(gzip.compress(body,mtime=0))
  record=client.s.c.execute('select * from source_records where source_id=?',(sid,)).fetchone()
  report['pages'].append({'file':name,'source_id':sid,'url':url,'request_cname':cname,'entity_bytes':len(body),'entity_sha256':sha(body),'requested_at':record['requested_at'] if record else None,'responded_at':record['responded_at'] if record else None,'http_status':record['http_status'] if record else None})
  client.valid(sid,path)
  return body
 try:
  for month in months:
   item={'month':month,'meeting_links':[],'selected_meetings':[],'result_links':[],'unparsed_meetings':[]};report['months'].append(item)
   entry=capture(f'{month:02d}_search_entry','https://www.jra.go.jp/JRADB/accessS.html','DIAGNOSTIC_SEARCH_ENTRY','pw01skl00999999/B3')
   match=re.search(r'objParam\["'+f'{year%100:02d}{month:02d}'+r'"\]="([0-9A-F]{2})"',decode_jra(entry))
   if not match:raise ValueError('OFFICIAL_MONTH_TOKEN_NOT_FOUND')
   index=capture(f'{month:02d}_month_index','https://www.jra.go.jp/JRADB/accessS.html','DIAGNOSTIC_MONTH_INDEX',f'pw01skl10{year:04d}{month:02d}/'+match[1])
   meetings=links(index,'srl');item['meeting_links']=meetings
   for number,cname in enumerate(meetings):
    date=re.search(r'('+str(year)+r'\d{4})/',cname)
    if not date:item['unparsed_meetings'].append(cname);continue
    value=date[1];d=value[:4]+'-'+value[4:6]+'-'+value[6:]
    if not start<=d<=end:continue
    item['selected_meetings'].append({'cname':cname,'date':d})
    body=capture(f'{month:02d}_selection_{number:03d}','https://www.jra.go.jp/JRADB/accessS.html','DIAGNOSTIC_RACE_SELECTION',cname)
    item['result_links'].extend(links(body,'sde'))
   item['result_links']=sorted(set(item['result_links']))
   item['reason']=('NO_MEETING_LINKS' if not meetings else 'MEETING_DATE_PARSE_INCOMPLETE' if item['unparsed_meetings'] else 'NO_MEETINGS_IN_RANGE' if not item['selected_meetings'] else 'NO_RESULT_LINKS' if not item['result_links'] else 'RESULT_LINKS_FOUND')
 except Exception as exc:report['errors'].append(type(exc).__name__+': '+str(exc))
 finally:
  report['completed_at']=now()
  report['result_links_found']=sum(len(m['result_links']) for m in report['months'])
  report['coverage_verified']=False
  report['status']='DIAGNOSTIC_ERROR' if report['errors'] else 'DIAGNOSTIC_LINKS_FOUND' if report['result_links_found'] else 'DIAGNOSTIC_EMPTY'
  (out/'SUMMARY.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
 return report
