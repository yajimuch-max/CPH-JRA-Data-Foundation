"""Offline regression for 2010-2026 one-click update and audited export."""
import json
import os
import runpy
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from jra_master.full_update import run_full_update, final_export
from jra_master.store import Store


class UnifiedUpdateTests(unittest.TestCase):
    def create_state(self, path, year):
        path.parent.mkdir(parents=True,exist_ok=True)
        s=Store(path)
        s.meta('year',year)
        s.c.commit()
        s.c.close()

    def run_action(self, year, directory, overrides=None):
        env={'TARGET_YEAR':str(year),'MODE':'update','WITH_PEDIGREE':'true',
             'WITH_TRACK':'true','WITH_OFFICIAL':'true','BASE_RELEASE_TAG':'',
             'BASE_ASSET_NAME':'','REFRESH':'false','MAX_HORSES':'12000','MAX_SOURCES':'12000'}
        if overrides:env.update(overrides)
        script=Path(__file__).resolve().parents[1]/'scripts'/'action_run.py'
        prior=os.getcwd();os.chdir(directory)
        try:
            with patch.dict(os.environ,env):
                with self.assertRaises(SystemExit) as ctx:
                    runpy.run_path(str(script),run_name='__main__')
            return ctx.exception.code
        finally:os.chdir(prior)

    def test_no_state_without_release_fails_before_collect(self):
        import jra_master.cli
        with tempfile.TemporaryDirectory() as tmp, patch.object(jra_master.cli,'main') as core:
            ret=self.run_action(2023,tmp)
            self.assertIn('BASELINE_REQUIRED',str(ret))
            core.assert_not_called()

    def test_2010_update_calls_unified_for_legacy_year(self):
        from jra_master import full_update
        import jra_master.cli
        with tempfile.TemporaryDirectory() as tmp:
            self.create_state(Path(tmp)/'state/2010/MASTER.sqlite3',2010)
            calls=[]
            def unified(**kwargs):
                calls.append(kwargs)
                return 0
            with patch.object(jra_master.cli,'main',return_value=0),patch.object(full_update,'run_full_update',side_effect=unified):
                self.assertEqual(self.run_action(2010,tmp),0)
            self.assertTrue(calls[0]['with_track'])
            self.assertTrue(calls[0]['with_official'])
            self.assertIn('--with-pedigree',calls[0]['core_args'])

    def test_2023_update_calls_unified_with_all_stages(self):
        from jra_master import full_update
        import jra_master.cli
        with tempfile.TemporaryDirectory() as tmp:
            self.create_state(Path(tmp)/'state/2023/MASTER.sqlite3',2023)
            with patch.object(jra_master.cli,'main',return_value=0),patch.object(full_update,'run_full_update',return_value=0) as wrapped:
                self.assertEqual(self.run_action(2023,tmp),0)
            w=wrapped.call_args.kwargs
            self.assertEqual(w['year'],2023)
            self.assertTrue(w['with_track'])
            self.assertTrue(w['with_official'])
            self.assertIn('--with-pedigree',w['core_args'])

    def test_combined_stages_and_legacy_course(self):
        import jra_master.track_action
        import jra_master.html_first
        import jra_master.full_update as fu
        with tempfile.TemporaryDirectory() as tmp:
            db=Path(tmp)/'MASTER.sqlite3';self.create_state(db,2017)
            calls=[]
            def core(a):calls.append('core');return 0
            def official(*args,**kwargs):
                calls.append('html');return {'status':'PARTIAL','known_official_html_urls':10,'verified_html_races':5,'remaining':5,'failed_receipts':0,'failed_this_run':0}
            def finish(*args):calls.append('export');return {'status':'PARTIAL'}
            with patch.object(jra_master.track_action,'run_track') as track,\
                 patch.object(jra_master.html_first,'run',side_effect=official),\
                 patch.object(fu,'final_export',side_effect=finish):
                self.assertEqual(run_full_update(year=2017,db=db,output=tmp,core_args=[],core_main=core),0)
            self.assertEqual(calls,['core','html','export'])
            track.assert_not_called()

    def test_newer_year_runs_all_stages_and_never_hides_failure(self):
        import jra_master.track_action
        import jra_master.html_first
        import jra_master.full_update as fu
        with tempfile.TemporaryDirectory() as tmp:
            db=Path(tmp)/'MASTER.sqlite3';self.create_state(db,2023)
            calls=[]
            def core(a):calls.append('core');return 2
            def track(*a,**kw):calls.append('track');return 2
            def official(*a,**kw):
                calls.append('html');return {'status':'PARTIAL','known_official_html_urls':10,'verified_html_races':5,'remaining':5,'failed_receipts':0,'failed_this_run':0}
            def finish(*args):calls.append('export');return {'status':'PARTIAL'}
            with patch.object(jra_master.track_action,'run_track',side_effect=track),\
                 patch.object(jra_master.html_first,'run',side_effect=official),\
                 patch.object(fu,'final_export',side_effect=finish):
                self.assertEqual(run_full_update(year=2023,db=db,output=tmp,core_args=[],core_main=core),0)
            self.assertEqual(calls,['core','track','html','export'])

    def test_empty_state_is_never_mislabelled_certified(self):
        # A placeholder state must NOT produce a distributable final MASTER.
        with tempfile.TemporaryDirectory() as tmp:
            db=Path(tmp)/'MASTER.sqlite3';self.create_state(db,2017)
            with self.assertRaisesRegex(ValueError,'NO_RACES'):
                final_export(2017,db,tmp,{'core':{'status':'PARTIAL'}})
            self.assertFalse((Path(tmp)/'2017_JRA_MASTER.zip').exists())


if __name__=='__main__':unittest.main()
