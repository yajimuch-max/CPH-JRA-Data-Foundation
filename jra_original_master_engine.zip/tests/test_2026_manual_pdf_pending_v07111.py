"""2026 manual update: PDF not yet published -> PENDING -> later import.
No live acquisition is attempted, and PASS PDFs are checkpointed.
"""
import json
import os
import runpy
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import requests
from jra_master.track_action import sync_year
from jra_master.track_enrichment import schema
from jra_master.full_update import run_full_update
from jra_master.store import Store

URL='https://www.jra.go.jp/keiba/baba/archive/2026pdf/tokyo04.pdf'

class Resp:
    def __init__(self, code=200,content=b'%PDF-1.4\nfake fixture'):
        self.status_code=code;self.content=content
    def raise_for_status(self):
        if self.status_code>=400:
            raise requests.HTTPError('404 not yet published',response=self)

class MockSession:
    def __init__(self,responses):self.headers={};self.responses=responses;self.calls=[]
    def get(self,url,timeout=50):
        self.calls.append(url)
        if isinstance(self.responses,Exception):raise self.responses
        return self.responses[url]

class ManualPdfTests(unittest.TestCase):
    def make_db(self,root):
        db=Path(root)/'state.sqlite3';c=sqlite3.connect(db)
        c.execute('CREATE TABLE races(race_id TEXT PRIMARY KEY,race_date TEXT,track TEXT,payload_json TEXT)')
        c.execute('CREATE TABLE runners(race_id TEXT)')
        c.execute('CREATE TABLE results(race_id TEXT)')
        c.execute('CREATE TABLE win_odds(race_id TEXT)')
        c.execute('CREATE TABLE pedigree(horse_id TEXT)')
        for day in ('03','04'):
            c.execute('INSERT INTO races VALUES (?,?,?,?)',('race'+day,'2026-10-'+day,'東京','{}'))
        schema(c);c.commit();c.close()
        return db
    def obs(self,day):
        return {'date':'2026-10-'+day,'track':'東京','source_url':URL,
            'source_sha256':'testhash','source_page':1,'raw_format':'MODERN_ROW',
            'used_course':'A','cushion_time':'07:00','cushion':9.6,
            'moisture_time':'05:00','turf_goal':12.3,'turf_fourth':13.1,
            'dirt_goal':5.5,'dirt_fourth':6.1}
    def test_missing_then_404_then_published_then_idempotent(self):
        with tempfile.TemporaryDirectory() as root:
            db=self.make_db(root);cache=Path(root)/'cache'
            with patch('jra_master.track_enrichment.get_archive_links',return_value=[]):
                empty=sync_year(2026,db,cache_root=cache,throttle=0)
            self.assertEqual(empty['status'],'PARTIAL')
            self.assertEqual(empty['missing_race_track_days'],2)
            self.assertEqual(empty['pdf_errors'],[])
            self.assertEqual(empty['pdf_pending_count'],0)
            session=MockSession({URL:Resp(404)})
            with patch('jra_master.track_enrichment.get_archive_links',return_value=[('東京',URL)]),\
                 patch('requests.Session',return_value=session):
                pending=sync_year(2026,db,cache_root=cache,throttle=0)
            self.assertEqual(pending['pdf_errors'],[])
            self.assertEqual(pending['pdf_pending_count'],1)
            self.assertEqual(pending['pdf_pending_downloads'][0]['reason'],'NOT_PUBLISHED')
            with sqlite3.connect(db) as c:
                self.assertEqual(c.execute('select parse_status from official_track_pdf_receipts').fetchone()[0],'PENDING')
                self.assertEqual(c.execute('select count(*) from official_track_daily').fetchone()[0],0)
            session=MockSession({URL:Resp(200)})
            with patch('jra_master.track_enrichment.get_archive_links',return_value=[('東京',URL)]),\
                 patch('jra_master.track_enrichment.extract_observations',return_value=[self.obs('03'),self.obs('04')]),\
                 patch('requests.Session',return_value=session):
                good=sync_year(2026,db,cache_root=cache,throttle=0)
            self.assertEqual(good['status'],'PASS')
            self.assertEqual(good['missing_race_track_days'],0)
            self.assertEqual(good['pdf_parsed'],1)
            with sqlite3.connect(db) as c:
                self.assertEqual(c.execute('select count(*) from official_track_daily').fetchone()[0],2)
                self.assertEqual(c.execute('select parse_status from official_track_pdf_receipts').fetchone()[0],'PASS')
            session=MockSession(AssertionError('PDF must not be fetched again'))
            with patch('jra_master.track_enrichment.get_archive_links',return_value=[('東京',URL)]),\
                 patch('requests.Session',return_value=session):
                again=sync_year(2026,db,cache_root=cache,throttle=0)
            self.assertEqual(again['status'],'PASS')
            self.assertEqual(again['pdf_checkpoint_skipped'],1)
            self.assertEqual(session.calls,[])
    def test_index_failure_deferred_not_certified(self):
        with tempfile.TemporaryDirectory() as root:
            db=self.make_db(root)
            with patch('jra_master.track_enrichment.get_archive_links',side_effect=requests.Timeout('index timeout')):
                x=sync_year(2026,db,cache_root=Path(root)/'cache',throttle=0)
            self.assertEqual(x['status'],'PARTIAL')
            self.assertIn('Timeout',x['archive_index_unavailable'])
            self.assertEqual(x['pdf_errors'],[])
    def test_update_never_calls_live_capture(self):
        import jra_master.track_action as ta
        import jra_master.html_first as html
        import jra_master.full_update as fu
        with tempfile.TemporaryDirectory() as root:
            db=Path(root)/'MASTER.sqlite3';Store(db).c.close()
            def fake_html(*a,**kw):
                return dict(status='PASS',verified_html_races=1,remaining=0,failed_receipts=0,
                            known_official_html_urls=1,stopped_for_safety=False,failed_this_run=0)
            with patch.object(ta,'run_track',return_value=0),\
                 patch.object(html,'run',side_effect=fake_html),\
                 patch.object(fu,'final_export',return_value={'status':'NOT_CERTIFIED'}),\
                 patch('jra_master.live_track.capture_live',side_effect=AssertionError('LIVE forbidden')):
                code=run_full_update(year=2026,db=db,output=root,
                         core_args=['--start','2026-01-01','--end','2026-10-04'],
                         core_main=lambda args:0)
            self.assertEqual(code,0)
    def test_missing_year_defaults_to_2026(self):
        from jra_master import full_update,cli
        with tempfile.TemporaryDirectory() as root:
            state=Path(root)/'state/2026/MASTER.sqlite3';state.parent.mkdir(parents=True)
            store=Store(state);store.meta('year',2026);store.c.close()
            cwd=os.getcwd();os.chdir(root)
            try:
                env=dict(TARGET_YEAR='',MODE='update',BASE_RELEASE_TAG='',BASE_ASSET_NAME='',
                         WITH_TRACK='true',WITH_OFFICIAL='true',REFRESH='false')
                with patch.dict(os.environ,env),patch.object(cli,'main',return_value=0),\
                     patch.object(full_update,'run_full_update',return_value=0) as runner:
                    with self.assertRaises(SystemExit) as x:
                        runpy.run_path(str(Path(__file__).resolve().parents[1]/'scripts/action_run.py'),run_name='__main__')
                self.assertEqual(x.exception.code,0)
                self.assertEqual(runner.call_args.kwargs['year'],2026)
            finally:os.chdir(cwd)

if __name__=='__main__':unittest.main()
