import unittest,tempfile
from jra_master.store import Store
from jra_master.profile_links import supplement,OBSERVED
class Links(unittest.TestCase):
 def test_missing_links_are_idempotent_no_pedigree_or_fake_times(self):
  with tempfile.TemporaryDirectory() as t:
   s=Store(t+'/db')
   for hid,name,url in OBSERVED:s.c.execute('INSERT INTO horses VALUES (?,?)',(hid,name))
   s.c.commit();self.assertEqual(supplement(s),len(OBSERVED));self.assertEqual(supplement(s),0)
   self.assertEqual(s.c.execute('SELECT count(*) FROM revisions').fetchone()[0],len(OBSERVED))
   self.assertEqual(s.c.execute('SELECT count(*) FROM pedigree').fetchone()[0],0)
   self.assertEqual(s.c.execute('SELECT count(*) FROM source_records WHERE requested_at IS NOT NULL OR entity_sha256 IS NOT NULL').fetchone()[0],0);s.c.close()
 def test_completed_and_name_mismatch_untouched(self):
  with tempfile.TemporaryDirectory() as t:
   s=Store(t+'/db');hid,name,url=OBSERVED[0]
   s.c.execute('INSERT INTO horses VALUES (?,?)',(hid,name));s.c.execute('INSERT INTO pedigree_receipts VALUES (?,?,?,?)',(hid,'existing',4,'PASS'))
   s.c.execute('INSERT INTO horses VALUES (?,?)',(OBSERVED[1][0],'別の馬'));s.c.commit()
   self.assertEqual(supplement(s),0);s.c.close()
