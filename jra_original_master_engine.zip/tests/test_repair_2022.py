import unittest,tempfile,json
from unittest.mock import patch
from jra_master.store import Store
from jra_master.repair_2022 import prepare,result_links
class RepairTests(unittest.TestCase):
 def setup_store(self,p):
  s=Store(p);s.meta('year',2022);s.meta('pending_official_reaudit',[])
  for date,numbers in [('2022-01-15',[4,5]),('2022-01-16',[4])]:
   for no in numbers:s.c.execute('insert into races values (?,?,?,?,?,?)',(f'{date}-小倉-{no:02d}',date,'小倉',no,'JUMP','{}'))
  s.c.commit();return s
 def test_exact_links_required_no_invented_checksum(self):
  self.assertEqual(result_links(b'pw01sde1010202201010420220115/AB', '20220115',[4]),{4:'pw01sde1010202201010420220115/AB'})
  with self.assertRaisesRegex(ValueError,'INCOMPLETE'):result_links(b'pw01sde1010202201010420220116/AB','20220115',[4])
 def test_queue_persisted_and_no_completed_refetch(self):
  with tempfile.TemporaryDirectory() as t:
   s=self.setup_store(t+'/db')
   class Client:
    calls=0
    def request(self,url,role,body):
     self.calls+=1
     date='20220115' if '20220115' in body else '20220116';nos=[4,5] if date=='20220115' else [4]
     return ' '.join(f'pw01sde101020220101{no:02d}{date}/AB' for no in nos).encode(),'source',None
    def valid(self,*a):pass
   client=Client();prepare(s,client);prepare(s,client)
   q=json.loads(s.c.execute("select value from metadata where key='pending_official_reaudit'").fetchone()[0]);self.assertEqual(len(q),3);self.assertEqual(client.calls,2)
   self.assertTrue(all(i['observed_from_source_id']=='source' for i in q));self.assertEqual(s.c.execute('select count(*) from pedigree').fetchone()[0],0);s.c.close()
 def test_failed_discovery_remains_incomplete(self):
  with tempfile.TemporaryDirectory() as t:
   s=self.setup_store(t+'/db')
   class Client:
    def request(self,*a):return b'wrong page','source',None
    def valid(self,*a):raise AssertionError('Invalid page must not be marked valid')
   prepare(s,Client());self.assertEqual(json.loads(s.c.execute("select value from metadata where key='pending_official_reaudit'").fetchone()[0]),[])
   self.assertEqual(s.c.execute("select count(*) from tasks where status='PENDING'").fetchone()[0],3);self.assertEqual(s.c.execute("select count(*) from issues where status='OPEN'").fetchone()[0],2);s.c.close()
