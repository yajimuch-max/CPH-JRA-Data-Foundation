"""Regression tests for 2012-2013 JRA PDFs with >1 race on a PDF page.
These are layout simulations, not a substitute for live JRA PDF acceptance tests.
"""
import unittest
from jra_master.official_expansion import extract_blocks
from jra_master import legacy_track

TRACK='東京'
URL='https://www.jra.go.jp/datafile/seiseki/report/2012/2012-5tokyo8.pdf'

def h(race, *, date=True):
    prefix='30091 11月25日 晴 良 ' if date else ''
    return f'{prefix}(24東京5)第8日 第{race}競走 サラブレッド系3歳以上'

def pdf_text(with_last=False):
    pages=[]
    # A second race header may be appended directly to a different text run;
    # never allow the first race's body to absorb the second race's conditions.
    for i in range(1,13,2):
        first=h(i)+'\n発走10時00分 (芝・左)\n未勝利;負担重量は馬齢重量\n本 賞 5000000円'
        if i==1:
            second=h(i+1)+'\n発走10時30分 (ダート・左)\n新馬;負担重量は馬齢重量\n本 賞 5000000円'
        else:
            second='注記など '+h(i+1,date=False)+'\n発走10時30分 (ダート・左)\n新馬;負担重量は馬齢重量\n本 賞 5000000円'
        pages.append((i//2+1,first+'\n'+second))
    if with_last:pages.append((7,'11月25日(日曜日) 晴 馬場 (芝Aコース) (ダート) 良'))
    return pages

class HeaderRecoveryTests(unittest.TestCase):
    def test_all_even_races_recovered_and_conditions_split(self):
        blocks=extract_blocks(pdf_text(),2012,TRACK,5,8)
        self.assertEqual([x['no'] for x in blocks],list(range(1,13)))
        self.assertTrue(all('新馬;' not in x['lines'][0] for x in blocks if x['no']%2))
    def test_meeting_day_or_track_mismatch_rejected(self):
        with self.assertRaisesRegex(ValueError,'MEETING_CONFLICT'):
            extract_blocks(pdf_text(),2012,TRACK,4,8)
        with self.assertRaisesRegex(ValueError,'DAY_CONFLICT'):
            extract_blocks(pdf_text(),2012,TRACK,5,6)
    def test_no_date_does_not_infer(self):
        pages=[(1,h(1,date=False)+'\n発走10時00分 (芝・左)')]
        self.assertEqual(extract_blocks(pages,2012,TRACK,5,8),[])
    def test_legacy_going_requires_header_value(self):
        day,rows,course=legacy_track.parse_report_pages(pdf_text(True),2012,TRACK,URL,'hash')
        self.assertEqual(day,'2012-11-25')
        self.assertEqual([r['race_number'] for r in rows],[1,2,3,5,7,9,11])
        self.assertEqual(course,'A')
    def test_2013_era_and_all_races(self):
        a=h(1).replace('11月25日','1月26日').replace('24東京5','25東京1').replace('第8日','第1日')
        b=h(2,date=False).replace('24東京5','25東京1').replace('第8日','第1日')
        blocks=extract_blocks([(1,a+'\n発走10時 (ダート・左)\n'+b+'\n発走10時30分 (芝・左)')],2013,'東京',1,1)
        self.assertEqual([(b['date'],b['no']) for b in blocks],[('2013-01-26',1),('2013-01-26',2)])

if __name__=='__main__':unittest.main()
