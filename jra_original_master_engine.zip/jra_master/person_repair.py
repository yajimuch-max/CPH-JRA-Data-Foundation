"""Resume-safe, person-only repair of a PRIVATE working MASTER.

This intentionally bypasses successful collection tasks. It never marks an
annual export complete, never overwrites nonmissing values, and never invents
an official person ID. The caller retains an unchanged source ZIP.
"""
import json,time,urllib.parse
from dataclasses import asdict
from pathlib import Path
from .jra_parser import parse_result
from .store import encode,now,sha
from .network import Deferred
from .person_audit import audit_people

PARSER_VERSION='PERSON_REPAIR_1.0.0'
FIELDS=('jockey_name','jockey_id','trainer_name','trainer_id')

def schema(c):
 c.execute('''CREATE TABLE IF NOT EXISTS person_repair_receipts(
 race_id TEXT PRIMARY KEY,parser_version TEXT,status TEXT,source_url TEXT,
 source_sha256 TEXT,checked_at TEXT,changed_fields INTEGER,reason TEXT)''')
 c.commit()

def plan(c,year):
 schema(c)
 # IDs can be absent on the official page. Check them once, then retain the
 # explicit unresolved status instead of looping over them indefinitely.
 return c.execute('''SELECT DISTINCT u.race_id FROM runners u
 LEFT JOIN person_repair_receipts p ON p.race_id=u.race_id
 WHERE substr(u.race_id,1,4)=?
 AND (p.race_id IS NULL OR p.parser_version<>? OR p.status='FAIL')
 AND (json_extract(u.payload_json,'$.jockey_name') IS NULL
 OR trim(json_extract(u.payload_json,'$.jockey_name'))=''
 OR json_extract(u.payload_json,'$.jockey_id') IS NULL
 OR json_extract(u.payload_json,'$.trainer_name') IS NULL
 OR trim(json_extract(u.payload_json,'$.trainer_name'))=''
 OR json_extract(u.payload_json,'$.trainer_id') IS NULL)
 ORDER BY u.race_id''',(str(year),PARSER_VERSION)).fetchall()

def validate_and_diff(c,rid,body):
 parsed=parse_result(body,rid[:10])
 if parsed.race_key!=rid:raise ValueError('RESULT_ID_MISMATCH')
 original={no:(hid,json.loads(raw)) for no,hid,raw in c.execute('SELECT horse_number,horse_id,payload_json FROM runners WHERE race_id=?',(rid,))}
 entries={e.horse_no:e for e in parsed.entries}
 if len(entries)!=len(parsed.entries) or set(original)!=set(entries):raise ValueError('RUNNER_SET_MISMATCH')
 updates=[];unresolved=0
 for no,e in entries.items():
  hid,old=original[no]
  if hid!=e.horse_id:raise ValueError('HORSE_ID_MISMATCH')
  values=asdict(e);new=old.copy();changed=[]
  for field in FIELDS:
   before=old.get(field);value=values[field]
   if before is not None and str(before).strip():
    if field.endswith('_id') and value and str(before)!=str(value):raise ValueError('EXISTING_PERSON_ID_CONFLICT')
    continue
   if value is not None and str(value).strip():new[field]=value;changed.append(field)
  unresolved+=sum(new.get(k) is None for k in ('jockey_id','trainer_id'))
  if changed:updates.append((no,hid,new,changed))
 return updates,unresolved

def apply(s,rid,body,sid,url):
 updates,unresolved=validate_and_diff(s.c,rid,body)
 fields=sum(len(x[3]) for x in updates)
 with s.c:
  for no,hid,payload,_ in updates:
   s.put('runners',['race_id','horse_number'],dict(race_id=rid,horse_number=no,horse_id=hid,payload_json=encode(payload)),sid,'OFFICIAL_PERSON_FIELDS_RECOVERED_'+PARSER_VERSION)
  s.c.execute('INSERT OR IGNORE INTO race_sources VALUES (?,?,?)',(rid,'PERSON_REPAIR_HTML',sid))
  s.c.execute("UPDATE source_records SET raw_state='RETAINED_PERSON_REPAIR_CACHE' WHERE source_id=?",(sid,))
  s.c.execute('INSERT OR REPLACE INTO person_repair_receipts VALUES(?,?,?,?,?,?,?,?)',(rid,PARSER_VERSION,'CHECKED_ID_UNAVAILABLE' if unresolved else 'PASS',url,sha(body),now(),fields,None))
 return fields

def result_url(c,rid):
 tables={r[0] for r in c.execute("select name from sqlite_master where type='table'")}
 if 'official_html_races' in tables:
  row=c.execute('select source_url from official_html_races where race_id=?',(rid,)).fetchone()
  if row and row[0]:return row[0]
 for url,meta in c.execute('select s.url,s.metadata_json from source_records s join race_sources r using(source_id) where r.race_id=?',(rid,)):
  if 'accessS.html?' in url and 'pw01sde' in url:return url
  body=json.loads(meta or '{}').get('request_body','')
  if 'pw01sde' in body:return 'https://www.jra.go.jp/JRADB/accessS.html?'+body
 raise ValueError('OFFICIAL_RESULT_URL_UNAVAILABLE')

def run(s,client,year,cache,max_pages=100,budget_seconds=600):
 if not 2010<=year<=2026:raise ValueError('unsupported repair year')
 yearmeta=s.c.execute("SELECT value FROM metadata WHERE key='year'").fetchone()
 if not yearmeta or json.loads(yearmeta[0])!=year:raise ValueError('WRONG_YEAR_MASTER')
 if s.c.execute('SELECT 1 FROM races WHERE race_date NOT LIKE ? LIMIT 1',(str(year)+'-%',)).fetchone():raise ValueError('CROSS_YEAR_RACE_IN_MASTER')
 start=time.monotonic();queue=plan(s.c,year);cache=Path(cache);cache.mkdir(parents=True,exist_ok=True)
 queue.sort(key=lambda row:(not (cache/(row[0]+'.html')).exists(),row[0]))
 changed=checked=0;errors=[]
 for row in queue[:max_pages]:
  if time.monotonic()-start>budget_seconds-40:break
  rid=row[0];url=None
  try:
   url=result_url(s.c,rid)
   u=urllib.parse.urlsplit(url)
   if u.scheme!='https' or u.hostname!='www.jra.go.jp' or u.path!='/JRADB/accessS.html':raise ValueError('UNEXPECTED_SOURCE')
   p=cache/(rid+'.html')
   if p.exists():
    body=p.read_bytes();validate_and_diff(s.c,rid,body)
    sid=s.source(dict(service='JRA',role='PERSON_REPAIR_CACHED_HTML',url=url,entity_sha256=sha(body),integrated_at=now(),raw_state='RETAINED_PERSON_REPAIR_CACHE',parser_version=PARSER_VERSION));s.c.commit()
   else:
    body,sid,_=client.request(url,'PERSON_REPAIR_HTML')
    validate_and_diff(s.c,rid,body)
    tmp=p.with_suffix('.tmp');tmp.write_bytes(body);tmp.replace(p)
   changed+=apply(s,rid,body,sid,url);checked+=1
   print('PERSON_REPAIR_CHECKED',rid,'fields',changed,flush=True)
  except Deferred:break
  except Exception as e:
   reason=str(e);errors.append(dict(race_id=rid,reason=reason))
   s.c.execute('INSERT OR REPLACE INTO person_repair_receipts VALUES(?,?,?,?,?,?,?,?)',(rid,PARSER_VERSION,'FAIL',url,None,now(),0,reason));s.c.commit()
   if 'HTTP_403' in reason or 'HTTP_401' in reason or 'UNEXPECTED_SOURCE' in reason:break
 report=dict(status='WORKING_REPAIR_NOT_CERTIFIED',year=year,checked_this_run=checked,changed_fields_this_run=changed,pending_races=len(plan(s.c,year)),errors=errors,person_fields=audit_people(s.c),parser_version=PARSER_VERSION,checked_at=now())
 s.meta('person_repair_latest',report)
 return report
