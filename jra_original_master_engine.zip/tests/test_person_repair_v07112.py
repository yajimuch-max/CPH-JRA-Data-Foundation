import unittest,tempfile,json
from pathlib import Path
from unittest.mock import patch
from jra_master.store import Store,encode
from jra_master.model import ParsedRace,RaceEntry,RaceResult
from jra_master.person_repair import plan,apply,validate_and_diff,run

class PersonRepairTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.s=Store(Path(self.tmp.name)/'work.sqlite3');self.rid='2025-01-05-中山-01'
  self.old=dict(horse_no=1,horse_id='H',horse_name='馬A',jockey_id=None,jockey_name=None,trainer_id=None,trainer_name=None,body_weight_kg=480,body_weight_change_kg=0)
  self.s.c.execute('insert into races values(?,?,?,?,?,?)',(self.rid,'2025-01-05','中山',1,'FLAT','{}'))
  self.s.c.execute('insert into horses values(?,?)',('H','馬A'))
  self.s.c.execute('insert into runners values(?,?,?,?)',(self.rid,1,'H',encode(self.old)))
  self.s.c.execute('insert into results values(?,?,?)',(self.rid,1,encode(dict(finish_status='FINISHED',finish_position=1))))
  self.sid=self.s.source(dict(service='JRA',role='TEST',url='https://www.jra.go.jp/JRADB/accessS.html'));self.s.c.commit()
  self.parsed=ParsedRace('2025-01-05','中山','1回中山1日',1,'未勝利','芝',2000,'芝右','10:00','晴','良',None,[RaceEntry(1,1,'H','馬A','牡3',56,None,'R.ムーア',None,'A.オブライエン',500,20)],[RaceResult(1,'FINISHED',1,'2:00.0',None,[],34.0)])
 def tearDown(self):self.s.c.close();self.tmp.cleanup()
 def test_completed_collection_does_not_skip_repair(self):
  self.s.task('RACE_OLD','PASS');self.assertEqual([r[0] for r in plan(self.s.c,2025)],[self.rid])
 def test_person_only_correction_is_audited_and_idempotent(self):
  plan(self.s.c,2025)
  with patch('jra_master.person_repair.parse_result',return_value=self.parsed):
   self.assertEqual(apply(self.s,self.rid,b'official',self.sid,'https://www.jra.go.jp/JRADB/accessS.html'),2)
   self.assertEqual(apply(self.s,self.rid,b'official',self.sid,'https://www.jra.go.jp/JRADB/accessS.html'),0)
  row=json.loads(self.s.c.execute('select payload_json from runners').fetchone()[0])
  self.assertEqual(row,self.old|dict(jockey_name='R.ムーア',trainer_name='A.オブライエン'))
  self.assertEqual(self.s.c.execute('select count(*) from revisions').fetchone()[0],1)
  self.assertEqual(self.s.c.execute('select status from person_repair_receipts').fetchone()[0],'CHECKED_ID_UNAVAILABLE')
  self.assertEqual(plan(self.s.c,2025),[])
 def test_wrong_horse_rejected_before_any_mutation(self):
  self.parsed.entries[0]=RaceEntry(1,1,'OTHER','馬A','牡3',56,None,'R.ムーア',None,'A.オブライエン',480,0)
  with patch('jra_master.person_repair.parse_result',return_value=self.parsed):
   with self.assertRaisesRegex(ValueError,'HORSE_ID_MISMATCH'):validate_and_diff(self.s.c,self.rid,b'official')
  self.assertEqual(json.loads(self.s.c.execute('select payload_json from runners').fetchone()[0]),self.old)
 def test_wrong_year_stops_before_network(self):
  self.s.meta('year',2024)
  with self.assertRaisesRegex(ValueError,'WRONG_YEAR_MASTER'):run(self.s,None,2025,self.tmp.name)
 def test_cross_year_rows_stop_before_network(self):
  self.s.meta('year',2025);self.s.c.execute("update races set race_date='2024-01-05'");self.s.c.commit()
  with self.assertRaisesRegex(ValueError,'CROSS_YEAR_RACE_IN_MASTER'):run(self.s,None,2025,self.tmp.name)
