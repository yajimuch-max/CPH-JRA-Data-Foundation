#!/usr/bin/env python3
"""Extract JRA result-page market facts into annual and combined SQLite DBs."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import re
import shutil
import sqlite3
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

from lxml import html


BET_TYPES = {
    "単勝": "WIN",
    "複勝": "PLACE",
    "枠連": "BRACKET_QUINELLA",
    "馬連": "QUINELLA",
    "ワイド": "WIDE",
    "馬単": "EXACTA",
    "3連複": "TRIO",
    "3連単": "TRIFECTA",
}
EXTRACTOR_VERSION = "market-result-v1"


SCHEMA = """
CREATE TABLE IF NOT EXISTS race_market_popularity (
  race_key TEXT NOT NULL,
  horse_no INTEGER NOT NULL,
  win_popularity INTEGER,
  source_snapshot_id INTEGER NOT NULL,
  extractor_version TEXT NOT NULL,
  PRIMARY KEY (race_key, horse_no),
  FOREIGN KEY (race_key, horse_no)
    REFERENCES race_entries_pre_race(race_key, horse_no),
  FOREIGN KEY (source_snapshot_id) REFERENCES raw_snapshots(snapshot_id)
);
CREATE INDEX IF NOT EXISTS idx_market_popularity_rank
  ON race_market_popularity(race_key, win_popularity);

CREATE TABLE IF NOT EXISTS race_payouts (
  race_key TEXT NOT NULL,
  bet_type TEXT NOT NULL,
  line_no INTEGER NOT NULL,
  combination_text TEXT,
  combination_json TEXT,
  payout_yen INTEGER,
  payout_popularity INTEGER,
  special_status TEXT,
  source_snapshot_id INTEGER NOT NULL,
  extractor_version TEXT NOT NULL,
  PRIMARY KEY (race_key, bet_type, line_no),
  FOREIGN KEY (race_key) REFERENCES races_pre_race(race_key),
  FOREIGN KEY (source_snapshot_id) REFERENCES raw_snapshots(snapshot_id)
);
CREATE INDEX IF NOT EXISTS idx_race_payouts_lookup
  ON race_payouts(race_key, bet_type);
"""


COMBINED_SCHEMA = """
CREATE TABLE market_popularity (
  year INTEGER NOT NULL,
  race_key TEXT NOT NULL,
  race_date TEXT NOT NULL,
  track TEXT NOT NULL,
  race_no INTEGER NOT NULL,
  horse_no INTEGER NOT NULL,
  win_popularity INTEGER,
  source_entity_sha256 TEXT NOT NULL,
  PRIMARY KEY (year, race_key, horse_no)
);
CREATE TABLE payouts (
  year INTEGER NOT NULL,
  race_key TEXT NOT NULL,
  race_date TEXT NOT NULL,
  track TEXT NOT NULL,
  race_no INTEGER NOT NULL,
  bet_type TEXT NOT NULL,
  line_no INTEGER NOT NULL,
  combination_text TEXT,
  combination_json TEXT,
  payout_yen INTEGER,
  payout_popularity INTEGER,
  special_status TEXT,
  source_entity_sha256 TEXT NOT NULL,
  PRIMARY KEY (year, race_key, bet_type, line_no)
);
CREATE INDEX idx_combined_popularity ON market_popularity(year, race_key, win_popularity);
CREATE INDEX idx_combined_payouts ON payouts(year, race_key, bet_type);
CREATE TABLE metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL);
"""


def compact_text(node) -> str:
    return " ".join("".join(node.itertext()).split())


def digits(value: str) -> int | None:
    found = re.sub(r"\D", "", value or "")
    return int(found) if found else None


def combination(value: str) -> str | None:
    numbers = [int(x) for x in re.findall(r"\d+", value or "")]
    return json.dumps(numbers, ensure_ascii=False, separators=(",", ":")) if numbers else None


def extract_annual(root: Path, year: int) -> dict:
    db_path = root / "data" / "cph_jra_df.sqlite3"
    con = sqlite3.connect(db_path)
    con.execute("PRAGMA foreign_keys=ON")
    con.executescript(SCHEMA)
    con.execute("DELETE FROM race_market_popularity")
    con.execute("DELETE FROM race_payouts")
    races = con.execute(
        """SELECT r.race_key, r.source_snapshot_id, s.relative_path
             FROM races_pre_race r
             JOIN raw_snapshots s ON s.snapshot_id=r.source_snapshot_id
            ORDER BY r.race_key"""
    ).fetchall()
    type_counts: Counter[str] = Counter()
    null_popularity = 0
    for race_key, snapshot_id, relative_path in races:
        raw_path = root / "data" / relative_path
        payload = gzip.open(raw_path, "rb").read() if raw_path.suffix == ".gz" else raw_path.read_bytes()
        doc = html.fromstring(payload)
        popularity_rows = []
        for tr in doc.xpath('//tr[td[contains(concat(" ",normalize-space(@class)," ")," num ")] and td[contains(concat(" ",normalize-space(@class)," ")," pop ")]]'):
            num_nodes = tr.xpath('./td[contains(concat(" ",normalize-space(@class)," ")," num ")]')
            pop_nodes = tr.xpath('./td[contains(concat(" ",normalize-space(@class)," ")," pop ")]')
            horse_no = digits(compact_text(num_nodes[0])) if num_nodes else None
            if horse_no is None:
                continue
            popularity = digits(compact_text(pop_nodes[0])) if pop_nodes else None
            null_popularity += popularity is None
            popularity_rows.append((race_key, horse_no, popularity, snapshot_id, EXTRACTOR_VERSION))
        con.executemany("INSERT INTO race_market_popularity VALUES (?,?,?,?,?)", popularity_rows)

        for dl in doc.xpath("//dl"):
            dt = dl.xpath("./dt")
            if not dt:
                continue
            label = compact_text(dt[0])
            if label not in BET_TYPES:
                continue
            bet_type = BET_TYPES[label]
            lines = dl.xpath('./dd//*[contains(concat(" ",normalize-space(@class)," ")," line ")]')
            if not lines:
                lines = dl.xpath("./dd")
            for line_no, line in enumerate(lines, 1):
                values = {}
                for item in line.xpath("./*"):
                    for cls in (item.get("class") or "").split():
                        values.setdefault(cls, compact_text(item))
                combination_text = values.get("num") or None
                payout_yen = digits(values.get("yen", ""))
                payout_popularity = digits(values.get("pop", ""))
                special_status = None
                if not combination_text and payout_yen is None:
                    special_status = "NOT_OFFERED_OR_NO_PAYOUT"
                con.execute(
                    "INSERT INTO race_payouts VALUES (?,?,?,?,?,?,?,?,?,?)",
                    (race_key, bet_type, line_no, combination_text, combination(combination_text or ""),
                     payout_yen, payout_popularity, special_status, snapshot_id, EXTRACTOR_VERSION),
                )
                type_counts[bet_type] += 1
    con.commit()

    entry_count = con.execute("SELECT COUNT(*) FROM race_entries_pre_race").fetchone()[0]
    market_count = con.execute("SELECT COUNT(*) FROM race_market_popularity").fetchone()[0]
    payout_count = con.execute("SELECT COUNT(*) FROM race_payouts").fetchone()[0]
    race_payout_coverage = con.execute("SELECT COUNT(DISTINCT race_key) FROM race_payouts").fetchone()[0]
    fk_errors = con.execute("PRAGMA foreign_key_check").fetchall()
    integrity = con.execute("PRAGMA integrity_check").fetchone()[0]
    if market_count != entry_count or race_payout_coverage != len(races) or fk_errors or integrity != "ok":
        raise RuntimeError((year, market_count, entry_count, race_payout_coverage, len(races), fk_errors, integrity))
    report = {
        "year": year,
        "status": "PASS",
        "extractor_version": EXTRACTOR_VERSION,
        "race_count": len(races),
        "market_popularity_rows": market_count,
        "market_popularity_null_rows": null_popularity,
        "payout_rows": payout_count,
        "payout_race_coverage": race_payout_coverage,
        "payout_rows_by_bet_type": dict(sorted(type_counts.items())),
        "foreign_key_check": "PASS",
        "integrity_check": integrity,
    }
    con.close()
    (root / f"{year}_市場データ監査結果.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    return report


def build_combined(annual_roots: list[tuple[int, Path]], output: Path) -> dict:
    if output.exists():
        output.unlink()
    con = sqlite3.connect(output)
    con.executescript(COMBINED_SCHEMA)
    totals = {"market_popularity_rows": 0, "payout_rows": 0}
    for year, root in annual_roots:
        source = sqlite3.connect(root / "data" / "cph_jra_df.sqlite3")
        market = source.execute(
            """SELECT ?,m.race_key,r.race_date,r.track,r.race_no,m.horse_no,m.win_popularity,s.entity_sha256
                 FROM race_market_popularity m
                 JOIN races_pre_race r ON r.race_key=m.race_key
                 JOIN raw_snapshots s ON s.snapshot_id=m.source_snapshot_id""", (year,)
        ).fetchall()
        payouts = source.execute(
            """SELECT ?,p.race_key,r.race_date,r.track,r.race_no,p.bet_type,p.line_no,
                      p.combination_text,p.combination_json,p.payout_yen,p.payout_popularity,
                      p.special_status,s.entity_sha256
                 FROM race_payouts p
                 JOIN races_pre_race r ON r.race_key=p.race_key
                 JOIN raw_snapshots s ON s.snapshot_id=p.source_snapshot_id""", (year,)
        ).fetchall()
        con.executemany("INSERT INTO market_popularity VALUES (?,?,?,?,?,?,?,?)", market)
        con.executemany("INSERT INTO payouts VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)", payouts)
        totals["market_popularity_rows"] += len(market)
        totals["payout_rows"] += len(payouts)
        source.close()
    now = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
    metadata = {
        "scope": "JRA 2024-2025 result-page market facts",
        "extractor_version": EXTRACTOR_VERSION,
        "created_at_utc": now,
        "important_limitation": "Contains win popularity ranks and official winning-combination payouts; not complete final odds for every combination.",
    }
    con.executemany("INSERT INTO metadata VALUES (?,?)", metadata.items())
    con.commit()
    integrity = con.execute("PRAGMA integrity_check").fetchone()[0]
    con.close()
    return {"status": "PASS", "years": [y for y, _ in annual_roots], **totals, "integrity_check": integrity}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--y2024", type=Path, required=True)
    ap.add_argument("--y2025", type=Path, required=True)
    ap.add_argument("--combined", type=Path, required=True)
    args = ap.parse_args()
    reports = [extract_annual(args.y2024, 2024), extract_annual(args.y2025, 2025)]
    combined = build_combined([(2024, args.y2024), (2025, args.y2025)], args.combined)
    print(json.dumps({"annual": reports, "combined": combined}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
