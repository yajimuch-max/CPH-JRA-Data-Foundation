import unittest
from jra_master.legacy_odds_parser import parse_odds
class WinOnlyOdds(unittest.TestCase):
 def body(self,final=True,caption='単勝オッズ（馬番順）'):
  return (('<p>最終オッズ</p>' if final else '<p>途中オッズ</p>')+'<table class="tanpuku tan"><caption>'+caption+'</caption><tbody><tr><td class="num">1</td><td class="horse">Horse</td><td class="odds_tan">1.3</td></tr><tr><td class="num">2</td><td class="horse">Other</td><td class="odds_tan cancel">取消</td></tr></tbody></table>').encode('cp932')
 def test_win_only_final_and_cancellation(self):
  rows=parse_odds(self.body());self.assertEqual(rows[0]['final_win_odds'],1.3);self.assertIsNone(rows[1]['final_win_odds']);self.assertEqual(rows[1]['status'],'取消')
 def test_non_final_rejected(self):
  with self.assertRaisesRegex(RuntimeError,'NOT_FINAL_WIN_ODDS_PAGE'):parse_odds(self.body(False))
 def test_unrelated_caption_rejected(self):
  with self.assertRaisesRegex(RuntimeError,'NOT_FINAL_WIN_ODDS_PAGE'):parse_odds(self.body(caption='複勝オッズ'))
