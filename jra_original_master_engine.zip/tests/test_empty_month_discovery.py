import tempfile,unittest
from pathlib import Path
from unittest.mock import Mock,patch
from jra_master.racing import collect
from jra_master.store import Store

class EmptyMonthDiscoveryTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.s=Store(Path(self.temp.name)/'MASTER.sqlite3')
  self.mk='DISCOVER_2026_10_2026-09-27_2026-10-04';self.key='links_'+self.mk;self.cname='pw01sde1005202604021120261004/AA'
 def tearDown(self):
  self.s.c.close();self.temp.cleanup()
 def run_collect(self):return collect(self.s,Mock(),2026,[10],'2026-09-27','2026-10-04',False)
 def test_empty_result_fails_completion(self):
  with patch('jra_master.racing.discover',return_value=[]):result=self.run_collect()
  self.assertEqual(result['completed_races'],0);self.assertTrue(result['errors'])
  self.assertFalse(self.s.done(self.mk));self.assertEqual(self.s.audit()['status'],'PARTIAL')
  self.assertEqual(self.s.c.execute('select kind from issues where issue_key=?',(self.mk,)).fetchone()[0],'RESULT_DISCOVERY_INCOMPLETE')
 def test_cached_empty_pass_is_rediscovered(self):
  self.s.meta(self.key,[]);self.s.task(self.mk,'PASS');self.s.task('RACE_'+self.cname,'PASS')
  with patch('jra_master.racing.discover',return_value=[self.cname]) as discover:result=self.run_collect()
  discover.assert_called_once();self.assertEqual(result['errors'],[]);self.assertTrue(self.s.done(self.mk))
 def test_cached_nonempty_does_not_refetch_completed_races(self):
  self.s.meta(self.key,[self.cname]);self.s.task('RACE_'+self.cname,'PASS')
  with patch('jra_master.racing.discover') as discover,patch('jra_master.racing.integrate_result') as integrate:
   result=self.run_collect()
  discover.assert_not_called();integrate.assert_not_called();self.assertEqual(result['completed_races'],0)
 def test_failed_empty_can_recover_and_resolve_issue(self):
  with patch('jra_master.racing.discover',return_value=[]):self.run_collect()
  self.s.task('RACE_'+self.cname,'PASS')
  with patch('jra_master.racing.discover',return_value=[self.cname]):result=self.run_collect()
  self.assertEqual(result['errors'],[]);self.assertTrue(self.s.done(self.mk))
  self.assertEqual(self.s.c.execute('select status from issues where issue_key=?',(self.mk,)).fetchone()[0],'RESOLVED')
 def test_no_calendar_confirmation_does_not_assume_racing(self):
  # A range with no races can be legitimate; until verified it must be incomplete,
  # rather than inventing races or declaring successful coverage.
  with patch('jra_master.racing.discover',return_value=[]):result=self.run_collect()
  self.assertIn('EMPTY_UNVERIFIED',result['errors'][0]);self.assertEqual(result['completed_races'],0)

if __name__=='__main__':unittest.main()
