"""JRA's four profile fields only; no recursive ancestors or external service."""
import re,json,unicodedata
from urllib.parse import urlencode,urlparse,parse_qs
from bs4 import BeautifulSoup
from .jra_parser import decode_jra
from .store import encode,now
from .network import Deferred
FIELDS={'父':'S','母':'M','母の父':'MS','母の母':'MM'}
def norm(x):return re.sub(r'\s+','',unicodedata.normalize('NFKC',x))
def parse(body,horse_id,expected_name,observed_cname):
 soup=BeautifulSoup(decode_jra(body),'lxml');title=soup.find('title')
 if not title or '競走馬情報' not in title.get_text():raise ValueError('NOT_JRA_HORSE_PROFILE')
 # Verify target ID from the exact official link observed in a result page.
 match=re.search(r'pw01dud(?:00|10)(\d{10})',observed_cname or '')
 if not match or match[1]!=horse_id:raise ValueError('OBSERVED_PROFILE_LINK_ID_MISMATCH')
 heading=soup.select_one('h1 .txt')
 if heading is None:raise ValueError('HORSE_PROFILE_HEADING_MISSING')
 heading=BeautifulSoup(str(heading),'lxml')
 for node in heading.select('.opt,.name_en,.icon'):node.decompose()
 if norm(heading.get_text(' ',strip=True))!=norm(expected_name):raise ValueError('HORSE_PROFILE_NAME_MISMATCH')
 rows=[];birth=None;profile={}
 for dt in soup.find_all('dt'):
  label=dt.get_text(strip=True);dd=dt.find_next_sibling('dd')
  if dd is None:continue
  if label=='生年月日':birth=dd.get_text(' ',strip=True)
  if label not in FIELDS:continue
  path=FIELDS[label];a=dd.find('a');name=a.get_text(' ',strip=True) if a else dd.get_text(' ',strip=True);name=re.sub(r'\s*産駒\s*$','',name).strip();ancestor_id=None;href=None
  if a:
   href=a.get('href','')+a.get('onclick','');m=re.search(r'pw01dud(?:00|10)(\d{10})',href)
   if m:ancestor_id=m[1]
  if name in ['','－','-','不明','未登録']:name=None
  rows.append({'path':path,'generation':len(path),'ancestor_id':ancestor_id,'ancestor_name':name,'birth_year':None,'status':'KNOWN' if name else 'NOT_PROVIDED'})
  profile[path]={'field':label,'official_name':name,'observed_ancestor_link':href}
 if len(rows)!=4 or {r['path'] for r in rows}!=set(FIELDS.values()):raise ValueError('JRA_PROFILE_FOUR_FIELDS_INCOMPLETE')
 return rows,{'horse_id':horse_id,'horse_name':expected_name,'birth_date_raw':birth,'fields':profile}

def collect(s,client,limit=500):
 rows=s.c.execute('SELECT h.* FROM horses h LEFT JOIN pedigree_receipts p USING(horse_id) WHERE p.horse_id IS NULL ORDER BY h.horse_id LIMIT ?',(limit,)).fetchall();completed=0;missing_links=0
 for h in rows:
  hid=h['horse_id'];key='JRA_PEDIGREE_'+hid;link=s.c.execute('SELECT value FROM metadata WHERE key=?',('horse_profile_'+hid,)).fetchone()
  if not link:
   s.task(key,'PENDING','No observed JRA profile link; reaudit saved result RAW or update official results first.');missing_links+=1;continue
  url=json.loads(link[0]);cname=(parse_qs(urlparse(url).query).get('CNAME') or [None])[0]
  if not cname:s.task(key,'FAIL','OBSERVED_CNAME_MISSING');continue
  try:
   body,sid,p=client.request('https://www.jra.go.jp/JRADB/accessU.html','JRA_PEDIGREE_FOUR_FIELDS',urlencode({'cname':cname}))
   facts,identity=parse(body,hid,h['horse_name'],cname)
   with s.c:
    for r in facts:s.put('pedigree',['horse_id','path'],{'horse_id':hid,**r,'source_id':sid},sid,'JRA_FOUR_PROFILE_FIELDS_VERIFIED')
    s.c.execute('INSERT OR REPLACE INTO pedigree_receipts VALUES (?,?,?,?)',(hid,sid,4,'PASS' if all(r['status']=='KNOWN' for r in facts) else 'PASS_WITH_SOURCE_MISSING'))
    s.c.execute('INSERT OR REPLACE INTO metadata VALUES (?,?)',('horse_identity_'+hid,encode(identity)))
   client.valid(sid,p);s.task(key,'PASS');s.resolve(key);completed+=1
  except Deferred as e:s.task(key,'DEFERRED',str(e));break
  except Exception as e:s.task(key,'FAIL',str(e));s.issue(key,'JRA_PEDIGREE_FETCH_OR_VALIDATION',{'error':str(e),'observed_url':url})
 return {'completed':completed,'missing_observed_profile_links':missing_links,'pending_horses':s.c.execute('SELECT count(*) FROM horses h LEFT JOIN pedigree_receipts p USING(horse_id) WHERE p.horse_id IS NULL').fetchone()[0]}
