import unittest, sqlite3, json
from jra_master import legacy_track as m
from jra_master.track_enrichment import schema as track_schema
class Fix2010Tests(unittest.TestCase):
    def test_official_short_filename_aliases(self):
        class Resp:
            def __init__(self,url,content):self.url=url;self.content=content
            def raise_for_status(self): pass
        class Session:
            def get(self,url,timeout):
                html=''.join(f'<a href="2010/1{x}.pdf">PDF</a>' for x in ['sap','hako','fuku','niiga','tokyo','naka','chu','kyo','han','koku'])
                return Resp(url,html.encode())
        links=m.official_report_links(2010,Session())
        self.assertEqual(len(links),10)
        self.assertEqual({v for v,_ in links},set(m.TRACK_ROMAN.values()))
    def test_2010_tokyo_2nd_meeting_divided_course(self):
        cover='第２回 東京競馬成績集計表 （平成２２年 ４月２４日～５月１６日 ８日間）\n馬場について\n本競馬前６日はAコース，後２日はBコースを使用して競走を施行した。'
        _,_,meet,days=m.parse_2010_meeting_courses([(1,cover)],2010,'東京','https://www.jra.go.jp/datafile/seiseki/report/2010/2tokyo.pdf')
        self.assertEqual(meet,2)
        self.assertEqual(days,{**{i:'A' for i in range(1,7)},7:'B',8:'B'})
        con=sqlite3.connect(':memory:');con.execute('PRAGMA foreign_keys=ON')
        con.execute('CREATE TABLE races(race_id TEXT PRIMARY KEY,race_date TEXT,track TEXT,race_number INTEGER,payload_json TEXT)')
        for di,date in [(1,'2010-04-24'),(6,'2010-05-09'),(7,'2010-05-15'),(8,'2010-05-16')]:
            con.execute('INSERT INTO races VALUES (?,?,?,?,?)',(str(di),date,'東京',5,json.dumps({'surface':'芝','meeting_label':f'2回東京{di}日'},ensure_ascii=False)))
        track_schema(con);m.schema(con)
        self.assertEqual(m._apply_2010_course(con,'2010-04-24','2010-05-16',2,'東京',days,'https://www.jra.go.jp/datafile/seiseki/report/2010/2tokyo.pdf','hash'),4)
        self.assertEqual(dict(con.execute('SELECT race_id,used_turf_course FROM official_legacy_race_values')),
                         {'1':'A','6':'A','7':'B','8':'B'})
        self.assertEqual(m._apply_2010_course(con,'2010-04-24','2010-05-16',2,'東京',days,'https://www.jra.go.jp/datafile/seiseki/report/2010/2tokyo.pdf','hash'),4)
    def test_fukushima_complex_split_and_unverified_rejected(self):
        cover='第３回 福島競馬成績集計表（平成２２年１０月２３日～１１月２１日１０日間）\n馬場について 本競馬前４日はAコース，第５・６日はBコース，後４日はCコースを使用して競走を施行した。'
        _,_,_,days=m.parse_2010_meeting_courses([(1,cover)],2010,'福島','https://www.jra.go.jp/datafile/seiseki/report/2010/3fuku.pdf')
        self.assertEqual(days,{**{i:'A' for i in range(1,5)},5:'B',6:'B',**{i:'C' for i in range(7,11)}})
        with self.assertRaisesRegex(ValueError,'2010_COURSE'):
            m.parse_2010_meeting_courses([(1,cover.replace('後４日はCコース','後３日はCコース'))],2010,'福島','https://www.jra.go.jp/datafile/seiseki/report/2010/3fuku.pdf')
    def test_2010_single_course(self):
        cover='第１回 札幌競馬成績集計表 （平成２２年 ８月１４日～９月５日 ８日間）\n馬場について 本競馬は，Aコースを使用して競走を施行した。'
        self.assertEqual(m.parse_2010_meeting_courses([(1,cover)],2010,'札幌','https://www.jra.go.jp/datafile/seiseki/report/2010/1sap.pdf')[3],{i:'A' for i in range(1,9)})
if __name__=='__main__':unittest.main()
