#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sqlite3
from pathlib import Path

from cph_jra_df.pipeline import Pipeline


RECOVERY_DATES = ("2023-02-12", "2023-02-25", "2023-10-28")


def latest_statuses(conn: sqlite3.Connection, mode: str) -> dict[str, str]:
    rows = conn.execute(
        "WITH latest AS ("
        " SELECT race_date, MAX(rowid) AS latest_rowid FROM pipeline_runs"
        " WHERE mode=? AND substr(race_date,1,4)='2023' GROUP BY race_date"
        ") SELECT p.race_date,p.status FROM latest l JOIN pipeline_runs p"
        " ON p.rowid=l.latest_rowid"
        " WHERE p.mode=?",
        (mode, mode),
    ).fetchall()
    return {race_date: status for race_date, status in rows}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-root", required=True)
    args = parser.parse_args()
    root = Path(args.data_root).resolve()
    db_path = root / "cph_jra_df.sqlite3"

    conn = sqlite3.connect(db_path)
    dates = conn.execute(
        "SELECT d.race_date,s.seed_url FROM year_race_days d"
        " JOIN result_seed_urls s ON s.race_date=d.race_date"
        " WHERE substr(d.race_date,1,4)='2023' ORDER BY d.race_date"
    ).fetchall()
    manifest_count = conn.execute(
        "SELECT race_day_count FROM year_schedule_manifests WHERE year=2023"
    ).fetchone()
    before = latest_statuses(conn, "CACHE_ONLY")
    conn.close()

    expected = len(dates)
    if expected != 107 or manifest_count is None or manifest_count[0] != 107:
        raise SystemExit("2023_ANNUAL_MANIFEST_NOT_107_DAYS")
    seeds = dict(dates)
    if any(date not in seeds for date in RECOVERY_DATES):
        raise SystemExit("RECOVERY_DATE_SEED_MISSING")
    unexpected_failures = sorted(
        date for date, status in before.items()
        if status != "PASS" and date not in RECOVERY_DATES
    )
    if unexpected_failures:
        raise SystemExit("UNEXPECTED_FAILED_DATES:" + ",".join(unexpected_failures))

    pipeline = Pipeline(root, workers=1)
    backup_path = root / "cph_jra_df.recovered.sqlite3"
    repaired: list[str] = []
    reparsed: list[str] = []
    try:
        # Only the three historically misclassified dates are imported again.
        # The other 104 already passed cache verification in the supplied base.
        recovery_runs: dict[str, str] = {}
        for race_date in RECOVERY_DATES:
            result = pipeline.run(race_date, seeds[race_date], cache_only=True)
            recovery_runs[race_date] = result["run_id"]
            repaired.append(race_date)

        after = latest_statuses(pipeline.conn, "CACHE_ONLY")
        if len(after) != expected or any(after.get(date) != "PASS" for date, _ in dates):
            raise RuntimeError("LATEST_CACHE_ONLY_NOT_ALL_PASS")

        # Reflect the repaired dates in the original monthly collection
        # summary while keeping the historical failed pipeline runs intact.
        for race_date, run_id in recovery_runs.items():
            pipeline.conn.execute(
                "UPDATE month_collection_items SET status='PASS',phase='COMPLETE',"
                " attempts=attempts+1,pipeline_run_id=?,completed_at=CURRENT_TIMESTAMP,"
                " reason_codes_json='[]' WHERE race_date=?",
                (run_id, race_date),
            )
        pipeline.conn.execute(
            "UPDATE month_collection_runs SET status='PASS',updated_at=CURRENT_TIMESTAMP"
            " WHERE year=2023 AND NOT EXISTS ("
            " SELECT 1 FROM month_collection_items i"
            " WHERE i.plan_id=month_collection_runs.plan_id AND i.status!='PASS')"
        )
        pipeline.conn.commit()

        # Reparse every stored result snapshot without network access.
        for race_date, _ in dates:
            pipeline.reparse(race_date)
            reparsed.append(race_date)

        reparse_status = latest_statuses(pipeline.conn, "REPARSE")
        if len(reparse_status) != expected or any(
            reparse_status.get(date) != "PASS" for date, _ in dates
        ):
            raise RuntimeError("LATEST_REPARSE_NOT_ALL_PASS")

        # Materialize the complete logical database into a fresh main file.
        # This makes the recovered artifact independent of WAL sidecars.
        target = sqlite3.connect(backup_path)
        try:
            pipeline.conn.backup(target)
            target.execute("PRAGMA journal_mode=DELETE")
            target.commit()
        finally:
            target.close()
    finally:
        pipeline.close()

    for suffix in ("-wal", "-shm"):
        sidecar = Path(str(db_path) + suffix)
        if sidecar.exists():
            sidecar.unlink()
    backup_path.replace(db_path)

    report = {
        "status": "PASS",
        "year": 2023,
        "expected_dates": expected,
        "repaired_cache_dates": repaired,
        "latest_cache_only_pass": expected,
        "latest_reparse_pass": len(reparsed),
        "network_requests_during_recovery": 0,
        "policy": "only known exact same-track surface/distance permutations are repaired",
    }
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
