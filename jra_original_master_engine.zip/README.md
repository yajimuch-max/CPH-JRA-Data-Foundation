# 週次更新 v0.3.0：GitHub Actionsでは mode=update、with_pedigree=true、with_track=true を既定とする。
# 日本語の簡単な手順は HOW_TO_UPDATE_JA.md を参照。

# JRA 年別・原本MASTER

2012〜2026年を年度ごとに管理する、エンジン非依存のSQLite原本です。ASTERや別エンジンの入力はこの原本から別途作成します。レース結果・単勝最終オッズ・払戻・ラップ・通過順・出走馬・血統を同じDBに保存します。既存原本の対応は2018〜2025型・2026型および本セットの2.0型です。2018〜2023年は実ファイルで主要行の一致・保存後再読込を確認済みです。2012〜2017年は新規取得対応を追加した段階で、全年度の実取得は未検証です。未知の形式は停止し、推測して移行しません。

## 2012〜2017年の新規取得

元原本がない年は初期化用STARTERをbootstrapし、`update`で公式検索の実リンクから本文を取得・検証します。初回は1月だけで現行の検索経路・結果・オッズ形式を確認してください。初期化用STARTERは年間全12月の未完了タスクを持つ空DBであり、完成原本ではありません。

2012〜2017年の専用経路では月一覧・開催選択・結果本文を別々にチェックポイント化します。オッズだけ失敗した場合は結果本文を取り直しません。`max_sources`はその実行でのrequest呼び出し上限（内部の一時障害再試行を除く）です。月一覧が空・トークンなし・未知形式は未解決として記録し、欠落を完了扱いしません。PDFのみ・取りやめ等は個別調査対象です。

本文取得済みタスクは再監査せず、最終確認では年度全体の公式開催・件数、構造化データ、血統4項目、出典、時刻、未解決タスク、DB整合性を照合します。本文取得後に完成年から血統を再利用し、未取得馬だけpedigreeを実行します。2018年以降のupdate/reaudit/pedigreeとMASTERのスキーマ・保存形式は変更しません。

## 保存のルール

- 年度ごとに `MASTER.sqlite3` を1つ。年度内は馬IDで共通管理。同一馬が別年度に入ることは許可します。
- 血統はJRAの父・母・母の父・母の母の4項目。同一年では再取得済みの馬を省略します。5代血統は収録しません。
- RAW本文は監査中の一時ファイルだけ。完了時・エラー時とも削除し、成果物や途中stateには入れません。
- 出典URL、本文ハッシュ、HTTP状態、実際の取得・応答・一時RAW保存・統合時刻、検証結果、修正履歴を残します。旧原本の不明時刻はNULLです。
- 欠損は欠損として保持。未取得・取得失敗・公式に記載なしを分けます。失敗は次回再開できます。
- レース・馬ID・馬名・馬番の一致とDB整合性を確認し、検証を通ったデータを統合します。
- 最終オッズは過去の締切前時点のオッズとは扱いません。予測やエンジン固有の特徴量は保存しません。
- 公式URLは実際の公式ページのリンクから取得。アクセス不能や403を「存在しない」と判定せず、未解決として残します。

## スマホからGitHubで使う

専用の非公開リポジトリを作り、ルートに `jra_original_master_engine.zip`、`.github/workflows/` に `jra_original_master.yml` を置きます。コードZIPの中身をスマホで1ファイルずつ登録する必要はありません。GitHubのWeb画面を使い、必要ならデスクトップ表示にします。

1. Actionsで本workflowを選び、Run workflow → `preflight` を実行。
2. 旧原本ZIPをReleaseの添付ファイルへ登録。例：タグ `inputs-2026`。RAWを含む旧原本は公開しないでください。
3. `year=2026`、`mode=bootstrap`、Releaseタグと元ZIPの正確な名前を入力。最初は `with_pedigree=false`。旧原本の構造化データを移します。
4. `mode=reaudit`、同じ元ZIPを指定して繰り返します。旧RAWで結果・オッズを再検証し、公式の馬ページのリンクも回収。URLだけの参照や本文未保存の結果は、記録済みのJRA公式URLから直接取得して検証します。初回は `with_pedigree=false`。完了済みの監査はスキップします。
5. `mode=pedigree`。例 `max_horses=500`。未取得分を取得し、同じ年のMASTERへ統合。件数上限や時間上限に達したら次回続きから実行します。
6. 実行結果のArtifact `jra-original-master-2026` をスマホへダウンロード。中の年別ZIPが新しい原本です。`AUDIT.json`で未取得・失敗・件数を確認。

途中stateは30日で期限が切れます。各回の年別ZIPは自分でダウンロードして保管してください。長く空く時は最新の年別ZIPをReleaseへ置き、stateがなくなった場合はそのZIPを入力に `bootstrap` で復元します。旧RAWでの監査が残っている場合は旧原本も保持します。

## 毎週の追加

`mode=update`、対象年、開始日と終了日を指定し、`with_pedigree=true`。レース・オッズを取得、検証、統合し、新しい馬の血統も取得します。前回の最終開催日から重ねて指定し、訂正確認が必要な週は `refresh=true`。公式ページで公開済みのデータが対象で、ライブオッズ配信ではありません。

新しい年には対象年の空のstateで `update` を開始します。毎回GitHubが途中stateを復元し、年別MASTERへ統合するため、通常はChatGPTへ毎週ファイルを渡す必要はありません。

自動の曜日スケジュールは設定していません。スマホで週ごとに実行してください。失敗時もstateと生成できた成果物を保存します。未完了の成果物は `PARTIAL` と表示します。

## 今ある原本の扱い

旧原本は最初にバックアップし、手作業でRAWだけを削除しないでください。`bootstrap` → `reaudit` → `pedigree` を進め、新原本の件数・元の構造化項目・出典情報・未解決リスト・SQLite整合性を確認してから置き換えます。原本から運用用の重複表や旧DBをそのままコピーせず、対応した主要表の各行を `payload_json` に保持します。2018〜2020年の競走取りやめ・複勝オッズ・公式補足項目・公式リンクなど、対応した追加表はsupplemental_recordsへ保持します。旧ファイルにその他の独自追加表がある場合は移行前に確認してください。

RAWの再監査が済んでいない段階で旧RAWを削除すると、その本文を使った再監査はできなくなります。新原本の承認後、旧RAW付きZIPは運用から外し、必要な復元期間だけ別に保管します。

## 2018〜2023年の互換性修正（r3）

2022年の旧RAWは圧縮gzipファイル自体のSHA-256、2023年は解凍後本文のSHA-256でした。両方を厳密に検証し、どちらを照合したかと本文ハッシュを出典に記録します。不一致を無視しません。URLだけのRESULT_HTML_VERIFIEDも再監査対象とし、本文未保存の各参照を個別のタスクIDで管理します。取得不能は未解決として残します。

両年度とも一部の馬のリンクは保存済みRAWだけでは不足するため、公式結果ページの直接取得が必要です。全馬の血統取得・公式接続の実稼働は未完了です。

r3では旧形式の補足項目を保持し、ハッシュ未記録の旧RAWは未記録として明示したうえで本文のID等を検証します。ZIP内の日本語名の文字コード差、OFFICIAL_RESULT_HTML / OFFICIAL_ODDS_HTMLにも対応。結果がPDFだけのレースは保存済み選択ページの実リンクから公式結果URLを補います。推測したCNAMEは使いません。

## 手元実行・検証

Python 3.11以上。`pip install .` の後：

```sh
python -m unittest discover -s tests -v
python -m jra_master.cli --year 2026 --mode preflight
python -m jra_master.cli --year 2026 --mode bootstrap --input OLD.zip
python -m jra_master.cli --year 2026 --mode reaudit --input OLD.zip
python -m jra_master.cli --year 2026 --mode pedigree --max-horses 500
python -m jra_master.cli --year 2026 --mode update --start 2026-09-20 --end 2026-09-27 --with-pedigree
```

このセットのテストはオフライン検証です。全年度取得、全馬の血統取得、GitHub Actionsの実稼働を完了したものではありません。サイト構造や公開範囲の変更時には更新が必要です。JRAの利用条件とアクセス制約を守り、403等を回避する認証偽装は行いません。

## 年度をまたぐ血統の再利用

`--pedigree-from 2026_JRA_MASTER.zip` を指定すると、馬IDと正規化した馬名が一致する取得済みJRA血統4項目をコピーします。元の実取得・応答・一時RAW保存時刻と本文ハッシュをそのまま残し、コピー日時は別のmetadataに記録します。年度内に完了済みの血統は上書きしません。未検証・欠損・馬名不一致はコピーせず、公式取得へ回します。コピー先の年別MASTERには出典レコードも入るので、別年度のファイルを参照せず使えます。

GitHub標準フォームの変更は不要です。血統コピー済みの準備版をReleaseに置き、対象年でbootstrapしてからpedigreeへ進められます。レースの監査に公式再取得が残っている場合は先にreauditを完了します。任意のカスタムworkflowでは `PEDIGREE_FROM` にローカルのコピー元ZIPパスを指定できます。


## 統一MASTER出力（JRA_UNIFIED_CURRENT_V1）
取得処理と再開用stateは従来どおりです。exportが独立したコピーを作り、各年度で共通のpayload項目に統一します。
必要な補足値は本体へ統合し、旧監査報告・取り込み専用情報・重複項目は出力から除きます。開催中止は例外の補足レコードとして保持します。
不明な項目はNULL。出典URL・本文ハッシュ・実時刻・馬ID・血統4項目・タスクは保持します。
初回の完成PASS出力を変更履歴の基準にし、それ以後の訂正は保持します。途中PARTIALでは基準を確定しません。
exportではJRAの再取得、血統取得、レース本文の再監査を行いません。再開用stateの取得済み行と過去履歴は書き換えません。
そのため整理後MASTERと再開用stateのpayloadおよび履歴件数は一致しません。原本はMASTER、再開はstateを使います。
既存の実行中ジョブは差し替え前のエンジンで継続します。完了後、最新stateを指定した新規mode=exportで統一版を出力できます。

平均1Fは既存HTML parserが取得したaverage_1fを優先します。旧項目official_average_1fは名前だけで公式値と判定しません。旧値だけしかない場合は主項目をNULLとして旧値を区別して保持します。


## v0.3.2: 2010-2017 historical track-report enrichment

- `mode=track` reads the annual baseline from the Release or a restored Actions state; it skips race / pedigree re-fetch.
- 2011-2017: links from the JRA annual results index, race-by-race PDF heading going, daily-summary turf A/B/C/D.
- 2010: official meeting-report cover can establish turf course, but incomplete/garbled race going remains `NULL` and audit `PARTIAL`.
- Historical PDF results are **post-event**, not a genuine pre-race/09:30 observation.
- Each parsed PDF has a persisted receipt/checkpoint. Prior PASS / PARTIAL are skipped unless `refresh=true`; failed documents can retry.
- Unparseable/mismatched values are withheld, reported as PARTIAL, and never extrapolated.
- Core tables and metadata schemas remain unchanged; facts live in `official_legacy_race_values` and `official_race_track_context`.
- Output filename is the ASCII `{year}_JRA_MASTER.zip`. No PDF binary embedded in the master.
- Live downloads must be validated via GitHub run's `jra-track-audit-{year}`; offline tests do NOT guarantee complete live coverage.
