"""Model-only person keys. Official source IDs are never rewritten.

Catalogues contain names/IDs and dates only, never race outcomes. A catalogue
must be rebuilt at each training boundary; it must not use later-year rows.
"""
import datetime,json,re,unicodedata,hashlib,copy
from collections import defaultdict

VERSION='PERSON_IDENTITY_1.0.1'
ROLES=('jockey','trainer')

def normalize_name(value):
 if value is None:return None
 if not isinstance(value,str):raise ValueError('NON_STRING_PERSON_NAME')
 # Official allowance symbols describe a ride, not the person's identity.
 display=unicodedata.normalize('NFKC',value).strip()
 display=re.sub(r'^[★▲△☆◇]\s*','',display)
 name=re.sub(r'\s+','',display)
 return name or None

def normalize_official_id(value):
 if value is None:return None
 if not isinstance(value,(str,int)) or isinstance(value,bool):raise ValueError('INVALID_OFFICIAL_PERSON_ID')
 pid=str(value).strip()
 if pid in ('','UNKNOWN'):return None
 if not re.fullmatch(r'\d{4,}',pid):raise ValueError('INVALID_OFFICIAL_PERSON_ID')
 return pid

def build_catalogue(records,cutoff):
 end=datetime.date.fromisoformat(cutoff);aliases={role:defaultdict(set) for role in ROLES};ids={role:defaultdict(set) for role in ROLES};used=future=0
 for row in records:
  day=datetime.date.fromisoformat(row['race_date'])
  if day>end:future+=1;continue
  role=row['role']
  if role not in ROLES:raise ValueError('INVALID_PERSON_ROLE')
  name=normalize_name(row.get('name'));pid=normalize_official_id(row.get('official_id'));used+=1
  if name and pid:aliases[role][name].add(pid);ids[role][pid].add(name)
 catalog=dict(version=VERSION,cutoff=cutoff,used_rows=used,excluded_future_rows=future,aliases={r:{n:sorted(v) for n,v in sorted(aliases[r].items())} for r in ROLES},id_names={r:{n:sorted(v) for n,v in sorted(ids[r].items())} for r in ROLES})
 catalog['sha256']=hashlib.sha256(json.dumps(catalog,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
 return catalog

def resolve(role,official_id,name,catalogue):
 if role not in ROLES:raise ValueError('INVALID_PERSON_ROLE')
 pid=normalize_official_id(official_id);norm=normalize_name(name);known=catalogue['aliases'][role].get(norm,[]) if norm else []
 if pid:
  if known and pid not in known:raise ValueError('PERSON_ID_NAME_CONFLICT')
  return dict(key='JRA_ID:'+role+':'+pid,status='OFFICIAL_ID',official_id=pid,normalized_name=norm)
 if not norm:return dict(key=None,status='MISSING_PERSON',official_id=None,normalized_name=None)
 if len(known)>1:return dict(key=None,status='AMBIGUOUS_NAME',official_id=None,normalized_name=norm)
 if len(known)==1:return dict(key='JRA_ID:'+role+':'+known[0],status='UNIQUE_NAME_TO_ID',official_id=None,normalized_name=norm)
 # Exact official display label only: a lower-confidence grouping, explicitly
 # separate from an official person ID. It is never exported into source IDs.
 return dict(key='NAME_ONLY:'+role+':'+norm,status='NAME_ONLY',official_id=None,normalized_name=norm)

def target_catalogue(history_catalogue,target_rows,card_observed_at,decision_time):
 """Use only person metadata actually observed before a target decision.

 A newly published profile ID can connect earlier name-only rows to the same
 displayed person. No target finish/time/payout fields are inspected.
 """
 observed=datetime.datetime.fromisoformat(card_observed_at.replace('Z','+00:00'))
 decision=datetime.datetime.fromisoformat(decision_time.replace('Z','+00:00'))
 if observed.tzinfo is None or decision.tzinfo is None or observed>decision:raise ValueError('PERSON_CARD_NOT_AVAILABLE_AT_DECISION')
 out=copy.deepcopy(history_catalogue)
 for row in target_rows:
  for role in ROLES:
   name=normalize_name(row.get(role+'_name'));pid=normalize_official_id(row.get(role+'_id'))
   if not name or not pid:continue
   known=out['aliases'][role].get(name,[])
   if known and pid not in known:raise ValueError('TARGET_PERSON_ID_NAME_CONFLICT')
   out['aliases'][role][name]=sorted(set(known)|{pid})
   out['id_names'][role][pid]=sorted(set(out['id_names'][role].get(pid,[]))|{name})
 out['target_metadata_observed_at']=card_observed_at
 out.pop('sha256',None)
 out['sha256']=hashlib.sha256(json.dumps(out,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
 return out
