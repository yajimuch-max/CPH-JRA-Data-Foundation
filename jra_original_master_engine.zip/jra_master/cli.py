import argparse,json,zipfile,sqlite3,shutil,tempfile
from pathlib import Path
from datetime import date,datetime
from zoneinfo import ZoneInfo
from .store import Store,sha,VERSION
from .network import Client
from .importer import bootstrap
from .racing import collect,reaudit_archive
from . import pedigree

def export(s,out,year):
 out=Path(out);out.mkdir(parents=True,exist_ok=True);audit=s.audit()
 missing=s.c.execute('SELECT count(*) FROM horses h LEFT JOIN pedigree_receipts p USING(horse_id) WHERE p.horse_id IS NULL OR p.status="NEEDS_REPARSE"').fetchone()[0]
 checked=s.c.execute('SELECT count(*) FROM pedigree_receipts WHERE checked_fields=4').fetchone()[0]
 slots=s.c.execute('SELECT count(*) FROM pedigree').fetchone()[0]
 audit['pedigree']={'source':'JRA','fields':['父','母','母の父','母の母'],'paths':['S','M','MS','MM'],'horses_without_receipt':missing,'checked_horses':checked,'stored_slots':slots,'source_missing_slots':s.c.execute("SELECT count(*) FROM pedigree WHERE status!='KNOWN'").fetchone()[0],'status':'CHECKED_ALL_HORSES' if not missing and slots==checked*4 else 'INCOMPLETE'}
 if missing or slots!=checked*4:audit['status']='PARTIAL'
 s.meta('last_audit',audit)
 s.c.execute("UPDATE source_records SET raw_state='NOT_RETAINED_IN_MASTER'");s.c.commit()
 with tempfile.TemporaryDirectory() as tmp:
  stage=Path(tmp);target=stage/'MASTER.sqlite3';dest=sqlite3.connect(target);dest.execute('PRAGMA journal_mode=TRUNCATE');s.c.backup(dest);dest.execute('VACUUM');dest.close()
  readback=sqlite3.connect(target)
  if readback.execute('PRAGMA integrity_check').fetchone()[0]!='ok' or readback.execute('PRAGMA foreign_key_check').fetchall():raise ValueError('EXPORT_DB_INTEGRITY_FAILED')
  readback.close()
  from .store import now
  manifest={'schema_version':VERSION,'purpose':'ENGINE_INDEPENDENT_ORIGINAL_MASTER','year':year,'built_at':now(),'audit_status':audit['status'],'master_sha256':sha(target.read_bytes()),'raw_included':False,'pedigree_source':'JRA','pedigree_fields':['父','母','母の父','母の母'],'cross_year_duplicate_horse_ids':'ALLOWED','historical_final_odds_are_decision_time_observations':False,'race_date_min':audit['race_date_min'],'race_date_max':audit['race_date_max'],'counts':audit['counts']}
  (stage/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');(stage/'AUDIT.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
  (stage/'README.txt').write_text('エンジン非依存の年別原本MASTER。SQLiteが本体です。RAW本文・取得コード・重複CSV・旧DBは収録しません。同一年の血統は馬ID単位で1件、別年の同じ馬IDは重複可。血統はJRA公式の父(S)・母(M)・母父(MS)・母母(MM)の4項目。欠損と監査未完了はAUDIT.json。構造化項目は各表のpayload_json、出典はsource_records、修正履歴はrevisionsに保持します。予測値・印・エンジン固有特徴量はありません。\n',encoding='utf-8')
  name=f'{year}_JRA公式データ_原本MASTER.zip';p=out/name
  with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
   for filename in ['MASTER.sqlite3','manifest.json','AUDIT.json','README.txt']:z.write(stage/filename,filename)
 with zipfile.ZipFile(p) as z:
  if z.testzip():raise ValueError('ZIP_INTEGRITY_FAILED')
 (out/(name+'.sha256')).write_text(sha(p.read_bytes())+'  '+name+'\n')
 print(json.dumps({'output':str(p),'bytes':p.stat().st_size,'status':audit['status'],'counts':audit['counts'],'pedigree':audit['pedigree']},ensure_ascii=False));return audit

def main(argv=None):
 p=argparse.ArgumentParser();p.add_argument('--db');p.add_argument('--year',type=int,required=True);p.add_argument('--mode',choices=['bootstrap','reaudit','update','pedigree','export','preflight'],default='update');p.add_argument('--input');p.add_argument('--pedigree-from',action='append',default=[]);p.add_argument('--months',default='');p.add_argument('--start');p.add_argument('--end');p.add_argument('--max-horses',type=int,default=500);p.add_argument('--max-sources',type=int,default=500);p.add_argument('--budget-seconds',type=int,default=9000);p.add_argument('--refresh',action='store_true');p.add_argument('--with-pedigree',action='store_true');p.add_argument('--output',default='delivery');args=p.parse_args(argv)
 if not 2018<=args.year<=2100:p.error('year must be 2018 or later')
 if args.max_horses<0 or args.max_sources<1 or not 30<=args.budget_seconds<=10800:p.error('invalid batch/budget')
 if args.mode=='preflight':
  assert pedigree.FIELDS=={'父':'S','母':'M','母の父':'MS','母の母':'MM'};print('PREFLIGHT_PASS');return 0
 db=args.db or f'state/{args.year}/MASTER.sqlite3';s=Store(db);r=s.c.execute("SELECT value FROM metadata WHERE key='year'").fetchone()
 if r and json.loads(r[0])!=args.year:raise ValueError('RESUMED_STATE_YEAR_MISMATCH')
 s.meta('year',args.year);s.meta('master_purpose','ENGINE_INDEPENDENT_ORIGINAL_MASTER')
 try:
  # All body files are job-local and removed on both success and failure.
  with tempfile.TemporaryDirectory(prefix='jra_audit_') as raw:
   client=Client(s,raw,args.budget_seconds)
   if args.mode=='bootstrap':
    if not args.input:p.error('--input required')
    print('BOOTSTRAP',bootstrap(s,args.input,args.year))
   elif args.mode=='reaudit':
    if not args.input:p.error('--input required')
    from .repair_2022 import prepare
    prepare(s,client)
    prepared=s.c.execute("SELECT value FROM metadata WHERE key='require_final_odds_completion'").fetchone()
    source_limit=max(args.max_sources,args.max_horses) if prepared and json.loads(prepared[0]) else args.max_sources
    print('REAUDIT',reaudit_archive(s,args.input,source_limit,client))
   elif args.mode=='update':
    start=args.start or f'{args.year}-01-01';end=args.end or min(datetime.now(ZoneInfo('Asia/Tokyo')).date().isoformat(),f'{args.year}-12-31')
    if not start.startswith(str(args.year)+'-') or not end.startswith(str(args.year)+'-') or start>end:p.error('invalid date range')
    date.fromisoformat(start);date.fromisoformat(end)
    months=[int(x) for x in args.months.split(',') if x] or list(range(int(start[5:7]),int(end[5:7])+1))
    if any(x<1 or x>12 for x in months):p.error('invalid months')
    print('UPDATE',collect(s,client,args.year,months,start,end,args.refresh))
   for donor in args.pedigree_from:
    from .reuse import reuse_pedigree
    print('PEDIGREE_REUSE',reuse_pedigree(s,donor))
   if args.mode=='pedigree' or args.with_pedigree:print('PEDIGREE',pedigree.collect(s,client,args.max_horses))
  audit=export(s,args.output,args.year);failure=any(t['status']=='FAIL' for t in audit['pending_tasks']) or bool(audit['open_issues'])
 finally:s.c.commit();s.c.close()
 return 2 if failure else 0
if __name__=='__main__':raise SystemExit(main())
