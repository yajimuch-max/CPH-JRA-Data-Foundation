import re,json,gzip
from dataclasses import asdict
from urllib.parse import urlencode,urljoin
from bs4 import BeautifulSoup
from .jra_parser import parse_result,decode_jra,compact_text as _compact_text
from .legacy_odds_parser import parse_odds,odds_cname
from .store import encode,now
from .network import Deferred
def compact_text(node):return _compact_text(node) if node is not None else ''
BET={'単勝':'WIN','複勝':'PLACE','枠連':'BRACKET_QUINELLA','馬連':'QUINELLA','ワイド':'WIDE','馬単':'EXACTA','3連複':'TRIO','3連単':'TRIFECTA'}
def n(x):
 m=re.search(r'\d[\d,]*',x);return int(m[0].replace(',','')) if m else None

def parse_all(body):
 p=parse_result(body);soup=BeautifulSoup(decode_jra(body),'lxml');race=p.as_dict();race.pop('entries');race.pop('results');race['race_type']='JUMP' if p.surface=='障害' else 'FLAT'
 payouts=[];laps=[];corners=[];names={};extra={};links={}
 table=next(t for t in soup.find_all('table') if t.select_one('thead th.place') and t.select_one('tbody td.horse'))
 for tr in table.select('tbody tr'):
  no=n(compact_text(tr.select_one('td.num')))
  if no is None:continue
  extra[no]={'popularity':n(compact_text(tr.select_one('td.pop'))),'average_1f':float(compact_text(tr.select_one('td.f_time'))) if p.surface=='障害' and re.fullmatch(r'\d+\.\d+',compact_text(tr.select_one('td.f_time'))) else None}
  a=tr.select_one('td.horse a');onclick=(a.get('href','')+a.get('onclick','')) if a else '';m=re.search(r'(pw01dud(?:00|10)[^\s\"\x27)]+)',onclick)
  if m:links[no]='https://www.jra.go.jp/JRADB/accessU.html?'+urlencode({'CNAME':m[1]})
 for dl in soup.find_all('dl'):
  dt=dl.find('dt');label=compact_text(dt)
  if label not in BET:continue
  lines=dl.select('dd .line') or dl.find_all('dd',recursive=False)
  for i,line in enumerate(lines,1):
   text=compact_text(line);combo=compact_text(line.select_one('.num')) or None;yen=n(compact_text(line.select_one('.yen')));pop=n(compact_text(line.select_one('.pop')))
   payouts.append({'bet_type':BET[label],'line_number':i,'combination_text':combo,'payout_yen':yen,'payout_popularity':pop,'special_status':None if combo and yen is not None else 'NOT_OFFERED_OR_NO_PAYOUT','official_text':text})
 for tr in soup.find_all('tr'):
  th=tr.find('th');td=tr.find('td');heading=compact_text(th)
  if heading=='ハロンタイム' and td:
   vals=re.findall(r'\d+\.\d+',compact_text(td));laps=[{'lap_index':i,'lap_time_seconds':float(v)} for i,v in enumerate(vals,1)]
  if 'コーナー' in heading and td and re.search(r'\d',heading):corners.append({'corner_index':heading,'order_text':compact_text(td)})
 return p,race,payouts,laps,corners,extra,links

def integrate_result(s,body,sid,expected_id=None):
 p,race,payouts,laps,corners,extra,links=parse_all(body);rid=p.race_key
 if expected_id and rid!=expected_id:raise ValueError('RESULT_ID_MISMATCH')
 # Validate whole page before writing. Known runner identity changes require investigation.
 old=s.c.execute('SELECT horse_number,horse_id FROM runners WHERE race_id=?',(rid,)).fetchall()
 if old and dict((r[0],r[1]) for r in old)!={r.horse_no:r.horse_id for r in p.entries}:raise ValueError('RUNNER_IDENTITY_SET_MISMATCH')
 with s.c:
  prior=s.c.execute('SELECT payload_json FROM races WHERE race_id=?',(rid,)).fetchone();payload=json.loads(prior[0]) if prior else {};payload.update(race)
  s.put('races',['race_id'],{'race_id':rid,'race_date':p.race_date,'track':p.track,'race_number':p.race_no,'race_type':race['race_type'],'payload_json':encode(payload)},sid)
  for e,r in zip(p.entries,p.results):
   s.c.execute('INSERT OR IGNORE INTO horses VALUES (?,?)',(e.horse_id,e.horse_name));oldentry=s.c.execute('SELECT payload_json FROM runners WHERE race_id=? AND horse_number=?',(rid,e.horse_no)).fetchone();entrypayload=json.loads(oldentry[0]) if oldentry else {};entrypayload.update(asdict(e));s.put('runners',['race_id','horse_number'],{'race_id':rid,'horse_number':e.horse_no,'horse_id':e.horse_id,'payload_json':encode(entrypayload)},sid)
   oldresult=s.c.execute('SELECT payload_json FROM results WHERE race_id=? AND horse_number=?',(rid,r.horse_no)).fetchone();resultpayload=json.loads(oldresult[0]) if oldresult else {};resultpayload.update(asdict(r));resultpayload['final_3f']=None if p.surface=='障害' else r.final_3f;resultpayload.update({k:v for k,v in extra.get(r.horse_no,{}).items() if v is not None});s.put('results',['race_id','horse_number'],{'race_id':rid,'horse_number':r.horse_no,'payload_json':encode(resultpayload)},sid)
   if e.horse_no in links:s.meta('horse_profile_'+e.horse_id,links[e.horse_no])
  for table,key,records in [('payouts','line_number',payouts),('laps','lap_index',laps),('corners','corner_index',corners)]:
   for rec in records:
    row={'race_id':rid,key:rec[key],'payload_json':encode(rec)}
    if table=='payouts':row['bet_type']=rec['bet_type']
    s.put(table,['race_id',key]+(['bet_type'] if table=='payouts' else []),row,sid)
  s.c.execute('INSERT OR IGNORE INTO race_sources VALUES (?,?,?)',(rid,'RESULT_HTML',sid))
 return rid,p

def integrate_odds(s,body,sid,rid):
 rows=parse_odds(body);expected=s.c.execute('SELECT * FROM runners WHERE race_id=?',(rid,)).fetchall()
 if len({r['horse_no'] for r in rows})!=len(rows):raise ValueError('ODDS_DUPLICATE_HORSE_NUMBER')
 if set(r['horse_no'] for r in rows)!=set(r['horse_number'] for r in expected):raise ValueError('ODDS_RUNNER_SET_MISMATCH')
 from .pedigree import norm
 names={r['horse_number']:s.c.execute('SELECT horse_name FROM horses WHERE horse_id=?',(r['horse_id'],)).fetchone()[0] for r in expected}
 if any(norm(r['horse_name'])!=norm(names[r['horse_no']]) for r in rows):raise ValueError('ODDS_HORSE_NAME_MISMATCH')
 with s.c:
  for r in rows:s.put('win_odds',['race_id','horse_number'],{'race_id':rid,'horse_number':r['horse_no'],'win_odds':r['final_win_odds'],'odds_status':r['status'],'source_id':sid,'payload_json':encode(r)},sid,'FINAL_ODDS_VALIDATED_BY_RACE_HORSE_NUMBER_NAME')
  s.c.execute('INSERT OR IGNORE INTO race_sources VALUES (?,?,?)',(rid,'FINAL_WIN_ODDS',sid))
 return len(rows)

def links(body,prefix):
 text=decode_jra(body);return sorted(set(re.findall(r'(pw01'+prefix+r'[^\s\"\x27)<>]+)',text)))
def form(cname):return urlencode({'cname':cname})
def discover(client,year,month,start,end):
 # Exact official month tokens and meeting/result links; no invented checksums.
 body,sid,p=client.request('https://www.jra.go.jp/JRADB/accessS.html','RESULT_SEARCH_ENTRY',form('pw01skl00999999/B3'))
 text=decode_jra(body);m=re.search(r'objParam\["'+f'{year%100:02d}{month:02d}'+r'"\]="([0-9A-F]{2})"',text)
 if not m:raise ValueError('OFFICIAL_MONTH_TOKEN_NOT_FOUND')
 client.valid(sid,p);body,sid,p=client.request('https://www.jra.go.jp/JRADB/accessS.html','RESULT_MONTH_INDEX',form(f'pw01skl10{year:04d}{month:02d}/'+m[1]));meetings=links(body,'srl');client.valid(sid,p)
 result=[]
 for cname in meetings:
  date=re.search(r'('+str(year)+r'\d{4})/',cname)
  if not date:raise ValueError('MEETING_DATE_UNPARSEABLE')
  d=date[1][:4]+'-'+date[1][4:6]+'-'+date[1][6:]
  if not start<=d<=end:continue
  body,sid,p=client.request('https://www.jra.go.jp/JRADB/accessS.html','RESULT_RACE_SELECTION',form(cname));found=links(body,'sde');client.valid(sid,p)
  if not found:raise ValueError('MEETING_RESULTS_EMPTY')
  result.extend(found)
 return sorted(set(result))

def collect(s,client,year,months,start,end,refresh=False):
 errors=[];completed=0
 for month in months:
  mk=f'DISCOVER_{year}_{month:02d}_{start}_{end}'
  try:
   key='links_'+mk;row=s.c.execute('SELECT value FROM metadata WHERE key=?',(key,)).fetchone()
   cnames=json.loads(row[0]) if row and not refresh else discover(client,year,month,start,end);s.meta(key,cnames);s.task(mk,'PASS')
   for cname in cnames:
    tk='RACE_'+cname
    if s.done(tk) and not refresh:continue
    try:
     body,sid,p=client.request('https://www.jra.go.jp/JRADB/accessS.html','RACE_RESULT',form(cname));rid,parsed=integrate_result(s,body,sid);client.valid(sid,p)
     oc=odds_cname(body);ob,osid,op=client.request('https://www.jra.go.jp/JRADB/accessO.html','FINAL_WIN_ODDS',form(oc));integrate_odds(s,ob,osid,rid);client.valid(osid,op);s.task(tk,'PASS');s.resolve(tk);completed+=1;print('RACE_PASS',rid,flush=True)
    except Deferred:raise
    except Exception as e:s.task(tk,'FAIL',str(e));s.issue(tk,'RACE_FETCH_OR_VALIDATION',{'error':str(e),'official_cname':cname});errors.append(str(e))
  except Deferred as e:s.task(mk,'DEFERRED',str(e));break
  except Exception as e:s.task(mk,'FAIL',str(e));errors.append(str(e))
 return {'completed_races':completed,'errors':errors}

def reaudit_archive(s,path,limit=1000):
 from .importer import Archive
 from .store import sha
 a=Archive(path);tables={r[0] for r in a.c.execute("SELECT name FROM sqlite_master WHERE type='table'")};modern='raw_sources' in tables;records=a.c.execute('SELECT * FROM '+('raw_sources' if modern else 'raw_catalog')).fetchall();count=0;errors=[]
 # Results first, odds second. Successful tasks checkpoint by content hash.
 def role(r):return r['role'] if modern else r['source_role']
 records=[r for r in records if role(r) in ['RACE_RESULT','RACE_RESULT_REMOTE_REFERENCE','FINAL_WIN_ODDS'] and (not modern or r['media_type']=='text/html')]
 records=sorted(records,key=lambda r:0 if role(r) in ['RACE_RESULT','RACE_RESULT_REMOTE_REFERENCE'] else 1)
 for r0 in records:
  r=dict(r0);tk='REAUDIT_'+role(r0)+'_'+str(r.get('sha256',r.get('entity_sha256')))
  if not s.c.execute('SELECT 1 FROM tasks WHERE task_key=?',(tk,)).fetchone():s.task(tk,'PENDING')
 for row in records:
  r=dict(row);kind=role(r)
  if kind not in ['RACE_RESULT','RACE_RESULT_REMOTE_REFERENCE','FINAL_WIN_ODDS']:continue
  digest=r.get('sha256',r.get('entity_sha256'));key='REAUDIT_'+kind+'_'+str(digest)
  if s.done(key):continue
  if count>=limit:break
  count+=1
  try:
   b=a.raw(r['relative_path'])
   if sha(b)!=digest:raise ValueError('BASE_RAW_HASH_MISMATCH')
   sid='BASE_'+str(r.get('raw_source_id',r.get('snapshot_id')))
   if kind=='FINAL_WIN_ODDS':
    # Resolve race from exact stored source relationship; never align by row order.
    if modern:linked=a.c.execute('SELECT DISTINCT race_id FROM race_sources WHERE raw_source_id=?',(r['raw_source_id'],)).fetchall()
    else:linked=a.c.execute('SELECT DISTINCT race_id FROM market_win_odds WHERE source_snapshot_id=?',(r['snapshot_id'],)).fetchall()
    if len(linked)!=1:raise ValueError('ODDS_SOURCE_RACE_LINK_AMBIGUOUS')
    integrate_odds(s,b,sid,linked[0][0])
   else:
    if modern:linked=a.c.execute('SELECT DISTINCT race_id FROM race_sources WHERE raw_source_id=?',(r['raw_source_id'],)).fetchall()
    else:linked=a.c.execute('SELECT DISTINCT race_id FROM races WHERE source_snapshot_id=?',(r['snapshot_id'],)).fetchall()
    if len(linked)!=1:raise ValueError('RESULT_SOURCE_RACE_LINK_AMBIGUOUS')
    integrate_result(s,b,sid,linked[0][0])
   s.task(key,'PASS');s.resolve(key)
  except Exception as e:s.task(key,'FAIL',str(e));s.issue(key,'BASE_RAW_REAUDIT',{'error':str(e),'path':r.get('relative_path')});errors.append(str(e))
 a.close();return {'processed_sources':count,'errors':errors}
