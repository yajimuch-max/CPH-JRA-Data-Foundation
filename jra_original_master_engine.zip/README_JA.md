# JRA ORIGINAL MASTER — HTML統一原本 v0.7.1.1（2026-10-10）

## この版の目的
- JRA公式のみ。平地と障害の全競走・単勝オッズ・血統・着順・騎手/負担重量/馬体重・ラップ・全券種払戻を維持。
- 競走結果HTMLから天候・馬場状態（**ダートも独立して検証**）・競走条件・クラスを照合。
- `race_summary` / `runner_summary` / `race_laps` / `race_sectionals` / `race_payouts` / `track_measurements` を同じSQLite内に作り、全年同じ読み方にする。
- `race_sectionals` のレース末尾3F/4Fは**公式200mラップの合計で計算した派生値**。各馬の上がり3Fは `runner_summary.runner_last_3f`。
- 過去の誤解析を含む**公式成績PDFの追加項目は正式原本に含めない**。使用コース A-D、馬主、生産者、生産地などは除外。取消・ブリンカーの不完全な補助テーブルも正式原本に含めない。
- 2018年以降の**独立した公式馬場観測資料**のみ、含水率・クッション値を `track_measurements` に採用。公式公表前の年度は0行。公表していない値を空欄の行で水増ししない。

## 不完全な原本を完成扱いにしない
- レース・馬単勝オッズ・結果・血統・平地ラップ・払戻の件数と整合性を確認。
- **各レースの天候、芝/ダート/障害の正しい馬場状態、競走条件、クラスがJRA公式HTMLに照合済み**でない場合は、`unified_audit_YYYY.json` に `NOT_CERTIFIED` を記録し、**最終版 `YYYY_JRA_MASTER.zip` を出力しない**。
- 2018年以降は公式含水率・クッション値取得段階も PASS を必要とする。
- 中途の作業内容は `jra-original-state-YYYY` Artifact に保存され、次回は**不足分だけ**再試行する（Releaseに同一ZIPを再アップしない）。
- 緑のワークフロー結果は**処理の正常終了**であり、原本の確定を意味しない。監査が `CERTIFIED` となり `CERTIFIED_MASTER` が出て初めて完成。

## GitHub配置（ファイル2点のみ）
- リポジトリ直下に `jra_original_master_engine.zip`
- `.github/workflows/jra_original_master.yml`
- Releasesは従来どおり `inputs-2010` / `2010_JRA_MASTER.zip` など。**既存2010/2011の最新stateを再利用する場合、Releaseからのリセットは不要。**

## まず2010年から
1. GitHubの上記2ファイルを交換する。既存のMASTER、state、Release、過去のWorkflow実行履歴は消さない。
2. `Run workflow`: `year=2010`, `mode=html_enrich`, `max_html_pages=20`, `reset_from_release=false`, `resume_run_id=空欄`, `refresh=false`。接続とダート馬場状態の修復が出来るか監査を見る。過去stateを復元できなければ止める。
3. 実際のダート馬場状態が正しく保存されたことを確認してから、`year=2010`, `mode=update`, `max_html_pages=4000`, `reset_from_release=false` で一括補完。実際のHTML通信速度によっては複数実行必要。
4. 監査で `CERTIFIED` を確認し、`2010_JRA_MASTER.zip` を保存。次は2011へ。同じ手順を繰り返す。

## 重大な制約
- **Github実アクセスの新DOM解析を使った本番試験は未実施。** HTMLの世代差があると`OFFICIAL_GOING_UNVERIFIED_ダート`で止め、推測値は書かない。最初の20件を飛ばさないこと。
- 2010・2011の既存stateのHTML取得自体は全件済み。ただし旧版はダート馬場状態を全件欠落させていた。再実行時は既存の正しい芝/障害をスキップし、不足ダートだけ再照合する。
- 2010年は公式含水率・クッション値の公表対象外なので、観測データを作らない。
- GitHub stateの容量と保持期間に注意。完了まで古いstateと完成ZIPを保管し、履歴はむやみに削除しない。

※ `CERTIFIED` は保存済みレースの項目完全性を示す。年度の全開催が収録されたことは、別途JRA開催一覧との照合が必要。特に進行中の2026年はYTD扱い。


## v0.7.1 追加: ブリンカー保存と正式原本の監査
- JRA公式HTMLに明示された「ブリンカー着用」記録は `official_html_runners` に保存し、正式原本でも消しません。
- `runner_summary.blinker_worn_confirmed` は 1 = 着用明示。NULLは非着用を意味しません。
- ブリンカーの馬番・元HTML取得ハッシュを照合し、誤対応は `CERTIFIED` を拒否します。
- 既存のレース・着順・単勝オッズ・払戻・血統・ラップは変更しません。
- 開催日とJRA公表統計の独立照合は、原本提出時の追加監査に含まれます。エンジン単独のCERTIFIEDだけでは、全実数値の独立再取得までは証明しません。


## v0.7.1.1: 2019年6月以降・将来年度の差分取得修正
- JRAが2019-06-01から「サラ系」の表示を省略した条件欄に対応。公式 result HTML の `.race_title` 本文のみを解析し、レース本体の `class_raw` をHTML照合済みの代用にしない。
- 条件/クラスを確定できない場合は `OFFICIAL_CONDITION_CLASS_UNVERIFIED` として検証失敗。推測値や空欄をPASSにしない。
- 過去の本物のHTML PASS証跡の解析版/観測時刻を**書き換えず再利用**。未完了HTMLレースのみ取得・再解析する（通常 `refresh=false`）。
- 2026年以降も `mode=update`、前回state自動復元で差分継続。新規公開レースと不完全な行だけ補完。
- 2018以降の `track_measurements` は従来 `unified_export` の定義で公式 `official_track_daily` を参照。A/B/C/Dは正式出力から除外。
- `with_track=true` の日別PDF取得は独立ステージ。古いPDFの既取得証跡に誤りがある場合は **`mode=track` + `refresh=true` の一時的な再検証** が必要な場合あり。通常の `mode=update` では `refresh=false` を維持。
- 2019年の2,015件の修復はGitHub上の本物の公式HTML通信で**これから検証**する。テスト通過は当該2,015件の公式再照合済みを意味しない。
