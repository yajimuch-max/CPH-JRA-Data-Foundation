from cph_jra_df.cli import main

raise SystemExit(main())

