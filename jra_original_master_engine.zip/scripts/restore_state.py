"""Restore the newest non-expired year state, including partial/failed checkpoints.

GitHub's artifact API can legitimately return workflow_run: null. That must
not prevent resuming a checkpoint; the artifact ID identifies the state ZIP.
"""
import argparse
import io
import json
import os
import sqlite3
import subprocess
import zipfile
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('--year', type=int, required=True)
p.add_argument('--run-id', default='')
args = p.parse_args()
repo = os.environ['GITHUB_REPOSITORY']
this_run = os.environ.get('GITHUB_RUN_ID', '')
name = 'jra-original-state-' + str(args.year)


def gh(*cmd):
    return subprocess.check_output(['gh', *cmd])


def artifact_run_id(item):
    # Some GitHub Actions artifact records have workflow_run=null, even when
    # they contain a valid downloadable state. Never call .get() on None.
    info = item.get('workflow_run') or {}
    return str(info.get('id') or item.get('workflow_run_id') or '')


candidates = []
for page in range(1, 11):
    # An explicitly requested run can contain artifacts with null workflow_run.
    # The run-scoped endpoint still identifies their run correctly.
    if args.run_id:
        endpoint = f'repos/{repo}/actions/runs/{args.run_id}/artifacts?per_page=100&page={page}'
    else:
        endpoint = f'repos/{repo}/actions/artifacts?per_page=100&page={page}'
    payload = json.loads(gh('api', endpoint))
    artifacts = payload.get('artifacts') or []
    for item in artifacts:
        if not isinstance(item, dict) or item.get('name') != name or item.get('expired', False):
            continue
        run = artifact_run_id(item)
        if run and run == this_run:
            continue
        if args.run_id and run and run != args.run_id:
            continue
        # When run metadata is unknown, still keep the prior state artifact.
        # This step runs before the current workflow uploads a new checkpoint.
        candidates.append(item)
    if len(artifacts) < 100:
        break

selected = max(candidates, key=lambda i: (i.get('created_at') or '', int(i['id']))) if candidates else None
if not selected:
    if args.run_id:
        raise SystemExit('Requested state artifact not found or expired')
    print('No prior state artifact found. Bootstrap/rebuild will start.')
    raise SystemExit(0)

body = gh('api', f"repos/{repo}/actions/artifacts/{selected['id']}/zip")
with zipfile.ZipFile(io.BytesIO(body)) as z:
    paths = [n for n in z.namelist() if n.endswith('MASTER.sqlite3')]
    if len(paths) != 1:
        raise SystemExit('State DB missing or ambiguous')
    db_content = z.read(paths[0])

state_file = Path('state') / str(args.year) / 'MASTER.sqlite3'
state_file.parent.mkdir(parents=True, exist_ok=True)
# Avoid overwriting a usable checkpoint until the newly downloaded DB is
# validated. This also prevents keeping a corrupt partial write.
tmp_file = state_file.with_suffix('.restore-tmp')
try:
    tmp_file.write_bytes(db_content)
    c = sqlite3.connect(f'file:{tmp_file.resolve()}?mode=ro', uri=True)
    try:
        if c.execute('PRAGMA quick_check').fetchone()[0] != 'ok':
            raise ValueError('Restored state failed SQLite quick_check')
        task_counts = c.execute('SELECT status,count(*) FROM tasks GROUP BY status').fetchall()
        pedigree_count = c.execute('SELECT count(*) FROM pedigree_receipts').fetchone()[0]
    finally:
        c.close()
    os.replace(tmp_file, state_file)
finally:
    tmp_file.unlink(missing_ok=True)

run = artifact_run_id(selected)
print('Restored state from artifact', selected['id'], 'run', run or '(metadata unavailable)')
print('Restored task counts', task_counts)
print('Restored pedigree horses', pedigree_count)
