import unittest,sqlite3,tempfile
from pathlib import Path
from jra_master.unified_export import clean_snapshot

class BlinkerCertTests(unittest.TestCase):
 def test_keep_explicit_flags_and_no_false_negatives(self):
  with tempfile.TemporaryDirectory() as d:
   c=sqlite3.connect(str(Path(d)/'t.sqlite3'))
   c.executescript("""CREATE TABLE races(race_id TEXT PRIMARY KEY);
   CREATE TABLE runners(race_id TEXT,horse_number INTEGER,horse_id TEXT,payload_json TEXT,PRIMARY KEY(race_id,horse_number));
   CREATE TABLE results(race_id TEXT,horse_number INTEGER,payload_json TEXT,PRIMARY KEY(race_id,horse_number));
   CREATE TABLE win_odds(race_id TEXT,horse_number INTEGER,win_odds REAL,PRIMARY KEY(race_id,horse_number));
   CREATE TABLE official_html_races(race_id TEXT,weather TEXT,going TEXT,class_text TEXT,condition_text TEXT,source_url TEXT);
   CREATE TABLE official_html_runners(race_id TEXT,horse_number INTEGER,blinker_confirmed INTEGER,cancellation_status TEXT,source_url TEXT,source_sha256 TEXT,timing_status TEXT,verified_at TEXT,PRIMARY KEY(race_id,horse_number));
   CREATE TABLE laps(race_id TEXT,lap_index INTEGER,payload_json TEXT);
   CREATE TABLE payouts(race_id TEXT,bet_type TEXT,line_number INTEGER,payload_json TEXT);
   CREATE TABLE official_expansion_bad(id INT);
   CREATE TABLE metadata(key TEXT,value TEXT);
   INSERT INTO races VALUES('r');
   INSERT INTO runners VALUES('r',1,'a','{}'),('r',2,'b','{}');
   INSERT INTO official_html_runners VALUES('r',1,1,NULL,'JRA','SHA','POST_EVENT','t');
   """)
   clean_snapshot(c,2010)
   self.assertEqual(c.execute('SELECT count(*) FROM official_html_runners').fetchone()[0],1)
   self.assertEqual(c.execute('SELECT blinker_worn_confirmed FROM runner_summary ORDER BY horse_number').fetchall(),[(1,),(None,)])
   self.assertFalse(c.execute("SELECT name FROM sqlite_master WHERE name='official_expansion_bad'").fetchall())
   c.close()
