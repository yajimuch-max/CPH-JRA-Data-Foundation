import unittest,contextlib,io
from jra_master.cli import main
from jra_master.fresh import race_identity
class Year2011Tests(unittest.TestCase):
 def test_preflight_2011(self):
  with contextlib.redirect_stdout(io.StringIO()):self.assertEqual(main(['--year','2011','--mode','preflight']),0)
 def test_2009_remains_blocked(self):
  with contextlib.redirect_stderr(io.StringIO()),self.assertRaises(SystemExit):main(['--year','2009','--mode','preflight'])
 def test_observed_2011_identity(self):
  self.assertEqual(race_identity('pw01sde1006201101010120110105/AA',2011,1,'2011-01-01','2011-12-31'),'2011-01-05-中山-01')
