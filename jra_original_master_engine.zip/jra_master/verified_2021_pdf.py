"""Narrow, provenance-labelled fallback for two verified 2021 JRA archive PDFs.

The sources are *official JRA PDFs*, but these values are manually transcribed
from visual inspection (2026-10-11), not falsely described as machine-parsed.
No fallback exists for other URLs/years. Failed/changed sources remain errors.
"""
import hashlib
from pathlib import Path
import pdfplumber

ROOT = 'https://www.jra.go.jp/keiba/baba/archive/2021pdf/'

# Each item: (Friday ISO date, (Fri, Sat, Sun) cushion, turf goal, turf 4C,
# dirt goal, dirt 4C). Dates include Fridays, because those are in the PDFs.
VERIFIED_GROUPS = {
 'hanshin02.pdf': [
  ('2021-03-26', (10.1,10.2,10.3), (9.5,8.9,9.0), (10.5,11.0,9.3), (7.0,5.4,4.7), (9.1,6.4,4.9)),
  ('2021-04-02', (9.8,9.5,10.3), (8.9,8.6,7.8), (11.9,10.5,9.7), (10.4,3.7,2.7), (9.4,4.2,3.4)),
  ('2021-04-09', (9.9,9.6,9.9), (9.7,10.1,9.8), (8.7,9.7,9.7), (7.0,5.3,3.1), (7.0,6.3,4.2)),
  ('2021-04-16', (9.9,8.8,8.8), (9.8,9.7,12.1), (10.5,10.5,11.5), (6.6,7.0,14.9), (8.5,8.3,16.5)),
  ('2021-04-23', (10.1,9.7,9.9), (9.0,8.7,8.8), (8.6,8.0,7.9), (4.6,3.7,2.9), (4.7,4.5,3.3)),
  ('2021-04-30', (9.2,9.5,9.5), (11.2,10.9,10.1), (10.8,9.1,9.6), (14.6,9.6,9.3), (14.8,9.5,10.5)),
 ],
 'chukyo06.pdf': [
  ('2021-12-03', (9.7,10.3,9.9), (14.5,14.5,13.3), (14.0,14.0,13.8), (9.9,8.2,7.2), (8.9,7.2,6.5)),
  ('2021-12-10', (9.7,9.9,10.2), (14.3,14.0,13.3), (14.1,13.1,13.1), (11.9,8.7,8.2), (11.1,8.9,8.0)),
  ('2021-12-17', (7.7,8.9,9.3), (14.8,14.9,14.2), (15.6,16.7,14.5), (17.8,17.8,12.7), (17.8,15.9,12.6)),
 ],
}
TRACKS={'hanshin02.pdf':'阪神','chukyo06.pdf':'中京'}


def expected_days(name):
    import datetime as dt
    return { (dt.date.fromisoformat(group[0])+dt.timedelta(days=i)).isoformat()
             for group in VERIFIED_GROUPS[name] for i in range(3)}


def automatic_observations_match_verified(name, observations):
    """Treat a machine parse as valid only when its archived values match
    the independently inspected official 2021 PDF for all expected days.
    """
    from datetime import date, timedelta
    index={x['date']:x for x in observations}
    if set(index)!=expected_days(name) or len(index)!=len(observations):
        return False
    for first,cushion,tg,t4,dg,d4 in VERIFIED_GROUPS[name]:
        for i in range(3):
            day=(date.fromisoformat(first)+timedelta(days=i)).isoformat()
            row=index[day]
            for key,expected in (('cushion',cushion[i]),('turf_goal',tg[i]),
                ('turf_fourth',t4[i]),('dirt_goal',dg[i]),('dirt_fourth',d4[i])):
                if row.get(key)!=expected:return False
    return True


def _verify_pdf_shape(pdf, name):
    data=Path(pdf).read_bytes()
    if not data.startswith(b'%PDF') or len(data)<1000:
        raise RuntimeError('2021 official archive fallback requires a real PDF')
    with pdfplumber.open(pdf) as doc:
        if len(doc.pages)!=1:
            raise RuntimeError('2021 official PDF page count changed; manual review required')
        page=doc.pages[0]
        text=page.extract_text() or ''
        if name=='hanshin02.pdf':
            # This PDF has text; verify the displayed triplets still match the
            # inspected official source before using the verified fallback.
            compact=''.join(text.split()).translate(str.maketrans('０１２３４５６７８９．','0123456789.'))
            missing=[]
            for group in VERIFIED_GROUPS[name]:
                for row in group[1:]:
                    signature=''.join(f'{v:.1f}' for v in row)
                    if signature not in compact:missing.append(signature)
            if missing:
                raise RuntimeError('2021 Hanshin PDF content does not match verified values; no backfill: '+repr(missing[:3]))
        elif name=='chukyo06.pdf':
            # This is a scanned image. Normal pdfplumber extraction cannot
            # validate numeric content; explicitly retain a visual-transcription
            # source label and source SHA-256. No generic OCR guess is allowed.
            if not page.images or len(text.strip())>150:
                raise RuntimeError('2021 Chukyo PDF format changed; visual source must be reviewed again')
    return hashlib.sha256(data).hexdigest()


def visually_verified_2021(track, url, pdf, previous_good_sha=None):
    """Use only for exact known URLs, never as generic missing-value imputation.

    The first imported PDF SHA is checkpointed. If JRA later updates the PDF,
    refuse to silently reuse fixed human-verified values against new content.
    """
    from datetime import date, timedelta
    name=url.removeprefix(ROOT)
    if name not in VERIFIED_GROUPS or url!=ROOT+name or track!=TRACKS[name]:
        raise RuntimeError('No visually verified official source exists for this PDF')
    source_sha=_verify_pdf_shape(pdf,name)
    if previous_good_sha and source_sha!=previous_good_sha:
        raise RuntimeError('OFFICIAL_PDF_CHANGED_HUMAN_REVIEW_REQUIRED: '+name)
    out=[]
    for first,cushion,tg,t4,dg,d4 in VERIFIED_GROUPS[name]:
        for idx in range(3):
            day=(date.fromisoformat(first)+timedelta(days=idx)).isoformat()
            out.append({'date':day,'track':track,'used_course':None,
              'cushion_time':None,'cushion':cushion[idx],
              'moisture_time':None,'turf_goal':tg[idx],'turf_fourth':t4[idx],
              'dirt_goal':dg[idx],'dirt_fourth':d4[idx],
              'source_url':url,'source_sha256':source_sha,'source_page':1,
              'raw_format':'OFFICIAL_PDF_VISUAL_2021_VERIFIED',
              'source_basis':'JRA_OFFICIAL_ARCHIVE_PDF_VISUAL_TRANSCRIPTION',
              'actual_published_at':None})
    return out
