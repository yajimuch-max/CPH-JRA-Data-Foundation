from __future__ import annotations

import hashlib
import gzip
import json
import sqlite3
from pathlib import Path


def build_report(conn: sqlite3.Connection, root: Path, race_date: str) -> dict:
    raw_rows = conn.execute(
        "SELECT snapshot_id,request_url,final_url,requested_at,responded_at,http_status,content_type,content_encoding,entity_bytes,entity_sha256,relative_path,fetcher_version,source_role FROM raw_snapshots ORDER BY snapshot_id"
    ).fetchall()
    raw = []
    bad_hash = 0
    for row in raw_rows:
        item = dict(row)
        path = root / item["relative_path"]
        stored = path.read_bytes() if path.is_file() else None
        body = gzip.decompress(stored) if stored is not None and path.suffix == ".gz" else stored
        actual = hashlib.sha256(body).hexdigest() if body is not None else None
        item["reread_sha256"] = actual
        item["integrity_pass"] = actual == item["entity_sha256"] and len(body or b"") == item["entity_bytes"]
        bad_hash += not item["integrity_pass"]
        raw.append(item)
    latest = conn.execute("SELECT * FROM pipeline_runs WHERE race_date=? ORDER BY started_at DESC LIMIT 1", (race_date,)).fetchone()
    manifests = [dict(r) for r in conn.execute("SELECT * FROM schedule_manifests WHERE race_date=?", (race_date,))]
    imports = [dict(r) for r in conn.execute(
        "SELECT ia.* FROM import_audit ia JOIN pipeline_runs pr ON pr.run_id=ia.run_id WHERE pr.race_date=? ORDER BY ia.run_id,ia.race_key", (race_date,)
    )]
    quality = [dict(r) for r in conn.execute(
        "SELECT dq.* FROM data_quality_events dq JOIN pipeline_runs pr ON pr.run_id=dq.run_id WHERE pr.race_date=? ORDER BY dq.event_id", (race_date,)
    )]
    integrity = conn.execute("PRAGMA integrity_check").fetchone()[0]
    fk = conn.execute("PRAGMA foreign_key_check").fetchall()
    return {
        "race_date": race_date,
        "latest_pipeline_run": dict(latest) if latest else None,
        "schedule_manifests": manifests,
        "raw_snapshots": raw,
        "raw_snapshot_count": len(raw),
        "raw_sha256_mismatch_count": bad_hash,
        "imports": imports,
        "data_quality_events": quality,
        "sqlite_integrity": integrity,
        "foreign_key_violation_count": len(fk),
        "pre_race_table": "races_pre_race + race_entries_pre_race",
        "result_table": "race_results",
    }


def write_report(path: Path, report: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
