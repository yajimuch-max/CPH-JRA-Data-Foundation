import unittest,tempfile,zipfile,json
from pathlib import Path
from jra_master.store import Store,encode
from jra_master.reuse import reuse_pedigree

class ReuseTests(unittest.TestCase):
 def test_actual_times_standalone_and_idempotency(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);donor=Store(root/'donor.sqlite3');donor.meta('year',2026)
   donor.c.execute("INSERT INTO horses VALUES ('H','Horse')")
   sid=donor.source({'source_id':'S','service':'JRA','role':'JRA_PEDIGREE_FOUR_FIELDS','entity_sha256':'a'*64,'http_status':200,'requested_at':'2026-10-01T01:00:00Z','raw_saved_at':None})
   for path in ['S','M','MS','MM']:donor.c.execute('INSERT INTO pedigree VALUES (?,?,?,?,?,?,?,?)',('H',path,len(path),None,'Ancestor',None,sid,'KNOWN'))
   donor.c.execute("INSERT INTO pedigree_receipts VALUES ('H','S',4,'PASS')");donor.meta('horse_identity_H',{'horse_id':'H','horse_name':'Horse'});donor.c.commit();donor.c.close()
   p=root/'donor.zip'
   with zipfile.ZipFile(p,'w') as z:z.write(root/'donor.sqlite3','MASTER.sqlite3')
   target=Store(root/'target.sqlite3');target.meta('year',2025);target.c.execute("INSERT INTO horses VALUES ('H','Horse')");target.c.commit()
   self.assertEqual(reuse_pedigree(target,p)['copied_horses'],1)
   self.assertEqual(reuse_pedigree(target,p)['copied_horses'],0)
   self.assertEqual(target.c.execute('SELECT requested_at,raw_saved_at FROM source_records').fetchone()[:],('2026-10-01T01:00:00Z',None))
   self.assertEqual(target.c.execute('PRAGMA foreign_key_check').fetchall(),[])
   self.assertEqual(target.c.execute('SELECT count(*) FROM pedigree').fetchone()[0],4)
   self.assertEqual(json.loads(target.c.execute("SELECT value FROM metadata WHERE key='year'").fetchone()[0]),2025)
   target.c.execute('DELETE FROM pedigree_receipts');target.c.execute("UPDATE horses SET horse_name='Other'");target.c.commit()
   self.assertEqual(reuse_pedigree(target,p)['name_conflicts_skipped'],['H']);target.c.close()
