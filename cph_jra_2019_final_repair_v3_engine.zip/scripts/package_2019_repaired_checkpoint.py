
from __future__ import annotations
import argparse, hashlib, json, zipfile
from pathlib import Path

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024*1024), b""):
            h.update(block)
    return h.hexdigest()

def main() -> int:
    p=argparse.ArgumentParser()
    p.add_argument("--root", required=True)
    p.add_argument("--manifest", required=True)
    p.add_argument("--output", required=True)
    a=p.parse_args()
    root=Path(a.root); manifest=Path(a.manifest); out=Path(a.output)
    out.mkdir(parents=True, exist_ok=True)
    db=root/"data"/"cph_jra_df.sqlite3"
    if not db.is_file(): raise SystemExit("CHECKPOINT_DB_MISSING")
    if not manifest.is_file(): raise SystemExit("CHECKPOINT_MANIFEST_MISSING")
    zip_path=out/"2019_repaired_base_checkpoint.zip"
    top=Path("2019_repaired_base_checkpoint")
    with zipfile.ZipFile(zip_path,"w",zipfile.ZIP_DEFLATED,compresslevel=6,allowZip64=True) as z:
        for path in sorted(p for p in root.rglob("*") if p.is_file()):
            z.write(path, top/"annual"/path.relative_to(root))
        z.write(manifest, top/"missing_odds_manifest.csv")
    digest=sha256(zip_path)
    (out/"2019_repaired_base_checkpoint_SHA256.txt").write_text(
        f"{digest}  {zip_path.name}\n",encoding="utf-8")
    print(json.dumps({"status":"PASS","checkpoint":str(zip_path),"sha256":digest},ensure_ascii=False))
    return 0
if __name__=="__main__":
    raise SystemExit(main())
