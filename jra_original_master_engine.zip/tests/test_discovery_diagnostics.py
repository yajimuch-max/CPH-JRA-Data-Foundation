import gzip,json,tempfile,unittest,hashlib
from pathlib import Path
from unittest.mock import patch
from jra_master.discovery_diagnostics import diagnose
from jra_master.store import Store
from jra_master.cli import main

ENTRY=b'<script>objParam["2610"]="C3";</script>'
MEETING=b'<a href="pw01srl10052026040220261004/AA">meeting</a>'
RESULT=b'<a href="pw01sde1005202604021120261004/AA">result</a>'

class FakeClient:
 def __init__(self,store,raw,*args,bodies=None):
  self.s=store;self.raw=Path(raw);self.raw.mkdir(exist_ok=True);self.bodies=list(bodies or [ENTRY,MEETING,RESULT]);self.calls=[]
 def request(self,url,role,body):
  self.calls.append((url,role,body));value=self.bodies.pop(0)
  if isinstance(value,Exception):raise value
  sid=self.s.source({'service':'JRA','role':role,'url':url,'http_status':200,'requested_at':'2026-10-06T14:00:00+00:00','responded_at':'2026-10-06T14:00:01+00:00'})
  self.s.c.commit();p=self.raw/(str(len(self.calls))+'.gz');p.write_bytes(gzip.compress(value));return value,sid,p
 def valid(self,sid,path):path.unlink()

class DiscoveryDiagnosticsTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.p=Path(self.temp.name);self.s=Store(self.p/'test.sqlite3')
 def tearDown(self):self.s.c.close();self.temp.cleanup()
 def run_diagnostic(self,bodies):
  client=FakeClient(self.s,self.p/'raw',bodies=bodies);r=diagnose(client,2026,[10],'2026-10-03','2026-10-04',self.p/'out');return client,r
 def test_empty_month_bytes_retained(self):
  client,r=self.run_diagnostic([ENTRY,b'<html>No meeting link</html>'])
  self.assertEqual(r['status'],'DIAGNOSTIC_EMPTY');self.assertEqual(r['months'][0]['reason'],'NO_MEETING_LINKS')
  self.assertEqual(gzip.decompress((self.p/'out/10_month_index.bin.gz').read_bytes()),b'<html>No meeting link</html>')
  self.assertEqual(len(client.calls),2);self.assertTrue((self.p/'out/SUMMARY.json').exists())
 def test_real_chain_shapes_but_no_race_body_fetch(self):
  client,r=self.run_diagnostic([ENTRY,MEETING,RESULT]);self.assertEqual(r['result_links_found'],1)
  self.assertFalse(r['coverage_verified']);self.assertEqual(len(client.calls),3)
  self.assertTrue(all(x[1].startswith('DIAGNOSTIC_') for x in client.calls))
 def test_bad_token_still_saves_entry_and_error_summary(self):
  _,r=self.run_diagnostic([b'<html>unexpected</html>']);self.assertEqual(r['status'],'DIAGNOSTIC_ERROR')
  self.assertEqual(len(r['pages']),1);self.assertIn('OFFICIAL_MONTH_TOKEN_NOT_FOUND',r['errors'][0])
 def test_network_error_has_summary(self):
  _,r=self.run_diagnostic([RuntimeError('HTTP_403')]);self.assertEqual(r['status'],'DIAGNOSTIC_ERROR')
  self.assertEqual(r['pages'],[]);self.assertTrue((self.p/'out/SUMMARY.json').exists())
 def test_out_of_range_reason(self):
  _,r=self.run_diagnostic([ENTRY,MEETING.replace(b'20261004',b'20261010')])
  self.assertEqual(r['months'][0]['reason'],'NO_MEETINGS_IN_RANGE')
 def test_cli_does_not_touch_original_state_or_pedigree(self):
  self.s.c.commit();before=hashlib.sha256((self.p/'test.sqlite3').read_bytes()).hexdigest()
  with patch('jra_master.cli.Client',side_effect=lambda store,raw,*args:FakeClient(store,raw,bodies=[ENTRY,b'<html>empty</html>'])),patch('jra_master.cli.pedigree.collect') as pedigree:
   code=main(['--year','2026','--mode','diagnose','--db',str(self.p/'test.sqlite3'),'--months','10','--start','2026-10-03','--end','2026-10-04','--with-pedigree','--output',str(self.p/'delivery')])
  self.assertEqual(code,2);pedigree.assert_not_called()
  self.assertEqual(before,hashlib.sha256((self.p/'test.sqlite3').read_bytes()).hexdigest())

if __name__=='__main__':unittest.main()
