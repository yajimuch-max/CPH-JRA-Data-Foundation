"""Official refund evidence, independent of model inputs and normal payouts."""
import json,re,time,unicodedata,urllib.parse
from pathlib import Path
from bs4 import BeautifulSoup
from .jra_parser import decode_jra,parse_result
from .store import encode,now,sha
from .network import Deferred

VERSION='REFUND_HTML_1.0.0'
INACTIVE={'取消','除外','SCRATCHED','EXCLUDED','CANCELLED'}

def parse_refunds(body):
    soup=BeautifulSoup(decode_jra(body),'lxml')
    def text(node):return unicodedata.normalize('NFKC',node.get_text(' ',strip=True))
    candidates=[]
    for node in soup.find_all(string=re.compile('返還馬番')):
        section=node.find_parent('dl')
        if section and section.find('dt') and text(section.find('dt'))=='返還':
            candidates.append(text(section));continue
        section=node.find_parent('tr')
        if section and section.find('th') and text(section.find('th'))=='返還':
            candidates.append(text(section));continue
        parent=node.parent
        for _ in range(4):
            value=text(parent)
            if re.search(r'返還馬番\s*\d',value):
                candidates.append(value);break
            parent=parent.parent
            if parent is None:break
    marker=soup.find(string=re.compile('返還馬番'))
    if marker and not candidates:raise ValueError('REFUND_NUMBERS_UNPARSED')
    if not candidates:
        # A payout section labelled refund must not silently become "none".
        for tag in soup.find_all(['dt','th']):
            if text(tag)=='返還':raise ValueError('REFUND_SECTION_UNPARSED')
        return []
    numbers=set();frames=set()
    for value in candidates:
        m=re.search(r'返還馬番\s*([\d\s番、,・，]+)',value)
        if not m:raise ValueError('REFUND_NUMBERS_UNPARSED')
        numbers.update(map(int,re.findall(r'\d+',m[1])))
        m=re.search(r'返還(?:同枠|枠番)\s*([\d\s枠、,・，]+)',value)
        if m:frames.update(map(int,re.findall(r'\d+',m[1])))
        elif re.search('返還(?:同枠|枠番)',value):raise ValueError('REFUND_FRAMES_UNPARSED')
    if not numbers or any(not 1<=n<=28 for n in numbers) or any(not 1<=n<=8 for n in frames):
        raise ValueError('REFUND_NUMBER_OUT_OF_RANGE')
    return [dict(bet_type='REFUND',line_number=1,combination_text=None,
                 payout_yen=None,payout_popularity=None,official_text='; '.join(dict.fromkeys(candidates)),
                 special_status='返還馬番 '+'、'.join(str(n)+'番' for n in sorted(numbers))+
                 (' 返還枠番 '+'、'.join(str(n)+'枠' for n in sorted(frames)) if frames else ''),
                 refund_horse_numbers=sorted(numbers),refund_frame_numbers=sorted(frames))]

def schema(c):
    c.execute('''CREATE TABLE IF NOT EXISTS refund_receipts(
      race_id TEXT PRIMARY KEY REFERENCES races(race_id),parser_version TEXT NOT NULL,
      status TEXT NOT NULL,source_url TEXT,source_sha256 TEXT,checked_at TEXT NOT NULL,
      refund_numbers_json TEXT,reason TEXT)''')

def validate(parsed,rows):
    states={r.horse_no:r.finish_status for r in parsed.results}
    numbers=[n for row in rows for n in row['refund_horse_numbers']]
    if any(n not in states or states[n] not in INACTIVE for n in numbers):
        raise ValueError('REFUND_NOT_A_CANCELLED_OR_EXCLUDED_RUNNER')

def record_receipt(c,rid,body,url,rows):
    c.execute('INSERT OR REPLACE INTO refund_receipts VALUES(?,?,?,?,?,?,?,?)',
              (rid,VERSION,'PASS',url,sha(body),now(),encode(rows[0]['refund_horse_numbers'] if rows else []),None))

def apply(s,parsed,body,sid,url):
    rows=parse_refunds(body);validate(parsed,rows);rid=parsed.race_key
    schema(s.c)
    original=dict(s.c.execute('select horse_number,horse_id from runners where race_id=?',(rid,)))
    if original!={r.horse_no:r.horse_id for r in parsed.entries}:raise ValueError('REFUND_RUNNER_IDENTITY_MISMATCH')
    # This repair cannot change cancellation states, person fields or results.
    states={no:json.loads(raw).get('finish_status') for no,raw in s.c.execute('select horse_number,payload_json from results where race_id=?',(rid,))}
    if states!={r.horse_no:r.finish_status for r in parsed.results}:raise ValueError('REFUND_RESULT_STATUS_MISMATCH')
    existing=s.c.execute("select * from payouts where race_id=? and bet_type='REFUND'",(rid,)).fetchall()
    if not rows and existing:raise ValueError('EXISTING_REFUND_MISSING_FROM_OFFICIAL_PAGE')
    if len(existing)>1:raise ValueError('AMBIGUOUS_EXISTING_REFUND_ROWS')
    if existing and existing[0]['line_number']!=1:raise ValueError('UNSUPPORTED_REFUND_LINE_NUMBER')
    with s.c:
        for row in rows:
            s.put('payouts',['race_id','bet_type','line_number'],dict(race_id=rid,bet_type='REFUND',line_number=1,payload_json=encode(row)),sid,'OFFICIAL_REFUND_RECONCILIATION_'+VERSION)
        record_receipt(s.c,rid,body,url,rows)
        if sid:s.c.execute('INSERT OR IGNORE INTO race_sources VALUES(?,?,?)',(rid,'REFUND_HTML',sid))
    return bool(rows)

def audit(c,year):
    tables={r[0] for r in c.execute("select name from sqlite_master where type='table'")}
    total=c.execute('select count(*) from races where race_date like ?',(f'{year}-%',)).fetchone()[0]
    verified=0;mismatches=0;invalid=[]
    if 'refund_receipts' in tables:
        receipts=c.execute("select p.race_id,p.refund_numbers_json,p.source_sha256 from refund_receipts p join races r using(race_id) where r.race_date like ? and p.parser_version=? and p.status='PASS'",(f'{year}-%',VERSION)).fetchall()
        for rid,raw,digest in receipts:
            try:
                expected=json.loads(raw)
                existing=[json.loads(row[0]) for row in c.execute("select payload_json from payouts where race_id=? and bet_type='REFUND'",(rid,))]
                numbers=[n for row in existing for n in row.get('refund_horse_numbers',[])]
                states={no:json.loads(payload).get('finish_status') for no,payload in c.execute('select horse_number,payload_json from results where race_id=?',(rid,))}
                ok=(isinstance(expected,list) and len(digest or '')==64 and sorted(expected)==sorted(numbers)
                    and len(existing)==int(bool(expected)) and all(states.get(n) in INACTIVE for n in expected))
            except (ValueError,TypeError,AttributeError):ok=False
            if ok:verified+=1
            else:mismatches+=1;invalid.append(rid)
    return dict(status='PASS' if total and verified==total else 'NOT_FULLY_VERIFIED',total_races=total,verified_races=verified,remaining=total-verified,receipt_data_mismatches=mismatches,receipt_data_mismatch_races=invalid,version=VERSION)

def run(s,client,year,cache,max_pages=4000,budget_seconds=10800):
    from .person_repair import result_url
    if not 2010<=year<=2026:raise ValueError('UNSUPPORTED_YEAR')
    meta=s.c.execute("select value from metadata where key='year'").fetchone()
    if not meta or json.loads(meta[0])!=year:raise ValueError('WRONG_YEAR_MASTER')
    if s.c.execute('select 1 from races where race_date not like ? limit 1',(f'{year}-%',)).fetchone():raise ValueError('CROSS_YEAR_MASTER')
    schema(s.c);s.c.commit();cache=Path(cache)/str(year);cache.mkdir(parents=True,exist_ok=True)
    queue=s.c.execute("select r.race_id from races r left join refund_receipts p using(race_id) where p.race_id is null or p.parser_version<>? or p.status<>'PASS' order by r.race_id",(VERSION,)).fetchall()
    for rid in audit(s.c,year)['receipt_data_mismatch_races']:
        if rid not in {row[0] for row in queue}:queue.append((rid,))
    started=time.monotonic();errors=[];checked=0
    for row in queue[:max_pages]:
        if time.monotonic()-started>budget_seconds-40:break
        rid=row[0];url=None
        try:
            url=result_url(s.c,rid)
            u=urllib.parse.urlsplit(url)
            if u.scheme!='https' or u.netloc!='www.jra.go.jp' or u.path!='/JRADB/accessS.html' or not u.query:
                raise ValueError('UNEXPECTED_SOURCE_URL')
            p=cache/(rid+'.html')
            if p.exists():
                body=p.read_bytes();parsed=parse_result(body,rid[:10])
                if parsed.race_key!=rid:raise ValueError('CACHED_REFUND_RACE_MISMATCH')
                sid=s.source(dict(service='JRA',role='REFUND_CACHED_HTML',url=url,entity_sha256=sha(body),integrated_at=now(),raw_state='RETAINED_REFUND_CACHE'));s.c.commit()
            else:
                body,sid,_=client.request(url,'REFUND_HTML');parsed=parse_result(body,rid[:10])
            if parsed.race_key!=rid:raise ValueError('REFUND_RACE_MISMATCH')
            apply(s,parsed,body,sid,url)
            tmp=p.with_suffix('.tmp');tmp.write_bytes(body);tmp.replace(p);checked+=1
        except Deferred:break
        except Exception as exc:
            errors.append(dict(race_id=rid,reason=str(exc)))
            with s.c:s.c.execute('INSERT OR REPLACE INTO refund_receipts VALUES(?,?,?,?,?,?,?,?)',(rid,VERSION,'FAIL',url,None,now(),None,str(exc)))
            if any(t in str(exc) for t in ['HTTP_403','HTTP_401','UNEXPECTED_SOURCE']):break
        if checked and checked%100==0:print('REFUND_PROGRESS',year,checked,flush=True)
        if len(errors)>=20:break
    result=audit(s.c,year)|dict(year=year,checked_this_run=checked,errors=errors,checked_at=now())
    s.meta('refund_audit_required',True);s.meta('refund_latest_audit',result)
    return result
