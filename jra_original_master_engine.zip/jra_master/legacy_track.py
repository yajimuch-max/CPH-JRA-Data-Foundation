"""JRA official historical (2010-2017) daily race-report PDF enrichment.

Append-only to core records: parsed facts live in dedicated tables.  PDF observations
are confirmed per race heading (date/track/race number/surface) and a dated daily
summary for the turf rail course.  No forecast-day publication times are inferred.
"""
import datetime as dt
import hashlib
import json
import re
import sqlite3
import time
import unicodedata
from pathlib import Path
from urllib.parse import urljoin, urlparse

TRACK_ROMAN = {'sapporo':'札幌','hakodate':'函館','fukushima':'福島','niigata':'新潟',
               'tokyo':'東京','nakayama':'中山','chukyo':'中京','kyoto':'京都',
               'hanshin':'阪神','kokura':'小倉'}
REPORT_ROOT = 'https://www.jra.go.jp/datafile/seiseki/report/'
GOING = ('良','稍重','重','不良')
HEADER = re.compile(r'(?P<month>\d{1,2})\s*月\s*(?P<day>\d{1,2})\s*日(?P<middle>.{0,100}?)第\s*(?P<race>\d{1,2})\s*競走')
COURSE = re.compile(r'[（(]\s*芝\s*([ABCD])\s*コース\s*[）)]')
SURFACE = re.compile(r'[（(]\s*(芝|ダート)\s*[・·･]')
NAME_RE = re.compile(r'(?P<year>20\d{2})-(?P<meeting>\d+)(?P<roman>[a-z]+)(?P<day>\d+)\.pdf$', re.I)
MEETING_RE = re.compile(r'(?P<meeting>\d+)(?P<roman>[a-z]+)\.pdf$', re.I)
# JRA's 2010 archive uses short historical filename aliases, unlike 2011+.
TRACK_2010_CODES = {**TRACK_ROMAN, 'sap':'札幌','hako':'函館','fuku':'福島',
                    'niiga':'新潟','naka':'中山','chu':'中京','kyo':'京都',
                    'han':'阪神','koku':'小倉'}


def norm(text):
    return unicodedata.normalize('NFKC', str(text or '')).replace('\u3000', ' ')


def official_report_links(year, session):
    """Use official year index, not invented days or predicted URLs."""
    from bs4 import BeautifulSoup
    url=f'{REPORT_ROOT}{year}.html'
    response=session.get(url,timeout=40);response.raise_for_status()
    index=BeautifulSoup(response.content,'html.parser')
    links={}
    for a in index.select('a[href]'):
        link=urljoin(response.url,a['href'])
        parsed=urlparse(link)
        if parsed.hostname not in ('www.jra.go.jp','jra.go.jp'):continue
        if not parsed.path.startswith(f'/datafile/seiseki/report/{year}/'):continue
        matched=NAME_RE.fullmatch(Path(parsed.path).name) if year>=2011 else MEETING_RE.fullmatch(Path(parsed.path).name)
        if not matched or (year>=2011 and int(matched['year'])!=year):continue
        roman=matched['roman'].lower()
        track_codes=TRACK_ROMAN if year>=2011 else TRACK_2010_CODES
        if roman not in track_codes:continue
        links[link]=track_codes[roman]
    return [(track,link) for link,track in sorted(links.items())]


def parse_report_pages(pages, year, track, url, source_sha256):
    """Use all verified race markers in the daily PDF (not 1 per text line).

    Legacy JRA report PDFs can contain two race headers on one PDF page;
    pdfplumber sometimes joins the second header to a previous line.  An
    explicitly verified meeting/day/race marker is necessary for each row.
    """
    from .official_expansion import extract_blocks
    src=NAME_RE.fullmatch(Path(urlparse(url).path).name)
    if not src or int(src['year'])!=year or TRACK_ROMAN.get(src['roman'].lower())!=track:
        raise ValueError('OFFICIAL_DAILY_PDF_FILENAME_MISMATCH')
    blocks=extract_blocks(pages,year,track,int(src['meeting']),int(src['day']))
    if not blocks:raise ValueError('NO_VERIFIED_RACE_HEADINGS')
    day=blocks[0]['date']
    rows=[]
    for block in blocks:
        header=block['lines'][0]
        # A going value must be printed in the HEADER itself, not in later
        # 'course record' sections; otherwise this field is missing/unknown.
        d=re.search(r'\d{1,2}\s*月\s*\d{1,2}\s*日\s*[^()（）]{0,30}?\b(稍重|不良|良|重)\b',header)
        if not d:continue
        near=block['lines'][:5]
        surface=None
        for line in near:
            m=SURFACE.search(line)
            if m:surface=m[1];break
        if surface is None:continue
        rows.append({'day':day,'race_number':block['no'],'surface':surface,
                     'going':d[1],'source_page':block['page']})
    if not rows:raise ValueError('NO_VERIFIED_RACE_HEADINGS')
    last_page=norm(pages[-1][1] if pages else '')
    courses=set(COURSE.findall(last_page)) if f'{int(day[5:7])}月{int(day[8:10])}日' in re.sub(r'\s+', '', last_page) else set()
    course=next(iter(courses)) if len(courses)==1 else None
    return day,rows,course

def parse_2010_meeting(pages, year, track, url):
    """Only course validated from printed meeting cover, never inferred daily going."""
    head=norm(' '.join(text for _,text in pages[:3]))
    # E.g. 第1回 東京競馬成績集計表 (平成22年1月30日～2月21日8日間)
    period=re.search(r'平成\s*22\s*年\s*(\d{1,2})月(\d{1,2})日\s*[~～〜-]\s*(\d{1,2})月(\d{1,2})日',head)
    exact_course=re.search(r'本競馬は[^。]{0,40}?([ABCD])\s*コースを使用して競走を施行',head)
    if not period or not exact_course:raise ValueError('MEETING_COURSE_OR_DATES_UNVERIFIED')
    try:
        lo=dt.date(year,int(period[1]),int(period[2])).isoformat()
        hi=dt.date(year,int(period[3]),int(period[4])).isoformat()
    except ValueError:raise ValueError('INVALID_MEETING_DATES')
    match=MEETING_RE.fullmatch(Path(urlparse(url).path).name)
    if not match or TRACK_2010_CODES.get(match['roman'].lower())!=track:
        raise ValueError('MEETING_FILENAME_TRACK_MISMATCH')
    return lo,hi,int(match['meeting']),exact_course[1]



def parse_2010_meeting_courses(pages, year, track, url):
    """2010 JRA meeting cover => certified course per numbered *meeting day*.

    The meeting summary sometimes says "前6日はA、後2日はB". Never
    apply a single rail letter to a meeting with mixed course assignments.
    Unknown or incomplete expressions fail closed (no guessed course).
    """
    opening=norm(pages[0][1] if pages else '')
    compact=re.sub(r'\s+', '', opening)
    period=re.search(r'平成22年(\d{1,2})月(\d{1,2})日[~～〜-](\d{1,2})月(\d{1,2})日(\d+)日間', compact)
    if not period:raise ValueError('2010_COVER_DATES_OR_DAYCOUNT_UNVERIFIED')
    lo=dt.date(year,int(period[1]),int(period[2])).isoformat()
    hi=dt.date(year,int(period[3]),int(period[4])).isoformat()
    n=int(period[5])
    if not (1<=n<=16):raise ValueError('2010_COVER_INVALID_DAYCOUNT')
    match=MEETING_RE.fullmatch(Path(urlparse(url).path).name)
    if not match or TRACK_2010_CODES.get(match['roman'].lower())!=track:
        raise ValueError('2010_MEETING_FILENAME_TRACK_MISMATCH')
    snippet=re.search(r'馬場について(.{0,350}?)競走を施行した', compact)
    if not snippet:raise ValueError('2010_COURSE_CLAUSE_UNVERIFIED')
    content=snippet[1]
    groups=list(re.finditer(r'([ABCD])コース',content))
    if not groups:raise ValueError('2010_COURSE_NOT_PRINTED')
    if len(groups)==1 and re.search(r'本競馬は[，,、]?([ABCD])コースを使用',content):
        return lo,hi,int(match['meeting']),{i:groups[0][1] for i in range(1,n+1)}
    courses={}
    pos=0
    for m in groups:
        prefix=content[pos:m.start()]
        # Requirement is a printed numbered range, never an inferred division.
        tokens=re.findall(r'(前\d+日|後\d+日|第\d+(?:[・･]\d+)*日|第\d+日[～〜-]第?\d+日)',prefix)
        if len(tokens)!=1:raise ValueError('2010_COURSE_RANGE_UNVERIFIED')
        part=tokens[0];letter=m[1]
        if part.startswith('前'):
            k=int(re.search(r'\d+',part)[0]);days=range(1,k+1)
        elif part.startswith('後'):
            k=int(re.search(r'\d+',part)[0]);days=range(n-k+1,n+1)
        elif '～' in part or '〜' in part or '-' in part:
            nums=list(map(int,re.findall(r'\d+',part)))
            if len(nums)!=2:raise ValueError('2010_COURSE_RANGE_UNVERIFIED')
            days=range(nums[0],nums[1]+1)
        else:
            nums=list(map(int,re.findall(r'\d+',part)))
            days=nums
        if not days:raise ValueError('2010_EMPTY_COURSE_DAY_RANGE')
        for day in days:
            if day<1 or day>n or day in courses:raise ValueError('2010_COURSE_DAY_OVERLAP_OR_INVALID')
            courses[day]=letter
        pos=m.end()
    if set(courses)!=set(range(1,n+1)):
        raise ValueError('2010_COURSE_DAY_COVERAGE_UNVERIFIED')
    return lo,hi,int(match['meeting']),courses


def parse_pdf_file(path,year,track,url):
    import pdfplumber
    raw=Path(path).read_bytes()
    if not raw.startswith(b'%PDF'):raise ValueError('INVALID_PDF')
    with pdfplumber.open(path) as pdf:
        pages=[(n, page.extract_text() or '') for n,page in enumerate(pdf.pages,1)]
    if year==2010:
        return (*parse_2010_meeting(pages,year,track,url),hashlib.sha256(raw).hexdigest())
    return (*parse_report_pages(pages,year,track,url,hashlib.sha256(raw).hexdigest()),
            hashlib.sha256(raw).hexdigest())


def schema(conn):
    conn.executescript('''
    CREATE TABLE IF NOT EXISTS official_legacy_report_receipts (
      source_url TEXT PRIMARY KEY, track TEXT NOT NULL, race_date TEXT,
      source_sha256 TEXT, parse_status TEXT NOT NULL,
      matched_races INTEGER NOT NULL DEFAULT 0, error TEXT, checked_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS official_legacy_race_values (
      race_id TEXT PRIMARY KEY REFERENCES races(race_id), race_date TEXT NOT NULL,
      track TEXT NOT NULL, race_number INTEGER NOT NULL, surface TEXT NOT NULL,
      going TEXT, used_turf_course TEXT, source_url TEXT NOT NULL,
      source_sha256 TEXT NOT NULL, source_page INTEGER NOT NULL,
      provenance TEXT NOT NULL, verified_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS official_legacy_revisions (
      id INTEGER PRIMARY KEY AUTOINCREMENT, race_id TEXT NOT NULL,
      before_json TEXT NOT NULL, after_json TEXT NOT NULL, observed_at TEXT NOT NULL);
    CREATE INDEX IF NOT EXISTS idx_official_legacy_date ON official_legacy_race_values(race_date,track);
    ''')
    # Existing current-archive context is kept but historical evidence is separated.
    cols={r[1] for r in conn.execute('PRAGMA table_info(official_race_track_context)')}
    if cols:
        if 'going_from_legacy_report_pdf' not in cols:
            conn.execute('ALTER TABLE official_race_track_context ADD COLUMN going_from_legacy_report_pdf TEXT')
        if 'legacy_report_source_sha256' not in cols:
            conn.execute('ALTER TABLE official_race_track_context ADD COLUMN legacy_report_source_sha256 TEXT')


def overlay_context(conn):
    tables={r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    if 'official_legacy_race_values' not in tables:return
    if 'official_race_track_context' not in tables:
        from .track_enrichment import schema as context_schema
        context_schema(conn)
    schema(conn)
    for race_id,day,track,surface,going,course,hashval in conn.execute('''
        SELECT race_id,race_date,track,surface,going,used_turf_course,source_sha256
        FROM official_legacy_race_values''').fetchall():
        conn.execute('''INSERT OR IGNORE INTO official_race_track_context
          (race_id,race_date,track,surface,going_at_0930_status,used_turf_course_status)
          VALUES(?,?,?,?,?,?)''',(race_id,day,track,surface,'NOT_RECORDED_HISTORIC_0930_SNAPSHOT','NOT_IN_ARCHIVE'))
        # Nothing is labelled as a pre-race snapshot.  Keep any legacy course
        # for turf only and do not replace a verified newer context course.
        conn.execute('''UPDATE official_race_track_context SET
          going_from_legacy_report_pdf=COALESCE(?,going_from_legacy_report_pdf),
          legacy_report_source_sha256=?,
          used_turf_course=CASE WHEN ?='芝' AND ? IS NOT NULL AND
                                  used_turf_course IS NULL THEN ? ELSE used_turf_course END,
          used_turf_course_status=CASE WHEN ?='芝' AND ? IS NOT NULL THEN
                                  'JRA_LEGACY_DAILY_REPORT' ELSE used_turf_course_status END
          WHERE race_id=?''',(going,hashval,surface,course,course,surface,course,race_id))


def _apply(conn,day,track,rows,course,source_url,hashval):
    expected={int(no):(rid,surface,json.loads(raw)) for rid,no,surface,raw in conn.execute('''
      SELECT race_id,race_number,json_extract(payload_json,'$.surface'),payload_json FROM races
      WHERE race_date=? AND track=?''',(day,track)) if surface in ('芝','ダート')}
    if not expected:raise ValueError(f'NO_MASTER_RACES {day} {track}')
    matched={}
    source_name=NAME_RE.fullmatch(Path(urlparse(source_url).path).name)
    if not source_name or TRACK_ROMAN.get(source_name['roman'].lower())!=track:
        raise ValueError('DAILY_PDF_FILENAME_NOT_VERIFIED')
    expected_meeting=f"{int(source_name['meeting'])}回{track}{int(source_name['day'])}日"
    for r in rows:
        no=r['race_number']
        if no not in expected:raise ValueError(f'PDF_RACE_NOT_IN_MASTER {no}')
        rid,surf,p=expected[no]
        if p.get('meeting_label') and p['meeting_label']!=expected_meeting:
            raise ValueError(f'MEETING_DAY_MISMATCH {no}: {p["meeting_label"]} vs {expected_meeting}')
        if surf!=r['surface']:raise ValueError(f'SURFACE_MISMATCH {no}: {surf} vs {r["surface"]}')
        original=p.get('track_condition_turf') if surf=='芝' else p.get('track_condition_dirt')
        original=original or p.get('track_condition')
        if original and original!=r['going']:raise ValueError(f'CORE_GOING_CONFLICT {no} {original} {r["going"]}')
        matched[no]=r
    now=dt.datetime.now(dt.timezone.utc).isoformat()
    for no,r in matched.items():
        rid,surf,_=expected[no]
        values={'race_id':rid,'race_date':day,'track':track,'race_number':no,'surface':surf,
                'going':r['going'],'used_turf_course':course if surf=='芝' else None,
                'source_url':source_url,'source_sha256':hashval,'source_page':r['source_page'],
                'provenance':'JRA_OFFICIAL_DAILY_POST_EVENT_REPORT','verified_at':now}
        oldrow=conn.execute('SELECT * FROM official_legacy_race_values WHERE race_id=?',(rid,)).fetchone()
        if oldrow:
            cols=[d[1] for d in conn.execute('PRAGMA table_info(official_legacy_race_values)')]
            old=dict(zip(cols,oldrow))
            comparable=('race_date','track','race_number','surface','going','used_turf_course','source_url')
            if all(old[k]==values[k] for k in comparable):
                if old['source_sha256']==hashval:continue
            else:
                if old['source_sha256']==hashval:
                    raise ValueError('CONFLICT_SAME_SOURCE_HASH '+rid)
                # Distinct PDF values may be official corrections; audit revision.
                conn.execute('''INSERT INTO official_legacy_revisions(race_id,before_json,after_json,observed_at)
                  VALUES(?,?,?,?)''',(rid,json.dumps(old,ensure_ascii=False),json.dumps(values,ensure_ascii=False),now))
            conn.execute('DELETE FROM official_legacy_race_values WHERE race_id=?',(rid,))
        keys=list(values)
        conn.execute(f"INSERT INTO official_legacy_race_values({','.join(keys)}) VALUES ({','.join('?' for _ in keys)})",
                     [values[k] for k in keys])
    expected_count=len(expected)
    complete=len(matched)==expected_count and (course is not None or all(surf!='芝' for _,surf,_ in expected.values()))
    return len(matched),complete,expected_count



def _apply_2010_course(conn,lo,hi,meeting,track,course,url,hashval):
    # Join only records whose *official existing meeting label* verifies this meeting.
    rows=conn.execute('''SELECT race_id,race_date,track,race_number,
      json_extract(payload_json,'$.surface'),meeting_label,payload_json FROM (
      SELECT race_id,race_date,track,race_number,payload_json,
       json_extract(payload_json,'$.meeting_label') AS meeting_label
      FROM races WHERE track=? AND race_date BETWEEN ? AND ?)
      ORDER BY race_date,race_number''',(track,lo,hi)).fetchall()
    matched=[]
    for rid,day,venue,no,surface,label,payload in rows:
        if not re.match(rf'^{meeting}回{re.escape(track)}\d+日$',label or ''):
            continue
        if surface!='芝':continue
        match_day=re.match(rf'^{meeting}回{re.escape(track)}(\d+)日$',label or '')
        day_index=int(match_day[1]) if match_day else None
        if isinstance(course,dict) and (day_index not in course):
            raise ValueError('2010_MASTER_COURSE_DAY_UNVERIFIED')
        matched.append((rid,day,venue,no,surface,day_index))
    if not matched:raise ValueError('2010_NO_EXACT_MEETING_TURF_RACES')
    now=dt.datetime.now(dt.timezone.utc).isoformat()
    count=0
    for rid,day,venue,no,surface,day_index in matched:
        actual_course=course[day_index] if isinstance(course,dict) else course
        old=conn.execute('SELECT used_turf_course FROM official_legacy_race_values WHERE race_id=?',(rid,)).fetchone()
        if old and old[0]!=actual_course:raise ValueError('2010_EXISTING_COURSE_CONFLICT '+rid)
        if old:continue
        conn.execute('''INSERT INTO official_legacy_race_values
          (race_id,race_date,track,race_number,surface,going,used_turf_course,source_url,
           source_sha256,source_page,provenance,verified_at)
          VALUES(?,?,?,?,?,?,?,?,?,?,?,?)''',(
            rid,day,venue,no,surface,None,actual_course,url,hashval,1,
            'JRA_OFFICIAL_2010_MEETING_COVER_COURSE_ONLY',now))
        count+=1
    return len(matched)

def sync_year(year,db_path,cache_root=Path('jra_pdf_cache'),throttle=1.2,offline=False,refresh_all=False,budget_seconds=7200):
    if year<2010 or year>2017:raise ValueError('legacy report year must be 2010..2017')
    import requests
    deadline=time.monotonic()+budget_seconds
    deferred=0
    db_path=Path(db_path)
    if not db_path.is_file():raise RuntimeError('MASTER state unavailable: set Release baseline or recover state')
    conn=sqlite3.connect(db_path)
    conn.execute('PRAGMA busy_timeout=30000')
    cache=Path(cache_root)/str(year)/'legacy_reports';cache.mkdir(parents=True,exist_ok=True)
    core=('races','runners','results','win_odds','pedigree')
    errors=[];processed=0;skipped=0;partial=0;downloaded=0;verified=0;links=[]
    try:
        before={t:conn.execute('SELECT count(*) FROM '+t).fetchone()[0] for t in core}
        bad=conn.execute('SELECT DISTINCT substr(race_date,1,4) FROM races').fetchall()
        if bad and (len(bad)!=1 or bad[0][0]!=str(year)):raise ValueError('MASTER_YEAR_MISMATCH')
        with conn:
            from .track_enrichment import schema as base_schema
            base_schema(conn);schema(conn)
        session=requests.Session();session.headers['User-Agent']='Mozilla/5.0 (JRA official report archival validation)'
        if offline:
            p=cache/'archive_index.json'
            if not p.exists():raise ValueError('OFFLINE_INDEX_MISSING')
            links=[(e['track'],e['url']) for e in json.loads(p.read_text())]
        else:
            links=official_report_links(year,session)
            if not links:raise ValueError('OFFICIAL_REPORT_INDEX_EMPTY')
            (cache/'archive_index.json').write_text(json.dumps([{'track':t,'url':u} for t,u in links],ensure_ascii=False,indent=2))
        for index,(track,url) in enumerate(links):
            if time.monotonic()>deadline-150:
                deferred=len(links)-index;break
            filename=Path(urlparse(url).path).name
            receipt=conn.execute('SELECT parse_status,source_sha256 FROM official_legacy_report_receipts WHERE source_url=?',(url,)).fetchone()
            if receipt and receipt[0] in ('PASS','PARTIAL') and not refresh_all:
                skipped+=1;continue
            try:
                pdf=cache/filename
                if offline:
                    if not pdf.exists():raise ValueError('OFFLINE_REPORT_NOT_CACHED')
                else:
                    r=session.get(url,timeout=50);r.raise_for_status()
                    if not r.content.startswith(b'%PDF'):raise ValueError('REPORT_NOT_PDF')
                    pdf.write_bytes(r.content);downloaded+=1;time.sleep(throttle)
                parsed=parse_pdf_file(pdf,year,track,url)
                if year==2010:
                    lo,hi,meeting,course,sha=parsed
                    day=lo;records=None
                else:
                    day,records,course,sha=parsed
                now=dt.datetime.now(dt.timezone.utc).isoformat()
                with conn:
                    if year==2010:
                        count=_apply_2010_course(conn,lo,hi,meeting,track,course,url,sha)
                        complete=False;expect=count # going intentionally remains unverified
                    else:
                        count,complete,expect=_apply(conn,day,track,records,course,url,sha)
                    conn.execute('''INSERT INTO official_legacy_report_receipts
                     (source_url,track,race_date,source_sha256,parse_status,matched_races,error,checked_at)
                     VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(source_url) DO UPDATE SET
                     race_date=excluded.race_date,source_sha256=excluded.source_sha256,
                     parse_status=excluded.parse_status,matched_races=excluded.matched_races,
                     error=excluded.error,checked_at=excluded.checked_at''',
                     (url,track,day,sha,'PASS' if complete else 'PARTIAL',count,
                      None if complete else f'INCOMPLETE_REPORT rows={count}/{expect}, course={course}',now))
                processed+=1;verified+=count
                if not complete:partial+=1
            except Exception as exc:
                message=f'{filename}: {type(exc).__name__}: {exc}'
                errors.append(message)
                with conn:
                    conn.execute('''INSERT INTO official_legacy_report_receipts
                     (source_url,track,parse_status,error,checked_at)
                     VALUES(?,?,?,?,?) ON CONFLICT(source_url) DO UPDATE SET
                     parse_status=excluded.parse_status,error=excluded.error,checked_at=excluded.checked_at''',
                     (url,track,'FAILED',message,dt.datetime.now(dt.timezone.utc).isoformat()))
        with conn:overlay_context(conn)
        after={t:conn.execute('SELECT count(*) FROM '+t).fetchone()[0] for t in core}
        integrity=conn.execute('PRAGMA integrity_check').fetchone()[0]
        fk=conn.execute('PRAGMA foreign_key_check').fetchall()
        if integrity!='ok' or fk or before!=after:raise ValueError(f'CORE_MUTATION_OR_DB_FAILURE {before} {after} {integrity} {len(fk)}')
        eligible={r[0] for r in conn.execute('''SELECT race_id FROM races WHERE json_extract(payload_json,'$.surface') IN ('芝','ダート')''')}
        filled={r[0] for r in conn.execute('SELECT race_id FROM official_legacy_race_values WHERE going IS NOT NULL')}
        expected_turf={r[0] for r in conn.execute("SELECT race_id FROM races WHERE json_extract(payload_json,'$.surface')='芝'")}
        with_course={r[0] for r in conn.execute('SELECT race_id FROM official_legacy_race_values WHERE used_turf_course IS NOT NULL')}
        receipt_partial=conn.execute("SELECT COUNT(*) FROM official_legacy_report_receipts WHERE parse_status='PARTIAL'").fetchone()[0]
        receipt_failed=conn.execute("SELECT COUNT(*) FROM official_legacy_report_receipts WHERE parse_status='FAILED'").fetchone()[0]
        missing=sorted(eligible-filled);missing_course=sorted(expected_turf-with_course)
        status='PASS' if not errors and not missing and not missing_course and receipt_partial==0 and receipt_failed==0 else 'PARTIAL'
        return {'year':year,'status':status,'source':'JRA_ANNUAL_ALL_RESULTS_DAILY_REPORT_PDF',
                'report_index':f'{REPORT_ROOT}{year}.html','official_pdfs_indexed':len(links),
                'pdf_downloaded_this_run':downloaded,'pdf_parsed_this_run':processed,'pdf_checkpoint_skipped':skipped,
                'deferred_due_to_budget':deferred,
                'pdf_partial_total':receipt_partial,'pdf_failed_total':receipt_failed,
                'pdf_errors_this_run':errors[:40],'races_eligible':len(eligible),
                'races_with_report_going':len(eligible & filled),'missing_going':len(missing),
                'turf_races':len(expected_turf),'turf_races_with_report_course':len(expected_turf & with_course),
                'missing_turf_course':len(missing_course),
                'missing_going_examples':missing[:15],'missing_course_examples':missing_course[:15],
                'core_table_counts_unchanged':before==after,'db_integrity':integrity,
                'note':'Historical post-event report only. Going is per race, turf course from daily summary. No 09:30 record or moisture/cushion for 2010-17. PARTIAL must not be relabelled PASS.',
                'checked_at':dt.datetime.now(dt.timezone.utc).isoformat()}
    finally:conn.close()
