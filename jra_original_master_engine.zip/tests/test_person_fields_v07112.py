import unittest,json,sqlite3
from bs4 import BeautifulSoup
from jra_master.jra_parser import _person_cell,ParseFailure
from jra_master.person_audit import audit_people

class PersonFieldsTests(unittest.TestCase):
 def row(self,s):return BeautifulSoup('<table><tr>'+s+'</tr></table>','lxml').tr
 def test_unlinked_foreign_names_remain_known_without_official_id(self):
  row=self.row('<td class="jockey">R.ムーア</td><td class="trainer">A.オブライエン</td>')
  self.assertEqual(_person_cell(row,'jockey'),('R.ムーア',None))
  self.assertEqual(_person_cell(row,'trainer'),('A.オブライエン',None))
 def test_linked_name_and_zero_padded_id_remain_unchanged(self):
  row=self.row('<td class="jockey"><a onclick="return doAction(\'x\',\'pw04kmk000666/8B\');">武 豊</a></td>')
  self.assertEqual(_person_cell(row,'jockey'),('武 豊','0666'))
 def test_href_only_official_id(self):
  row=self.row('<td class="jockey"><a href="/JRADB/accessK.html?CNAME=pw04kmk005473/8B">C.デムーロ</a></td>')
  self.assertEqual(_person_cell(row,'jockey'),('C.デムーロ','5473'))
 def test_conflicting_official_ids_are_rejected(self):
  row=self.row('<td class="jockey"><a href="pw04kmk005473/8B" onclick="pw04kmk005212/AA">C.デムーロ</a></td>')
  with self.assertRaisesRegex(ParseFailure,'AMBIGUOUS_JOCKEY_ID'):_person_cell(row,'jockey')
 def test_empty_cells_are_not_fabricated(self):
  self.assertEqual(_person_cell(self.row('<td class="jockey"> </td>'),'jockey'),(None,None))
 def audit(self,kind='FINISHED',name=None):
  c=sqlite3.connect(':memory:');c.executescript('create table runners(race_id text,horse_number int,payload_json text);create table results(race_id text,horse_number int,payload_json text);')
  c.execute('insert into runners values(?,?,?)',('R',1,json.dumps(dict(jockey_name=name,trainer_name='A.オブライエン',jockey_id=None,trainer_id=None))))
  c.execute('insert into results values(?,?,?)',('R',1,json.dumps(dict(finish_status=kind))))
  out=audit_people(c);c.close();return out
 def test_active_missing_name_blocks_admission(self):
  x=self.audit();self.assertEqual(x['status'],'MISSING_REQUIRED_NAMES');self.assertEqual(x['missing_active_names']['jockey'],1)
 def test_verified_name_with_no_official_id_is_explicitly_reported(self):
  x=self.audit(name='R.ムーア');self.assertEqual(x['status'],'PASS');self.assertEqual(x['missing_official_ids'],dict(jockey=1,trainer=1))
 def test_nonstarter_missing_name_is_separately_counted(self):
  x=self.audit(kind='取消');self.assertEqual(x['status'],'PASS');self.assertEqual(x['inactive_missing_names']['jockey'],1)
