from __future__ import annotations

import hashlib
import json
import sqlite3
import uuid
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import quote
from typing import Callable
from concurrent.futures import ThreadPoolExecutor

from . import DATA_FOUNDATION_ID, PARSER_VERSION
from .db import connect, import_race, insert_manifest, race_transaction, record_quality
from .fetcher import (FetchFailure, Snapshot, fetch, fetch_many, fetch_post_form, fetch_result_many, read_snapshot_bytes)
from .model import ParsedRace, ScheduleRace, ValidationIssue
from .parser import (TRACK_CODE, ParseFailure, decode_jra, discover_result_urls, parse_result, parse_schedule)
from .validation import schedule_order_change_keys, validate_manifest, validate_race


class PipelineFailure(RuntimeError):
    def __init__(self, stage: str, reasons: list[str]):
        super().__init__(f"{stage}: {', '.join(reasons)}")
        self.stage = stage
        self.reasons = reasons


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="microseconds")


def canonical_hash(value) -> str:
    body = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(body).hexdigest()


def schedule_url(race_date: str) -> str:
    year, month, day = race_date.split("-")
    y = int(year)
    # JRA archive path differs for older years.
    # 2018 and earlier: /keiba/calendar/YYYY/M/MMDD.html
    # 2019+ historical:  /keiba/calendarYYYY/YYYY/M/MMDD.html
    if y <= 2018:
        return f"https://www.jra.go.jp/keiba/calendar/{year}/{int(month)}/{month}{day}.html"
    branch = f"calendar{year}" if y < datetime.now().year else "calendar"
    return f"https://www.jra.go.jp/keiba/{branch}/{year}/{int(month)}/{month}{day}.html"


class Pipeline:
    def __init__(self, root: Path, db_path: Path | None = None, workers: int = 4):
        self.root = root
        self.root.mkdir(parents=True, exist_ok=True)
        self.db_path = db_path or root / "cph_jra_df.sqlite3"
        self.conn = connect(self.db_path)
        self.workers = max(1, min(int(workers), 4))

    def close(self) -> None:
        try:
            if self.conn.in_transaction:
                self.conn.commit()
            # Keep the portable artifact self-contained in the main database
            # file instead of depending on a leftover WAL sidecar.
            self.conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        finally:
            self.conn.close()

    def _start(self, race_date: str, mode: str) -> str:
        run_id = f"DFRUN-{race_date}-{uuid.uuid4().hex[:12]}"
        self.conn.execute("INSERT INTO pipeline_runs(run_id,race_date,mode,started_at,status,stage) VALUES(?,?,?,?,?,?)",
                          (run_id, race_date, mode, now(), "RUNNING", "DISCOVER"))
        self.conn.commit()
        return run_id

    def _stage(self, run_id: str, stage: str) -> None:
        self.conn.execute("UPDATE pipeline_runs SET stage=? WHERE run_id=?", (stage, run_id))
        self.conn.commit()

    def _finish(self, run_id: str, status: str, stage: str, reasons: list[str] | None = None) -> None:
        self.conn.execute("UPDATE pipeline_runs SET completed_at=?,status=?,stage=?,reason_codes_json=? WHERE run_id=?",
                          (now(), status, stage, json.dumps(reasons or []), run_id))
        self.conn.commit()

    def _record_issues(self, run_id: str, stage: str, issues: list[ValidationIssue]) -> None:
        grouped: dict[tuple, list[ValidationIssue]] = {}
        for issue in issues:
            grouped.setdefault((issue.race_key, issue.code, issue.severity, issue.message), []).append(issue)
        for (_, _, _, _), group in grouped.items():
            issue = group[0]
            event_class = "EXPECTED_NULL" if issue.severity == "INFO" else "VALIDATION_FAILURE"
            suffix = f" (count={len(group)})" if len(group) > 1 else ""
            record_quality(self.conn, run_id, stage, event_class, issue.code, issue.message + suffix, now(), issue.race_key)
        self.conn.commit()


    def _discover_2017_from_results(self, run_id: str, race_date: str,
                                    cache_only: bool) -> tuple[list[ScheduleRace], dict[str, Snapshot]]:
        ref = self.conn.execute(
            "SELECT month_index_snapshot_id FROM result_seed_urls WHERE race_date=?",
            (race_date,),
        ).fetchone()
        if ref is None:
            raise PipelineFailure("DISCOVER", ["RESULT_MONTH_INDEX_REFERENCE_MISSING"])

        raw = self.conn.execute(
            "SELECT request_url,request_method,request_body FROM raw_snapshots "
            "WHERE snapshot_id=?",
            (ref["month_index_snapshot_id"],),
        ).fetchone()
        if raw is None or raw["request_method"] != "POST" or not raw["request_body"]:
            raise PipelineFailure("DISCOVER", ["RESULT_MONTH_INDEX_SNAPSHOT_INVALID"])

        month_index = fetch_post_form(
            self.conn, self.root, raw["request_url"], "RESULT_MONTH_INDEX",
            raw["request_body"], cache_only
        )
        text = decode_jra(read_snapshot_bytes(month_index))
        ymd = race_date.replace("-", "")
        cnames = sorted(set(re.findall(
            rf"(pw01srl10(?P<track>[0-9]{{2}})[0-9]+{ymd}/[0-9A-F]{{2}})",
            text,
        )))
        if not cnames:
            raise PipelineFailure("DISCOVER", ["RESULT_MEETING_CNAME_NOT_FOUND"])

        result_urls: dict[str, str] = {}
        source_snapshot_id: int | None = None
        for cname, track_code in cnames:
            track = TRACK_CODE.get(track_code)
            if track is None:
                continue
            selection = fetch_post_form(
                self.conn, self.root,
                "https://www.jra.go.jp/JRADB/accessS.html",
                "RESULT_RACE_SELECTION",
                "cname=" + quote(cname, safe=""),
                cache_only,
            )
            if source_snapshot_id is None:
                source_snapshot_id = selection.snapshot_id
            found = discover_result_urls(read_snapshot_bytes(selection), race_date)
            for key, url in found.items():
                if key.startswith(f"{race_date}-{track}-"):
                    result_urls[key] = url

        if not result_urls or source_snapshot_id is None:
            raise PipelineFailure("DISCOVER", ["RESULT_DETAIL_URL_NOT_FOUND"])

        by_url = fetch_result_many(
            self.conn, self.root,
            [(url, "RACE_RESULT") for url in sorted(set(result_urls.values()))],
            cache_only, self.workers,
        )

        parsed: dict[str, ParsedRace] = {}
        snapshots: dict[str, Snapshot] = {}
        for _, url in sorted(result_urls.items()):
            snap = by_url[url]
            try:
                race = parse_result(read_snapshot_bytes(snap), race_date)
            except ParseFailure as exc:
                if str(exc) == "NON_FLAT_OR_UNKNOWN_RESULT":
                    continue
                raise
            parsed[race.race_key] = race
            snapshots[race.race_key] = snap

        if not parsed:
            raise PipelineFailure("DISCOVER", ["NO_FLAT_RACES"])

        races = [
            ScheduleRace(
                r.race_date, r.track, r.meeting_label, r.race_no,
                r.race_name, r.surface, r.distance_m, r.post_time, True
            )
            for r in parsed.values()
        ]
        races.sort(key=lambda r: (r.track, r.race_no))

        manifest_issues = validate_manifest(races)
        self._record_issues(run_id, "DISCOVER", manifest_issues)
        errors = [x.code for x in manifest_issues if x.severity == "ERROR"]
        if errors:
            raise PipelineFailure("DISCOVER", errors)

        manifest_payload = [asdict(r) | {"race_key": r.race_key} for r in races]
        manifest_id = f"RESULT-DERIVED-{race_date}-{canonical_hash(manifest_payload)[:16]}"
        insert_manifest(
            self.conn, manifest_id, source_snapshot_id, now(),
            canonical_hash(manifest_payload), races
        )
        self.conn.commit()
        return races, snapshots

    def discover(self, run_id: str, race_date: str, bootstrap_url: str, cache_only: bool) -> tuple[list[ScheduleRace], dict[str, Snapshot]]:
        if int(race_date[:4]) <= 2017:
            return self._discover_2017_from_results(run_id, race_date, cache_only)
        schedule = fetch(self.conn, self.root, schedule_url(race_date), "SCHEDULE", cache_only)
        races = parse_schedule(read_snapshot_bytes(schedule), race_date)
        manifest_issues = validate_manifest(races)
        self._record_issues(run_id, "DISCOVER", manifest_issues)
        errors = [x.code for x in manifest_issues if x.severity == "ERROR"]
        if errors:
            raise PipelineFailure("DISCOVER", errors)
        manifest_id = f"SCHEDULE-{race_date}-{schedule.sha256[:16]}"
        manifest_payload = [asdict(r) | {"race_key": r.race_key} for r in races]
        insert_manifest(self.conn, manifest_id, schedule.snapshot_id, now(), canonical_hash(manifest_payload), races)
        self.conn.commit()
        expected = {r.race_key for r in races if r.is_flat}
        queue = [bootstrap_url]
        seen_urls: set[str] = set()
        snapshots: dict[str, Snapshot] = {}
        discovered: dict[str, str] = {}
        # Navigation may have to pass through a non-flat race page.  Keep every
        # official result link for this date as a traversal edge, while only
        # importing links that belong to the flat-race Schedule Manifest.
        navigation_urls: dict[str, str] = {}
        while queue and set(discovered) != expected:
            url = queue.pop(0)
            if url in seen_urls:
                continue
            seen_urls.add(url)
            snap = fetch(self.conn, self.root, url, "RACE_RESULT", cache_only)
            found = discover_result_urls(read_snapshot_bytes(snap), race_date)
            for key, found_url in sorted(found.items()):
                navigation_urls[key] = found_url
                if key in expected and key not in discovered:
                    discovered[key] = found_url
            try:
                parsed = parse_result(read_snapshot_bytes(snap), race_date)
                if parsed.race_key in expected:
                    snapshots[parsed.race_key] = snap
            except ParseFailure:
                pass
            # A result page normally contains every race at its current track and
            # one navigation entry for each other track. Follow only one known
            # entry per still-incomplete track; fetching every current-track page
            # serially here would duplicate the later bounded parallel FETCH.
            if not queue and set(discovered) != expected:
                occupied = seen_urls | set(queue)
                missing_groups = sorted({key.rsplit("-", 1)[0]
                                         for key in expected - set(discovered)})
                for group in missing_groups:
                    candidates = sorted(
                        (key, found_url) for key, found_url in navigation_urls.items()
                        if key.rsplit("-", 1)[0] == group and found_url not in occupied
                    )
                    if candidates:
                        next_url = candidates[0][1]
                        queue.append(next_url)
                        occupied.add(next_url)
        missing_links = sorted(expected - set(discovered))
        if missing_links:
            raise PipelineFailure("DISCOVER", ["RESULT_URL_DISCOVERY_INCOMPLETE"] + missing_links)
        # FETCH every manifest race exactly once; cached bootstrap snapshots are reused.
        by_url = fetch_many(self.conn, self.root,
                            [(discovered[key], "RACE_RESULT") for key in sorted(expected)],
                            cache_only, self.workers)
        for key in sorted(expected):
            snapshots[key] = by_url[discovered[key]]
        return races, snapshots

    def run(self, race_date: str, bootstrap_url: str, cache_only: bool = False,
            before_import: Callable[[ParsedRace], None] | None = None) -> dict:
        mode = "CACHE_ONLY" if cache_only else "ONLINE"
        run_id = self._start(race_date, mode)
        try:
            self._stage(run_id, "DISCOVER")
            races, snapshots = self.discover(run_id, race_date, bootstrap_url, cache_only)
            flat = {r.race_key: r for r in races if r.is_flat}
            self._stage(run_id, "PARSE")
            parsed: dict[str, ParsedRace] = {}
            def parse_one(item):
                key, snap = item
                return key, parse_result(read_snapshot_bytes(snap), race_date)
            with ThreadPoolExecutor(max_workers=self.workers, thread_name_prefix="jra-parse") as pool:
                for key, race in pool.map(parse_one, sorted(snapshots.items())):
                    parsed[key] = race
            self.conn.commit()
            if set(parsed) != set(flat):
                raise PipelineFailure("PARSE", ["PARSED_RACE_SET_INCOMPLETE"] + sorted(set(flat) - set(parsed)))
            self._stage(run_id, "VALIDATE")
            all_issues: list[ValidationIssue] = []
            order_changed = schedule_order_change_keys(flat, parsed)
            for key in sorted(flat):
                all_issues.extend(validate_race(
                    flat[key], parsed[key], schedule_order_changed=key in order_changed))
            self._record_issues(run_id, "VALIDATE", all_issues)
            errors = [x.code for x in all_issues if x.severity == "ERROR"]
            if errors:
                raise PipelineFailure("VALIDATE", sorted(set(errors)))
            self._stage(run_id, "IMPORT")
            committed = 0
            for key in sorted(flat):
                snap = snapshots[key]
                race = parsed[key]
                try:
                    with race_transaction(self.conn):
                        if before_import:
                            before_import(race)
                        import_race(self.conn, race, snap.snapshot_id, PARSER_VERSION)
                        self.conn.execute(
                            "INSERT INTO import_audit VALUES(?,?,?,?,?,?,?,?)",
                            (run_id, key, snap.snapshot_id, PARSER_VERSION, "COMMITTED", len(race.entries), len(race.results), now()),
                        )
                    self.conn.commit()
                    committed += 1
                except Exception as exc:
                    self.conn.execute(
                        "INSERT OR REPLACE INTO import_audit VALUES(?,?,?,?,?,?,?,?)",
                        (run_id, key, snap.snapshot_id, PARSER_VERSION, "ROLLED_BACK", 0, 0, now()),
                    )
                    record_quality(self.conn, run_id, "IMPORT", "IMPORT_FAILURE", "RACE_TRANSACTION_ROLLBACK", str(exc), now(), key)
                    self.conn.commit()
                    raise PipelineFailure("IMPORT", ["RACE_TRANSACTION_ROLLBACK", key]) from exc
            self._stage(run_id, "AUDIT")
            audit = self.audit(race_date, expected_count=len(flat), run_id=run_id)
            if audit["status"] != "PASS":
                raise PipelineFailure("AUDIT", audit["reason_codes"])
            self._finish(run_id, "PASS", "AUDIT")
            return {"status": "PASS", "run_id": run_id, "mode": mode, "race_date": race_date,
                    "schedule_race_count": len(races), "flat_race_count": len(flat),
                    "committed_race_count": committed, "audit": audit}
        except (PipelineFailure, FetchFailure, ParseFailure) as exc:
            stage = exc.stage if isinstance(exc, PipelineFailure) else self.conn.execute("SELECT stage FROM pipeline_runs WHERE run_id=?", (run_id,)).fetchone()[0]
            reasons = exc.reasons if isinstance(exc, PipelineFailure) else [str(exc)]
            event_class = "SOURCE_FETCH_FAILURE" if isinstance(exc, FetchFailure) else "PARSE_FAILURE" if isinstance(exc, ParseFailure) else "AUDIT_FAILURE"
            record_quality(self.conn, run_id, stage, event_class, reasons[0], str(exc), now())
            self._finish(run_id, "FAIL", stage, reasons)
            raise

    def reparse(self, race_date: str) -> dict:
        run_id = self._start(race_date, "REPARSE")
        try:
            rows = self.conn.execute(
                "SELECT DISTINCT rs.* FROM raw_snapshots rs JOIN import_audit ia ON ia.source_snapshot_id=rs.snapshot_id "
                "JOIN pipeline_runs pr ON pr.run_id=ia.run_id WHERE pr.race_date=? AND pr.status='PASS' "
                "AND ia.transaction_status='COMMITTED' ORDER BY rs.snapshot_id", (race_date,)
            ).fetchall()
            if not rows:
                raise PipelineFailure("PARSE", ["NO_CACHED_RACE_SNAPSHOTS"])
            def parse_row(r):
                path = self.root / r["relative_path"]
                body = gzip.decompress(path.read_bytes()) if path.suffix == ".gz" else path.read_bytes()
                return parse_result(body, race_date)
            import gzip
            with ThreadPoolExecutor(max_workers=self.workers, thread_name_prefix="jra-reparse") as pool:
                parsed = list(pool.map(parse_row, rows))
            self._finish(run_id, "PASS", "PARSE")
            return {"status": "PASS", "run_id": run_id, "mode": "REPARSE", "parsed_race_count": len(parsed),
                    "network_requests": 0, "parser_version": PARSER_VERSION}
        except (PipelineFailure, ParseFailure) as exc:
            reasons = exc.reasons if isinstance(exc, PipelineFailure) else [str(exc)]
            self._finish(run_id, "FAIL", "PARSE", reasons)
            raise

    def audit(self, race_date: str, expected_count: int | None = None, run_id: str | None = None) -> dict:
        reasons: list[str] = []
        integrity = self.conn.execute("PRAGMA integrity_check").fetchone()[0]
        fk = self.conn.execute("PRAGMA foreign_key_check").fetchall()
        race_count = self.conn.execute("SELECT COUNT(*) FROM races_pre_race WHERE race_date=?", (race_date,)).fetchone()[0]
        entry_count = self.conn.execute("SELECT COUNT(*) FROM race_entries_pre_race WHERE race_key LIKE ?", (race_date + "-%",)).fetchone()[0]
        result_count = self.conn.execute("SELECT COUNT(*) FROM race_results WHERE race_key LIKE ?", (race_date + "-%",)).fetchone()[0]
        duplicate_entries = self.conn.execute(
            "SELECT COUNT(*) FROM (SELECT race_key,horse_id,COUNT(*) c FROM race_entries_pre_race WHERE race_key LIKE ? GROUP BY race_key,horse_id HAVING c>1)",
            (race_date + "-%",),
        ).fetchone()[0]
        if integrity != "ok": reasons.append("SQLITE_INTEGRITY_FAIL")
        if fk: reasons.append("SQLITE_FOREIGN_KEY_FAIL")
        if expected_count is not None and race_count != expected_count: reasons.append("RACE_COUNT_MISMATCH")
        if entry_count != result_count: reasons.append("PRE_RACE_RESULT_COUNT_MISMATCH")
        if duplicate_entries: reasons.append("DUPLICATE_RACE_HORSE_ID")
        return {"status": "PASS" if not reasons else "FAIL", "reason_codes": reasons,
                "sqlite_integrity": integrity, "foreign_key_violations": len(fk),
                "race_count": race_count, "entry_count": entry_count, "result_count": result_count,
                "duplicate_race_horse_id": duplicate_entries, "pre_race_result_separated": True,
                "run_id": run_id}
