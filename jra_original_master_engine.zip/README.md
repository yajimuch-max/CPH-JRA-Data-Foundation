# JRA Original MASTER incremental engine

Current build: **v0.7.1.11 — manual update from 2026, PDF pending / backfill**.

Read `README_2026_MANUAL_PDF_v07111_JA.md` first. This edition does not run
LIVE race-day observations or create schedules. It retains resumable JRA core
collection, source audit, official PDF import and provisional snapshot export.
