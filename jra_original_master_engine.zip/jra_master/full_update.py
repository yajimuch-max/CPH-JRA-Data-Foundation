"""JRA official all-in-one incremental runner (2021-23 unknown-progress safe).

No limits on ZIP byte size. Never edits the source release. Native state remains
checkpointable even when individual stages are incomplete.
"""
from __future__ import annotations
import datetime as dt
import hashlib
import json
import sqlite3
import tempfile
import zipfile
from pathlib import Path

VERSION='JRA_MASTER_UNIFIED_UPDATE_v0.5.3'
CORE=('races','horses','runners','results','win_odds','payouts','laps','corners','pedigree', 'pedigree_receipts')

def _counts(c, tables):
    known={r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    return {t:c.execute(f'SELECT COUNT(*) FROM {t}').fetchone()[0] if t in known else None for t in tables}

def _meta(c, key):
    row=c.execute('SELECT value FROM metadata WHERE key=?',(key,)).fetchone()
    if not row:return None
    try:return json.loads(row[0])
    except (ValueError,TypeError):return row[0]

def final_export(year, db, output, stages):
    """Lossless SQLite snapshot; report stage failures as PARTIAL, never PASS."""
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    db=Path(db)
    if not db.is_file():raise FileNotFoundError(f'STATE_MISSING: {db}')
    source=sqlite3.connect(db)
    try:
        if source.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise ValueError('DB_INTEGRITY_FAILED')
        if source.execute('PRAGMA foreign_key_check').fetchall():raise ValueError('DB_FOREIGN_KEYS')
        row=_meta(source,'year')
        if row!=year:raise ValueError(f'WRONG_MASTER_YEAR: {row} vs {year}')
        core=_counts(source,CORE)
        gaps={t:source.execute(f"""SELECT count(*) FROM runners r LEFT JOIN {t} x
                     ON r.race_id=x.race_id AND r.horse_number=x.horse_number
                     WHERE x.race_id IS NULL""").fetchone()[0] for t in ('results','win_odds')}
        tasks=dict(source.execute('SELECT status,COUNT(*) FROM tasks GROUP BY status'))
        issues=dict(source.execute('SELECT status,COUNT(*) FROM issues GROUP BY status'))
        track=_meta(source,'track_enrichment_audit')
        official=_meta(source,'official_expansion_audit')
        track_receipts=dict(source.execute('SELECT parse_status,COUNT(*) FROM official_track_pdf_receipts GROUP BY parse_status')) if 'official_track_pdf_receipts' in {r[0] for r in source.execute("SELECT name FROM sqlite_master WHERE type='table'")} else {}
        official_receipts=dict(source.execute('SELECT status,COUNT(*) FROM official_expansion_receipts GROUP BY status')) if 'official_expansion_receipts' in {r[0] for r in source.execute("SELECT name FROM sqlite_master WHERE type='table'")} else {}
        missing_pedigree=source.execute("""SELECT count(*) FROM horses h LEFT JOIN pedigree_receipts p
                                 ON p.horse_id=h.horse_id WHERE p.horse_id IS NULL OR p.status='NEEDS_REPARSE' """).fetchone()[0]
        verified_at=dt.datetime.now(dt.timezone.utc).isoformat()
        complete=bool(core['races']) and not any(gaps.values()) and missing_pedigree==0 and not any(k!='PASS' for k in tasks) and issues.get('OPEN',0)==0 and all(x.get('status') in ('PASS','MERGED_WITH_OFFICIAL') for x in stages.values())
        # Some older annual PDFs can only yield a limited subset. PARTIAL is
        # expected and should not hide that the new data was checkpointed.
        audit={'status':'PASS' if complete else 'PARTIAL','year':year,'engine':VERSION,'verified_at':verified_at,
               'sqlite_integrity':'ok','foreign_keys':[], 'core_counts':core,
               'runner_coverage_gaps':gaps,'missing_pedigree_receipts':missing_pedigree,
               'task_status_counts':tasks,'issue_status_counts':issues,
               'stages_this_run':stages,'last_track_audit':track,'last_official_expansion_audit':official,
               'track_pdf_receipts':track_receipts,'official_result_pdf_receipts':official_receipts,
               'provenance':'ONLY_JRA_OFFICIAL; HISTORICAL_POST_EVENT_PDF_NOT_0930_SNAPSHOT',
               'notes':['PARTIAL means at least one coverage, audit or stage gate remains unfinished.',
                        'Blank and unverified values are not inferred.',
                        'Underlying CORE rows have not been rewritten by this exporter.']}
        with tempfile.TemporaryDirectory(prefix='jra_unified_master_') as temp:
            snapshot=Path(temp)/'MASTER.sqlite3'
            target=sqlite3.connect(snapshot)
            try:source.backup(target,pages=2048);target.commit()
            finally:target.close()
            checked=sqlite3.connect(snapshot)
            try:
                if checked.execute('PRAGMA integrity_check').fetchone()[0]!='ok' or checked.execute('PRAGMA foreign_key_check').fetchall():raise ValueError('SNAPSHOT_INTEGRITY_FAILED')
                if _counts(checked,CORE)!=core:raise ValueError('CORE_COUNT_CHANGED_ON_EXPORT')
            finally:checked.close()
            raw=snapshot.read_bytes()
            manifest={'purpose':'ENGINE_INDEPENDENT_ORIGINAL_MASTER','schema_version':'2.1.0',
                      'year':year,'engine':VERSION,'built_at':verified_at,'audit_status':audit['status'],
                      'master_sha256':hashlib.sha256(raw).hexdigest(),'raw_included':False,
                      'source':'JRA_OFFICIAL_ONLY','counts':core}
            for name,obj in [('manifest.json',manifest),('AUDIT.json',audit)]:
                (Path(temp)/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
            (Path(temp)/'README.txt').write_text('JRA official-only annual SQLite master. See AUDIT.json for every stage and any partial/failed checks. Old official results PDFs do not prove pre-race publication timing.\n',encoding='utf-8')
            file=output/f'{year}_JRA_MASTER.zip'
            temporary=file.with_suffix('.zip.tmp')
            with zipfile.ZipFile(temporary,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
                for n in ('MASTER.sqlite3','manifest.json','AUDIT.json','README.txt'):z.write(Path(temp)/n,n)
            with zipfile.ZipFile(temporary) as z:
                if z.testzip() is not None:raise ValueError('ZIP_CORRUPTION')
            temporary.replace(file)
            (output/(file.name+'.sha256')).write_text(hashlib.sha256(file.read_bytes()).hexdigest()+'  '+file.name+'\n',encoding='utf-8')
            (output/f'unified_audit_{year}.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
            print('FINAL_UNIFIED_MASTER',file,'bytes',file.stat().st_size,'status',audit['status'],flush=True)
            return audit
    finally:source.close()

def _documented_2010_limit_only(year, db, audit, stages):
    """Mark a run done only if 2010's unsupported fields are the ONLY gap.

    The independent annual data audit stays PARTIAL. We never hide an incomplete
    download, an unverified course, or a core/SQLite integrity failure.
    """
    if year != 2010 or audit.get('status') != 'PARTIAL':
        return False
    if (stages.get('core',{}).get('status') != 'PASS' or
        stages.get('track',{}).get('status') != 'MERGED_WITH_OFFICIAL' or
        stages.get('official_expansion',{}).get('status') != 'PARTIAL' or
        stages.get('official_expansion',{}).get('exit_code') != 0):
        return False
    if (audit.get('sqlite_integrity') != 'ok' or audit.get('foreign_keys') or
        any(audit.get('runner_coverage_gaps',{}).values()) or
        audit.get('missing_pedigree_receipts',1) != 0 or
        any(k != 'PASS' for k in audit.get('task_status_counts',{})) or
        audit.get('issue_status_counts',{}).get('OPEN',0) != 0):
        return False
    report=audit.get('last_official_expansion_audit')
    if not isinstance(report,dict) or report.get('year') != 2010:
        return False
    total=report.get('pdf_index_count')
    if (not isinstance(total,int) or total <= 0 or
        report.get('pending_pdfs') != 0 or
        report.get('deferred_due_to_budget') != 0 or
        report.get('failed_this_run') != [] or
        report.get('receipt_status_counts') != {'PARTIAL':total} or
        report.get('2010_note') != '2010 official meeting PDF has a different structure; only validated meeting course is imported.'):
        return False
    try:
        with sqlite3.connect(db) as c:
            race_count=c.execute("SELECT COUNT(*) FROM races WHERE json_extract(payload_json,'$.surface')='芝'").fetchone()[0]
            verified=c.execute("""SELECT COUNT(*) FROM races r
                  JOIN official_legacy_race_values x ON x.race_id=r.race_id
                 WHERE json_extract(r.payload_json,'$.surface')='芝'
                   AND x.used_turf_course IN ('A','B','C','D')""").fetchone()[0]
            receipt_count=c.execute("SELECT COUNT(*) FROM official_expansion_receipts WHERE year=2010 AND status='PARTIAL'").fetchone()[0]
        return bool(race_count and verified == race_count and receipt_count == total)
    except (sqlite3.DatabaseError,OSError):
        return False

def run_full_update(*,year,db,output,core_args,core_main,with_track=True,with_official=True,refresh=False):
    """Stages are checkpointed independently; no stage rolls back a previous one."""
    stages={}
    overall=0
    try:
        core=core_main(core_args)
        stages['core']={'status':'PASS' if core==0 else 'PARTIAL','exit_code':core}
        if core not in (0,2):return core
        if core==2:overall=2
    except Exception as e:
        # Fail clearly, leave DB artifact for recovery. Do not claim a final master.
        print('CORE_STAGE_EXCEPTION',type(e).__name__,str(e),flush=True)
        raise
    if with_track and year>=2018:
        from .track_action import run_track
        print('UNIFIED_TRACK_START',year,flush=True)
        try:
            x=run_track(year,db,output,refresh_all=refresh,budget_seconds=1600,export_master=False)
            stages['track']={'status':'CHECK_AUDIT' if x==0 else 'PARTIAL','exit_code':x}
            if x:
                auditfile=Path(output)/f'track_audit_{year}.json'
                if auditfile.exists():
                    try:stages['track']['status']=json.loads(auditfile.read_text(encoding='utf8')).get('status','PARTIAL')
                    except (ValueError,OSError):pass
                overall=2
        except Exception as exc:
            stages['track']={'status':'ERROR','error':f'{type(exc).__name__}: {exc}'}
            overall=2
    elif with_track:
        stages['track']={'status':'MERGED_WITH_OFFICIAL','note':'2010-2017 course and going are extracted by official expansion, not separate track archive.'}
    if with_official:
        from .official_expansion import run
        print('UNIFIED_OFFICIAL_REPORT_START',year,flush=True)
        try:
            x=run(year,db,output,refresh=refresh,budget_seconds=2200 if year>=2018 else 3500,export_master=False)
            stages['official_expansion']={'status':'CHECK_AUDIT' if x==0 else 'PARTIAL','exit_code':x}
            if x:
                auditfile=Path(output)/f'official_expansion_audit_{year}.json'
                if auditfile.exists():
                    try:stages['official_expansion']['status']=json.loads(auditfile.read_text(encoding='utf8')).get('status','PARTIAL')
                    except (ValueError,OSError):pass
                overall=2
        except Exception as exc:
            stages['official_expansion']={'status':'ERROR','error':f'{type(exc).__name__}: {exc}'}
            overall=2
    # Look up final snapshot's audit status, not just zero exit codes.
    if Path(db).exists():
        with sqlite3.connect(db) as c:
            for key,field in [('track','track_enrichment_audit'),('official_expansion','official_expansion_audit')]:
                if key in stages and stages[key]['status']=='CHECK_AUDIT':
                    reported=_meta(c,field)
                    stage_status=reported.get('status') if isinstance(reported,dict) else 'NOT_RECORDED'
                    stages[key]['status']=stage_status
                    if stage_status!='PASS':overall=2
        audit=final_export(year,db,output,stages)
        if audit['status']!='PASS':overall=2
        # No false red failure for the expected 2010 PDF-format limitation.
        # The exported audit intentionally stays PARTIAL.
        if overall == 2 and _documented_2010_limit_only(year,db,audit,stages):
            print('::warning title=2010 known PDF limitation::All 2010 turf-course values verified; owner/blinker/class/going extraction remains unsupported. Annual audit stays PARTIAL.',flush=True)
            print('JRA_2010_EXPECTED_LIMITATION_FINISHED; AUDIT_STATUS_PARTIAL',flush=True)
            overall=0
    print('UNIFIED_UPDATE_DONE',json.dumps({'year':year,'stages':stages,'exit_code':overall},ensure_ascii=False),flush=True)
    return overall
