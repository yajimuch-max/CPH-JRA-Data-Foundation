import unittest
from jra_master.pedigree import parse
class ProfileStatus(unittest.TestCase):
 def body(self,name):
  return ('<title>競走馬情報 JRA</title><h1><span class="txt"><span class="opt">競走馬情報</span>'+name+'<span class="name_en">English(JPN)</span></span></h1><dl>'+''.join('<dt>'+x+'</dt><dd>Ancestor</dd>' for x in ['父','母','母の父','母の母'])+'</dl>').encode()
 def test_statuses(self):
  for status in ['', '放牧','入厩','登録抹消','（放牧）']:
   with self.subTest(status=status):self.assertEqual(len(parse(self.body('ヘリオス'+status),'2016102370','ヘリオス','pw01dud102016102370/63')[0]),4)
 def test_different_name_rejected(self):
  with self.assertRaisesRegex(ValueError,'NAME_MISMATCH'):parse(self.body('ヘリオス別馬放牧'),'2016102370','ヘリオス','pw01dud102016102370/63')
