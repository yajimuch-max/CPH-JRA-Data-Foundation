#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import sqlite3
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from integrate_market_data import extract_annual  # noqa: E402


WIN_ODDS_SCHEMA = """
CREATE TABLE IF NOT EXISTS win_odds (
  race_key TEXT NOT NULL,
  horse_no INTEGER NOT NULL,
  final_win_odds REAL,
  status TEXT NOT NULL,
  result_url TEXT NOT NULL,
  odds_cname TEXT NOT NULL,
  raw_sha256 TEXT NOT NULL,
  fetched_at_utc TEXT NOT NULL,
  PRIMARY KEY (race_key, horse_no),
  FOREIGN KEY (race_key, horse_no)
    REFERENCES race_entries_pre_race(race_key, horse_no)
);
CREATE INDEX IF NOT EXISTS idx_win_odds_value ON win_odds(final_win_odds);
"""


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def integrate_odds(root: Path, odds_root: Path, year: int) -> dict:
    sources = sorted(odds_root.rglob(f"{year}_*_単勝最終オッズ.sqlite3"))
    if len(sources) != 12:
        raise SystemExit(f"MONTH_DATABASE_COUNT:{len(sources)}")

    db_path = root / "data" / "cph_jra_df.sqlite3"
    con = sqlite3.connect(db_path)
    con.execute("PRAGMA foreign_keys=ON")
    con.execute("DROP TABLE IF EXISTS win_odds")
    con.executescript(WIN_ODDS_SCHEMA)
    for index, source in enumerate(sources):
        src = sqlite3.connect(source)
        error_count = src.execute("SELECT COUNT(*) FROM collection_errors").fetchone()[0]
        if error_count:
            raise SystemExit(f"MONTH_HAS_ERRORS:{source}:{error_count}")
        rows = src.execute(
            """SELECT race_key,horse_no,final_win_odds,status,
                      result_url,odds_cname,raw_sha256,fetched_at_utc
                 FROM win_odds"""
        ).fetchall()
        src.close()
        con.executemany("INSERT INTO win_odds VALUES (?,?,?,?,?,?,?,?)", rows)

    checks = {
        "month_database_count": len(sources),
        "race_count": con.execute("SELECT COUNT(*) FROM races_pre_race").fetchone()[0],
        "entry_count": con.execute("SELECT COUNT(*) FROM race_entries_pre_race").fetchone()[0],
        "odds_race_count": con.execute("SELECT COUNT(DISTINCT race_key) FROM win_odds").fetchone()[0],
        "odds_rows": con.execute("SELECT COUNT(*) FROM win_odds").fetchone()[0],
        "numeric_odds_rows": con.execute(
            "SELECT COUNT(*) FROM win_odds WHERE final_win_odds IS NOT NULL"
        ).fetchone()[0],
        "cancelled_rows": con.execute(
            "SELECT COUNT(*) FROM win_odds WHERE status='取消' AND final_win_odds IS NULL"
        ).fetchone()[0],
        "entries_without_odds": con.execute(
            """SELECT COUNT(*) FROM race_entries_pre_race e
               LEFT JOIN win_odds o USING(race_key,horse_no)
               WHERE o.race_key IS NULL"""
        ).fetchone()[0],
        "odds_without_entries": con.execute(
            """SELECT COUNT(*) FROM win_odds o
               LEFT JOIN race_entries_pre_race e USING(race_key,horse_no)
               WHERE e.race_key IS NULL"""
        ).fetchone()[0],
        "horse_name_mismatches": 0,
        "duplicate_odds_keys": con.execute(
            """SELECT COUNT(*) FROM (
               SELECT race_key,horse_no,COUNT(*) AS n
               FROM win_odds GROUP BY race_key,horse_no HAVING n>1)"""
        ).fetchone()[0],
        "month_count": con.execute(
            """SELECT COUNT(DISTINCT substr(r.race_date,1,7))
               FROM win_odds o JOIN races_pre_race r USING(race_key)"""
        ).fetchone()[0],
    }

    # Horse names are checked against the monthly source databases before they
    # are discarded from the normalized integrated table.
    for source in sources:
        alias = "src"
        con.execute(f"ATTACH DATABASE ? AS {alias}", (str(source),))
        checks["horse_name_mismatches"] += con.execute(
            f"""SELECT COUNT(*) FROM {alias}.win_odds o
                JOIN race_entries_pre_race e USING(race_key,horse_no)
                WHERE replace(o.horse_name,' ','') <> replace(e.horse_name,' ','')"""
        ).fetchone()[0]
        # End the read transaction before detaching. GitHub's SQLite build can
        # otherwise report "database ... is locked" here.
        con.commit()
        con.execute(f"DETACH DATABASE {alias}")

    checks["integrity_check"] = con.execute("PRAGMA integrity_check").fetchone()[0]
    checks["foreign_key_violations"] = len(con.execute("PRAGMA foreign_key_check").fetchall())
    checks["status"] = "PASS" if (
        checks["month_database_count"] == 12
        and checks["race_count"] == checks["odds_race_count"]
        and checks["entry_count"] == checks["odds_rows"]
        and checks["entries_without_odds"] == 0
        and checks["odds_without_entries"] == 0
        and checks["horse_name_mismatches"] == 0
        and checks["duplicate_odds_keys"] == 0
        and checks["month_count"] == 12
        and checks["integrity_check"] == "ok"
        and checks["foreign_key_violations"] == 0
    ) else "FAIL"
    con.execute("PRAGMA wal_checkpoint(TRUNCATE)")
    con.commit()
    con.close()
    if checks["status"] != "PASS":
        raise SystemExit("ODDS_INTEGRATION_AUDIT_FAILED:" + json.dumps(checks, ensure_ascii=False))
    return checks


def write_support_files(root: Path, year: int, market: dict, odds: dict) -> None:
    audit = {
        "asset": f"{year}_JRA公式データ_年間統合版",
        "status": "PASS",
        "audited_at_utc": datetime.now(timezone.utc).isoformat(),
        "scope": [
            "JRA公式年間レース・出走馬・結果",
            "全馬の最終単勝オッズ",
            "単勝人気順",
            "全券種の確定払戻",
        ],
        "market": market,
        "odds": odds,
    }
    (root / f"{year}_統合監査結果.json").write_text(
        json.dumps(audit, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    readme = f"""{year} JRA公式データ 年間統合版
===============================

最終監査: PASS

この資産は、JRA公式の年間開催データ、出走馬、結果、単勝人気順、
全券種の確定払戻、全馬の最終単勝オッズを1つのSQLite DBへ
統合した年間完成版です。

主データベース: data/cph_jra_df.sqlite3
統合監査: {year}_統合監査結果.json

収録件数
--------
- 平地レース: {odds['race_count']:,}
- 出走馬・結果・全馬単勝最終オッズ: {odds['entry_count']:,}
- 数値オッズ: {odds['numeric_odds_rows']:,}
- 取消（オッズ数値なし）: {odds['cancelled_rows']:,}
- 確定払戻: {market['payout_rows']:,}

時系列オッズ、予測、収支、購入履歴、独自評価は含みません。
このZIPと対応するSHA256ファイルを年間正本として保存してください。
月別成果物は保存不要です。
"""
    (root / "00_最初に読んでください.txt").write_text(readme, encoding="utf-8")
    (root / "SCHEMA_統合追加.sql").write_text(WIN_ODDS_SCHEMA, encoding="utf-8")


def package(root: Path, output: Path, year: int) -> tuple[Path, Path, str]:
    output.mkdir(parents=True, exist_ok=True)
    zip_path = output / f"{year}_JRA公式データ_年間統合版.zip"
    top = Path(f"{year}_JRA公式データ_年間統合版")
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED, compresslevel=6, allowZip64=True) as archive:
        for path in sorted(item for item in root.rglob("*") if item.is_file()):
            archive.write(path, top / path.relative_to(root))
    digest = file_sha256(zip_path)
    sha_path = output / f"{year}_JRA公式データ_年間統合版_SHA256.txt"
    sha_path.write_text(f"{digest}  {zip_path.name}\n", encoding="utf-8")
    return zip_path, sha_path, digest


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--year", type=int, required=True)
    parser.add_argument("--annual-root", type=Path, required=True)
    parser.add_argument("--odds-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    market = extract_annual(args.annual_root, args.year)
    odds = integrate_odds(args.annual_root, args.odds_root, args.year)
    write_support_files(args.annual_root, args.year, market, odds)
    zip_path, sha_path, digest = package(args.annual_root, args.output, args.year)
    print(json.dumps({
        "status": "PASS", "zip": str(zip_path), "sha": str(sha_path), "sha256": digest,
        "market": market, "odds": odds,
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
