"""Copy verified JRA pedigree facts between standalone annual masters."""
import json
from .importer import Archive
from .store import sha,encode,now,VERSION
from .pedigree import norm

def reuse_pedigree(s,path):
 a=Archive(path)
 try:
  src=a.c
  if src.execute('PRAGMA integrity_check').fetchone()[0]!='ok' or src.execute('PRAGMA foreign_key_check').fetchall():raise ValueError('PEDIGREE_DONOR_INTEGRITY_FAILED')
  meta={r['key']:json.loads(r['value']) for r in src.execute('SELECT * FROM metadata')}
  if meta.get('schema_version')!=VERSION:raise ValueError('PEDIGREE_DONOR_SCHEMA_MISMATCH')
  donor_year=meta.get('year');digest=sha(a.path.read_bytes());copied=0;conflicts=[];skipped=0
  if not isinstance(donor_year,int):raise ValueError('PEDIGREE_DONOR_YEAR_MISSING')
  for h in s.c.execute('SELECT * FROM horses ORDER BY horse_id').fetchall():
   hid=h['horse_id'];existing=s.c.execute('SELECT status FROM pedigree_receipts WHERE horse_id=?',(hid,)).fetchone()
   if existing and existing[0] in ('PASS','PASS_WITH_SOURCE_MISSING'):continue
   receipt=src.execute("SELECT p.*,h.horse_name FROM pedigree_receipts p JOIN horses h USING(horse_id) WHERE p.horse_id=? AND p.checked_fields=4 AND p.status='PASS'",(hid,)).fetchone()
   if not receipt:continue
   if norm(h['horse_name'])!=norm(receipt['horse_name']):conflicts.append(hid);continue
   identity=meta.get('horse_identity_'+hid)
   if not identity or identity.get('horse_id')!=hid or norm(identity.get('horse_name',''))!=norm(h['horse_name']):skipped+=1;continue
   facts=src.execute('SELECT * FROM pedigree WHERE horse_id=?',(hid,)).fetchall()
   if len(facts)!=4 or {r['path'] for r in facts}!={'S','M','MS','MM'} or any(r['status']!='KNOWN' or not r['ancestor_name'] for r in facts):skipped+=1;continue
   sources={r['source_id'] for r in facts}|{receipt['source_id']};records=[];mapped={}
   for sid in sources:
    r=src.execute('SELECT * FROM source_records WHERE source_id=?',(sid,)).fetchone()
    if not r or r['service']!='JRA' or r['http_status']!=200 or not r['entity_sha256']:break
    mapped[sid]='REUSE_'+str(donor_year)+'_'+digest[:16]+'_'+sid;rec=dict(r);rec['source_id']=mapped[sid];rec['raw_state']='NOT_RETAINED_IN_MASTER';records.append(rec)
   else:
    with s.c:
     for rec in records:
      keys=list(rec);s.c.execute('INSERT OR IGNORE INTO source_records('+','.join(keys)+') VALUES ('+','.join('?' for _ in keys)+')',[rec[k] for k in keys])
     for r in facts:
      row=dict(r);row['source_id']=mapped[row['source_id']];s.put('pedigree',['horse_id','path'],row,row['source_id'],'VERIFIED_JRA_PEDIGREE_REUSED_ACROSS_YEARS')
     s.c.execute('INSERT OR REPLACE INTO pedigree_receipts VALUES (?,?,?,?)',(hid,mapped[receipt['source_id']],4,'PASS'))
     for prefix in ['horse_identity_','horse_profile_']:
      if prefix+hid in meta:s.c.execute('INSERT OR REPLACE INTO metadata VALUES (?,?)',(prefix+hid,encode(meta[prefix+hid])))
     s.c.execute('INSERT OR REPLACE INTO metadata VALUES (?,?)',('pedigree_reuse_'+hid,encode({'donor_year':donor_year,'donor_zip_sha256':digest,'donor_source_id':receipt['source_id'],'copied_at':now(),'observed_times':'PRESERVED_FROM_DONOR; not refetched'})))
    s.task('JRA_PEDIGREE_'+hid,'PASS','Verified facts reused from annual MASTER '+str(donor_year));s.resolve('JRA_PEDIGREE_'+hid);copied+=1;continue
   skipped+=1
  return {'donor_year':donor_year,'copied_horses':copied,'name_conflicts_skipped':conflicts,'invalid_donor_receipts_skipped':skipped}
 finally:a.close()
