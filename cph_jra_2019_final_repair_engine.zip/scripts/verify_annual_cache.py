from __future__ import annotations

import argparse
import json
import sqlite3
from pathlib import Path

from cph_jra_df.pipeline import Pipeline


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--year", required=True, type=int)
    parser.add_argument("--data-root", required=True)
    args = parser.parse_args()
    root = Path(args.data_root).resolve()
    conn = sqlite3.connect(root / "cph_jra_df.sqlite3")
    dates = conn.execute(
        "SELECT d.race_date, s.seed_url FROM year_race_days d "
        "JOIN result_seed_urls s ON s.race_date=d.race_date "
        "WHERE substr(d.race_date,1,4)=? ORDER BY d.race_date",
        (str(args.year),),
    ).fetchall()
    expected = conn.execute(
        "SELECT COUNT(*) FROM year_race_days WHERE substr(race_date,1,4)=?",
        (str(args.year),),
    ).fetchone()[0]
    conn.close()
    if len(dates) != expected or not dates:
        raise SystemExit("annual seed coverage is incomplete")

    pipeline = Pipeline(root, workers=1)
    cache_pass = reparse_pass = 0
    failures: list[dict] = []
    try:
        for race_date, seed_url in dates:
            try:
                pipeline.run(race_date, seed_url, cache_only=True)
                cache_pass += 1
            except Exception as exc:
                failures.append({"date": race_date, "mode": "CACHE_ONLY", "error": str(exc)})
        if not failures:
            for race_date, _ in dates:
                try:
                    pipeline.reparse(race_date)
                    reparse_pass += 1
                except Exception as exc:
                    failures.append({"date": race_date, "mode": "REPARSE", "error": str(exc)})
    finally:
        pipeline.close()

    result = {
        "status": "PASS" if not failures else "FAIL",
        "year": args.year,
        "expected_dates": expected,
        "cache_only_pass": cache_pass,
        "reparse_pass": reparse_pass,
        "workers": 1,
        "network_requests_during_reparse": 0,
        "failures": failures,
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
