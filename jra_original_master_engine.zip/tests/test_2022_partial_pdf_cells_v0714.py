"""2022 Hanshin source-text regression: malformed Friday must not erase Sat/Sun.
All values are used only in fixtures; no PDF/source was fetched in this test.
"""
import unittest
from jra_master.track_enrichment import extract_legacy, extract_legacy_text_fallback

URL='https://www.jra.go.jp/keiba/baba/archive/2022pdf/hanshin01.pdf'
ROWS=[
 ['場所','金曜日','土曜日','日曜日'],
 ['芝コースクッション値','','10.0','9.9','9.8'],
 ['芝コース含水率','ゴール前','8..8','9.1','8.7'],
 ['', '４コーナー','9.8','10.8','11.1'],
 ['ダートコース含水率','ゴール前','4.6','3.9','3.2'],
 ['', '４コーナー','3.9','4.2','3.3']]
class FakeTable:
 bbox=(0,100,500,350)
 def extract(self):return ROWS
class FakePage:
 def find_tables(self,**kwargs):return [FakeTable()]
 def extract_text_lines(self):return [{'top':10,'text':'第５日・第６日（2022年2月25日～27日）'}]
 def extract_text(self):return '\n'.join(['第５日・第６日（2022年2月25日～27日）','場所 金曜日 土曜日 日曜日',
  '芝コース含水率 ゴール前 8..8 9.1 8.7','４コーナー 9.8 10.8 11.1',
  'ダートコース含水率 ゴール前 4.6 3.9 3.2','４コーナー 3.9 4.2 3.3'])

class TestPartialCells2022(unittest.TestCase):
 def test_valid_days_survive_malformed_friday(self):
  rows=extract_legacy(FakePage(),2022,'阪神',URL,'test-sha',1)
  self.assertEqual([r['date'] for r in rows],['2022-02-26','2022-02-27'])
  self.assertEqual([(r['cushion'],r['turf_goal'],r['turf_fourth'],r['dirt_goal'],r['dirt_fourth']) for r in rows],
                    [(9.9,9.1,10.8,3.9,4.2),(9.8,8.7,11.1,3.2,3.3)])
  self.assertTrue(all(r['used_course'] is None for r in rows))
 def test_bad_cell_not_silently_normalized(self):
  rows=extract_legacy(FakePage(),2022,'阪神',URL,'sha',1)
  self.assertNotIn('2022-02-25',[x['date'] for x in rows])
 def test_valid_friday_preserved_when_cell_correct(self):
  prev=ROWS[2][2]
  try:
   ROWS[2][2]='8.8'
   rows=extract_legacy(FakePage(),2022,'阪神',URL,'sha',1)
   self.assertEqual(len(rows),3)
   self.assertEqual(rows[0]['turf_goal'],8.8)
  finally:ROWS[2][2]=prev
 def test_invalid_cushion_not_certified_post_2020(self):
  prev=ROWS[1][3]
  try:
   ROWS[1][3]='???'
   rows=extract_legacy(FakePage(),2022,'阪神',URL,'sha',1)
   self.assertEqual([x['date'] for x in rows],['2022-02-27'])
  finally:ROWS[1][3]=prev
 def test_unambiguous_conflict_fails_closed(self):
  class Duplicate(FakeTable):
   def extract(self):return ROWS+[['芝コース含水率','ゴール前','8..8','8.5','8.7']]
  class Page(FakePage):
   def find_tables(self,**kwargs):return [Duplicate()]
  with self.assertRaisesRegex(ValueError,'Conflicting'):
   extract_legacy(Page(),2022,'阪神',URL,'sha',1)
 def test_fallback_cannot_certify_post_2020_without_cushion(self):
  rows=extract_legacy_text_fallback(FakePage(),2022,'阪神',URL,'sha',1)
  self.assertEqual(rows,[])

if __name__=='__main__':unittest.main()
