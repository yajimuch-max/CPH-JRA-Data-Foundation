import datetime as dt
import json
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from zoneinfo import ZoneInfo

from jra_master.live_track import URLS, parse_live_html, capture_live
from jra_master.track_enrichment import schema, upsert_obs
from jra_master.track_action import sync_year

DAY='2026-10-10'
NOW=dt.datetime(2026,10,10,10,14,tzinfo=ZoneInfo('Asia/Tokyo'))

def page(*,day='10',eve='',track='東京',cushion='9.6',turf='12.3',dirt='5.5'):
    c=f'<span class="actual-cushion">{cushion}</span>' if cushion else ''
    weekday='土' if day=='10' else '日' if day=='11' else '土'
    return f'''<!doctype html><html><body>
    <h2>第4回{track}競馬第3日{eve}（2026年10月{day}日（{weekday}曜））</h2>
    <h3>芝のクッション値</h3><h4>測定時刻</h4><p>7:00</p><h4>クッション値</h4>
    {c}<ul><li>12</li><li>10</li><li>8</li><li>7</li></ul>
    <h3>含水率</h3><h4>測定時刻</h4><p>5:15</p>
    <h4>ゴール前と4コーナーの含水率</h4>
    <table><tr><th></th><th>ゴール前</th><th>4コーナー</th></tr>
    <tr><th>芝</th><td>{turf}</td><td>13.1</td></tr>
    <tr><th>ダート</th><td>{dirt}</td><td>6.1</td></tr></table>
    <h4>含水率表</h4><table><tr><th>芝</th><td>良</td></tr></table>
    </body></html>'''.encode()

class Response:
    def __init__(self,content):self.content=content
    def raise_for_status(self):pass
class Session:
    def __init__(self, pages):self.pages=pages
    def get(self,url,timeout):return Response(self.pages[url])

class WeeklyLiveTests(unittest.TestCase):
    def test_parse_exact_complete(self):
        x=parse_live_html(page(),URLS[0],DAY)
        self.assertEqual(x['status'],'COMPLETE')
        self.assertEqual(x['track'],'東京')
        self.assertEqual(x['metrics']['turf_cushion'],9.6)
        self.assertEqual(x['metrics']['turf_goal_moisture'],12.3)
    def test_no_gauge_fabrication(self):
        x=parse_live_html(page(cushion=''),URLS[0],DAY)
        self.assertEqual(x['status'],'PARTIAL_VALUES')
        self.assertIsNone(x['metrics']['turf_cushion'])
    def test_wrong_race_day_rejected(self):
        self.assertIsNone(parse_live_html(page(day='11'),URLS[0],DAY))
    def test_friday_preview_rejected(self):
        self.assertIsNone(parse_live_html(page(eve='前日'),URLS[0],DAY))
    def test_wrong_track_site_rejected(self):
        with self.assertRaises(ValueError):parse_live_html(page(),'https://fake.jra.example/baba/',DAY)
    def test_scrambled_row_no_acceptance(self):
        x=parse_live_html(page(turf='13..1'),URLS[0],DAY)
        self.assertNotEqual(x['status'],'COMPLETE')
    def test_early_returns_without_network(self):
        x=capture_live(2026,'ignored.db',now=NOW.replace(hour=8))
        self.assertEqual(x['status'],'TOO_EARLY')
    def test_history_prohibited(self):
        with self.assertRaises(ValueError):capture_live(2026,'ignored.db',day='2026-10-04',now=NOW)
    def test_idempotence_and_no_archive_overwrite(self):
        with tempfile.TemporaryDirectory() as t:
            path=Path(t)/'MASTER.sqlite3';c=sqlite3.connect(path)
            c.execute('CREATE TABLE races(race_id TEXT PRIMARY KEY,race_date TEXT,track TEXT,payload_json TEXT)')
            c.execute('''CREATE TABLE supplemental_records(table_name TEXT,item_key TEXT,race_id TEXT,horse_id TEXT,payload_json TEXT,PRIMARY KEY(table_name,item_key))''')
            c.execute('INSERT INTO races VALUES (?,?,?,?)',('race','2026-10-10','東京','{}'))
            schema(c);c.commit();c.close()
            ses=Session({URLS[0]:page()})
            x=capture_live(2026,path,Path(t)/'delivery',now=NOW,session=ses,urls=(URLS[0],))
            self.assertEqual(x['status'],'LIVE_CAPTURED')
            x=capture_live(2026,path,Path(t)/'delivery',now=NOW,session=ses,urls=(URLS[0],))
            self.assertEqual(x['records'][0]['status'],'UNCHANGED')
            c=sqlite3.connect(path)
            self.assertEqual(c.execute("select count(*) from supplemental_records").fetchone()[0],1)
            self.assertEqual(c.execute("select source_basis from official_track_daily").fetchone()[0],'JRA_OFFICIAL_LIVE_HTML')
            archive={'date':DAY,'track':'東京','source_url':'https://www.jra.go.jp/keiba/baba/archive/2026pdf/tokyo04.pdf',
                'source_sha256':'verifiedarchive','source_page':1,'raw_format':'MODERN_ROW',
                'used_course':'A','cushion_time':'07:00','cushion':9.6,'moisture_time':'05:00',
                'turf_goal':12.3,'turf_fourth':13.1,'dirt_goal':5.5,'dirt_fourth':6.1}
            upsert_obs(c,[archive]);c.commit();c.close()
            x=capture_live(2026,path,Path(t)/'delivery',now=NOW,session=ses,urls=(URLS[0],))
            self.assertEqual(x['records'][0]['status'],'ARCHIVE_ALREADY_VERIFIED')
            c=sqlite3.connect(path)
            self.assertEqual(c.execute("select source_basis from official_track_daily").fetchone()[0],'JRA_OFFICIAL_ARCHIVE_PDF')
            c.close()
    def test_pdf_pending_even_when_all_live_fields_present(self):
        from unittest.mock import patch
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'MASTER.sqlite3';c=sqlite3.connect(p)
            c.executescript('''CREATE TABLE races(race_id TEXT PRIMARY KEY,race_date TEXT,track TEXT,payload_json TEXT);
                CREATE TABLE runners(race_id TEXT);CREATE TABLE results(race_id TEXT);
                CREATE TABLE win_odds(race_id TEXT);CREATE TABLE pedigree(horse_id TEXT);
                CREATE TABLE supplemental_records(table_name TEXT,item_key TEXT,race_id TEXT,horse_id TEXT,payload_json TEXT,PRIMARY KEY(table_name,item_key));''')
            c.execute('INSERT INTO races VALUES(?,?,?,?)',('race',DAY,'東京','{}'))
            schema(c);c.commit();c.close()
            capture_live(2026,p,Path(t)/'delivery',now=NOW,session=Session({URLS[0]:page()}),urls=(URLS[0],))
            with patch('jra_master.track_enrichment.get_archive_links',return_value=[]):
                result=sync_year(2026,p,cache_root=Path(t)/'cache',throttle=0,budget_seconds=350)
            self.assertEqual(result['status'],'PARTIAL')
            self.assertEqual(result['weekly_missing_race_track_days'],0)
            self.assertEqual(result['archive_pdf_verification_pending_days'],1)
            self.assertEqual(result['live_provisional_race_track_days'],1)

    def test_partial_stored_evidence_not_daily(self):
        with tempfile.TemporaryDirectory() as t:
            path=Path(t)/'MASTER.sqlite3';c=sqlite3.connect(path)
            c.execute('CREATE TABLE races(race_id TEXT PRIMARY KEY,race_date TEXT,track TEXT,payload_json TEXT)')
            c.execute('''CREATE TABLE supplemental_records(table_name TEXT,item_key TEXT,race_id TEXT,horse_id TEXT,payload_json TEXT,PRIMARY KEY(table_name,item_key))''')
            schema(c);c.commit();c.close()
            x=capture_live(2026,path,Path(t)/'delivery',now=NOW,session=Session({URLS[0]:page(cushion='')}),urls=(URLS[0],))
            self.assertEqual(x['status'],'PARTIAL')
            c=sqlite3.connect(path)
            self.assertEqual(c.execute("select count(*) from official_track_daily").fetchone()[0],1)
            self.assertEqual(c.execute("select turf_cushion,turf_goal_moisture from official_track_daily").fetchone(),(None,12.3))
            self.assertEqual(c.execute("select count(*) from supplemental_records").fetchone()[0],1)
            c.close()

if __name__=='__main__':unittest.main()
