import unittest,tempfile,json,sqlite3,zipfile
from pathlib import Path
from jra_master.store import Store,encode
from jra_master.cli import export
from jra_master.unified import normalize_export_store,FIELDS
class UnifiedExportTests(unittest.TestCase):
 def fixture(self,root,complete=True):
  s=Store(root/'state.sqlite3')
  s.c.execute("INSERT INTO races VALUES ('R','2016-01-05','TEST',1,'FLAT',?)",(encode({'race_name':'Race','source_snapshot_id':9}),))
  s.c.execute("INSERT INTO horses VALUES ('H','Horse')")
  s.c.execute("INSERT INTO runners VALUES ('R',1,'H',?)",(encode({'horse_name':'Horse','horse_id':'H','body_weight_kg':496,'body_weight_change_kg':0,'horse_no':1}),))
  s.c.execute("INSERT INTO results VALUES ('R',1,?)",(encode({'horse_no':1,'finish_position':1,'final_3f':38.3,'official_average_1f':15.7,'average_1f':13.2}),))
  s.c.execute("INSERT INTO win_odds VALUES ('R',1,8.8,'OK',NULL,?)",(encode({'final_win_odds':8.8,'horse_no':1,'horse_name':'Horse','status':'OK'}),))
  sid=s.source({'source_id':'S','service':'JRA','role':'JRA_PEDIGREE_FOUR_FIELDS','entity_sha256':'a'*64,'http_status':200,'requested_at':'2026-10-01T01:00:00Z','responded_at':None,'raw_saved_at':None})
  if complete:
   for path in ['S','M','MS','MM']:s.c.execute('INSERT INTO pedigree VALUES (?,?,?,?,?,?,?,?)',('H',path,len(path),None,'Ancestor',None,sid,'KNOWN'))
   s.c.execute("INSERT INTO pedigree_receipts VALUES ('H','S',4,'PASS')")
  s.c.execute('INSERT INTO supplemental_records VALUES (?,?,?,?,?)',('result_details','D','R','H',encode({'horse_id':'H','body_weight_official':'496(0)','finish_display':'1','final_section_official':'38.3','final_section_header':'推定上り'})))
  s.c.execute('INSERT INTO supplemental_records VALUES (?,?,?,?,?)',('cancelled_races','C','C',None,encode({'status':'取りやめ','source_snapshot_id':9})))
  s.c.execute('INSERT INTO revisions(table_name,reason) VALUES (?,?)',('results','OLD_IMPORT'))
  s.c.commit();return s
 def readback(self,root):
  with zipfile.ZipFile(root/'out'/'2016_JRA公式データ_原本MASTER.zip') as z:(root/'read.sqlite3').write_bytes(z.read('MASTER.sqlite3'))
  return sqlite3.connect('file:'+str(root/'read.sqlite3')+'?mode=ro&immutable=1',uri=True)
 def test_complete_snapshot_preserves_state_and_provenance(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);s=self.fixture(root)
   before={t:[tuple(r) for r in s.c.execute('select * from '+t)] for t in ['races','runners','results','source_records','pedigree','tasks','revisions','supplemental_records']}
   self.assertEqual(export(s,root/'out',2016)['status'],'PASS')
   for t,rows in before.items():self.assertEqual(rows,[tuple(r) for r in s.c.execute('select * from '+t)],t)
   a=self.readback(root);self.assertEqual(a.execute('select count(*) from revisions').fetchone()[0],0)
   expected_sources=[r[:10]+('NOT_RETAINED_IN_MASTER',)+r[11:] for r in before['source_records']]
   self.assertEqual(expected_sources,a.execute('select * from source_records').fetchall())
   self.assertEqual(before['pedigree'],a.execute('select * from pedigree').fetchall())
   q=json.loads(a.execute('select payload_json from results').fetchone()[0]);self.assertEqual(q['average_1f_seconds'],15.7);self.assertEqual(q['legacy_average_1f_seconds'],13.2)
   self.assertEqual(a.execute('select table_name from supplemental_records').fetchall(),[('cancelled_races',)])
   a.close();s.c.close()
 def test_future_corrections_survive_repeated_exports(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);s=self.fixture(root);export(s,root/'out',2016)
   s.put('win_odds',['race_id','horse_number'],{'race_id':'R','horse_number':1,'win_odds':9.4,'odds_status':'OK','source_id':None,'payload_json':encode({'final_win_odds':9.4,'horse_no':1,'horse_name':'Horse','status':'OK'})},reason='NEW_CORRECTION');s.c.commit()
   for _ in range(2):
    export(s,root/'out',2016);a=self.readback(root);self.assertEqual(a.execute('select reason from revisions').fetchall(),[('NEW_CORRECTION',)]);self.assertEqual(a.execute('select win_odds from win_odds').fetchone()[0],9.4);a.close()
   s.c.close()
 def test_partial_does_not_establish_baseline(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);s=self.fixture(root,False);self.assertEqual(export(s,root/'out',2016)['status'],'PARTIAL');self.assertIsNone(s.c.execute("select value from metadata where key='unified_export_baseline'").fetchone());a=self.readback(root);self.assertEqual(a.execute('select count(*) from revisions').fetchone()[0],1);a.close();s.c.close()
 def test_projection_is_idempotent_and_uniform(self):
  with tempfile.TemporaryDirectory() as tmp:
   s=self.fixture(Path(tmp));normalize_export_store(s,1)
   before={t:[tuple(r) for r in s.c.execute('select * from '+t)] for t in FIELDS};normalize_export_store(s,1)
   for t,rows in before.items():
    self.assertEqual(rows,[tuple(r) for r in s.c.execute('select * from '+t)])
    for raw, in s.c.execute('select payload_json from '+t):self.assertEqual(set(json.loads(raw)),set(FIELDS[t]))
   s.c.close()

 def test_failed_projection_does_not_establish_baseline(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);s=self.fixture(root)
   s.c.execute("INSERT INTO supplemental_records VALUES ('UNRECOGNIZED','U',NULL,NULL,'{}')");s.c.commit()
   with self.assertRaises(AssertionError):export(s,root/'out',2016)
   self.assertIsNone(s.c.execute("select value from metadata where key='unified_export_baseline'").fetchone())
   self.assertEqual(s.c.execute('select count(*) from supplemental_records').fetchone()[0],3);s.c.close()
