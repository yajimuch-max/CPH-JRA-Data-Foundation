
from __future__ import annotations
import argparse, csv, subprocess, sys
from pathlib import Path

def main() -> int:
    p=argparse.ArgumentParser()
    p.add_argument("--manifest", required=True)
    p.add_argument("--engine-script", required=True)
    p.add_argument("--output-root", required=True)
    a=p.parse_args()
    months=set()
    with Path(a.manifest).open("r",encoding="utf-8",newline="") as f:
        for row in csv.DictReader(f):
            if row.get("month"): months.add(int(row["month"]))
    if not months:
        print("NO_MISSING_ODDS")
        return 0
    out_root=Path(a.output_root); out_root.mkdir(parents=True,exist_ok=True)
    for month in sorted(months):
        out=out_root/f"month{month:02d}"
        subprocess.run([
            sys.executable,a.engine_script,
            "--manifest",a.manifest,
            "--year","2019","--month",str(month),
            "--mode","full","--output",str(out)
        ], check=True)
    return 0
if __name__=="__main__":
    raise SystemExit(main())
