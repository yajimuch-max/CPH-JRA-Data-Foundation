import unittest,sqlite3,json,tempfile
from pathlib import Path
from unittest.mock import patch
from jra_master.store import Store
from jra_master.model import ParsedRace,RaceEntry,RaceResult
from jra_master.html_first import schema,apply,valid_existing_cname,source_index,run

RID='2012-02-04-東京-05'
BODY='cname=pw01sde1005201201030520120204%2F01'
HTML=b'<html><div class="race_title">'+'サラ系3歳 新馬 （混合）［指定］ 馬齢 コース：1,800メートル（芝・左）</div><table><thead><tr><th class="place">着順</th></tr></thead><tbody><tr><td class="num">7</td><td class="horse">TEST</td><td class="place">1</td></tr></tbody></table></html>'.encode('cp932')

class HTMLFirstTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);self.s=Store(self.root/'year.sqlite3');self.s.meta('year',2012)
  self.s.c.execute('INSERT INTO races VALUES (?,?,?,?,?,?)',(RID,'2012-02-04','東京',5,'FLAT',json.dumps({'surface':'芝','distance_m':1800})))
  self.s.c.execute('INSERT INTO horses VALUES (?,?)',('2009100001','TEST'))
  self.s.c.execute('INSERT INTO runners VALUES (?,?,?,?)',(RID,7,'2009100001','{}'))
  self.s.c.execute('INSERT INTO results VALUES (?,?,?)',(RID,7,'{}'))
  self.s.c.execute("INSERT INTO win_odds VALUES (?,?,?,? ,?,?)",(RID,7,12.0,'OK',None,'{}'))
  meta={'request_body':BODY}
  self.s.c.execute("INSERT INTO source_records VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",('S','JRA','RACE_RESULT','https://www.jra.go.jp/JRADB/accessS.html',None,None,None,None,None,200,'NOT_RETAINED',json.dumps(meta)))
  self.s.c.execute("INSERT INTO race_sources VALUES (?,?,?)",(RID,'RESULT_HTML','S'))
  self.s.c.commit();schema(self.s.c)
 def tearDown(self):self.s.c.close();self.tmp.cleanup()
 def parsed(self,track='東京',id='2009100001'):
  return ParsedRace('2012-02-04',track,'1回東京3日',5,'メイクデビュー東京','芝',1800,'芝左','12:30','晴','良',None,
   [RaceEntry(7,4,id,'TEST','牡3',56.0,None,None,None,None,472,None)],
   [RaceResult(7,'FINISHED',1,'1:50.4',None,[],33.6)])
 def test_url_must_come_from_actual_saved_result_link(self):
  self.assertEqual(source_index(self.s.c,2012),{RID:BODY})
  self.assertIsNone(valid_existing_cname(BODY,'2012-02-04-東京-06'))
  self.assertIsNone(valid_existing_cname('cname=pw01sde1005201201030520120204%2F01&other=x',RID))
  self.assertIsNone(valid_existing_cname('CNAME=pw01sde1005201201030520120204%2F01',RID))
 def test_valid_html_additive_and_idempotent(self):
  with patch('jra_master.html_first.parse_result',return_value=self.parsed()):
   apply(self.s.c,RID,HTML,'https://www.jra.go.jp/JRADB/accessS.html?CNAME=TEST')
   apply(self.s.c,RID,HTML,'https://www.jra.go.jp/JRADB/accessS.html?CNAME=TEST')
  self.assertIn('新馬',self.s.c.execute('SELECT condition_text FROM official_html_races').fetchone()[0])
  self.assertEqual(self.s.c.execute('SELECT going FROM official_html_races').fetchone()[0],'良')
  self.assertEqual(self.s.c.execute('SELECT status FROM official_html_receipts').fetchone()[0],'PASS')
  self.assertEqual(self.s.c.execute('SELECT count(*) FROM official_html_revisions').fetchone()[0],0)
  self.assertEqual(self.s.c.execute('SELECT count(*) FROM results').fetchone()[0],1)
 def test_wrong_runner_never_written(self):
  with patch('jra_master.html_first.parse_result',return_value=self.parsed(id='BAD')):
   with self.assertRaisesRegex(ValueError,'RUNNER_IDENTITIES'):
    apply(self.s.c,RID,HTML,'https://www.jra.go.jp/JRADB/accessS.html')
  self.assertEqual(self.s.c.execute('SELECT count(*) FROM official_html_races').fetchone()[0],0)
 def test_other_race_never_written(self):
  with patch('jra_master.html_first.parse_result',return_value=self.parsed(track='京都')):
   with self.assertRaisesRegex(ValueError,'HEADER_MISMATCH'):
    apply(self.s.c,RID,HTML,'https://www.jra.go.jp/JRADB/accessS.html')
 def test_offline_reports_incomplete_without_fake_success(self):
  self.s.c.close()
  report=run(2012,self.root/'year.sqlite3',self.root/'out',max_pages=1,offline=True)
  self.assertEqual(report['status'],'PARTIAL');self.assertEqual(report['remaining'],1)
  self.assertEqual(report['missing_source_links'],0)
  self.assertEqual(report['fetched_this_run'],0)
  self.s=Store(self.root/'year.sqlite3')
if __name__=='__main__':unittest.main()
