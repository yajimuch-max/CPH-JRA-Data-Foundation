"""Explicit private-copy repair; successful collection tasks do not skip it."""
import argparse,json,zipfile,hashlib,sqlite3,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from jra_master.store import Store
from jra_master.network import Client
from jra_master.person_repair import run

def main():
 p=argparse.ArgumentParser();p.add_argument('--source-zip',required=True);p.add_argument('--work-db',required=True);p.add_argument('--cache',required=True);p.add_argument('--report',required=True);p.add_argument('--max-pages',type=int,default=100);p.add_argument('--budget-seconds',type=int,default=600);a=p.parse_args()
 if a.max_pages<1 or not 45<=a.budget_seconds<=12000:p.error('invalid page/time budget')
 source=Path(a.source_zip).resolve();work=Path(a.work_db).resolve()
 if source==work:raise ValueError('ORIGINAL_OVERWRITE_FORBIDDEN')
 with zipfile.ZipFile(source) as z:
  manifest=json.loads(z.read('manifest.json'));raw=z.read('MASTER.sqlite3');digest=hashlib.sha256(raw).hexdigest()
  if digest!=manifest['master_sha256']:raise ValueError('SOURCE_SHA_MISMATCH')
 if not work.exists():
  work.parent.mkdir(parents=True,exist_ok=True);tmp=work.with_suffix('.tmp');tmp.write_bytes(raw);tmp.replace(work)
 else:
  c=sqlite3.connect('file:'+str(work)+'?mode=ro&immutable=1',uri=True)
  marker=c.execute("select value from metadata where key='person_repair_original_sha256'").fetchone();c.close()
  if not marker or json.loads(marker[0])!=digest:raise ValueError('RESUME_SOURCE_MISMATCH')
 s=Store(work)
 try:
  s.meta('person_repair_original_sha256',digest)
  client=Client(s,Path(a.cache)/'raw',a.budget_seconds)
  report=run(s,client,int(manifest['year']),a.cache,a.max_pages,a.budget_seconds)
  report.update(original_master_sha256=digest,source_zip=source.name,output_kind='PRIVATE_WORKING_DB_NOT_CERTIFIED_MASTER')
  path=Path(a.report);path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(report,ensure_ascii=False,indent=2))
  assert s.c.execute('pragma integrity_check').fetchone()[0]=='ok'
  print(json.dumps(report,ensure_ascii=False));return 2 if report['errors'] else 0
 finally:s.c.close()
if __name__=='__main__':raise SystemExit(main())
