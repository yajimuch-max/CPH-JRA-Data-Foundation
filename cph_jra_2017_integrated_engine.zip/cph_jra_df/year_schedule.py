from __future__ import annotations

import hashlib
import json
import re
from dataclasses import asdict, dataclass
from pathlib import Path
from urllib.parse import quote

from bs4 import BeautifulSoup

from .fetcher import Snapshot, fetch_many, fetch_post_form, read_snapshot_bytes
from .pipeline import now


class YearScheduleFailure(RuntimeError):
    pass


@dataclass(frozen=True)
class RaceDay:
    race_date: str
    day_label: str
    meeting_labels: tuple[str, ...]
    tracks: tuple[str, ...]


def month_url(year: int, month: int) -> str:
    return f"https://www.jra.go.jp/keiba/common/calendar/json/{year:04d}{month:02d}.json"


RESULT_ENTRY_URL = "https://www.jra.go.jp/JRADB/accessS.html"
RESULT_ENTRY_FORM = "cname=pw01skl00999999%2FB3"
TRACKS = ("札幌", "函館", "福島", "新潟", "東京", "中山", "中京", "京都", "阪神", "小倉")


def _decode_jradb(body: bytes) -> str:
    for enc in ("cp932", "shift_jis", "utf-8"):
        try:
            return body.decode(enc)
        except UnicodeDecodeError:
            pass
    raise YearScheduleFailure("YEAR_RESULT_INDEX_DECODE_FAILED")


def _result_month_token(entry_body: bytes, year: int, month: int) -> str:
    text = _decode_jradb(entry_body)
    key = f"{year % 100:02d}{month:02d}"
    match = re.search(rf'objParam\["{key}"\]="([0-9A-F]{{2}})"', text)
    if not match:
        raise YearScheduleFailure(f"YEAR_RESULT_MONTH_TOKEN_NOT_FOUND:{year}:{month:02d}")
    return match.group(1)


def _result_month_cname(year: int, month: int, token: str) -> str:
    return f"pw01skl10{year:04d}{month:02d}/{token}"


def parse_result_month_index(body: bytes, year: int, expected_month: int) -> list[RaceDay]:
    """Parse JRA's official past-result month index into annual race days.

    This source is used for 2017 and older because the newer common calendar JSON
    endpoint does not reliably expose those years.
    """
    soup = BeautifulSoup(_decode_jradb(body), "lxml")
    output: list[RaceDay] = []

    for unit in soup.select("div.past_result_line_unit"):
        heading = unit.select_one("h3.sub_header")
        if heading is None:
            continue
        heading_text = " ".join(heading.stripped_strings)
        md = re.search(r"(\d+)月(\d+)日", heading_text)
        if not md:
            continue
        month = int(md.group(1))
        day = int(md.group(2))
        if month != expected_month:
            continue

        race_date = f"{year:04d}-{month:02d}-{day:02d}"
        ymd = race_date.replace("-", "")
        labels: list[str] = []
        tracks: list[str] = []

        for anchor in unit.select("div.cell.kaisai a"):
            onclick = anchor.get("onclick", "")
            label_text = " ".join(anchor.stripped_strings)
            if "pw01srl" not in onclick or ymd not in onclick:
                continue

            lm = re.search(
                r"(\d+)回(" + "|".join(TRACKS) + r")(\d+)日",
                label_text,
            )
            if not lm:
                raise YearScheduleFailure(
                    f"YEAR_RESULT_MEETING_LABEL_INVALID:{race_date}:{label_text}"
                )
            meeting_label = f"{lm.group(1)}回{lm.group(2)}"
            track = lm.group(2)
            labels.append(meeting_label)
            tracks.append(track)

        if not labels:
            continue
        if len(tracks) != len(set(tracks)):
            raise YearScheduleFailure(f"YEAR_RESULT_DUPLICATE_TRACK:{race_date}")

        output.append(
            RaceDay(
                race_date=race_date,
                day_label=heading_text,
                meeting_labels=tuple(labels),
                tracks=tuple(tracks),
            )
        )

    if len({x.race_date for x in output}) != len(output):
        raise YearScheduleFailure("YEAR_RESULT_DUPLICATE_DATE")
    return sorted(output, key=lambda x: x.race_date)


def parse_calendar_month(body: bytes, year: int, expected_month: int) -> list[RaceDay]:
    try:
        payload = json.loads(body.decode("utf-8-sig"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise YearScheduleFailure("YEAR_CALENDAR_JSON_INVALID") from exc
    if not isinstance(payload, list) or len(payload) != 1:
        raise YearScheduleFailure("YEAR_CALENDAR_MONTH_ROOT_INVALID")
    root = payload[0]
    if int(root.get("month", 0)) != expected_month or not isinstance(root.get("data"), list):
        raise YearScheduleFailure("YEAR_CALENDAR_MONTH_MISMATCH")
    output: list[RaceDay] = []
    for item in root["data"]:
        infos = item.get("info") or []
        labels: list[str] = []
        for info in infos:
            for race in info.get("race") or []:
                name = str(race.get("name", "")).strip()
                if name:
                    labels.append(name)
        if not labels:
            continue
        day = int(item["date"])
        date = f"{year:04d}-{expected_month:02d}-{day:02d}"
        tracks = []
        for label in labels:
            match = re.search(r"\d+回(.+)$", label)
            if not match:
                raise YearScheduleFailure("YEAR_CALENDAR_MEETING_LABEL_INVALID")
            tracks.append(match.group(1))
        if len(tracks) != len(set(tracks)):
            raise YearScheduleFailure("YEAR_CALENDAR_DUPLICATE_TRACK")
        output.append(RaceDay(date, str(item.get("day", "")), tuple(labels), tuple(tracks)))
    if len({x.race_date for x in output}) != len(output):
        raise YearScheduleFailure("YEAR_CALENDAR_DUPLICATE_DATE")
    return sorted(output, key=lambda x: x.race_date)


def canonical_hash(days: list[RaceDay]) -> str:
    body = json.dumps([asdict(x) for x in days], ensure_ascii=False, sort_keys=True,
                      separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(body).hexdigest()


class YearScheduleBuilder:
    def __init__(self, pipeline):
        self.pipeline = pipeline
        self.conn = pipeline.conn
        self.root = pipeline.root

    def _build_from_result_index(self, year: int, cache_only: bool) -> tuple[list[RaceDay], dict[int, Snapshot], bool]:
        # One official JRADB entry page contains month tokens for historical years.
        entry = fetch_post_form(
            self.conn, self.root, RESULT_ENTRY_URL, "YEAR_RESULT_SEARCH_ENTRY",
            RESULT_ENTRY_FORM, cache_only
        )
        entry_body = read_snapshot_bytes(entry)

        snapshots: dict[int, Snapshot] = {}
        days: list[RaceDay] = []
        all_cache = entry.from_cache

        for month in range(1, 13):
            token = _result_month_token(entry_body, year, month)
            cname = _result_month_cname(year, month, token)
            form = "cname=" + quote(cname, safe="")
            snap = fetch_post_form(
                self.conn, self.root, RESULT_ENTRY_URL, "YEAR_RESULT_MONTH_INDEX",
                form, cache_only
            )
            snapshots[month] = snap
            all_cache = all_cache and snap.from_cache
            days.extend(parse_result_month_index(read_snapshot_bytes(snap), year, month))

        return days, snapshots, all_cache

    def build(self, year: int, cache_only: bool = False) -> dict:
        if year < 1986 or year > 2100:
            raise YearScheduleFailure("YEAR_OUT_OF_RANGE")

        if year <= 2017:
            days, snapshots, all_sources_from_cache = self._build_from_result_index(year, cache_only)
            source_mode = "JRADB_RESULT_MONTH_INDEX"
        else:
            items = [(month_url(year, m), "YEAR_CALENDAR_MONTH") for m in range(1, 13)]
            by_url = fetch_many(self.conn, self.root, items, cache_only, self.pipeline.workers)
            snapshots = {m: by_url[month_url(year, m)] for m in range(1, 13)}
            days = []
            for month in range(1, 13):
                days.extend(parse_calendar_month(read_snapshot_bytes(snapshots[month]), year, month))
            all_sources_from_cache = all(x.from_cache for x in snapshots.values())
            source_mode = "COMMON_CALENDAR_JSON"

        days.sort(key=lambda x: x.race_date)
        if not days:
            raise YearScheduleFailure("YEAR_CALENDAR_NO_RACE_DAYS")
        if len({x.race_date for x in days}) != len(days):
            raise YearScheduleFailure("YEAR_CALENDAR_DUPLICATE_DATE_ACROSS_MONTHS")

        digest = canonical_hash(days)
        manifest_id = f"YEAR-SCHEDULE-{year}-{digest[:16]}"
        self.conn.execute("DELETE FROM year_schedule_manifests WHERE manifest_id=?", (manifest_id,))
        self.conn.execute("INSERT INTO year_schedule_manifests VALUES(?,?,?,?,?)",
                          (manifest_id, year, now(), len(days), digest))
        self.conn.executemany("INSERT INTO year_calendar_sources VALUES(?,?,?)",
                              [(manifest_id, m, snapshots[m].snapshot_id) for m in range(1, 13)])
        self.conn.executemany("INSERT INTO year_race_days VALUES(?,?,?,?,?,?)", [
            (manifest_id, x.race_date, x.day_label,
             json.dumps(x.meeting_labels, ensure_ascii=False), json.dumps(x.tracks, ensure_ascii=False),
             "H1" if int(x.race_date[5:7]) <= 6 else "H2") for x in days
        ])
        self.conn.commit()

        result = self.audit(year, manifest_id)
        result.update({
            "mode": "CACHE_ONLY" if cache_only else "ONLINE",
            "manifest_sha256": digest,
            "source_snapshot_count": 12,
            "all_sources_from_cache": all_sources_from_cache,
            "source_mode": source_mode,
        })
        return result

    def audit(self, year: int, manifest_id: str | None = None) -> dict:
        if manifest_id is None:
            row = self.conn.execute(
                "SELECT manifest_id FROM year_schedule_manifests WHERE year=? ORDER BY created_at DESC LIMIT 1", (year,)
            ).fetchone()
            if row is None:
                raise YearScheduleFailure("YEAR_MANIFEST_NOT_FOUND")
            manifest_id = row[0]
        month_count = self.conn.execute(
            "SELECT COUNT(*) FROM year_calendar_sources WHERE manifest_id=?", (manifest_id,)
        ).fetchone()[0]
        rows = self.conn.execute(
            "SELECT * FROM year_race_days WHERE manifest_id=? ORDER BY race_date", (manifest_id,)
        ).fetchall()
        reasons = []
        if month_count != 12: reasons.append("YEAR_SOURCE_MONTH_COUNT_MISMATCH")
        if not rows: reasons.append("YEAR_RACE_DAY_EMPTY")
        if any(not r["race_date"].startswith(f"{year:04d}-") for r in rows): reasons.append("YEAR_RACE_DATE_MISMATCH")
        if len({r["race_date"] for r in rows}) != len(rows): reasons.append("YEAR_RACE_DAY_DUPLICATE")
        return {"status": "PASS" if not reasons else "FAIL", "reason_codes": reasons,
                "manifest_id": manifest_id, "year": year, "race_day_count": len(rows),
                "h1_count": sum(r["half_year"] == "H1" for r in rows),
                "h2_count": sum(r["half_year"] == "H2" for r in rows),
                "source_month_count": month_count}

    def export(self, year: int, output: Path) -> dict:
        audit = self.audit(year)
        rows = self.conn.execute(
            "SELECT race_date,day_label,meeting_labels_json,tracks_json,half_year FROM year_race_days "
            "WHERE manifest_id=? ORDER BY race_date", (audit["manifest_id"],)
        ).fetchall()
        payload = {"manifest_id": audit["manifest_id"], "year": year,
                   "race_day_count": len(rows), "days": [
                       {"date": r["race_date"], "day_label": r["day_label"],
                        "meeting_labels": json.loads(r["meeting_labels_json"]),
                        "tracks": json.loads(r["tracks_json"]), "period": r["half_year"]}
                       for r in rows]}
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        return payload
