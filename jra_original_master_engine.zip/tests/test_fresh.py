import contextlib,io,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from jra_master.store import Store
from jra_master.fresh import collect,discover,race_identity,month_task
from jra_master.network import Deferred
from jra_master.cli import main

CNAME='pw01sde1006201701010120170105/AA'
MEETING='pw01srl10062017010120170105/BB'
ODDS='pw151ou1006201701010120170105Z/CC'
RID='2017-01-05-中山-01'

class Client:
 def __init__(self,fail_odds=False,fail_selection=False):
  self.calls=[];self.fail_odds=fail_odds;self.fail_selection=fail_selection
 def request(self,url,role,body=None):
  self.calls.append((url,role,body))
  if role=='FINAL_WIN_ODDS' and self.fail_odds:raise RuntimeError('HTTP_503')
  if role=='RESULT_RACE_SELECTION' and self.fail_selection:raise Deferred('TIME_BUDGET_CHECKPOINT')
  bodies={'RESULT_SEARCH_ENTRY':b'objParam["1701"]="DD";',
          'RESULT_MONTH_INDEX':MEETING.encode(),
          'RESULT_RACE_SELECTION':CNAME.encode(),
          'RACE_RESULT':b'result','FINAL_WIN_ODDS':b'odds'}
  return bodies[role],'SID_'+str(len(self.calls)),Path('unused')
 def valid(self,*args):pass

class FreshTests(unittest.TestCase):
 def setUp(self):self.s=Store(':memory:')
 def tearDown(self):self.s.c.close()
 def stub_result(self,s,body,sid,rid):
  s.c.execute('INSERT OR IGNORE INTO races VALUES (?,?,?,?,?,?)',(rid,'2017-01-05','中山',1,'FLAT','{}'));s.c.commit()
  return rid,None
 def test_identity_exact_observed_reference(self):
  self.assertEqual(race_identity(CNAME,2017,1,'2017-01-01','2017-12-31'),RID)
 def test_identity_rejects_wrong_year_month_date_checksum(self):
  for c,y,m in [(CNAME,2013,1),(CNAME,2017,2),(CNAME[:-2]+'XX',2017,1),('invented',2017,1)]:
   with self.assertRaises(ValueError):race_identity(c,y,m,'2017-01-01','2017-12-31')
 def test_discovery_resume_does_not_refetch_entry_or_index(self):
  c=Client(fail_selection=True)
  with self.assertRaises(Deferred):discover(self.s,c,2017,1,'2017-01-01','2017-12-31')
  c.fail_selection=False;c.calls=[]
  self.assertEqual(discover(self.s,c,2017,1,'2017-01-01','2017-12-31'),[CNAME])
  self.assertEqual([x[1] for x in c.calls],['RESULT_RACE_SELECTION'])
  c.calls=[];discover(self.s,c,2017,1,'2017-01-01','2017-12-31');self.assertEqual(c.calls,[])
 def test_missing_month_token_not_invented(self):
  with self.assertRaisesRegex(ValueError,'TOKEN_NOT_FOUND'):discover(self.s,Client(),2013,1,'2013-01-01','2013-12-31')
 def test_empty_month_never_marked_complete(self):
  c=Client();original=c.request
  c.request=lambda u,r,b: (b'no meetings','S',Path('unused')) if r=='RESULT_MONTH_INDEX' else original(u,r,b)
  out=collect(self.s,c,2017,[1],'2017-01-01','2017-12-31')
  self.assertTrue(out['errors']);self.assertFalse(self.s.done(month_task(2017,1,'2017-01-01','2017-12-31')))
 def test_odds_failure_retry_only_odds_and_resolve_issue(self):
  c=Client(fail_odds=True)
  with patch('jra_master.fresh.integrate_result',side_effect=self.stub_result) as result,patch('jra_master.fresh.odds_cname',return_value=ODDS),patch('jra_master.fresh.integrate_odds'):
   self.assertEqual(collect(self.s,c,2017,[1],'2017-01-01','2017-12-31')['errors'],['HTTP_503'])
   self.assertEqual(result.call_count,1);c.fail_odds=False;c.calls=[]
   self.assertEqual(collect(self.s,c,2017,[1],'2017-01-01','2017-12-31')['errors'],[])
   self.assertEqual(result.call_count,1);self.assertEqual([x[1] for x in c.calls],['FINAL_WIN_ODDS'])
   self.assertEqual(self.s.c.execute("select count(*) from issues where status='OPEN'").fetchone()[0],0)
   c.calls=[];collect(self.s,c,2017,[1],'2017-01-01','2017-12-31');self.assertEqual(c.calls,[])
 def test_time_limit_after_result_keeps_validated_result(self):
  c=Client()
  with patch('jra_master.fresh.integrate_result',side_effect=self.stub_result) as result,patch('jra_master.fresh.odds_cname',return_value=ODDS),patch('jra_master.fresh.integrate_odds'):
   out=collect(self.s,c,2017,[1],'2017-01-01','2017-12-31',max_sources=4)
   self.assertEqual(out['requested_sources'],4);self.assertTrue(self.s.done('FRESH_RESULT_'+CNAME));self.assertFalse(self.s.done('FRESH_RACE_'+CNAME))
   c.calls=[];collect(self.s,c,2017,[1],'2017-01-01','2017-12-31');self.assertEqual(result.call_count,1)
   self.assertEqual([x[1] for x in c.calls],['FINAL_WIN_ODDS'])
 def test_discovery_failure_can_resume_and_resolve(self):
  c=Client();original=c.request
  c.request=lambda u,r,b: (b'bad index','S',Path('unused')) if r=='RESULT_MONTH_INDEX' else original(u,r,b)
  collect(self.s,c,2017,[1],'2017-01-01','2017-12-31');c.request=original
  with patch('jra_master.fresh.integrate_result',side_effect=self.stub_result),patch('jra_master.fresh.odds_cname',return_value=ODDS),patch('jra_master.fresh.integrate_odds'):
   collect(self.s,c,2017,[1],'2017-01-01','2017-12-31')
  self.assertEqual(self.s.c.execute("select count(*) from issues where status='OPEN'").fetchone()[0],0)
 def test_annual_pending_months_remain_after_january(self):
  for m in range(1,13):self.s.task(month_task(2017,m,'2017-01-01','2017-12-31'),'PENDING')
  with patch('jra_master.fresh.integrate_result',side_effect=self.stub_result),patch('jra_master.fresh.odds_cname',return_value=ODDS),patch('jra_master.fresh.integrate_odds'):
   collect(self.s,Client(),2017,[1],'2017-01-01','2017-12-31')
  self.assertEqual(self.s.c.execute("select count(*) from tasks where status!='PASS'").fetchone()[0],11)
 def test_wrong_checkpoint_race_never_fetches_odds(self):
  self.s.meta('fresh_result_'+CNAME,{'race_id':'WRONG','odds_cname':ODDS});self.s.task('FRESH_RESULT_'+CNAME,'PASS')
  c=Client();out=collect(self.s,c,2017,[1],'2017-01-01','2017-12-31')
  self.assertEqual(out['errors'],['RESULT_CHECKPOINT_ID_MISMATCH']);self.assertNotIn('FINAL_WIN_ODDS',[x[1] for x in c.calls])
 def test_range_preflight_all_six_years(self):
  for y in range(2011,2018):
   with contextlib.redirect_stdout(io.StringIO()):self.assertEqual(main(['--year',str(y),'--mode','preflight']),0)
  with contextlib.redirect_stderr(io.StringIO()),self.assertRaises(SystemExit):main(['--year','2010','--mode','preflight'])

 def test_2012_result_reference_identity(self):
  cname="pw01sde1006201201010120120105/AA"
  self.assertEqual(race_identity(cname,2012,1,"2012-01-01","2012-12-31"),"2012-01-05-中山-01")
