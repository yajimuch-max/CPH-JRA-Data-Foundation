import gzip,unittest,tempfile
from pathlib import Path
from jra_master.racing import month_cname,validate_search_response,discover,links
from jra_master.discovery_diagnostics import diagnose
from jra_master.store import Store
from test_discovery_diagnostics import FakeClient

FIXTURES=Path(__file__).parent/'fixtures/discovery_20261006'
ENTRY=gzip.decompress((FIXTURES/'10_search_entry.bin.gz').read_bytes())
ERROR=gzip.decompress((FIXTURES/'10_month_index.bin.gz').read_bytes())

class OfficialMonthRoutingTests(unittest.TestCase):
 def test_actual_current_month_route(self):
  self.assertEqual(month_cname(ENTRY,2026,10),'pw01skl00202610/C3')
 def test_actual_previous_month_route(self):
  self.assertEqual(month_cname(ENTRY,2026,9),'pw01skl10202609/3B')
 def test_future_month_uses_current_family(self):
  self.assertEqual(month_cname(ENTRY,2026,11),'pw01skl00202611/91')
 def test_routing_changes_at_official_boundary(self):
  # Read from source, not machine date; keep November token verbatim.
  self.assertEqual(month_cname(ENTRY.replace(b'var yearMonth = "202610"',b'var yearMonth = "202611"'),2026,10),'pw01skl10202610/C3')
 def test_actual_http200_error_not_valid_index(self):
  with self.assertRaisesRegex(ValueError,'JRA_PARAMETER_ERROR_PAGE'):validate_search_response(ERROR)
 def test_missing_boundary_never_guessed(self):
  with self.assertRaisesRegex(ValueError,'BOUNDARY_NOT_FOUND'):month_cname(b'objParam["2610"]="C3";',2026,10)
 def test_actual_meetings_and_replay_request_route(self):
  meetings=links(ENTRY,'srl');self.assertEqual(len(meetings),4)
  # Captured entry and current index share the same month listing; selection
  # bodies below are synthetic. This is not a live result-page validation.
  selections=[('<a href="'+c.replace('srl','sde').replace('20261003/','0120261003/').replace('20261004/','0120261004/')+'">R</a>').encode() for c in meetings]
  with tempfile.TemporaryDirectory() as d:
   s=Store(Path(d)/'state.sqlite3')
   try:
    c=FakeClient(s,Path(d)/'raw',bodies=[ENTRY,ENTRY]+selections)
    result=discover(c,2026,10,'2026-10-03','2026-10-04')
    self.assertEqual(len(result),4);self.assertIn('cname=pw01skl00202610%2FC3',c.calls[1][2])
    self.assertEqual([x[1] for x in c.calls],['RESULT_SEARCH_ENTRY','RESULT_MONTH_INDEX']+['RESULT_RACE_SELECTION']*4)
   finally:s.c.close()
 def test_diagnostic_preserves_parameter_error_evidence(self):
  with tempfile.TemporaryDirectory() as d:
   s=Store(Path(d)/'state.sqlite3')
   try:
    c=FakeClient(s,Path(d)/'raw',bodies=[ENTRY,ERROR]);r=diagnose(c,2026,[10],'2026-10-03','2026-10-04',Path(d)/'out')
    self.assertEqual(r['status'],'DIAGNOSTIC_ERROR');self.assertIn('JRA_PARAMETER_ERROR_PAGE',r['errors'][0])
    self.assertEqual(gzip.decompress((Path(d)/'out/10_month_index.bin.gz').read_bytes()),ERROR)
   finally:s.c.close()
