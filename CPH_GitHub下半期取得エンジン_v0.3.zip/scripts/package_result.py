from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import zipfile


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--date", required=True)
    parser.add_argument("--status", choices=("PASS", "FAIL"), required=True)
    parser.add_argument("--data-root", required=True)
    parser.add_argument("--reports-root", required=True)
    parser.add_argument("--delivery-root", required=True)
    args = parser.parse_args()

    data_root = Path(args.data_root).resolve()
    reports_root = Path(args.reports_root).resolve()
    delivery_root = Path(args.delivery_root).resolve()
    delivery_root.mkdir(parents=True, exist_ok=True)

    year = args.date[:4]
    base = f"CPH_JRA公式データ_{year}年_{args.date}_接続試験_CHECKPOINT"
    status_path = reports_root / "実行状態.json"
    status_path.write_text(
        json.dumps(
            {
                "status": args.status,
                "race_date": args.date,
                "purpose": "GitHub Actions 1開催日接続試験",
                "data_foundation_id": "CPH-JRA-DF-v0.14.0",
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )

    zip_path = delivery_root / f"{base}.zip"
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for root, prefix in ((reports_root, "reports"), (data_root, "data")):
            if not root.exists():
                continue
            for path in sorted(p for p in root.rglob("*") if p.is_file()):
                zf.write(path, Path(prefix) / path.relative_to(root))

    digest = hashlib.sha256(zip_path.read_bytes()).hexdigest()
    sha_path = delivery_root / f"{base}_SHA256.txt"
    sha_path.write_text(f"{digest}  {zip_path.name}\n", encoding="utf-8")
    print(json.dumps({"zip": str(zip_path), "sha256": digest}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
