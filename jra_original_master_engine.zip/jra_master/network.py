import time,urllib.request,urllib.error,urllib.parse,urllib.robotparser,tempfile,gzip
from pathlib import Path
from datetime import datetime,timezone
from .store import now,sha,encode
AGENT='JRA-Original-Master-Collector/1.0'
class Deferred(Exception):pass
class FetchError(Exception):pass
class Client:
 def __init__(self,store,raw_dir,budget_seconds=9000,jra_interval=2):
  self.s=store;self.raw_dir=Path(raw_dir);self.raw_dir.mkdir(parents=True,exist_ok=True);self.deadline=time.monotonic()+budget_seconds;self.jra_interval=max(2,jra_interval);self.robot=None
 def request(self,url,role,body=None):
  host=urllib.parse.urlparse(url).hostname
  if host not in ['www.jra.go.jp']:raise FetchError('UNEXPECTED_SOURCE_HOST')
  if urllib.parse.urlparse(url).scheme!='https':raise FetchError('HTTPS_REQUIRED')
  interval=self.jra_interval
  old=self.s.c.execute('SELECT last_requested_at FROM host_budget WHERE host=?',(host,)).fetchone()
  wait=max(0,interval-(datetime.now(timezone.utc)-datetime.fromisoformat(old[0])).total_seconds()) if old else 0
  if time.monotonic()+wait+40>self.deadline:raise Deferred('TIME_BUDGET_CHECKPOINT')
  while wait>0:
   chunk=min(30,wait);time.sleep(chunk);wait-=chunk
  started=now();self.s.c.execute('INSERT OR REPLACE INTO host_budget VALUES (?,?)',(host,started));self.s.c.commit()
  req=urllib.request.Request(url,data=body.encode() if body is not None else None,headers={'User-Agent':AGENT,'Accept-Encoding':'identity'})
  rec={'service':'JRA','role':role,'url':url,'requested_at':started,'request_method':'POST' if body is not None else 'GET','request_body':body,'request_body_sha256':sha(body.encode()) if body is not None else None,'raw_state':'TEMPORARY','parser_version':'2.0.0'}
  try:
   with urllib.request.urlopen(req,timeout=35) as r:
    data=r.read();rec.update(http_status=r.status,final_url=r.url,responded_at=now())
    if urllib.parse.urlparse(r.url).hostname!=host:raise FetchError('CROSS_HOST_REDIRECT')
  except urllib.error.HTTPError as e:
   rec.update(http_status=e.code,responded_at=now(),raw_state='NOT_SAVED',integrated_at=now());self.s.source(rec);self.s.c.commit();raise FetchError('HTTP_'+str(e.code)) from e
  except (urllib.error.URLError,TimeoutError) as e:raise FetchError(str(e)) from e
  rec.update(entity_sha256=sha(data),entity_bytes=len(data));p=self.raw_dir/(rec['entity_sha256']+'.bin.gz');p.write_bytes(gzip.compress(data,mtime=0));rec.update(raw_saved_at=now(),raw_path=str(p),storage_sha256=sha(p.read_bytes()),integrated_at=now());sid=self.s.source(rec);self.s.c.commit();return data,sid,p
 def valid(self,sid,p):
  self.s.c.execute("UPDATE source_records SET raw_state='AUDITED_NOT_RETAINED' WHERE source_id=?",(sid,));self.s.c.commit();p.unlink(missing_ok=True)
