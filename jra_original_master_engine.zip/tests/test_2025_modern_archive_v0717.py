"""2025 JRA PDF row-layout regression fixtures.

The text fixtures transcribe official 2025 chukyo01, nakayama01, fukushima03
and chukyo05 archive PDFs. These verify parser logic but DO NOT substitute for
running the official PDF bytes through the deployed Github Actions pipeline.
"""
from pathlib import Path
from unittest.mock import patch

import pytest

from jra_master.track_enrichment import (
    extract_modern_text_rows, extract_observations, merge_modern_rows,
    modern_table,
)

JRA_ROOT = 'https://www.jra.go.jp/keiba/baba/archive/2025pdf/'
CHUKYO = '''2025年 1回中京競馬
ゴール前 4コーナー ゴール前 4コーナー
 1月 4日 土曜日 A 09:30 9.1 09:30 13.5 14.8 1.1 1.2
第 1日 1月 5日 日曜日 A 06:30 9.4 05:30 11.6 12.8 1.1 1.2
第 2日 1月 6日 月曜日 A 06:30 9.4 05:30 10.7 13.0 1.2 1.4
 1月10日 金曜日 A 09:30 9.2 09:30 12.6 13.2 6.1 4.6
第 3日 1月11日 土曜日 A 06:30 9.1 05:30 11.4 13.0 5.9 6.8
第 4日 1月12日 日曜日 A 06:30 8.9 05:30 12.5 13.3 4.4 4.5
第 5日 1月13日 月曜日 A 06:30 9.2 05:30 11.8 13.4 4.0 5.0
 1月17日 金曜日 B 09:30 9.4 09:30 11.9 12.5 2.0 3.7
第 6日 1月18日 土曜日 B 06:30 9.8 05:30 11.9 12.4 1.4 2.7
第 7日 1月19日 日曜日 B 06:30 10.0 05:30 11.7 12.0 1.6 2.7
 1月24日 金曜日 B 09:30 9.3 09:30 12.3 12.8 2.2 2.8
第 8日 1月25日 土曜日 B 05:30 9.3 05:30 13.7 12.3 1.6 2.3
第 9日 1月26日 日曜日 B 06:30 9.6 05:30 11.8 13.1 1.4 1.7
２０２５年 第１回 中京競馬 クッション値・含水率一覧'''
NAKAYAMA = '''2025年 1回中山競馬
ゴール前 4コーナー ゴール前 4コーナー
 1月 4日 土曜日 B 10:30 10.1 10:30 13.4 13.7 2.1 2.1
第 1日 1月 5日 日曜日 B 08:30 10.2 05:00 13.6 13.6 2.0 1.6
第 2日 1月 6日 月曜日 B 08:00 10.1 06:00 13.7 14.2 1.7 1.5
 1月10日 金曜日 C 10:30 10.2 10:30 12.4 14.8 7.8 8.2
第 3日 1月11日 土曜日 C 08:00 10.0 06:00 13.1 14.6 7.9 6.4
第 4日 1月12日 日曜日 C 07:00 10.0 05:00 12.6 13.8 5.9 4.6
第 5日 1月13日 月曜日 C 07:00 10.0 06:00 12.7 13.9 6.0 3.8
 1月17日 金曜日 C 10:30 10.4 10:30 11.3 11.9 1.9 2.1
第 6日 1月18日 土曜日 C 08:00 10.7 05:00 11.8 13.8 1.6 1.6
第 7日 1月19日 日曜日 C 08:00 10.5 06:00 12.1 12.0 1.7 1.9
 1月24日 金曜日 C 10:30 10.2 10:30 12.1 11.8 3.2 2.2
第 8日 1月25日 土曜日 C 07:00 10.2 06:00 13.0 12.3 2.7 2.2
第 9日 1月26日 日曜日 C 08:00 9.9 06:00 12.1 12.4 2.7 2.3'''
FUKUSHIMA = '''11月 7日 金曜日 A 09:00 9.0 09:00 14.3 13.2 4.9 3.3
第 1日 11月 8日 土曜日 A 07:00 9.2 05:00 12.1 12.9 3.7 3.4
第 2日 11月 9日 日曜日 A 07:00 9.2 06:00 12.4 11.9 2.0 3.6
11月14日 金曜日 A 09:00 9.1 09:00 12.3 13.1 3.1 3.1
第 3日 11月15日 土曜日 A 07:00 8.9 05:00 11.3 11.6 1.9 1.3
第 4日 11月16日 日曜日 A 07:00 9.3 06:00 11.0 11.7 2.0 1.3
11月21日 金曜日 B 09:00 8.9 09:00 9.7 11.6 1.7 1.6
第 5日 11月22日 土曜日 B 07:00 9.2 05:00 10.3 11.0 1.4 2.1
第 6日 11月24日 月曜日 B 07:00 9.5 06:00 11.3 10.5 1.1 1.2'''
CHUKYO_DEC = '''12月 5日 金曜日 A 09:30 9.6 09:30 11.1 13.2 4.5 4.2
第 1日 12月 6日 土曜日 A 06:30 9.7 05:30 11.6 12.1 4.6 4.0
第 2日 12月 7日 日曜日 A 06:30 9.5 05:30 11.1 11.4 3.8 4.6
12月12日 金曜日 A 09:30 9.9 09:30 11.0 11.3 2.4 2.2
第 3日 12月13日 土曜日 A 06:30 10.0 05:30 10.8 12.0 1.8 2.3
第 4日 12月14日 日曜日 A 06:30 9.3 05:30 11.4 12.2 4.8 5.4
12月19日 金曜日 A 09:30 10.2 09:30 10.9 11.1 5.9 5.9
第 5日 12月20日 土曜日 A 06:30 9.7 05:30 11.1 11.9 6.0 6.5
第 6日 12月21日 日曜日 A 06:30 9.7 05:30 12.8 12.7 7.4 7.8'''

class FakePage:
    def __init__(self,text,tables=()):self.text=text;self.tables=tables
    def extract_text(self):return self.text
    def find_tables(self,**kwargs):return self.tables


@pytest.mark.parametrize('name,track,text,rows,check',[
    ('chukyo01.pdf','中京',CHUKYO,13,('2025-01-05',9.4,11.6,1.1)),
    ('nakayama01.pdf','中山',NAKAYAMA,13,('2025-01-05',10.2,13.6,2.0)),
    ('fukushima03.pdf','福島',FUKUSHIMA,9,('2025-11-24',9.5,11.3,1.1)),
    ('chukyo05.pdf','中京',CHUKYO_DEC,9,('2025-12-21',9.7,12.8,7.4)),
])
def test_2025_official_sample_lines(name,track,text,rows,check):
    url=JRA_ROOT+name
    result=extract_modern_text_rows(FakePage(text),2025,track,url,'test-hash',1)
    assert len(result)==rows
    row=next(x for x in result if x['date']==check[0])
    assert (row['cushion'],row['turf_goal'],row['dirt_goal'])==check[1:]
    assert row['source_url']==url and row['raw_format']=='MODERN_TEXT_ROW'
    assert all(x['cushion'] is not None for x in result)


def test_wrong_weekday_rejected_and_no_values_inferred():
    text=CHUKYO.replace('1月 5日 日曜日 A','1月 5日 月曜日 A')
    text=text.replace('1月 6日 月曜日 A 06:30 9.4', '1月 6日 月曜日 A 06:30 8..8')
    result=extract_modern_text_rows(FakePage(text),2025,'中京',JRA_ROOT+'chukyo01.pdf','hash',1)
    assert len(result)==11
    assert all(x['date'] not in ('2025-01-05','2025-01-06') for x in result)


def test_text_grid_agree_and_conflict():
    record=extract_modern_text_rows(FakePage(CHUKYO),2025,'中京',JRA_ROOT+'chukyo01.pdf','hash',1)[0]
    grid={**record, 'raw_format':'MODERN_ROW'}
    assert len(merge_modern_rows([grid],[record],record['source_url']))==1
    assert merge_modern_rows([grid],[record],record['source_url'])[0]['raw_format']=='MODERN_ROW'
    with pytest.raises(ValueError,match='DISAGREEMENT'):
        merge_modern_rows([{**grid,'cushion':11.3}],[record],record['source_url'])


def test_modern_2025_branch_extract_observations(tmp_path):
    """The old v0.7.1.6 implementation failed all such pages, since year<2026."""
    path=tmp_path/'chukyo01.pdf';path.write_bytes(b'%PDF-MOCK-2025')
    class FakeDoc:
        pages=[FakePage(CHUKYO)]
        def __enter__(self):return self
        def __exit__(self,*args):pass
    with patch('jra_master.track_enrichment.pdfplumber.open',return_value=FakeDoc()):
        observations=extract_observations('中京',JRA_ROOT+'chukyo01.pdf',path)
    assert len(observations)==13
    assert observations[1]['date']=='2025-01-05'


def test_modern_2025_grid_branch(tmp_path):
    row=['第1日','1月5日','日曜日','A','06:30','9.4','05:30','11.6','12.8','1.1','1.2']
    grid=modern_table([row],2025,'中京',JRA_ROOT+'chukyo01.pdf','h',1)
    assert len(grid)==1 and grid[0]['dirt_fourth']==1.2
    merged=merge_modern_rows(grid,extract_modern_text_rows(FakePage(CHUKYO),2025,'中京',JRA_ROOT+'chukyo01.pdf','h',1),JRA_ROOT+'chukyo01.pdf')
    assert len(merged)==13
    assert next(x for x in merged if x['date']=='2025-01-05')['raw_format']=='MODERN_ROW'


def test_year_and_legacy_gated():
    assert extract_modern_text_rows(FakePage(CHUKYO),2024,'中京',JRA_ROOT+'chukyo01.pdf','h',1)==[]
