import unittest,tempfile
from pathlib import Path
from unittest.mock import patch
from jra_master.store import Store
from jra_master.racing import reaudit_compact_pending
class CompactAuditTests(unittest.TestCase):
 def test_exact_reference_validated_and_checkpointed(self):
  with tempfile.TemporaryDirectory() as tmp:
   s=Store(Path(tmp)/'MASTER.sqlite3');s.c.execute("INSERT INTO races VALUES ('R','2025-01-01','TEST',1,'FLAT','{}')");s.c.commit()
   s.meta('pending_official_reaudit',[{'task_key':'T','race_id':'R','kind':'RESULT','url':'https://www.jra.go.jp/JRADB/accessS.html?CNAME=OBSERVED/AA'}]);s.task('T','PENDING')
   class Client:
    calls=0
    def request(self,*args):self.calls+=1;return b'BODY','SID',Path(tmp)/'raw'
    def valid(self,*args):pass
   c=Client()
   with patch('jra_master.racing.integrate_result') as parse:
    self.assertEqual(reaudit_compact_pending(s,5,c)['errors'],[]);parse.assert_called_once_with(s,b'BODY','SID','R')
    self.assertEqual(reaudit_compact_pending(s,5,c)['processed_sources'],0);self.assertEqual(c.calls,1)
   s.c.close()
 def test_wrong_host_rejected_before_fetch(self):
  with tempfile.TemporaryDirectory() as tmp:
   s=Store(Path(tmp)/'MASTER.sqlite3');s.meta('pending_official_reaudit',[{'task_key':'T','race_id':'R','kind':'RESULT','url':'https://example.com/JRADB/accessS.html?CNAME=X'}])
   class Client:
    def request(self,*args):raise AssertionError('must not request')
   self.assertEqual(reaudit_compact_pending(s,1,Client())['errors'],['INVALID_OFFICIAL_REFERENCE_URL']);s.c.close()
