#!/usr/bin/env python3
"""Add official JRA archive track observations to a COPY of an annual MASTER zip.

No final-result field is mislabelled as the 09:30 observation. No estimate is imputed.
Use on a networked machine (e.g. GitHub Actions), or with locally cached JRA PDFs.
"""
import argparse
import datetime as dt
import hashlib
import json
import re
import shutil
import sqlite3
import tempfile
import time
import zipfile
from pathlib import Path
from urllib.parse import urljoin, urlparse

import pdfplumber
import requests
from bs4 import BeautifulSoup

BASE = 'https://www.jra.go.jp/keiba/baba/archive/'
TRACK_ROMAN = {'sapporo':'札幌','hakodate':'函館','fukushima':'福島','niigata':'新潟',
               'tokyo':'東京','nakayama':'中山','chukyo':'中京','kyoto':'京都',
               'hanshin':'阪神','kokura':'小倉'}
TIME_RE = re.compile(r'^\d{1,2}:\d{2}$')
DATE_RE = re.compile(r'(?P<month>\d{1,2})\s*月\s*(?P<day>\d{1,2})\s*日')
SPAN_RE = re.compile(r'(?P<year>20\d{2})\s*年\s*(?P<m>\d{1,2})\s*月\s*(?P<d>\d{1,2})\s*日(?:[（(][月火水木金土日][）)])?\s*(?:[～〜~\-]|から)\s*(?:(?P<m2>\d{1,2})\s*月)?\s*(?P<d2>\d{1,2})\s*日?')


def sha256(data): return hashlib.sha256(data).hexdigest()
def s(x): return re.sub(r'\s+', '',str(x or '')).translate(str.maketrans('０１２３４５６７８９．：', '0123456789.:'))
def number(x):
    x = s(x).replace('%','').replace('％','')
    return float(x) if re.fullmatch(r'\d+(?:\.\d+)?',x) else None

def date_from_cell(cell, year):
    m = DATE_RE.search(s(cell))
    if not m: return None
    try: return dt.date(year,int(m['month']),int(m['day'])).isoformat()
    except ValueError: return None

def get_archive_links(year, session):
    r = session.get(f'{BASE}{year}.html',timeout=40)
    r.raise_for_status()
    doc = BeautifulSoup(r.content,'html.parser')
    urls = []
    for a in doc.select('a[href]'):
        url = urljoin(r.url,a['href'])
        if not re.search(r'/archive/\d{4}pdf/[a-z]+\d+\.pdf$', urlparse(url).path,re.I): continue
        stem = Path(urlparse(url).path).stem.lower()
        code = re.match(r'([a-z]+)\d+',stem)
        if code and code.group(1) in TRACK_ROMAN:
            urls.append((TRACK_ROMAN[code.group(1)],url))
    return sorted(set(urls),key=lambda x:x[1])

def download_pdfs(year, root, session, throttle=0.8, offline=False):
    year_dir = root / str(year)
    year_dir.mkdir(parents=True,exist_ok=True)
    index_path = year_dir/'archive_index.json'
    if offline:
        if not index_path.is_file(): raise RuntimeError(f'Offline requires {index_path}')
        entries = json.loads(index_path.read_text(encoding='utf-8'))
    else:
        entries=[{'track':t,'url':u} for t,u in get_archive_links(year,session)]
        if not entries: raise RuntimeError(f'No JRA official archive PDFs found for {year}')
        index_path.write_text(json.dumps(entries,ensure_ascii=False,indent=2),encoding='utf-8')
    files=[]
    for ent in entries:
        url=ent['url']; name=Path(urlparse(url).path).name
        local=year_dir/name
        if not local.is_file() or not local.read_bytes().startswith(b'%PDF'):
            if offline: raise RuntimeError(f'Cache missing required JRA PDF: {local}')
            response=session.get(url,timeout=45)
            response.raise_for_status()
            if not response.content.startswith(b'%PDF'):
                raise RuntimeError(f'Not PDF: {url}')
            local.write_bytes(response.content)
            time.sleep(throttle)
        files.append((ent['track'],url,local))
    return files


def modern_table(table,year,track,url,filehash,page_no):
    result=[]
    for row in table:
        cells=[s(v) for v in row]
        pos=next((i for i,x in enumerate(cells) if date_from_cell(x,year)),None)
        if pos is None:continue
        date=date_from_cell(cells[pos],year)
        cp=next((i for i in range(pos+1,len(cells)) if cells[i] in 'ABCD' and len(cells[i])==1),None)
        if cp is None: continue
        rest=cells[cp+1:]
        # Values are, in order: cushion measure time, cushion, moisture measure time,
        # turf finish/4th, dirt finish/4th.  Do not shift columns to fake a value.
        if len(rest)<7: continue
        if not TIME_RE.match(rest[0]) or not TIME_RE.match(rest[2]):continue
        vals=list(map(number,(rest[1],*rest[3:7])))
        if any(v is None for v in vals):continue
        result.append({'date':date,'track':track,'used_course':cells[cp],
          'cushion_time':rest[0],'cushion':vals[0],
          'moisture_time':rest[2],'turf_goal':vals[1],'turf_fourth':vals[2],
          'dirt_goal':vals[3],'dirt_fourth':vals[4],
          'source_url':url,'source_sha256':filehash,'source_page':page_no,
          'raw_format':'MODERN_ROW','actual_published_at':None})
    return result


def previous_legacy_span(lines,top):
    spans=[]
    for line in lines:
        match=SPAN_RE.search(s(line['text']))
        if match and line['top']<top:
            y=int(match['year']); m=int(match['m']); d=int(match['d']);m2=int(match['m2'] or m);d2=int(match['d2'])
            try:
                first=dt.date(y,m,d);last=dt.date(y,m2,d2)
            except ValueError:continue
            if not (0 <= (last-first).days <= 6):continue
            spans.append((line['top'],[(first+dt.timedelta(days=k)).isoformat() for k in range((last-first).days+1)]))
    return spans[-1][1] if spans else None



def dates_from_weekday_columns(span_dates, header_text):
    """Map PDF weekday columns onto the actual dates within a published span.

    Postponed race meetings can print e.g. Fri/Sat/Tue over Sep 28--Oct 2.
    Never infer values for the intervening days (Sun/Mon).
    """
    weekdays=re.findall(r'([月火水木金土日])曜日',s(header_text))
    if len(weekdays)<2 or len(set(weekdays))!=len(weekdays):
        return None
    wd_index={name:i for i,name in enumerate('月火水木金土日')}
    available={dt.date.fromisoformat(day).weekday():day for day in span_dates}
    if any(wd_index[wd] not in available for wd in weekdays):
        return None
    selected=[available[wd_index[wd]] for wd in weekdays]
    return selected if selected==sorted(selected) else None


def dates_for_legacy_table(span_dates, rows):
    for row in rows[:5]:
        header=''.join(s(v) for v in row)
        found=dates_from_weekday_columns(span_dates,header)
        if found is not None:
            return found
    # Historical pages without a legible header retain the old conservative
    # consecutive-span extraction rule. Never invent nonconsecutive dates.
    return span_dates


def extract_legacy(page,year,track,url,filehash,page_no):
    """2018-2025 grouped-tables; cautious matching; reject conflicting/incomplete cells."""
    lines=page.extract_text_lines()  # source table headings bind each group to calendar dates
    buckets={}
    for tbl in sorted(page.find_tables(table_settings={'vertical_strategy':'lines','horizontal_strategy':'lines'}),key=lambda t:t.bbox[1]):
        span_dates=previous_legacy_span(lines,tbl.bbox[1]);rows=tbl.extract()
        if not span_dates:continue
        dates=dates_for_legacy_table(span_dates,rows)
        n=len(dates)
        last_label='';fourth_count={'turf':0,'dirt':0}
        for row in rows:
            cells=[s(v) for v in row]
            joined=''.join(cells)
            if not joined:continue
            numeric=[number(c) for c in cells[-n:]]
            if len(numeric)!=n or any(x is None for x in numeric):continue
            label=''.join(cells[:-n])
            typ=None
            if '芝コースクッション値' in label:
                typ='cushion'
            elif '芝コース含水率' in label:
                last_label='turf'
            elif 'ダートコース含水率' in label:
                last_label='dirt'
            if typ is None:
                if 'ゴール前' in label:typ=last_label+'_goal'
                elif '4コーナー' in label or '４コーナー' in label:typ=last_label+'_fourth'
            if typ is None and last_label in ('turf','dirt'):
                # Table sometimes merges the label and row, so track row count.
                fourth_count[last_label]+=1
                typ=last_label+('_goal' if fourth_count[last_label]==1 else '_fourth')
            if typ not in ('cushion','turf_goal','turf_fourth','dirt_goal','dirt_fourth'):continue
            for date,value in zip(dates,numeric):
                old=buckets.setdefault(date,{})
                if typ in old and old[typ]!=value:
                    raise ValueError(f'Conflicting {typ} on {date} in {url}')
                old[typ]=value
    out=[]
    for date,b in buckets.items():
        if not all(k in b for k in ('turf_goal','turf_fourth','dirt_goal','dirt_fourth')):continue
        out.append({'date':date,'track':track,'used_course':None,
            'cushion_time':None,'cushion':b.get('cushion'),
            'moisture_time':None,'turf_goal':b['turf_goal'],'turf_fourth':b['turf_fourth'],
            'dirt_goal':b['dirt_goal'],'dirt_fourth':b['dirt_fourth'],
            'source_url':url,'source_sha256':filehash,'source_page':page_no,
            'raw_format':'LEGACY_GROUP','actual_published_at':None})
    return out


def extract_legacy_text_fallback(page,year,track,url,filehash,page_no):
    """Verified legacy table text, used only when table boundaries are not parsed.

    Require a dated Fri/Sat/Sun header and all four labelled rows per group;
    reject partial or ambiguously segmented groups rather than guessing values.
    """
    text = page.extract_text() or ''
    if not text: return []
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    groups=[]; current=None
    for line in lines:
        clean=s(line)
        span=SPAN_RE.search(clean)
        if span:
            y=int(span['year']);m=int(span['m']);d=int(span['d'])
            m2=int(span['m2'] or m);d2=int(span['d2'])
            try:
                start=dt.date(y,m,d);end=dt.date(y,m2,d2)
            except ValueError:
                current=None;continue
            if y!=year or not 1 <= (end-start).days <= 6:
                current=None;continue
            current={'span_dates':[(start+dt.timedelta(days=k)).isoformat() for k in range((end-start).days+1)],
                     'dates':None,'values':{},'surface':None,'duplicated':False,'header':False}
            groups.append(current)
            continue
        if current is None:continue
        if '曜日' in clean:
            mapped=dates_from_weekday_columns(current['span_dates'],clean)
            if mapped is not None:
                current['dates']=mapped
                current['header']=True
            continue
        if not current['header']:
            continue
        if '芝コース含水率' in clean: current['surface']='turf'
        elif 'ダートコース含水率' in clean:current['surface']='dirt'
        surface=current['surface']
        if surface is None:continue
        location=None
        if 'ゴール前' in clean:location='goal'
        elif '4コーナー' in clean:location='fourth'
        if location is None:continue
        # Only accept exactly the expected 3 decimal values in a labelled row.
        tail=line.split('ゴール前',1)[-1] if location=='goal' else re.split('[4４]コーナー',line,1)[-1]
        nums=re.findall(r'(?<![\d.])\d+(?:\.\d+)?(?![\d.])',tail)
        vals=[number(x) for x in nums]
        if len(vals)!=len(current['dates']) or any(v is None for v in vals):
            current['duplicated']=True;continue
        key=surface+'_'+location
        if key in current['values']:current['duplicated']=True
        current['values'][key]=vals
    records=[]
    for group in groups:
        needed=('turf_goal','turf_fourth','dirt_goal','dirt_fourth')
        if group['duplicated'] or not group['header'] or any(k not in group['values'] for k in needed):
            continue
        for idx,date in enumerate(group['dates']):
            records.append({'date':date,'track':track,'used_course':None,
              'cushion_time':None,'cushion':None,'moisture_time':None,
              'turf_goal':group['values']['turf_goal'][idx],
              'turf_fourth':group['values']['turf_fourth'][idx],
              'dirt_goal':group['values']['dirt_goal'][idx],
              'dirt_fourth':group['values']['dirt_fourth'][idx],
              'source_url':url,'source_sha256':filehash,'source_page':page_no,
              'raw_format':'LEGACY_TEXT_VERIFIED','actual_published_at':None})
    return records


def extract_observations(track,url,pdf):
    data=pdf.read_bytes();y=int(re.search(r'/archive/(\d{4})pdf/',url).group(1))
    records=[]
    with pdfplumber.open(pdf) as doc:
        for page_no,page in enumerate(doc.pages,1):
            tables=page.find_tables(table_settings={'vertical_strategy':'lines','horizontal_strategy':'lines'})
            modern=[]
            if y>=2026:
                for table in tables:modern+=modern_table(table.extract(),y,track,url,sha256(data),page_no)
            if modern:
                records+=modern
            else:
                legacy=extract_legacy(page,y,track,url,sha256(data),page_no)
                if legacy:
                    records+=legacy
                else:
                    records+=extract_legacy_text_fallback(page,y,track,url,sha256(data),page_no)
    # An archive can have one or more rows; do not mark as audited if none parse.
    if not records:
        raise RuntimeError(f'PDF parser could not verify rows; manual review required: {url}')
    return records


def schema(c):
    c.executescript('''
    CREATE TABLE IF NOT EXISTS official_track_daily (
      race_date TEXT NOT NULL, track TEXT NOT NULL, source_url TEXT NOT NULL,
      source_sha256 TEXT NOT NULL, source_page INTEGER NOT NULL,
      archive_format TEXT NOT NULL, used_turf_course TEXT,
      cushion_measured_time TEXT, turf_cushion REAL,
      moisture_measured_time TEXT, turf_goal_moisture REAL, turf_4c_moisture REAL,
      dirt_goal_moisture REAL, dirt_4c_moisture REAL,
      actual_published_at TEXT, planned_publication_time TEXT,
      source_basis TEXT NOT NULL, timing_status TEXT NOT NULL,
      PRIMARY KEY (race_date,track)
    );
    CREATE TABLE IF NOT EXISTS official_race_track_context (
      race_id TEXT PRIMARY KEY, race_date TEXT NOT NULL, track TEXT NOT NULL,
      surface TEXT, going_from_official_result TEXT,
      going_at_0930 TEXT, going_at_0930_status TEXT NOT NULL,
      used_turf_course TEXT, used_turf_course_status TEXT NOT NULL,
      source_date TEXT, source_sha256 TEXT,
      FOREIGN KEY(race_id) REFERENCES races(race_id)
    );
    CREATE TABLE IF NOT EXISTS official_track_pdf_receipts (
      source_url TEXT PRIMARY KEY, track TEXT NOT NULL, source_sha256 TEXT,
      parse_status TEXT NOT NULL, parsed_rows INTEGER NOT NULL DEFAULT 0,
      checked_at TEXT NOT NULL, error TEXT
    );
    CREATE TABLE IF NOT EXISTS official_track_revisions (
      revision_id INTEGER PRIMARY KEY AUTOINCREMENT,
      race_date TEXT NOT NULL, track TEXT NOT NULL,
      before_json TEXT NOT NULL, after_json TEXT NOT NULL,
      previous_sha256 TEXT NOT NULL, new_sha256 TEXT NOT NULL,
      observed_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_jra_track_daily on official_track_daily(track,race_date);
    ''')


def upsert_obs(c, observations):
    """Idempotent inserts. A changed official archive row is versioned, never overwritten silently."""
    fields=('race_date','track','source_url','source_sha256','source_page',
        'archive_format','used_turf_course','cushion_measured_time','turf_cushion',
        'moisture_measured_time','turf_goal_moisture','turf_4c_moisture',
        'dirt_goal_moisture','dirt_4c_moisture','actual_published_at',
        'planned_publication_time','source_basis','timing_status')
    revisions=0
    for x in observations:
        day=x['date']
        planned='AFTERNOON' if dt.date.fromisoformat(day).weekday()==4 else '09:30_APPROX'
        row=(day,x['track'],x['source_url'],x['source_sha256'],x['source_page'],
            x['raw_format'],x['used_course'],x['cushion_time'],x['cushion'],
            x['moisture_time'],x['turf_goal'],x['turf_fourth'],x['dirt_goal'],x['dirt_fourth'],
            None,planned,'JRA_OFFICIAL_ARCHIVE_PDF','RECONSTRUCTED_FROM_POST_EVENT_ARCHIVE')
        old=c.execute('SELECT * FROM official_track_daily WHERE race_date=? AND track=?',row[:2]).fetchone()
        if old:
            old=dict(zip(fields,old))
            new=dict(zip(fields,row))
            if old['source_sha256']==x['source_sha256']:
                if any(old[f]!=new[f] for f in fields):
                    raise ValueError(f'CONFLICT_SAME_SOURCE_HASH {row[:2]}')
                continue
            # If an official PDF has changed, track the *content change* separately.
            compare=('used_turf_course','cushion_measured_time','turf_cushion',
                     'moisture_measured_time','turf_goal_moisture','turf_4c_moisture',
                     'dirt_goal_moisture','dirt_4c_moisture')
            if any(old[f]!=new[f] for f in compare):
                c.execute("""INSERT INTO official_track_revisions
                    (race_date,track,before_json,after_json,previous_sha256,new_sha256,observed_at)
                    VALUES (?,?,?,?,?,?,?)""",(
                    day,x['track'],json.dumps(old,ensure_ascii=False),
                    json.dumps(new,ensure_ascii=False),old['source_sha256'],
                    x['source_sha256'],dt.datetime.now(dt.timezone.utc).isoformat()))
                revisions+=1
            c.execute("""UPDATE official_track_daily SET """+
                ','.join(f+'=?' for f in fields[2:])+' WHERE race_date=? AND track=?',
                row[2:]+row[:2])
        else:
            c.execute('INSERT INTO official_track_daily VALUES('+','.join('?' for _ in fields)+')',row)
    return revisions


def populate_context(c):
    import json as _j
    original=c.execute('select race_id,race_date,track,payload_json from races').fetchall()
    for race_id,date,track,pjson in original:
        p=_j.loads(pjson);surface=p.get('surface')
        going=p.get('track_condition_turf') if surface=='芝' else p.get('track_condition_dirt') if surface=='ダート' else None
        if not going:going=p.get('track_condition')
        x=c.execute('select used_turf_course,source_sha256 from official_track_daily where race_date=? and track=?',(date,track)).fetchone()
        used=x[0] if (x and surface=='芝') else None
        c.execute('''INSERT INTO official_race_track_context
            (race_id,race_date,track,surface,going_from_official_result,going_at_0930,
             going_at_0930_status,used_turf_course,used_turf_course_status,source_date,source_sha256)
            VALUES(?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(race_id) DO UPDATE SET
            going_from_official_result=excluded.going_from_official_result,
            used_turf_course=excluded.used_turf_course,used_turf_course_status=excluded.used_turf_course_status,
            source_date=excluded.source_date,source_sha256=excluded.source_sha256''',
            (race_id,date,track,surface,going,None,'NOT_RECORDED_HISTORIC_0930_SNAPSHOT',used,
             'JRA_ARCHIVE_OBSERVED' if used else 'NOT_IN_ARCHIVE',date if x else None,x[1] if x else None))
    from .legacy_track import overlay_context
    overlay_context(c)
    return len(original)


def create_master(src,out,observations,pdf_files):
    with tempfile.TemporaryDirectory(prefix='jra-track-') as tmp:
        tmp=Path(tmp)
        with zipfile.ZipFile(src) as z:z.extractall(tmp)
        db=tmp/'MASTER.sqlite3'
        if not db.is_file(): raise RuntimeError('Not an annual master ZIP: MASTER.sqlite3 missing')
        manifest_path=tmp/'manifest.json'
        manifest=json.loads(manifest_path.read_text(encoding='utf-8'))
        baseline_sha=sha256(db.read_bytes())
        if baseline_sha!=manifest.get('master_sha256'):
            raise RuntimeError('Source manifest master_sha256 disagrees. Aborted; original untouched.')
        year=manifest['year']
        obs=[x for x in observations if int(x['date'][:4])==year]
        old_counts={}
        c=sqlite3.connect(str(db));c.execute('PRAGMA busy_timeout=20000')
        for t in ('races','runners','results','win_odds','pedigree'):
            old_counts[t]=c.execute(f'SELECT count(*) FROM {t}').fetchone()[0]
        try:
            with c:
                schema(c)
                upsert_obs(c,obs)
                n=populate_context(c)
            actual_counts={t:c.execute(f'SELECT count(*) FROM {t}').fetchone()[0] for t in old_counts}
            check=c.execute('pragma integrity_check').fetchone()[0]
            daily=c.execute('select count(*) from official_track_daily').fetchone()[0]
            race_course=c.execute("select count(*) from official_race_track_context where used_turf_course is not null").fetchone()[0]
            race_going=c.execute("select count(*) from official_race_track_context where going_from_official_result is not null").fetchone()[0]
            if check!='ok' or old_counts!=actual_counts:raise RuntimeError('Master integrity/core row count changed')
        finally:c.close()
        # SQLite page reuse is safest with checkpoint, then hashing the closed DB.
        manifest['base_master_sha256']=baseline_sha
        manifest['master_sha256']=sha256(db.read_bytes())
        manifest['schema_version']='2.1.0'
        manifest['track_enrichment']='ADDITIVE_OFFICIAL_ARCHIVE_AND_RESULT_CONTEXT'
        manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
        audit={'status':'PASS','integrity':check,'base_counts':old_counts,'new_counts':actual_counts,
               'race_count':n,'archived_track_day_count':daily,'race_with_used_course':race_course,
               'race_with_official_result_going':race_going,
               'historic_0930_going_observed':0,
               'time_policy':'ARCHIVE RECONSTRUCTED; ACTUAL_PUBLICATION_AT UNKNOWN',
               'master_original_sha256':baseline_sha,'master_enriched_sha256':manifest['master_sha256'],
               'finished_utc':dt.datetime.now(dt.timezone.utc).isoformat()}
        (tmp/'track_enrichment_audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
        sources=[{'url':u,'track':t,'sha256':sha256(f.read_bytes()),'archive_path':f'official_track_pdfs/{year}/{f.name}'}
                 for t,u,f in pdf_files]
        (tmp/'track_enrichment_sources.json').write_text(json.dumps(sources,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
        out.parent.mkdir(parents=True,exist_ok=True)
        with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
            for f in sorted(tmp.iterdir()):
                if f.is_file():z.write(f, f.name)
            for _,_,pdf in pdf_files:
                z.write(pdf,f'official_track_pdfs/{year}/{pdf.name}')
        return audit


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--master',required=True,type=Path)
    ap.add_argument('--output',required=True,type=Path)
    ap.add_argument('--cache-dir',default='jra_pdf_cache',type=Path)
    ap.add_argument('--offline',action='store_true')
    ap.add_argument('--throttle',type=float,default=0.8)
    args=ap.parse_args()
    with zipfile.ZipFile(args.master) as z:
        manifest=json.loads(z.read('manifest.json'))
        year=manifest['year']
    session=requests.Session();session.headers['User-Agent']='Mozilla/5.0 (JRA official data research archival; contact repository owner)'
    files=download_pdfs(year,args.cache_dir,session,args.throttle,args.offline) if year>=2018 else []
    observations=[]
    failed=[]
    for track,url,file in files:
        try:observations+=extract_observations(track,url,file)
        except Exception as e:failed.append(f'{url}: {e}')
    if failed:
        raise RuntimeError('UNVERIFIED PDF PARSING; no output written.\n'+'\n'.join(failed))
    unique={}
    for x in observations:
        key=x['date'],x['track']
        if key in unique and unique[key]!=x:
            raise RuntimeError(f'Conflicting observations for {key}; must audit sources')
        unique[key]=x
    result=create_master(args.master,args.output,list(unique.values()),files)
    print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
