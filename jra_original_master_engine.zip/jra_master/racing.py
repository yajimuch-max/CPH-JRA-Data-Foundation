import re,json,gzip
from dataclasses import asdict
from urllib.parse import urlencode,urljoin
from bs4 import BeautifulSoup
from .jra_parser import parse_result,decode_jra,compact_text as _compact_text
from .legacy_odds_parser import parse_odds,odds_cname
from .store import encode,now
from .network import Deferred
def compact_text(node):return _compact_text(node) if node is not None else ''
BET={'単勝':'WIN','複勝':'PLACE','枠連':'BRACKET_QUINELLA','馬連':'QUINELLA','ワイド':'WIDE','馬単':'EXACTA','3連複':'TRIO','3連単':'TRIFECTA'}
def n(x):
 m=re.search(r'\d[\d,]*',x);return int(m[0].replace(',','')) if m else None

def parse_all(body):
 p=parse_result(body);soup=BeautifulSoup(decode_jra(body),'lxml');race=p.as_dict();race.pop('entries');race.pop('results');race['race_type']='JUMP' if p.surface=='障害' else 'FLAT'
 payouts=[];laps=[];corners=[];names={};extra={};links={}
 table=next(t for t in soup.find_all('table') if t.select_one('thead th.place') and t.select_one('tbody td.horse'))
 for tr in table.select('tbody tr'):
  no=n(compact_text(tr.select_one('td.num')))
  if no is None:continue
  extra[no]={'popularity':n(compact_text(tr.select_one('td.pop'))),'average_1f':float(compact_text(tr.select_one('td.f_time'))) if p.surface=='障害' and re.fullmatch(r'\d+\.\d+',compact_text(tr.select_one('td.f_time'))) else None}
  a=tr.select_one('td.horse a');onclick=(a.get('href','')+a.get('onclick','')) if a else '';m=re.search(r'(pw01dud(?:00|10)[^\s\"\x27)]+)',onclick)
  if m:links[no]='https://www.jra.go.jp/JRADB/accessU.html?'+urlencode({'CNAME':m[1]})
 for dl in soup.find_all('dl'):
  dt=dl.find('dt');label=compact_text(dt)
  if label not in BET:continue
  lines=dl.select('dd .line') or dl.find_all('dd',recursive=False)
  for i,line in enumerate(lines,1):
   text=compact_text(line);combo=compact_text(line.select_one('.num')) or None;yen=n(compact_text(line.select_one('.yen')));pop=n(compact_text(line.select_one('.pop')))
   payouts.append({'bet_type':BET[label],'line_number':i,'combination_text':combo,'payout_yen':yen,'payout_popularity':pop,'special_status':None if combo and yen is not None else 'NOT_OFFERED_OR_NO_PAYOUT','official_text':text})
 for tr in soup.find_all('tr'):
  th=tr.find('th');td=tr.find('td');heading=compact_text(th)
  if heading=='ハロンタイム' and td:
   vals=re.findall(r'\d+\.\d+',compact_text(td));laps=[{'lap_index':i,'lap_time_seconds':float(v)} for i,v in enumerate(vals,1)]
  if 'コーナー' in heading and td and re.search(r'\d',heading):corners.append({'corner_index':heading,'order_text':compact_text(td)})
 return p,race,payouts,laps,corners,extra,links

def integrate_result(s,body,sid,expected_id=None):
 p,race,payouts,laps,corners,extra,links=parse_all(body);rid=p.race_key
 if expected_id and rid!=expected_id:raise ValueError('RESULT_ID_MISMATCH')
 # Validate whole page before writing. Known runner identity changes require investigation.
 old=s.c.execute('SELECT horse_number,horse_id FROM runners WHERE race_id=?',(rid,)).fetchall()
 if old and dict((r[0],r[1]) for r in old)!={r.horse_no:r.horse_id for r in p.entries}:raise ValueError('RUNNER_IDENTITY_SET_MISMATCH')
 with s.c:
  prior=s.c.execute('SELECT payload_json FROM races WHERE race_id=?',(rid,)).fetchone();payload=json.loads(prior[0]) if prior else {};payload.update(race)
  s.put('races',['race_id'],{'race_id':rid,'race_date':p.race_date,'track':p.track,'race_number':p.race_no,'race_type':race['race_type'],'payload_json':encode(payload)},sid)
  for e,r in zip(p.entries,p.results):
   s.c.execute('INSERT OR IGNORE INTO horses VALUES (?,?)',(e.horse_id,e.horse_name));oldentry=s.c.execute('SELECT payload_json FROM runners WHERE race_id=? AND horse_number=?',(rid,e.horse_no)).fetchone();entrypayload=json.loads(oldentry[0]) if oldentry else {};entrypayload.update(asdict(e));s.put('runners',['race_id','horse_number'],{'race_id':rid,'horse_number':e.horse_no,'horse_id':e.horse_id,'payload_json':encode(entrypayload)},sid)
   oldresult=s.c.execute('SELECT payload_json FROM results WHERE race_id=? AND horse_number=?',(rid,r.horse_no)).fetchone();resultpayload=json.loads(oldresult[0]) if oldresult else {};resultpayload.update(asdict(r));resultpayload['final_3f']=None if p.surface=='障害' else r.final_3f;resultpayload.update({k:v for k,v in extra.get(r.horse_no,{}).items() if v is not None});s.put('results',['race_id','horse_number'],{'race_id':rid,'horse_number':r.horse_no,'payload_json':encode(resultpayload)},sid)
   if e.horse_no in links:s.meta('horse_profile_'+e.horse_id,links[e.horse_no])
  for table,key,records in [('payouts','line_number',payouts),('laps','lap_index',laps),('corners','corner_index',corners)]:
   for rec in records:
    row={'race_id':rid,key:rec[key],'payload_json':encode(rec)}
    if table=='payouts':row['bet_type']=rec['bet_type']
    s.put(table,['race_id',key]+(['bet_type'] if table=='payouts' else []),row,sid)
  s.c.execute('INSERT OR IGNORE INTO race_sources VALUES (?,?,?)',(rid,'RESULT_HTML',sid))
 return rid,p

def _official_odds_name_matches(horse_id, canonical_name, odds_display_name):
 # A known JRA display truncation is allowed only for a VERIFIED horse ID and
 # exact display spelling. Do not use generic prefix-based acceptance.
 from .pedigree import norm
 if norm(canonical_name)==norm(odds_display_name):
  return True
 VERIFIED_TRUNCATIONS={
  ('2012190005', 'ウエスタンエクスプレス', 'ウエスタンエクスプ'),
  # 2024 JRA international runners: the archived odds table may retain a
  # shorter display spelling than the horse-profile-verified canonical name.
  # Strict (horse ID, canonical name, odds display name) allowlist only.
  ('2018190002', 'ロマンチックウォリアー', 'ロマンチックウォリ'),
  ('2020190004', 'ファンタスティックムーン', 'ファンタスティック'),
 }
 return (str(horse_id), norm(canonical_name), norm(odds_display_name)) in VERIFIED_TRUNCATIONS


def integrate_odds(s,body,sid,rid):
 rows=parse_odds(body);expected=s.c.execute('SELECT * FROM runners WHERE race_id=?',(rid,)).fetchall()
 if len({r['horse_no'] for r in rows})!=len(rows):raise ValueError('ODDS_DUPLICATE_HORSE_NUMBER')
 if set(r['horse_no'] for r in rows)!=set(r['horse_number'] for r in expected):raise ValueError('ODDS_RUNNER_SET_MISMATCH')
 runners_by_no={r['horse_number']:r for r in expected}
 names={no:s.c.execute('SELECT horse_name FROM horses WHERE horse_id=?',(runner['horse_id'],)).fetchone()[0] for no,runner in runners_by_no.items()}
 mismatched=[(r['horse_no'], runners_by_no[r['horse_no']]['horse_id'], names[r['horse_no']], r['horse_name'])
             for r in rows if not _official_odds_name_matches(runners_by_no[r['horse_no']]['horse_id'], names[r['horse_no']], r['horse_name'])]
 if mismatched:
  # Keep strict validation. Emit the exact official display discrepancy rather
  # than a generic error, so a remaining unexpected naming variant is auditable.
  detail='; '.join('horse_no={} horse_id={} canonical={!r} odds={!r}'.format(*part) for part in mismatched[:5])
  raise ValueError('ODDS_HORSE_NAME_MISMATCH: '+detail)
 with s.c:
  for r in rows:s.put('win_odds',['race_id','horse_number'],{'race_id':rid,'horse_number':r['horse_no'],'win_odds':r['final_win_odds'],'odds_status':r['status'],'source_id':sid,'payload_json':encode(r)},sid,'FINAL_ODDS_VALIDATED_BY_RACE_HORSE_NUMBER_NAME')
  s.c.execute('INSERT OR IGNORE INTO race_sources VALUES (?,?,?)',(rid,'FINAL_WIN_ODDS',sid))
 return len(rows)

def links(body,prefix):
 text=decode_jra(body);return sorted(set(re.findall(r'(pw01'+prefix+r'[^\s\"\x27)<>]+)',text)))
def form(cname):return urlencode({'cname':cname})
def month_cname(body,year,month):
 # Reproduce the branch published by the official search page, not the clock.
 text=decode_jra(body)
 token=re.search(r'objParam\["'+f'{year%100:02d}{month:02d}'+r'"\]\s*=\s*"([0-9A-F]{2})"',text)
 if not token:raise ValueError('OFFICIAL_MONTH_TOKEN_NOT_FOUND')
 cutoff=re.search(r'var\s+yearMonth\s*=\s*["\x27](\d{6})["\x27]',text)
 if not cutoff:raise ValueError('OFFICIAL_MONTH_ROUTE_BOUNDARY_NOT_FOUND')
 # Fail closed if the official routing expression changes.
 branch=re.search(r'if\s*\(Number\(arg\)\s*>=\s*yearMonth\)\s*\{\s*param\s*=\s*\x27pw01skl00\x27',text)
 past=re.search(r'else\s*\{\s*param\s*=\s*\x27pw01skl10\x27',text)
 if not branch or not past:raise ValueError('OFFICIAL_MONTH_ROUTE_UNRECOGNIZED')
 prefix='pw01skl00' if year*100+month>=int(cutoff[1]) else 'pw01skl10'
 return f'{prefix}{year:04d}{month:02d}/'+token[1]

def validate_search_response(body):
 soup=BeautifulSoup(decode_jra(body),'lxml')
 title=compact_text(soup.title)
 if 'パラメータエラー' in title:raise ValueError('JRA_PARAMETER_ERROR_PAGE')

def discover(client,year,month,start,end):
 # Exact official month tokens and meeting/result links; no invented checksums.
 body,sid,p=client.request('https://www.jra.go.jp/JRADB/accessS.html','RESULT_SEARCH_ENTRY',form('pw01skl00999999/B3'))
 cname=month_cname(body,year,month)
 client.valid(sid,p);body,sid,p=client.request('https://www.jra.go.jp/JRADB/accessS.html','RESULT_MONTH_INDEX',form(cname));validate_search_response(body);meetings=links(body,'srl');client.valid(sid,p)
 result=[]
 for cname in meetings:
  date=re.search(r'('+str(year)+r'\d{4})/',cname)
  if not date:raise ValueError('MEETING_DATE_UNPARSEABLE')
  d=date[1][:4]+'-'+date[1][4:6]+'-'+date[1][6:]
  if not start<=d<=end:continue
  body,sid,p=client.request('https://www.jra.go.jp/JRADB/accessS.html','RESULT_RACE_SELECTION',form(cname));found=links(body,'sde');client.valid(sid,p)
  if not found:raise ValueError('MEETING_RESULTS_EMPTY')
  result.extend(found)
 return sorted(set(result))

def collect(s,client,year,months,start,end,refresh=False):
 errors=[];completed=0
 for month in months:
  mk=f'DISCOVER_{year}_{month:02d}_{start}_{end}'
  try:
   key='links_'+mk;row=s.c.execute('SELECT value FROM metadata WHERE key=?',(key,)).fetchone()
   # An empty cached search is not proof that the requested period is complete.
   # Rediscover it without refreshing completed race bodies.
   cached=json.loads(row[0]) if row and not refresh else None
   cnames=cached if cached else discover(client,year,month,start,end)
   s.meta(key,cnames)
   if not cnames:raise ValueError('RESULT_DISCOVERY_EMPTY_UNVERIFIED: no result links in requested month/date range; verify official calendar or search response')
   s.task(mk,'PASS');s.resolve(mk)
   for cname in cnames:
    tk='RACE_'+cname
    if s.done(tk) and not refresh:continue
    try:
     body,sid,p=client.request('https://www.jra.go.jp/JRADB/accessS.html','RACE_RESULT',form(cname));rid,parsed=integrate_result(s,body,sid);client.valid(sid,p)
     oc=odds_cname(body);ob,osid,op=client.request('https://www.jra.go.jp/JRADB/accessO.html','FINAL_WIN_ODDS',form(oc));integrate_odds(s,ob,osid,rid);client.valid(osid,op);s.task(tk,'PASS');s.resolve(tk);completed+=1;print('RACE_PASS',rid,flush=True)
    except Deferred:raise
    except Exception as e:s.task(tk,'FAIL',str(e));s.issue(tk,'RACE_FETCH_OR_VALIDATION',{'error':str(e),'official_cname':cname});errors.append(str(e))
  except Deferred as e:s.task(mk,'DEFERRED',str(e));break
  except Exception as e:s.task(mk,'FAIL',str(e));s.issue(mk,'RESULT_DISCOVERY_INCOMPLETE',{'error':str(e),'year':year,'month':month,'start':start,'end':end});errors.append(str(e))
 return {'completed_races':completed,'errors':errors}

def reaudit_archive(s,path,limit=1000,client=None):
 from .importer import Archive
 from .store import sha
 a=Archive(path);tables={r[0] for r in a.c.execute("SELECT name FROM sqlite_master WHERE type='table'")};
 if 'pedigree_receipts' in tables:
  a.close();return reaudit_compact_pending(s,limit,client)
 modern='raw_sources' in tables;records=a.c.execute('SELECT * FROM '+('raw_sources' if modern else 'raw_catalog')).fetchall();count=0;errors=[]
 # Results first, odds second. Successful tasks checkpoint by content hash.
 def role(r):return r['role'] if modern else r['source_role']
 result_roles=['RACE_RESULT','RACE_RESULT_REMOTE_REFERENCE','RESULT_HTML_VERIFIED','OFFICIAL_RESULT_HTML','JRA_RESULT_STRUCTURED_CAPTURE','JRA_OFFICIAL_PDF_STRUCTURED_CAPTURE','DISCOVERED_RESULT_REFERENCE']
 odds_roles=['FINAL_WIN_ODDS','OFFICIAL_ODDS_HTML','JRA_FINAL_WIN_ODDS_CAPTURE']
 # PDF-only historical races still have exact official result links in saved
 # race-selection pages. Reuse those links, never manufacture CNAME tokens.
 observed={}
 if 'races' in tables:
  from .jra_parser import TRACK_CODE
  known={r[0] for r in a.c.execute('SELECT race_id FROM races')}
  for record in records:
   if role(record)!='RESULT_RACE_SELECTION':continue
   try:selection=a.raw(record['relative_path'])
   except FileNotFoundError:continue
   for cname in links(selection,'sde'):
    match=re.fullmatch(r'pw01sde10(?P<track>\d{2})(?P<year>\d{4})\d{4}(?P<race>\d{2})(?P<date>\d{8})/[0-9A-F]{2}',cname)
    if match and match['year']==match['date'][:4] and match['track'] in TRACK_CODE:
     date=match['date'];rid=f'{date[:4]}-{date[4:6]}-{date[6:]}-{TRACK_CODE[match["track"]]}-{int(match["race"]):02d}'
     if rid in known:observed[rid]='https://www.jra.go.jp/JRADB/accessS.html?'+urlencode({'CNAME':cname})
 records=[dict(r) for r in records if role(r) in result_roles+odds_roles and (not modern or r['media_type'] in ['text/html','reference/url'])]
 covered=set()
 if observed:
  for record in records:
   if role(record) not in result_roles:continue
   linked=a.c.execute('SELECT DISTINCT race_id FROM race_sources WHERE raw_source_id=?',(record['raw_source_id'],)).fetchall() if modern else a.c.execute('SELECT race_id FROM races WHERE source_snapshot_id=?',(record['snapshot_id'],)).fetchall()
   covered.update(r[0] for r in linked)
   if len(linked)==1:record['_official_result_url']=observed.get(linked[0][0])
  for rid in sorted(set(observed)-covered):
   source_key='DISCOVERED_'+rid
   record={'role':'DISCOVERED_RESULT_REFERENCE','source_role':'DISCOVERED_RESULT_REFERENCE','raw_source_id':source_key,'snapshot_id':source_key,'relative_path':None,'sha256':None,'media_type':'reference/url','source_url':observed[rid],'_linked_race_id':rid}
   s.source({'source_id':'BASE_'+source_key,'service':'JRA','role':'DISCOVERED_RESULT_REFERENCE','url':observed[rid],'raw_state':'REFERENCE_ONLY','observed_in':'LEGACY_RESULT_RACE_SELECTION'})
   records.append(record)
  s.c.commit()
 records=sorted(records,key=lambda r:0 if role(r) in result_roles else 1)
 def task_key(r):
  digest=r.get('sha256',r.get('entity_sha256'))
  return 'REAUDIT_'+role(r)+'_'+str(digest or ('SOURCE_'+str(r.get('raw_source_id',r.get('snapshot_id')))))
 for r0 in records:
  r=dict(r0);tk=task_key(r)
  if not s.c.execute('SELECT 1 FROM tasks WHERE task_key=?',(tk,)).fetchone():s.task(tk,'PENDING')
 for row in records:
  r=dict(row);kind=role(r)
  digest=r.get('sha256',r.get('entity_sha256'));key=task_key(r)
  if s.done(key):continue
  if count>=limit:break
  count+=1
  try:
   sid='BASE_'+str(r.get('raw_source_id',r.get('snapshot_id')))
   fetched_path=None
   try:
    if kind in ['JRA_RESULT_STRUCTURED_CAPTURE','JRA_OFFICIAL_PDF_STRUCTURED_CAPTURE','JRA_FINAL_WIN_ODDS_CAPTURE']:raise FileNotFoundError('STRUCTURED_CAPTURE_NEEDS_OFFICIAL_HTML')
    b=a.raw(r['relative_path'])
    if digest is None:hash_scope='LEGACY_HASH_NOT_RECORDED'
    elif sha(b)==digest:hash_scope='DECOMPRESSED_BODY'
    elif r['relative_path'].endswith('.gz') and sha(a.stored_raw(r['relative_path']))==digest:hash_scope='STORED_GZIP_BYTES'
    else:raise ValueError('BASE_RAW_HASH_MISMATCH')
    provenance=s.c.execute('SELECT metadata_json FROM source_records WHERE source_id=?',(sid,)).fetchone()
    if provenance:
     meta=json.loads(provenance[0]);meta.update(verified_legacy_hash_scope=hash_scope,verified_body_sha256=sha(b),legacy_hash_verified_at=now())
     s.c.execute('UPDATE source_records SET entity_sha256=?,metadata_json=? WHERE source_id=?',(sha(b),encode(meta),sid));s.c.commit()
   except FileNotFoundError:
    if client is None:raise ValueError('BASE_RAW_UNAVAILABLE_NEEDS_OFFICIAL_FETCH')
    from urllib.parse import urlparse,parse_qs
    official=urlparse((r.get('_official_result_url') if kind in result_roles else None) or r.get('source_url',r.get('request_url')) or '')
    expected_path='/JRADB/accessO.html' if kind in odds_roles else '/JRADB/accessS.html'
    cname=(parse_qs(official.query).get('CNAME') or [None])[0]
    if official.scheme!='https' or official.hostname not in ['www.jra.go.jp','jra.go.jp'] or official.path!=expected_path or not cname:raise ValueError('INVALID_OFFICIAL_REFERENCE_URL')
    b,sid,fetched_path=client.request('https://www.jra.go.jp'+expected_path,'REAUDIT_OFFICIAL_'+kind,form(cname))
   if kind in odds_roles:
    # Resolve race from exact stored source relationship; never align by row order.
    if r.get('_linked_race_id'):linked=[(r['_linked_race_id'],)]
    elif modern:linked=a.c.execute('SELECT DISTINCT race_id FROM race_sources WHERE raw_source_id=?',(r['raw_source_id'],)).fetchall()
    else:
     columns={x[1] for x in a.c.execute('PRAGMA table_info(market_win_odds)')}
     linked=a.c.execute('SELECT DISTINCT race_id FROM market_win_odds WHERE source_snapshot_id=?',(r['snapshot_id'],)).fetchall() if 'source_snapshot_id' in columns else []
     if not linked:
      from .jra_parser import TRACK_CODE
      candidate_ids=set()
      for match in re.finditer(r'pw01sde10(?P<track>\d{2})(?P<year>\d{4})\d{4}(?P<race>\d{2})(?P<date>\d{8})/[0-9A-F]{2}',decode_jra(b)):
       date=match['date'];track=TRACK_CODE.get(match['track'])
       if track and date[:4]==match['year']:
        rid=f'{date[:4]}-{date[4:6]}-{date[6:]}-{track}-{int(match["race"]):02d}'
        if a.c.execute('SELECT 1 FROM races WHERE race_id=?',(rid,)).fetchone():candidate_ids.add(rid)
      linked=[(rid,) for rid in sorted(candidate_ids)]
    if len(linked)!=1:raise ValueError('ODDS_SOURCE_RACE_LINK_AMBIGUOUS')
    integrate_odds(s,b,sid,linked[0][0])
   else:
    if r.get('_linked_race_id'):linked=[(r['_linked_race_id'],)]
    elif modern:linked=a.c.execute('SELECT DISTINCT race_id FROM race_sources WHERE raw_source_id=?',(r['raw_source_id'],)).fetchall()
    else:linked=a.c.execute('SELECT DISTINCT race_id FROM races WHERE source_snapshot_id=?',(r['snapshot_id'],)).fetchall()
    if len(linked)!=1:raise ValueError('RESULT_SOURCE_RACE_LINK_AMBIGUOUS')
    integrate_result(s,b,sid,linked[0][0])
   if fetched_path is not None:client.valid(sid,fetched_path)
   s.task(key,'PASS');s.resolve(key)
  except Deferred as e:s.task(key,'DEFERRED',str(e));break
  except Exception as e:s.task(key,'FAIL',str(e));s.issue(key,'BASE_RAW_REAUDIT',{'error':str(e),'path':r.get('relative_path')});errors.append(str(e))
 a.close();return {'processed_sources':count,'errors':errors}


def queue_result_final_odds(s,body,rid,sid,queue):
 # The exact final-odds link is read from a validated official result body.
 key='REAUDIT_FINAL_ODDS_'+rid
 if s.done(key) or any(item['task_key']==key for item in queue):return
 cname=odds_cname(body)
 url='https://www.jra.go.jp/JRADB/accessO.html?'+urlencode({'CNAME':cname})
 queue.append({'task_key':key,'race_id':rid,'kind':'ODDS','url':url,'observed_from_source_id':sid})
 s.meta('pending_official_reaudit',queue);s.task(key,'PENDING','Final odds official body not stored in legacy archive')

def reaudit_compact_pending(s,limit,client):
 # Prepared compact masters carry exact recorded URLs for remaining official
 # checks, so smartphone users do not need to upload the old RAW archive again.
 from urllib.parse import urlparse,parse_qs
 row=s.c.execute("SELECT value FROM metadata WHERE key='pending_official_reaudit'").fetchone()
 if not row:raise ValueError('COMPACT_MASTER_HAS_NO_OFFICIAL_REAUDIT_QUEUE')
 queue=json.loads(row[0]);count=0;errors=[]
 for item in queue:
  key=item['task_key']
  if s.done(key):continue
  if count>=limit:break
  count+=1
  try:
   if client is None:raise ValueError('OFFICIAL_FETCH_CLIENT_REQUIRED')
   rid=item['race_id'];kind=item['kind'];url=urlparse(item['url']);expected='/JRADB/accessO.html' if kind=='ODDS' else '/JRADB/accessS.html'
   cname=(parse_qs(url.query).get('CNAME') or [None])[0]
   if kind not in ['RESULT','ODDS'] or url.scheme!='https' or url.hostname not in ['www.jra.go.jp','jra.go.jp'] or url.path!=expected or not cname:raise ValueError('INVALID_OFFICIAL_REFERENCE_URL')
   if not s.c.execute('SELECT 1 FROM races WHERE race_id=?',(rid,)).fetchone():raise ValueError('UNKNOWN_REAUDIT_RACE')
   body,sid,path=client.request('https://www.jra.go.jp'+expected,'REAUDIT_OFFICIAL_PREPARED_'+kind,form(cname))
   if kind=='RESULT':integrate_result(s,body,sid,rid)
   else:integrate_odds(s,body,sid,rid)
   client.valid(sid,path)
   required=s.c.execute("SELECT value FROM metadata WHERE key='require_final_odds_completion'").fetchone()
   if kind=='RESULT' and required and json.loads(required[0]):queue_result_final_odds(s,body,rid,sid,queue)
   s.task(key,'PASS');s.resolve(key);print('OFFICIAL_REAUDIT_PASS',rid,flush=True)
  except Deferred as e:s.task(key,'DEFERRED',str(e));break
  except Exception as e:
   s.task(key,'FAIL',str(e));s.issue(key,'BASE_RAW_REAUDIT',{'error':str(e),'observed_url':item.get('url')});errors.append(str(e))
 return {'processed_sources':count,'errors':errors}
