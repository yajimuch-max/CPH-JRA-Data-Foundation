from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass(frozen=True)
class ScheduleRace:
    race_date: str
    track: str
    meeting_label: str
    race_no: int
    race_name: str
    surface: str
    distance_m: int
    post_time: str
    is_flat: bool

    @property
    def race_key(self) -> str:
        return f"{self.race_date}-{self.track}-{self.race_no:02d}"


@dataclass(frozen=True)
class RaceEntry:
    horse_no: int
    frame_no: int | None
    horse_id: str
    horse_name: str
    sex_age: str | None
    assigned_weight_kg: float | None
    jockey_id: str | None
    jockey_name: str | None
    trainer_id: str | None
    trainer_name: str | None
    body_weight_kg: int | None
    body_weight_change_kg: int | None


@dataclass(frozen=True)
class RaceResult:
    horse_no: int
    finish_status: str
    finish_position: int | None
    finish_time: str | None
    margin: str | None
    corner_positions: list[int] = field(default_factory=list)
    final_3f: float | None = None


@dataclass(frozen=True)
class ParsedRace:
    race_date: str
    track: str
    meeting_label: str
    race_no: int
    race_name: str
    surface: str
    distance_m: int
    course_detail: str | None
    post_time: str
    weather: str | None
    track_condition: str | None
    grade: str | None
    entries: list[RaceEntry]
    results: list[RaceResult]

    @property
    def race_key(self) -> str:
        return f"{self.race_date}-{self.track}-{self.race_no:02d}"

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class ValidationIssue:
    code: str
    severity: str
    message: str
    race_key: str | None = None

