"""One portable SQLite master; source records are metadata, never hidden RAW."""
import sqlite3,json,hashlib
from datetime import datetime,timezone
from pathlib import Path
VERSION='2.0.0'
def now():return datetime.now(timezone.utc).isoformat()
def encode(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def sha(b):return hashlib.sha256(b).hexdigest()
SCHEMA='''
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS metadata(key TEXT PRIMARY KEY,value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS races(race_id TEXT PRIMARY KEY,race_date TEXT NOT NULL,track TEXT NOT NULL,race_number INTEGER NOT NULL,race_type TEXT NOT NULL,payload_json TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS horses(horse_id TEXT PRIMARY KEY,horse_name TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS runners(race_id TEXT,horse_number INTEGER,horse_id TEXT NOT NULL,payload_json TEXT NOT NULL,PRIMARY KEY(race_id,horse_number),FOREIGN KEY(race_id) REFERENCES races,FOREIGN KEY(horse_id) REFERENCES horses);
CREATE TABLE IF NOT EXISTS results(race_id TEXT,horse_number INTEGER,payload_json TEXT NOT NULL,PRIMARY KEY(race_id,horse_number),FOREIGN KEY(race_id,horse_number) REFERENCES runners);
CREATE TABLE IF NOT EXISTS win_odds(race_id TEXT,horse_number INTEGER,win_odds REAL,odds_status TEXT NOT NULL,source_id TEXT,payload_json TEXT NOT NULL,PRIMARY KEY(race_id,horse_number),FOREIGN KEY(race_id,horse_number) REFERENCES runners);
CREATE TABLE IF NOT EXISTS payouts(race_id TEXT,bet_type TEXT,line_number INTEGER,payload_json TEXT NOT NULL,PRIMARY KEY(race_id,bet_type,line_number),FOREIGN KEY(race_id) REFERENCES races);
CREATE TABLE IF NOT EXISTS laps(race_id TEXT,lap_index INTEGER,payload_json TEXT NOT NULL,PRIMARY KEY(race_id,lap_index),FOREIGN KEY(race_id) REFERENCES races);
CREATE TABLE IF NOT EXISTS corners(race_id TEXT,corner_index TEXT,payload_json TEXT NOT NULL,PRIMARY KEY(race_id,corner_index),FOREIGN KEY(race_id) REFERENCES races);
CREATE TABLE IF NOT EXISTS source_records(source_id TEXT PRIMARY KEY,service TEXT NOT NULL,role TEXT NOT NULL,url TEXT,entity_sha256 TEXT,requested_at TEXT,responded_at TEXT,raw_saved_at TEXT,integrated_at TEXT,http_status INTEGER,raw_state TEXT NOT NULL,metadata_json TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS race_sources(race_id TEXT,role TEXT,source_id TEXT,PRIMARY KEY(race_id,role,source_id),FOREIGN KEY(race_id) REFERENCES races,FOREIGN KEY(source_id) REFERENCES source_records);
CREATE TABLE IF NOT EXISTS revisions(revision_id INTEGER PRIMARY KEY AUTOINCREMENT,table_name TEXT,item_key TEXT,old_json TEXT,new_json TEXT,source_id TEXT,reason TEXT,corrected_at TEXT);
CREATE TABLE IF NOT EXISTS tasks(task_key TEXT PRIMARY KEY,status TEXT NOT NULL,updated_at TEXT,message TEXT);
CREATE TABLE IF NOT EXISTS issues(issue_key TEXT PRIMARY KEY,kind TEXT,status TEXT NOT NULL,details_json TEXT NOT NULL,created_at TEXT,resolved_at TEXT);
CREATE TABLE IF NOT EXISTS pedigree(horse_id TEXT,path TEXT,generation INTEGER NOT NULL,ancestor_id TEXT,ancestor_name TEXT,birth_year INTEGER,source_id TEXT,status TEXT NOT NULL,PRIMARY KEY(horse_id,path),FOREIGN KEY(horse_id) REFERENCES horses,FOREIGN KEY(source_id) REFERENCES source_records);
CREATE TABLE IF NOT EXISTS pedigree_receipts(horse_id TEXT PRIMARY KEY,source_id TEXT NOT NULL,checked_fields INTEGER NOT NULL,status TEXT NOT NULL,FOREIGN KEY(horse_id) REFERENCES horses);
CREATE TABLE IF NOT EXISTS host_budget(host TEXT PRIMARY KEY,last_requested_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS supplemental_records(table_name TEXT,item_key TEXT,race_id TEXT,horse_id TEXT,payload_json TEXT NOT NULL,PRIMARY KEY(table_name,item_key));
'''
class Store:
 def __init__(self,path):
  Path(path).parent.mkdir(parents=True,exist_ok=True);self.path=Path(path);self.c=sqlite3.connect(path);self.c.row_factory=sqlite3.Row
  # Keep rollback journals at zero length after commit: portable across
  # filesystems where an unlinked journal may remain visible to a new process.
  self.c.execute('PRAGMA journal_mode=TRUNCATE')
  if self.c.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise ValueError('RESUMED_STATE_INTEGRITY_FAILED')
  self.c.executescript(SCHEMA);self.meta('schema_version','2.1.0' if self.c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='official_track_daily'").fetchone() else VERSION)
 def meta(self,k,v):self.c.execute('INSERT OR REPLACE INTO metadata VALUES (?,?)',(k,encode(v)));self.c.commit()
 def done(self,k):return self.c.execute('SELECT 1 FROM tasks WHERE task_key=? AND status=?',(k,'PASS')).fetchone() is not None
 def task(self,k,status,message=''):self.c.execute('INSERT OR REPLACE INTO tasks VALUES (?,?,?,?)',(k,status,now(),message));self.c.commit()
 def issue(self,k,kind,details):self.c.execute('INSERT OR REPLACE INTO issues VALUES (?,?,?,?,?,NULL)',(k,kind,'OPEN',encode(details),now()));self.c.commit()
 def resolve(self,k):self.c.execute("UPDATE issues SET status='RESOLVED',resolved_at=? WHERE issue_key=?",(now(),k));self.c.commit()
 def source(self,rec):
  rec=dict(rec);sid=rec.pop('source_id',None) or sha(encode(rec).encode())
  vals=[sid]+[rec.get(k) for k in ['service','role','url','entity_sha256','requested_at','responded_at','raw_saved_at','integrated_at','http_status']]+[rec.get('raw_state','NOT_RETAINED'),encode(rec)]
  self.c.execute('INSERT OR IGNORE INTO source_records VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',vals);return sid
 def put(self,table,keys,record,source=None,reason='OFFICIAL_VERIFIED_UPDATE'):
  cols=list(record);where=' AND '.join('"'+k+'"=?' for k in keys);old=self.c.execute('SELECT * FROM '+table+' WHERE '+where,[record[k] for k in keys]).fetchone()
  if old:
   previous=dict(old)
   if previous==record:return False
   self.c.execute('INSERT INTO revisions(table_name,item_key,old_json,new_json,source_id,reason,corrected_at) VALUES (?,?,?,?,?,?,?)',(table,encode({k:record[k] for k in keys}),encode(previous),encode(record),source,reason,now()))
   self.c.execute('UPDATE '+table+' SET '+','.join('"'+k+'"=?' for k in cols)+' WHERE '+where,[record[k] for k in cols]+[record[k] for k in keys])
  else:self.c.execute('INSERT INTO '+table+'('+','.join('"'+k+'"' for k in cols)+') VALUES ('+','.join('?' for k in cols)+')',[record[k] for k in cols])
  return True
 def audit(self):
  tables=['races','horses','runners','results','win_odds','payouts','laps','corners','pedigree','revisions','source_records','supplemental_records']
  counts={t:self.c.execute('SELECT count(*) FROM '+t).fetchone()[0] for t in tables};integrity=self.c.execute('PRAGMA integrity_check').fetchone()[0];fk=[tuple(x) for x in self.c.execute('PRAGMA foreign_key_check')]
  gaps={t:self.c.execute('SELECT count(*) FROM runners r LEFT JOIN '+t+' x USING(race_id,horse_number) WHERE x.race_id IS NULL').fetchone()[0] for t in ['results','win_odds']}
  pending=[dict(x) for x in self.c.execute("SELECT * FROM tasks WHERE status!='PASS'")];issues=[dict(x) for x in self.c.execute("SELECT * FROM issues WHERE status='OPEN'")]
  result={'status':'PASS' if integrity=='ok' and not fk and not any(gaps.values()) and not pending and not issues and counts['races'] else 'PARTIAL','integrity':integrity,'foreign_keys':fk,'counts':counts,'runner_coverage_gaps':gaps,'pending_tasks':pending,'open_issues':issues,'audited_at':now(),'race_date_min':self.c.execute('SELECT min(race_date) FROM races').fetchone()[0],'race_date_max':self.c.execute('SELECT max(race_date) FROM races').fetchone()[0]}
  self.meta('last_audit',result);return result
