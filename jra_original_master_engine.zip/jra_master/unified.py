import json,collections,re
from .store import now
FIELDS={
'races':'race_date track race_no race_type race_name meeting_label post_time distance_m surface course_detail grade weather track_condition class_raw class_canonical track_condition_dirt track_condition_turf official_sectional_3f official_sectional_4f race_status starter_count entry_count race_class_official race_notes_official payout_category_notes'.split(),
'runners':'horse_no frame_no horse_id horse_name sex_age assigned_weight_kg jockey_id jockey_name trainer_id trainer_name body_weight_kg body_weight_change_kg body_weight_official'.split(),
'results':'horse_no finish_position finish_status finish_time margin popularity final_3f corner_positions average_1f_seconds legacy_average_1f_seconds finish_display final_section_header final_section_official'.split(),
'win_odds':'final_win_odds horse_name horse_no status'.split(),
'payouts':'bet_type combination_text line_number official_text payout_popularity payout_yen special_status'.split(),
'laps':'lap_index lap_time_seconds'.split(),
'corners':'corner_index order_text'.split()}
def decode(s):
 try:return json.loads(s)
 except json.JSONDecodeError:return json.loads(s.replace('\\"','"'))
def encode(d):return json.dumps(d,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def norm(s):return re.sub(r'\s','',str(s))
def normalize_export_store(s,baseline_cutoff=None):
 # Operates only on an isolated export snapshot; resumable collection rows stay intact.
 c=s.c
 payloads={};outers={};cols={}
 for t,fields in FIELDS.items():
  cols[t]=[r[1] for r in c.execute('pragma table_info('+t+')')];payloads[t]={};outers[t]={}
  keys=[r[1] for r in c.execute('pragma table_info('+t+')') if r[5]]
  for row in c.execute('select * from '+t):
   d=dict(zip(cols[t],row));key=tuple(d[k] for k in keys);old=decode(d['payload_json']);new={k:old.get(k) for k in fields}
   for name,outer in [('horse_no','horse_number'),('race_no','race_number'),('race_date','race_date'),('track','track'),('race_type','race_type')]:
    if name in new and new[name] is None:new[name]=d.get(outer)
   if t=='win_odds':
    if new['final_win_odds'] is None:new['final_win_odds']=d['win_odds']
    if new['status'] is None:new['status']=d['odds_status']
   if t=='results':
    official=old.get('official_average_1f')
    previous=old.get('average_1f_seconds',old.get('average_1f'))
    if previous is None:previous=old.get('average_1f')
    if official is not None:
     new['average_1f_seconds']=official
     if previous is not None and previous!=official:new['legacy_average_1f_seconds']=previous
    elif new['average_1f_seconds'] is None:new['average_1f_seconds']=old.get('average_1f')
    if new['corner_positions'] is None and old.get('corner_positions_json'):new['corner_positions']=decode(old['corner_positions_json'])
   if t=='runners':
    if new['frame_no'] is None:new['frame_no']=old.get('frame_number')
   if t=='corners' and new['corner_index'] is None:new['corner_index']=d['corner_index']
   for k in fields:
    if old.get(k) is not None and k!='average_1f_seconds':assert new[k]==old[k],(t,key,k)
   payloads[t][key]=new;outers[t][key]=d
 horse_keys={(k[0],v['horse_id']):k for k,v in outers['runners'].items()}
 payout_bets={(k[0],k[1]) for k in payloads['payouts']}
 exceptional=[];suppstats=collections.Counter()
 for row in c.execute('select * from supplemental_records'):
  t,item,race,hid,raw=row;d=decode(raw);suppstats[t]+=1
  if t=='race_details':
   q=payloads['races'][(race,)]
   for old,new in [('race_class_official','race_class_official'),('race_notes_official','race_notes_official')]:
    if d.get(old) is not None:q[new]=d[old]
  elif t=='result_details':
   k=horse_keys[(race,d.get('horse_id') or hid)];r=payloads['runners'][k];q=payloads['results'][k]
   text=d.get('body_weight_official');expected=str(r['body_weight_kg'])+'('+('+' if (r['body_weight_change_kg'] or 0)>0 else '')+str(r['body_weight_change_kg'])+')'
   if text is not None and norm(text)!=norm(expected):r['body_weight_official']=text
   text=d.get('finish_display')
   if text is not None and norm(text)!=norm(q['finish_position']):q['finish_display']=text
   value=d.get('final_section_official',d.get('section_value'));head=d.get('final_section_header',d.get('section_header'))
   try:equiv=value is None or float(value)==q['final_3f']
   except (ValueError,TypeError):equiv=False
   if not equiv:q['final_section_official']=value;q['final_section_header']=head
  elif t=='payout_categories':
   bet=d.get('bet_type');has=(race,bet) in payout_bets
   if not has or d.get('status') not in [None,'PAYOUT','ESTABLISHED']:
    q=payloads['races'][(race,)];q['payout_category_notes']=q['payout_category_notes'] or {};q['payout_category_notes'][bet]={'official_text':d.get('official_text'),'status':d.get('status')}
  elif t=='cancelled_races':
   d.pop('source_snapshot_id',None);exceptional.append((t,item,race,hid,encode(d)))
  elif t not in ['LEGACY_DOCUMENT','legacy_audit_report','official_race_keys']:raise AssertionError((t,))
 with s.c:
  
  if baseline_cutoff is not None:s.c.execute('delete from revisions where revision_id<=?',(baseline_cutoff,))
  s.c.execute('delete from supplemental_records');s.c.executemany('insert into supplemental_records values(?,?,?,?,?)',exceptional)
  for t in FIELDS:
   keys=[r[1] for r in c.execute('pragma table_info('+t+')') if r[5]]
   sql='update '+t+' set payload_json=? where '+' and '.join(k+'=?' for k in keys)
   s.c.executemany(sql,[(encode(d),*key) for key,d in payloads[t].items()])
 if baseline_cutoff is not None and not c.execute("select 1 from metadata where key='master_history_policy'").fetchone():s.meta('master_history_policy',{'policy':'CURRENT_COMPLETED_DATA_AS_INITIAL_BASELINE','effective_at':now(),'future_changes':'Record corrections made after this baseline.'})
 s.meta('master_data_format',{'version':'JRA_UNIFIED_CURRENT_V1','payload_fields':FIELDS,'optional_values':'NULL when not available; no historical reconstruction.','supplemental_types':['cancelled_races'],'odds':'Final win odds only; not pre-close snapshots.'})
