from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path


def scalar(conn: sqlite3.Connection, sql: str, params=()):
    return conn.execute(sql, params).fetchone()[0]


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--year", required=True, type=int)
    p.add_argument("--data-root", required=True)
    p.add_argument("--output", required=True)
    a = p.parse_args()
    root = Path(a.data_root).resolve()
    conn = sqlite3.connect(root / "cph_jra_df.sqlite3")
    conn.row_factory = sqlite3.Row
    stamp = datetime.now(timezone.utc).isoformat(timespec="microseconds")
    manifest = conn.execute(
        "SELECT manifest_id,race_day_count,manifest_sha256 FROM year_schedule_manifests WHERE year=?",
        (a.year,),
    ).fetchone()
    if manifest is None:
        raise SystemExit("annual manifest is missing")
    # Use a fresh audit-snapshot plan id on every final audit.
    # Prior PASS/FAIL seed-plan history is never deleted.
    compact_stamp = stamp.replace("-", "").replace(":", "").replace("+", "_").replace(".", "_")
    plan_id = f"YEAR-SEED-FINAL-{a.year}-{manifest['manifest_sha256'][:8]}-{compact_stamp}"
    dates = conn.execute(
        "SELECT d.race_date,d.half_year,s.seed_url FROM year_race_days d "
        "LEFT JOIN result_seed_urls s ON s.race_date=d.race_date "
        "WHERE substr(d.race_date,1,4)=? ORDER BY d.race_date", (str(a.year),)
    ).fetchall()
    conn.execute(
        "INSERT INTO year_seed_plans VALUES(?,?,?,?,?,?,?)",
        (plan_id, a.year, manifest["manifest_id"], stamp, stamp, "PASS", len(dates)),
    )
    for ordinal, row in enumerate(dates, 1):
        status = "PASS" if row["seed_url"] else "FAIL"
        conn.execute(
            "INSERT INTO year_seed_items VALUES(?,?,?,?,?,?,?,?,?,?)",
            (plan_id, row["race_date"], row["half_year"], ordinal, status, 1,
             row["seed_url"], None, stamp, "[]" if status == "PASS" else '["SEED_MISSING"]'),
        )
    conn.commit()

    raw_missing = raw_storage_bad = raw_entity_bad = raw_metadata_bad = 0
    for row in conn.execute("SELECT * FROM raw_snapshots"):
        path = root / row["relative_path"]
        if not path.is_file():
            raw_missing += 1
            continue
        stored = path.read_bytes()
        raw_storage_bad += hashlib.sha256(stored).hexdigest() != row["storage_sha256"]
        entity = gzip.decompress(stored) if row["storage_encoding"] == "gzip" else stored
        raw_entity_bad += hashlib.sha256(entity).hexdigest() != row["entity_sha256"]
        required = (row["request_url"], row["final_url"], row["requested_at"],
                    row["responded_at"], row["content_type"], row["fetcher_version"])
        raw_metadata_bad += any(value in (None, "") for value in required)

    day_count = len(dates)
    # Historical schedule manifests are intentionally retained.  Count only
    # the newest manifest for each race date when comparing schedule vs DB.
    flat = scalar(
        conn,
        "SELECT COUNT(*) FROM schedule_races sr "
        "JOIN schedule_manifests sm ON sm.manifest_id=sr.manifest_id "
        "WHERE sr.is_flat=1 "
        "AND sm.manifest_id=("
        " SELECT sm2.manifest_id FROM schedule_manifests sm2 "
        " WHERE sm2.race_date=sm.race_date "
        " ORDER BY sm2.created_at DESC, sm2.manifest_id DESC LIMIT 1"
        ")",
    )
    races = scalar(conn, "SELECT COUNT(*) FROM races_pre_race")
    entries = scalar(conn, "SELECT COUNT(*) FROM race_entries_pre_race")
    results = scalar(conn, "SELECT COUNT(*) FROM race_results")
    duplicates = scalar(conn, "SELECT COUNT(*) FROM (SELECT race_key,horse_id,COUNT(*) c FROM race_entries_pre_race GROUP BY race_key,horse_id HAVING c>1)")
    unpaired = scalar(conn, "SELECT COUNT(*) FROM race_entries_pre_race e LEFT JOIN race_results r ON r.race_key=e.race_key AND r.horse_no=e.horse_no WHERE r.race_key IS NULL")
    unpaired += scalar(conn, "SELECT COUNT(*) FROM race_results r LEFT JOIN race_entries_pre_race e ON e.race_key=r.race_key AND e.horse_no=r.horse_no WHERE e.race_key IS NULL")
    checks = {
        "sqlite_integrity_ok": scalar(conn, "PRAGMA integrity_check") == "ok",
        "foreign_key_violations_zero": len(conn.execute("PRAGMA foreign_key_check").fetchall()) == 0,
        "all_12_months_pass": scalar(
            conn,
            "SELECT COUNT(DISTINCT month) FROM month_collection_runs "
            "WHERE year=? AND status='PASS'",
            (a.year,),
        ) == 12,
        "annual_dates_match_manifest": day_count == manifest["race_day_count"],
        "all_seed_items_pass": scalar(conn, "SELECT COUNT(*) FROM year_seed_items WHERE plan_id=? AND status='PASS'", (plan_id,)) == day_count,
        "all_schedule_manifests_present": scalar(conn, "SELECT COUNT(DISTINCT race_date) FROM schedule_manifests WHERE substr(race_date,1,4)=?", (str(a.year),)) == day_count,
        "flat_schedule_and_race_counts_match": flat == races,
        "entry_and_result_counts_match": entries == results,
        "duplicate_race_horse_zero": duplicates == 0,
        "entry_result_pairing_complete": unpaired == 0,
        "raw_files_all_present": raw_missing == 0,
        "stored_hashes_all_match": raw_storage_bad == 0,
        "entity_hashes_all_match": raw_entity_bad == 0,
        "raw_metadata_complete": raw_metadata_bad == 0,
        "all_http_status_200": scalar(conn, "SELECT COUNT(*) FROM raw_snapshots WHERE http_status!=200") == 0,
        "unexpected_quality_events_zero": scalar(
            conn,
            "SELECT COUNT(*) FROM data_quality_events d "
            "JOIN pipeline_runs p ON p.run_id=d.run_id "
            "WHERE d.event_class!='EXPECTED_NULL' "
            "AND substr(p.race_date,1,4)=? "
            "AND p.mode IN ('ONLINE','CACHE_ONLY') "
            "AND p.run_id=("
            " SELECT p2.run_id FROM pipeline_runs p2 "
            " WHERE p2.race_date=p.race_date AND p2.mode IN ('ONLINE','CACHE_ONLY') "
            " ORDER BY p2.completed_at DESC LIMIT 1"
            ")",
            (str(a.year),),
        ) == 0,
        # Repair workflows intentionally reuse already-good days instead of
        # re-importing them.  Requiring a CACHE_ONLY pipeline row for every
        # historical PASS day would contradict that no-touch policy.
        # The repair script itself cache-proves every repaired date before
        # reaching this audit.  Full-year offline verification is REPARSE.
        "offline_reparse_all_dates_pass": scalar(
            conn,
            "SELECT COUNT(DISTINCT race_date) FROM pipeline_runs "
            "WHERE mode='REPARSE' AND status='PASS' "
            "AND substr(race_date,1,4)=?",
            (str(a.year),),
        ) == day_count,
        "no_running_pipeline_rows": scalar(conn, "SELECT COUNT(*) FROM pipeline_runs WHERE status='RUNNING'") == 0,
    }
    report = {
        "package_id": f"CPH-JRA-DF-v0.14.12-{a.year}-ANNUAL",
        "audit_status": "PASS" if all(checks.values()) else "FAIL",
        "audited_at_utc": stamp,
        "year": a.year,
        "counts": {
            "race_days": day_count,
            "schedule_races_all": scalar(conn, "SELECT COUNT(*) FROM schedule_races"),
            "schedule_races_flat": flat,
            "schedule_races_non_flat": scalar(conn, "SELECT COUNT(*) FROM schedule_races WHERE is_flat=0"),
            "committed_flat_races": races,
            "entries": entries,
            "results": results,
            "raw_snapshots": scalar(conn, "SELECT COUNT(*) FROM raw_snapshots"),
        },
        "checks": checks,
        "operational_note": "Already-good dates were not re-imported. Repaired dates were re-proven CACHE_ONLY inside the recovery step; all race days were then verified offline by REPARSE. Historical failures/manifests remain retained.",
    }
    Path(a.output).write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
    conn.close()
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["audit_status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
