"""Allowance marks describe a ride; they must not split model person histories."""
import unittest
from jra_master.person_identity import normalize_name,build_catalogue,resolve,target_catalogue
class AllowanceIdentityTests(unittest.TestCase):
 def record(self,name,pid=None,date='2020-01-01'):
  return dict(role='jockey',name=name,official_id=pid,race_date=date)
 def test_all_five_official_allowance_marks(self):
  for mark in '★▲△☆◇':
   with self.subTest(mark=mark):self.assertEqual(normalize_name(' '+mark+' 山本　咲希到 '),'山本咲希到')
 def test_name_only_history_uses_same_key(self):
  c=build_catalogue([],'2020-01-01');a=resolve('jockey',None,'☆ 落合 玄太',c);b=resolve('jockey',None,'落合 玄太',c)
  self.assertEqual(a['key'],b['key']);self.assertIsNone(a['official_id'])
 def test_original_source_record_is_not_mutated(self):
  r=self.record('☆ 落合 玄太');build_catalogue([r],'2020-01-01');self.assertEqual(r['name'],'☆ 落合 玄太');self.assertIsNone(r['official_id'])
 def test_known_id_alias_keeps_unknown_source_id(self):
  c=build_catalogue([self.record('落合 玄太','1234')],'2020-01-01');r=resolve('jockey',None,'☆ 落合 玄太',c)
  self.assertEqual(r['key'],'JRA_ID:jockey:1234');self.assertIsNone(r['official_id'])
 def test_conflicting_ids_still_rejected(self):
  c=build_catalogue([self.record('落合 玄太','1234')],'2020-01-01')
  with self.assertRaises(ValueError):resolve('jockey','9999','☆ 落合 玄太',c)
 def test_future_profile_link_not_used(self):
  c=build_catalogue([self.record('落合 玄太','1234','2021-01-01')],'2020-01-01');self.assertEqual(resolve('jockey',None,'☆ 落合 玄太',c)['status'],'NAME_ONLY')
 def test_ordinary_and_foreign_names(self):
  self.assertEqual(normalize_name('Ｍ．デムーロ'),'M.デムーロ');self.assertEqual(normalize_name('田中 淳司'),'田中淳司');self.assertNotEqual(normalize_name('田中 学'),normalize_name('田中 純'));self.assertIsNone(normalize_name(None))
 def test_only_leading_allowance_is_removed(self):
  self.assertEqual(normalize_name('A☆B'),'A☆B')
