import unittest,tempfile,json,hashlib
from pathlib import Path
from jra_master.rebuild_guard import fingerprint,require_ready,validate_feature_times,reusable_cache
from jra_master.person_identity import VERSION

class RebuildGuardTests(unittest.TestCase):
 def setUp(self):
  self.bounds=dict(selection_fit_end=2023,selection_year=2024,fit_end=2024,calibration_year=2025)
  self.ready=dict(raw_history_ready=True,remaining_active_unresolved_people=dict(jockey=0,trainer=0),causal_features_ready=True,person_protocol=VERSION,training_run_permitted=True,source_years=list(range(2010,2026)))
 def test_valid_2026_boundaries_admitted(self):self.assertTrue(require_ready(self.ready,2026,self.bounds))
 def test_missing_person_rows_cannot_be_trained(self):
  x=self.ready|dict(remaining_active_unresolved_people=dict(jockey=1,trainer=0))
  with self.assertRaisesRegex(ValueError,'INCOMPLETE_PERSON_HISTORY'):require_ready(x,2026,self.bounds)
 def test_old_precomputed_features_cannot_be_reused_as_rebuilt(self):
  with self.assertRaisesRegex(ValueError,'CAUSAL_PERSON_FEATURES_NOT_REBUILT'):require_ready(self.ready|dict(person_protocol='OLD_ID_ONLY'),2026,self.bounds)
 def test_2026_sources_cannot_select_2026_model(self):
  with self.assertRaisesRegex(ValueError,'FUTURE_SELECTION_DATA'):require_ready(self.ready|dict(source_years=list(range(2010,2027))),2026,self.bounds)
 def test_boundaries_cannot_be_shifted_after_seeing_result(self):
  with self.assertRaisesRegex(ValueError,'INVALID_ANNUAL_BOUNDARIES'):require_ready(self.ready,2026,self.bounds|dict(selection_year=2026))
 def test_same_day_and_future_history_is_rejected(self):
  d=[dict(race_date='2025-01-05',history_cutoff='2025-01-05')]
  with self.assertRaisesRegex(ValueError,'NONCAUSAL_HISTORY_CUTOFF'):validate_feature_times(d,2025)
 def test_old_cache_miss_when_original_or_identity_or_feature_spec_changes(self):
  args=dict(source_hashes=['a'],person_catalogue_sha256='p',feature_spec_sha256='f',columns=['x'],recipe={'name':'hgb'},boundaries=self.bounds)
  old=fingerprint(**args)
  for k,v in [('source_hashes',['b']),('person_catalogue_sha256','q'),('feature_spec_sha256','g')]:self.assertNotEqual(old,fingerprint(**(args|{k:v})))
 def test_cache_requires_matching_inputs_and_artifact_sha(self):
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp)/'model.pkl';p.write_bytes(b'model');m=p.with_suffix('.pkl.inputs.json')
   self.assertFalse(reusable_cache(p,'new'))
   m.write_text(json.dumps(dict(input_fingerprint='old',artifact_sha256=hashlib.sha256(p.read_bytes()).hexdigest())))
   self.assertFalse(reusable_cache(p,'new'));self.assertTrue(reusable_cache(p,'old'))
   p.write_bytes(b'changed');self.assertFalse(reusable_cache(p,'old'))
