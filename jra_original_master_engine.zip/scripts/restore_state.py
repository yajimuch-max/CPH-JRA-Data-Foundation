"""Restore the newest non-expired year state, including partial/failed checkpoints."""
import argparse,json,os,subprocess,zipfile,io
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--year',type=int,required=True);p.add_argument('--run-id',default='');args=p.parse_args();repo=os.environ['GITHUB_REPOSITORY'];this_run=os.environ.get('GITHUB_RUN_ID');name='jra-original-state-'+str(args.year)
def gh(*cmd):return subprocess.check_output(['gh',*cmd])
selected=None
for page in range(1,11):
 payload=json.loads(gh('api',f'repos/{repo}/actions/artifacts?per_page=100&page={page}'))
 for item in payload['artifacts']:
  run=str(item.get('workflow_run',{}).get('id',''))
  if item['name']==name and not item['expired'] and run!=this_run and (not args.run_id or run==args.run_id):selected=item;break
 if selected or len(payload['artifacts'])<100:break
if not selected:
 if args.run_id:raise SystemExit('Requested state artifact not found or expired')
 print('No prior state. Bootstrap/rebuild will start.');raise SystemExit(0)
body=gh('api',f"repos/{repo}/actions/artifacts/{selected['id']}/zip");z=zipfile.ZipFile(io.BytesIO(body));paths=[n for n in z.namelist() if n.endswith('MASTER.sqlite3')]
if len(paths)!=1:raise SystemExit('State DB missing or ambiguous')
(Path('state')/str(args.year)).mkdir(parents=True,exist_ok=True);(Path('state')/str(args.year)/'MASTER.sqlite3').write_bytes(z.read(paths[0]));print('Restored state from run',selected['workflow_run']['id'])
