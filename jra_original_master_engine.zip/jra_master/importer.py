import zipfile,sqlite3,tempfile,json,gzip
from pathlib import Path
from .store import encode,sha,now
CORE_2024=['races','runners','results','win_odds','payouts','race_laps','race_corner_orders']
CORE_2026=['races','runners_pre_race','results_post_race','market_win_odds','market_popularity','market_payouts','official_laps']
class Archive:
 def __init__(self,path):
  self.path=Path(path);self.z=zipfile.ZipFile(path);names=[n for n in self.z.namelist() if n.endswith('.sqlite3') and '/legacy/' not in n and '/history/' not in n and '/delta_history/' not in n]
  if len(names)!=1:raise ValueError('PRIMARY_DB_AMBIGUOUS:'+str(names))
  def logical(n):
   try:return n.encode('cp437').decode('utf-8')
   except (UnicodeEncodeError,UnicodeDecodeError):return n
  self.members={logical(n):n for n in self.z.namelist()};self.members.update({n:n for n in self.z.namelist()})
  self.dbname=names[0];self.root=logical(self.dbname.rsplit('/data/',1)[0]) if '/data/' in self.dbname else ''
  self.tmp=tempfile.TemporaryDirectory();db=Path(self.tmp.name)/'input.sqlite3';db.write_bytes(self.z.read(self.dbname));self.c=sqlite3.connect(db);self.c.row_factory=sqlite3.Row
 def stored_raw(self,path):
  if not path:raise FileNotFoundError('NO_STORED_RAW_PATH')
  variants=[self.root+'/data/'+path,self.root+'/'+path,path];n=next((self.members[n] for n in variants if n in self.members),None)
  if not n:raise FileNotFoundError(path)
  return self.z.read(n)
 def raw(self,path):
  b=self.stored_raw(path);return gzip.decompress(b) if path.endswith('.gz') else b
 def close(self):self.c.close();self.z.close();self.tmp.cleanup()
def bootstrap(s,path,year):
 if s.c.execute('SELECT count(*) FROM races').fetchone()[0]:raise ValueError('BOOTSTRAP_REQUIRES_EMPTY_DB; use resumed state instead')
 a=Archive(path);src=a.c;names={r[0] for r in src.execute("SELECT name FROM sqlite_master WHERE type='table'")};modern='runners' in names
 if 'source_records' in names and 'pedigree_receipts' in names:
  expected=src.execute("SELECT value FROM metadata WHERE key='year'").fetchone()
  if expected is None or json.loads(expected[0])!=year:raise ValueError('ORIGINAL_MASTER_YEAR_MISMATCH')
  version=src.execute("SELECT value FROM metadata WHERE key='schema_version'").fetchone()
  if version is None or json.loads(version[0]) not in ('2.0.0','2.1.0'):raise ValueError('COMPACT_MASTER_SCHEMA_VERSION_MISMATCH')
  if src.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise ValueError('INPUT_INTEGRITY_FAILED')
  imported={}
  for table in ['metadata','horses','races','source_records','runners','results','win_odds','payouts','laps','corners','race_sources','revisions','tasks','issues','pedigree','pedigree_receipts','host_budget','supplemental_records']:
   if table not in names:continue
   rows=src.execute('SELECT * FROM '+table).fetchall()
   if rows:s.c.executemany('INSERT OR REPLACE INTO '+table+' VALUES ('+','.join('?' for _ in rows[0])+')',[tuple(r) for r in rows])
   imported[table]=len(rows)
  # Retain all JRA official enrichment tables during bootstrap from an exported
  # master, otherwise a missing/expired Actions state silently discards progress.
  if any(t.startswith('official_') for t in names):
   from .track_enrichment import schema as track_schema
   from .legacy_track import schema as legacy_schema
   from .official_expansion import schema as expansion_schema
   track_schema(s.c);legacy_schema(s.c);expansion_schema(s.c)
  official_tables=[
    'official_track_daily','official_track_pdf_receipts','official_race_track_context',
    'official_legacy_report_receipts','official_legacy_race_values','official_legacy_revisions',
    'official_expansion_receipts','official_expansion_races',
    'official_expansion_runners','official_expansion_revisions']
  for table in official_tables:
   if table not in names:continue
   source_cols=[x[1] for x in src.execute('PRAGMA table_info('+table+')')]
   dest_cols=[x[1] for x in s.c.execute('PRAGMA table_info('+table+')')]
   overlap=[name for name in source_cols if name in dest_cols]
   # Fail closed on an unknown non-null required column rather than importing a partial row.
   unknown=set(source_cols)-set(dest_cols)
   if unknown:raise ValueError(f'OFFICIAL_TABLE_UNKNOWN_COLUMNS:{table}:{sorted(unknown)}')
   if overlap:
    quoted=','.join('"'+name+'"' for name in overlap)
    rows=src.execute('SELECT '+quoted+' FROM '+table).fetchall()
    if rows:s.c.executemany('INSERT OR REPLACE INTO '+table+'('+quoted+') VALUES ('+','.join('?' for _ in overlap)+')',[tuple(r) for r in rows])
    imported[table]=len(rows)
  s.c.commit();a.close();return imported
 required=CORE_2024 if modern else CORE_2026
 for t in required:
  if t not in names and t not in ['race_corner_orders']:raise ValueError('UNSUPPORTED_SCHEMA:'+t)
 imported={};source_map={}
 with s.c:
  # Source metadata only. Unknown historical timestamps stay NULL.
  source_table='raw_sources' if modern else 'raw_catalog'
  if source_table in names:
   for row in src.execute('SELECT * FROM '+source_table):
    r=dict(row);key=r.get('raw_source_id',r.get('snapshot_id'));source_map[str(key)]=s.source({'source_id':'BASE_'+str(key),'service':r.get('source','JRA'),'role':r.get('role',r.get('source_role','LEGACY')),'url':r.get('source_url',r.get('request_url')),'entity_sha256':r.get('sha256',r.get('entity_sha256')),'requested_at':r.get('requested_at'),'responded_at':r.get('responded_at'),'raw_saved_at':r.get('raw_saved_at'),'http_status':r.get('http_status'),'integrated_at':None,'raw_state':'BASE_RAW_EXTERNAL_OR_UNAVAILABLE','original_record':r})
  for r0 in src.execute('SELECT * FROM races'):
   r=dict(r0);rid=r['race_id'];date=r.get('race_date',rid[:10])
   if not date.startswith(str(year)+'-'):raise ValueError('YEAR_MISMATCH')
   s.put('races',['race_id'],{'race_id':rid,'race_date':date,'track':r['track'],'race_number':r.get('race_number',r.get('race_no')),'race_type':r.get('race_type','FLAT'),'payload_json':encode(r)},reason='BASE_IMPORT')
  runner_table='runners' if modern else 'runners_pre_race';idx={}
  for row in src.execute('SELECT * FROM '+runner_table):
   r=dict(row);rid=r['race_id'];hid=r['horse_id'];no=r['horse_number'];idx[(rid,hid)]=no
   previous=s.c.execute('SELECT horse_name FROM horses WHERE horse_id=?',(hid,)).fetchone()
   if previous and previous[0]!=r['horse_name']:s.issue('HORSE_NAME_'+hid,'HORSE_NAME_VARIATION',{'previous':previous[0],'current':r['horse_name']})
   s.c.execute('INSERT OR IGNORE INTO horses VALUES (?,?)',(hid,r['horse_name']))
   s.put('runners',['race_id','horse_number'],{'race_id':rid,'horse_number':no,'horse_id':hid,'payload_json':encode(r)},reason='BASE_IMPORT')
  if not modern:
   pops={}
   for row in src.execute('SELECT * FROM market_popularity'):pops[(row['race_id'],row['horse_id'])]=dict(row)
  else:pops={}
  routes=[('results' if modern else 'results_post_race','results'),('win_odds' if modern else 'market_win_odds','win_odds'),('payouts' if modern else 'market_payouts','payouts'),('race_laps' if modern else 'official_laps','laps'),('race_corner_orders','corners')]
  for old,new in routes:
   if old not in names:continue
   count=0
   for row in src.execute('SELECT * FROM '+old):
    r=dict(row);rid=r['race_id'];rec={'race_id':rid};count+=1
    if new in ['results','win_odds']:
     no=r.get('horse_number',idx.get((rid,r.get('horse_id'))))
     if no is None:raise ValueError('RUNNER_JOIN_FAILURE')
     rec['horse_number']=no
    if new=='win_odds':
     if (rid,r.get('horse_id')) in pops:r['original_popularity']=pops[(rid,r['horse_id'])]
     rec.update(win_odds=r.get('win_odds',r.get('final_win_odds')),odds_status=r.get('odds_status',r.get('status','UNKNOWN')),source_id=source_map.get(str(r.get('source_snapshot_id'))))
    if new=='payouts':rec.update(bet_type=r['bet_type'],line_number=r.get('line_number',r.get('line_no')))
    if new=='laps':rec['lap_index']=r.get('lap_index',r.get('lap_number'))
    if new=='corners':rec['corner_index']=str(r.get('corner_index',r.get('corner_number',r.get('corner_label',count))))
    rec['payload_json']=encode(r);s.put(new,[k for k in rec if k!='payload_json' and k not in ['win_odds','odds_status','source_id']],rec,reason='BASE_IMPORT')
   imported[old]=count
  if modern and 'race_sources' in names:
   for row in src.execute('SELECT * FROM race_sources'):
    r=dict(row);sid=source_map.get(str(r['raw_source_id']))
    if sid:s.c.execute('INSERT OR IGNORE INTO race_sources VALUES (?,?,?)',(r['race_id'],r['role'],sid))
  elif not modern:
   for r in src.execute('SELECT race_id,source_snapshot_id FROM races'):
    sid=source_map.get(str(r['source_snapshot_id']))
    if sid:s.c.execute('INSERT OR IGNORE INTO race_sources VALUES (?,?,?)',(r['race_id'],'RESULT_HTML',sid))
  # Preserve nonredundant historical fields without copying operational mirrors.
  for table in ['race_details','result_details','payout_categories','cancelled_races','market_place_odds','official_race_keys']:
   if table not in names:continue
   count=0
   for row in src.execute('SELECT * FROM '+table):
    rec=dict(row);payload=encode(rec);key=sha(payload.encode());s.c.execute('INSERT OR IGNORE INTO supplemental_records VALUES (?,?,?,?,?)',(table,key,rec.get('race_id'),rec.get('horse_id'),payload));count+=1
   imported[table]=count
  s.meta('year',year);s.meta('baseline_import',{'filename':Path(path).name,'zip_sha256':sha(Path(path).read_bytes()),'imported_at':now(),'row_counts':imported,'field_preservation':'Each core row preserved in payload_json; distinct historical fields in supplemental_records; operational/duplicate mirrors excluded.'});s.meta('decision_time_eligible',False)
 a.close();return imported
