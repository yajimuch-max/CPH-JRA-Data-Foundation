import unittest,contextlib,io
from jra_master.cli import main
from jra_master.fresh import race_identity
class Year2010Tests(unittest.TestCase):
 def test_preflight_2010(self):
  with contextlib.redirect_stdout(io.StringIO()):self.assertEqual(main(['--year','2010','--mode','preflight']),0)
 def test_observed_2010_identity(self):
  self.assertEqual(race_identity('pw01sde1006201001010120100105/AA',2010,1,'2010-01-01','2010-12-31'),'2010-01-05-中山-01')
 def test_wrong_year_rejected(self):
  with self.assertRaises(ValueError):race_identity('pw01sde1006201001010120100105/AA',2011,1,'2011-01-01','2011-12-31')
