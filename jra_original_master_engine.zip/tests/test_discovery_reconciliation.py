import json
import sqlite3
import unittest

from jra_master.discovery_reconciliation import reconcile_discovery_tasks


class DiscoveryReconciliationTests(unittest.TestCase):
    def setUp(self):
        self.db = sqlite3.connect(':memory:')
        self.addCleanup(self.db.close)
        self.db.executescript('CREATE TABLE tasks(task_key TEXT PRIMARY KEY,status TEXT,updated_at TEXT,message TEXT); CREATE TABLE metadata(key TEXT PRIMARY KEY,value TEXT);')
        self.old = 'DISCOVER_2026_03_2026-01-01_2026-10-10'
        self.new = 'DISCOVER_2026_03_2026-01-01_2026-11-02'
        self.db.executemany('INSERT INTO tasks VALUES (?,?,?,?)', [
            (self.old, 'DEFERRED', '2026-10-10T10:00:00+00:00', 'TIME_BUDGET_CHECKPOINT'),
            (self.new, 'PASS', '2026-11-02T10:00:00+00:00', ''),
            ('RACE_test', 'PASS', '2026-11-02T10:00:00+00:00', '')])
        self.db.execute('INSERT INTO metadata VALUES (?,?)', ('links_' + self.new, json.dumps(['test'])))
        self.db.commit()

    def test_verified_cover_resolves_once_and_keeps_original_record(self):
        self.assertEqual(len(reconcile_discovery_tasks(self.db, 2026)), 1)
        evidence = json.loads(self.db.execute('SELECT value FROM metadata WHERE key=?', ('discovery_reconciliation:' + self.old,)).fetchone()[0])
        self.assertEqual(evidence['previous_task']['status'], 'DEFERRED')
        self.assertEqual(evidence['covering_task'], self.new)
        self.assertEqual(reconcile_discovery_tasks(self.db, 2026), [])

    def test_missing_or_failed_race_stays_deferred(self):
        self.db.execute("UPDATE tasks SET status='FAIL' WHERE task_key='RACE_test'")
        self.assertEqual(reconcile_discovery_tasks(self.db, 2026), [])

    def test_empty_discovery_stays_deferred(self):
        self.db.execute('UPDATE metadata SET value=?', ('[]',))
        self.assertEqual(reconcile_discovery_tasks(self.db, 2026), [])

    def test_old_known_links_must_be_covered(self):
        self.db.execute('INSERT INTO metadata VALUES (?,?)', ('links_' + self.old, '["other"]'))
        self.assertEqual(reconcile_discovery_tasks(self.db, 2026), [])

    def test_other_year_is_untouched(self):
        self.assertEqual(reconcile_discovery_tasks(self.db, 2025), [])

    def test_failed_discovery_is_not_silently_resolved(self):
        self.db.execute("UPDATE tasks SET status='FAIL' WHERE task_key=?", (self.old,))
        self.assertEqual(reconcile_discovery_tasks(self.db, 2026), [])

    def test_narrower_period_cannot_resolve(self):
        self.db.execute('UPDATE tasks SET task_key=? WHERE task_key=?', ('DISCOVER_2026_03_2026-02-01_2026-11-02', self.new))
        self.assertEqual(reconcile_discovery_tasks(self.db, 2026), [])


if __name__ == '__main__':
    unittest.main()
