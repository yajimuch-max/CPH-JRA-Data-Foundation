from __future__ import annotations

import argparse
import hashlib
import json
import zipfile
from pathlib import Path


def main() -> int:
    p = argparse.ArgumentParser()
    for name in ("year", "status", "data_root", "reports_root", "delivery_root"):
        p.add_argument(f"--{name.replace('_', '-')}", required=True)
    a = p.parse_args()
    data = Path(a.data_root).resolve()
    reports = Path(a.reports_root).resolve()
    delivery = Path(a.delivery_root).resolve()
    delivery.mkdir(parents=True, exist_ok=True)
    # Operational filenames stay ASCII so GitHub/iOS cannot alter Unicode
    # normalization between upload and workflow execution.
    base = f"{a.year}_JRA_base_annual"
    (reports / "実行状態.json").write_text(json.dumps({
        "status": a.status,
        "year": int(a.year),
        "purpose": "GitHub Actions 年間連続取得",
        "runner_version": "v0.4",
        "data_foundation_id": "CPH-JRA-DF-v0.14.9",
    }, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    zpath = delivery / f"{base}.zip"
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED, compresslevel=6, allowZip64=True) as zf:
        for root, prefix in ((reports, "reports"), (data, "data")):
            if root.exists():
                for path in sorted(x for x in root.rglob("*") if x.is_file()):
                    zf.write(path, Path(prefix) / path.relative_to(root))
    digest = hashlib.sha256(zpath.read_bytes()).hexdigest()
    sha = delivery / f"{base}_SHA256.txt"
    sha.write_text(f"{digest}  {zpath.name}\n", encoding="utf-8")
    print(json.dumps({"zip": str(zpath), "sha256": digest}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
