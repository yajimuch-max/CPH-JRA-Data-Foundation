from __future__ import annotations
import argparse, json, uuid
from datetime import datetime, timezone
from pathlib import Path
from cph_jra_df.pipeline import Pipeline

def now():
    return datetime.now(timezone.utc).isoformat(timespec="microseconds")

def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--data-root", required=True)
    p.add_argument("--year", type=int, default=2019)
    a = p.parse_args()

    pipe = Pipeline(Path(a.data_root).resolve(), workers=1)
    try:
        rows = pipe.conn.execute(
            "SELECT d.race_date,s.seed_url FROM year_race_days d "
            "LEFT JOIN result_seed_urls s ON s.race_date=d.race_date "
            "WHERE substr(d.race_date,1,4)=? ORDER BY d.race_date",
            (str(a.year),),
        ).fetchall()

        cache_pass, failures = 0, []
        for row in rows:
            if not row["seed_url"]:
                failures.append({"date": row["race_date"], "error": "SEED_MISSING"})
                continue
            try:
                r = pipe.run(row["race_date"], row["seed_url"], cache_only=True)
                cache_pass += int(r.get("status") == "PASS")
            except Exception as exc:
                failures.append({"date": row["race_date"], "error": str(exc)})

        if failures:
            print(json.dumps({"status":"FAIL","cache_only_pass":cache_pass,"failures":failures},
                             ensure_ascii=False, indent=2))
            return 1

        reparse_pass, reparse_failures = 0, []
        for row in rows:
            try:
                r = pipe.reparse(row["race_date"])
                if r.get("status") == "PASS":
                    reparse_pass += 1
                else:
                    reparse_failures.append({"date":row["race_date"],"result":r})
            except Exception as exc:
                reparse_failures.append({"date":row["race_date"],"error":str(exc)})

        if reparse_failures:
            print(json.dumps({"status":"FAIL","reparse_pass":reparse_pass,
                              "reparse_failures":reparse_failures},
                             ensure_ascii=False, indent=2))
            return 1

        # Append a PASS monthly audit only for months that do not already have one.
        manifest = pipe.conn.execute(
            "SELECT manifest_id FROM year_schedule_manifests WHERE year=?",
            (a.year,),
        ).fetchone()
        if manifest is None:
            raise SystemExit("YEAR_MANIFEST_MISSING")
        stamp = now()
        added_months = []
        for month in range(1,13):
            has_pass = pipe.conn.execute(
                "SELECT 1 FROM month_collection_runs WHERE year=? AND month=? AND status='PASS' LIMIT 1",
                (a.year, month),
            ).fetchone()
            if has_pass:
                continue
            month_dates = [r[0] for r in pipe.conn.execute(
                "SELECT race_date FROM year_race_days "
                "WHERE race_date LIKE ? ORDER BY race_date",
                (f"{a.year}-{month:02d}-%",),
            ).fetchall()]
            plan_id = f"MONTH-RECOVERY-{a.year}-{month:02d}-{uuid.uuid4().hex[:10]}"
            pipe.conn.execute(
                "INSERT INTO month_collection_runs"
                "(plan_id,year,month,year_manifest_id,created_at,updated_at,status,expected_dates)"
                " VALUES(?,?,?,?,?,?,?,?)",
                (plan_id,a.year,month,manifest["manifest_id"],stamp,stamp,"PASS",len(month_dates)),
            )
            for ordinal, race_date in enumerate(month_dates,1):
                run = pipe.conn.execute(
                    "SELECT run_id FROM pipeline_runs WHERE race_date=? AND mode='CACHE_ONLY' "
                    "AND status='PASS' ORDER BY completed_at DESC LIMIT 1",
                    (race_date,),
                ).fetchone()
                if run is None:
                    raise SystemExit(f"CACHE_PASS_EVIDENCE_MISSING:{race_date}")
                pipe.conn.execute(
                    "INSERT INTO month_collection_items"
                    "(plan_id,race_date,ordinal,status,phase,attempts,pipeline_run_id,"
                    "started_at,completed_at,reason_codes_json)"
                    " VALUES(?,?,?,?,?,?,?,?,?,?)",
                    (plan_id,race_date,ordinal,"PASS","AUDIT",1,run["run_id"],
                     stamp,stamp,"[]"),
                )
            added_months.append(month)
        pipe.conn.commit()

        print(json.dumps({
            "status":"PASS",
            "race_days":len(rows),
            "cache_only_pass":cache_pass,
            "reparse_pass":reparse_pass,
            "recovery_month_pass_added":added_months,
            "history_policy":"past FAIL/PARTIAL rows retained",
        }, ensure_ascii=False, indent=2))
        return 0
    finally:
        pipe.close()

if __name__ == "__main__":
    raise SystemExit(main())
