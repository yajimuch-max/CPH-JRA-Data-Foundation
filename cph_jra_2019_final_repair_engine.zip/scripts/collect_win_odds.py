#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import gzip
import hashlib
import json
import re
import sqlite3
import subprocess
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import quote_plus

from bs4 import BeautifulSoup


def decode(body: bytes) -> str:
    for enc in ("cp932", "shift_jis", "utf-8"):
        try:
            return body.decode(enc)
        except UnicodeDecodeError:
            pass
    return body.decode("cp932", errors="replace")


def curl(url: str, output: Path, cookie: Path, post_cname: str | None = None) -> None:
    cmd = [
        "/usr/bin/curl", "--compressed", "--location", "--silent", "--show-error",
        "--fail", "--max-time", "60", "--retry", "2", "--retry-delay", "2",
        "--user-agent", "CPH-JRA-Integrated-Collector/1.0", "--cookie", str(cookie),
        "--cookie-jar", str(cookie), "--output", str(output),
    ]
    if post_cname is not None:
        cmd += ["--request", "POST", "--data", "cname=" + quote_plus(post_cname)]
    cmd.append(url)
    result = subprocess.run(cmd, text=True, capture_output=True, check=False)
    if result.returncode:
        raise RuntimeError(f"CURL_{result.returncode}:{result.stderr.strip()}")


def odds_cname(result_html: bytes) -> str:
    text = decode(result_html)
    matches = re.findall(
        r"doAction\(\s*['\"]/?JRADB/accessO\.html['\"]\s*,\s*['\"]([^'\"]*pw151ou[^'\"]+)['\"]",
        text, flags=re.I,
    )
    if not matches:
        raise RuntimeError("FINAL_ODDS_LINK_NOT_FOUND")
    return matches[-1]


def number(text: str) -> float | None:
    match = re.search(r"\d+(?:\.\d+)?", text.replace(",", ""))
    return float(match.group()) if match else None


def parse_odds(body: bytes) -> list[dict]:
    text = decode(body)
    soup = BeautifulSoup(text, "lxml")
    title = soup.get_text(" ", strip=True)
    if "最終オッズ" not in title or "単勝・複勝オッズ" not in title:
        raise RuntimeError("NOT_FINAL_WIN_ODDS_PAGE")
    table = soup.select_one("table.tanpuku")
    if table is None:
        raise RuntimeError("WIN_ODDS_TABLE_NOT_FOUND")
    rows = []
    for tr in table.select("tbody tr"):
        num = tr.select_one("td.num")
        horse = tr.select_one("td.horse")
        win = tr.select_one("td.odds_tan")
        if num is None or horse is None or win is None:
            continue
        horse_no_match = re.search(r"\d+", num.get_text(" ", strip=True))
        if not horse_no_match:
            continue
        raw_odds = win.get_text(" ", strip=True)
        value = number(raw_odds)
        status = "OK" if value is not None else (raw_odds or "NOT_OFFERED")
        rows.append({
            "horse_no": int(horse_no_match.group()),
            "horse_name": horse.get_text(" ", strip=True),
            "final_win_odds": value,
            "status": status,
        })
    if not rows:
        raise RuntimeError("WIN_ODDS_ROWS_EMPTY")
    return rows


def init_db(path: Path) -> sqlite3.Connection:
    con = sqlite3.connect(path)
    con.executescript("""
    CREATE TABLE IF NOT EXISTS win_odds (
      race_key TEXT NOT NULL,
      race_date TEXT NOT NULL,
      track TEXT NOT NULL,
      race_no INTEGER NOT NULL,
      horse_no INTEGER NOT NULL,
      horse_name TEXT NOT NULL,
      final_win_odds REAL,
      status TEXT NOT NULL,
      result_url TEXT NOT NULL,
      odds_cname TEXT NOT NULL,
      raw_sha256 TEXT NOT NULL,
      fetched_at_utc TEXT NOT NULL,
      PRIMARY KEY (race_key, horse_no)
    );
    CREATE TABLE IF NOT EXISTS collection_errors (
      race_key TEXT PRIMARY KEY, error TEXT NOT NULL
    );
    """)
    return con


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", type=Path, required=True)
    ap.add_argument("--year", type=int, required=True)
    ap.add_argument("--month", type=int, required=True)
    ap.add_argument("--mode", choices=("connection_test", "full"), required=True)
    ap.add_argument("--output", type=Path, required=True)
    args = ap.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    raw_dir = args.output / "raw_odds"
    raw_dir.mkdir(exist_ok=True)
    with args.manifest.open(encoding="utf-8", newline="") as fh:
        races = [r for r in csv.DictReader(fh)
                 if int(r["year"]) == args.year and int(r["month"]) == args.month]
    if args.mode == "connection_test":
        races = races[:1]
    db = init_db(args.output / f"{args.year}_{args.month:02d}_単勝最終オッズ.sqlite3")
    errors = []
    with tempfile.TemporaryDirectory(prefix="jra_odds_") as temp:
        temp = Path(temp)
        cookie = temp / "cookies.txt"
        for index, race in enumerate(races, 1):
            key = race["race_key"]
            try:
                result_file = temp / "result.html"
                odds_file = temp / "odds.html"
                curl(race["result_url"], result_file, cookie)
                cname = odds_cname(result_file.read_bytes())
                curl("https://www.jra.go.jp/JRADB/accessO.html", odds_file, cookie, cname)
                body = odds_file.read_bytes()
                parsed = parse_odds(body)
                expected = int(race["expected_horses"])
                if len(parsed) != expected:
                    raise RuntimeError(f"HORSE_COUNT_MISMATCH:{len(parsed)}:{expected}")
                sha = hashlib.sha256(body).hexdigest()
                raw_path = raw_dir / f"{key}_{sha}.html.gz"
                raw_path.write_bytes(gzip.compress(body, compresslevel=9, mtime=0))
                fetched = datetime.now(timezone.utc).isoformat(timespec="seconds")
                for row in parsed:
                    db.execute("INSERT OR REPLACE INTO win_odds VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", (
                        key, race["race_date"], race["track"], int(race["race_no"]),
                        row["horse_no"], row["horse_name"], row["final_win_odds"], row["status"],
                        race["result_url"], cname, sha, fetched,
                    ))
                db.commit()
                print(f"[{index}/{len(races)}] OK {key} {len(parsed)}頭", flush=True)
            except Exception as exc:
                message = f"{type(exc).__name__}:{exc}"
                db.execute("INSERT OR REPLACE INTO collection_errors VALUES (?,?)", (key, message))
                db.commit()
                errors.append({"race_key": key, "error": message})
                print(f"[{index}/{len(races)}] ERROR {key} {message}", flush=True)
            time.sleep(0.8)
    total = db.execute("SELECT COUNT(*) FROM win_odds").fetchone()[0]
    numeric = db.execute("SELECT COUNT(*) FROM win_odds WHERE final_win_odds IS NOT NULL").fetchone()[0]
    report = {
        "year": args.year, "month": args.month, "mode": args.mode,
        "race_targets": len(races), "race_success": len(races) - len(errors),
        "race_errors": len(errors), "horse_rows": total, "numeric_odds_rows": numeric,
        "status": "PASS" if not errors else "FAIL", "errors": errors,
    }
    (args.output / "audit.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    db.close()
    print(json.dumps(report, ensure_ascii=False), flush=True)
    if errors:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
