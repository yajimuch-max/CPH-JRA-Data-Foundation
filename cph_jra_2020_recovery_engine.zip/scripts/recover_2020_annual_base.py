from __future__ import annotations

import argparse
import json
import uuid
from datetime import datetime, timezone
from pathlib import Path

from cph_jra_df.pipeline import Pipeline

TARGET_DATE = "2020-11-07"

def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="microseconds")

def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--data-root", required=True)
    a = p.parse_args()
    root = Path(a.data_root).resolve()

    pipeline = Pipeline(root, workers=1)
    try:
        seed = pipeline.conn.execute(
            "SELECT seed_url FROM result_seed_urls WHERE race_date=?",
            (TARGET_DATE,),
        ).fetchone()
        if seed is None:
            raise SystemExit("RECOVERY_FAIL: seed missing for 2020-11-07")

        # This date failed before IMPORT, so only this date is reprocessed.
        recovered = pipeline.run(TARGET_DATE, seed[0], cache_only=True)

        # Reparse every race day from saved raw snapshots after the fix.
        # No network access is used by reparse().
        dates = [row[0] for row in pipeline.conn.execute(
            "SELECT race_date FROM year_race_days "
            "WHERE substr(race_date,1,4)='2020' ORDER BY race_date"
        ).fetchall()]
        reparse_pass = 0
        for race_date in dates:
            result = pipeline.reparse(race_date)
            if result.get("status") != "PASS":
                raise SystemExit(f"RECOVERY_FAIL: reparse failed for {race_date}")
            reparse_pass += 1

        # Preserve the original November PARTIAL plan and failure row.
        # Append a new PASS recovery plan proving all November dates.
        manifest = pipeline.conn.execute(
            "SELECT manifest_id FROM year_schedule_manifests WHERE year=2020"
        ).fetchone()
        if manifest is None:
            raise SystemExit("RECOVERY_FAIL: annual manifest missing")

        november_dates = [row[0] for row in pipeline.conn.execute(
            "SELECT race_date FROM year_race_days "
            "WHERE race_date LIKE '2020-11-%' ORDER BY race_date"
        ).fetchall()]
        evidence = []
        for race_date in november_dates:
            row = pipeline.conn.execute(
                "SELECT run_id FROM pipeline_runs "
                "WHERE race_date=? AND status='PASS' AND stage='AUDIT' "
                "AND mode IN ('ONLINE','CACHE_ONLY') "
                "ORDER BY completed_at DESC LIMIT 1",
                (race_date,),
            ).fetchone()
            if row is None:
                raise SystemExit(f"RECOVERY_FAIL: no PASS audit evidence for {race_date}")
            evidence.append((race_date, row[0]))

        stamp = now()
        plan_id = f"MONTH-RECOVERY-2020-11-{uuid.uuid4().hex[:12]}"
        pipeline.conn.execute(
            "INSERT INTO month_collection_runs"
            "(plan_id,year,month,year_manifest_id,created_at,updated_at,status,expected_dates)"
            " VALUES(?,?,?,?,?,?,?,?)",
            (plan_id, 2020, 11, manifest[0], stamp, stamp, "PASS", len(november_dates)),
        )
        for ordinal, (race_date, run_id) in enumerate(evidence, 1):
            pipeline.conn.execute(
                "INSERT INTO month_collection_items"
                "(plan_id,race_date,ordinal,status,phase,attempts,pipeline_run_id,"
                "started_at,completed_at,reason_codes_json) "
                "VALUES(?,?,?,?,?,?,?,?,?,?)",
                (plan_id, race_date, ordinal, "PASS", "AUDIT", 1, run_id,
                 stamp, stamp, "[]"),
            )
        pipeline.conn.commit()

        report = {
            "status": "PASS",
            "target_date": TARGET_DATE,
            "original_failure": "FINISH_STATUS_UNKNOWN: horse_no=3 status=失格",
            "repair": "失格をJRA公式の既知の非完走ステータスとして許可",
            "target_date_result": recovered,
            "annual_reparse_pass": reparse_pass,
            "november_recovery_plan_id": plan_id,
            "history": "元のFAIL/PARTIAL行は削除せず、新しいPASS証拠を追記",
        }
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 0
    finally:
        pipeline.close()

if __name__ == "__main__":
    raise SystemExit(main())
