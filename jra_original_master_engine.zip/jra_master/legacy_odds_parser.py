#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import gzip
import hashlib
import json
import re
import sqlite3
import subprocess
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import parse_qs, quote_plus, urlparse

from bs4 import BeautifulSoup


def decode(body: bytes) -> str:
    for enc in ("cp932", "shift_jis", "utf-8"):
        try:
            return body.decode(enc)
        except UnicodeDecodeError:
            pass
    return body.decode("cp932", errors="replace")


def odds_cname(result_html: bytes) -> str:
    text = decode(result_html)
    matches = re.findall(
        r"doAction\(\s*['\"]/?JRADB/accessO\.html['\"]\s*,\s*['\"]([^'\"]*pw151ou[^'\"]+)['\"]",
        text, flags=re.I,
    )
    if not matches:
        raise RuntimeError("FINAL_ODDS_LINK_NOT_FOUND")
    return matches[-1]


def number(text: str) -> float | None:
    match = re.search(r"\d+(?:\.\d+)?", text.replace(",", ""))
    return float(match.group()) if match else None


def parse_odds(body: bytes) -> list[dict]:
    text = decode(body)
    soup = BeautifulSoup(text, "lxml")
    title = soup.get_text(" ", strip=True)
    single = soup.select_one("table.tanpuku.tan caption")
    single_title = single.get_text(" ", strip=True) if single else ""
    win_only = single_title == "単勝オッズ（馬番順）" and "単勝オッズ（馬番順）" in title
    if "最終オッズ" not in title or not ("単勝・複勝オッズ" in title or win_only):
        raise RuntimeError("NOT_FINAL_WIN_ODDS_PAGE")
    table = soup.select_one("table.tanpuku")
    if table is None:
        raise RuntimeError("WIN_ODDS_TABLE_NOT_FOUND")
    rows = []
    for tr in table.select("tbody tr"):
        num = tr.select_one("td.num")
        horse = tr.select_one("td.horse")
        win = tr.select_one("td.odds_tan")
        if num is None or horse is None or win is None:
            continue
        horse_no_match = re.search(r"\d+", num.get_text(" ", strip=True))
        if not horse_no_match:
            continue
        raw_odds = win.get_text(" ", strip=True)
        value = number(raw_odds)
        status = "OK" if value is not None else (raw_odds or "NOT_OFFERED")
        rows.append({
            "horse_no": int(horse_no_match.group()),
            "horse_name": horse.get_text(" ", strip=True),
            "final_win_odds": value,
            "status": status,
        })
    if not rows:
        raise RuntimeError("WIN_ODDS_ROWS_EMPTY")
    return rows

