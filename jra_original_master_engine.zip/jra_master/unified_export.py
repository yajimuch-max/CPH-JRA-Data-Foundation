"""Single-file JRA annual MASTER export with strict field-level admission.

The workflow state is a resumable WORKING database, never itself a certified
master. Only independently verified JRA result HTML data are admitted. Old
PDF result/course enrichments are omitted. JRA's separate official track
measurements are allowed from their documented publication period.
"""
from __future__ import annotations
import datetime as dt
import hashlib
import json
import sqlite3
import tempfile
import zipfile
from pathlib import Path

VERSION='JRA_UNIFIED_HTML_v0.7.1.7'
CORE=('races','horses','runners','results','win_odds','payouts','laps','corners','pedigree','pedigree_receipts')
OBSOLETE_PREFIXES=('official_expansion_', 'official_legacy_')
UNWANTED_TABLES=('official_race_track_context','official_track_revisions')


def _tables(c):
 return {r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}


def _count(c, name):
 return c.execute('SELECT count(*) FROM '+name).fetchone()[0]


def audit_source(c,year,stages):
 if c.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise ValueError('SOURCE_INTEGRITY_FAILED')
 if c.execute('PRAGMA foreign_key_check').fetchall():raise ValueError('SOURCE_FOREIGN_KEYS_FAILED')
 t=_tables(c)
 if not set(CORE).issubset(t):raise ValueError('CORE_TABLES_MISSING')
 yearmeta=c.execute("SELECT value FROM metadata WHERE key='year'").fetchone()
 if not yearmeta or json.loads(yearmeta[0])!=year:raise ValueError('WRONG_YEAR_MASTER')
 if c.execute('SELECT 1 FROM races WHERE race_date NOT LIKE ? LIMIT 1',(f'{year}-%',)).fetchone():
  raise ValueError('CROSS_YEAR_RACE_IN_MASTER')
 total=_count(c,'races')
 if not total:raise ValueError('NO_RACES')
 counts={t:_count(c,t) for t in CORE}
 missing={t:c.execute('SELECT count(*) FROM runners r LEFT JOIN '+t+' x ON x.race_id=r.race_id AND x.horse_number=r.horse_number WHERE x.race_id IS NULL').fetchone()[0] for t in ('results','win_odds')}
 no_pedigree=c.execute('SELECT count(*) FROM horses h LEFT JOIN pedigree_receipts p ON p.horse_id=h.horse_id WHERE p.horse_id IS NULL OR p.status<>\'PASS\'').fetchone()[0]
 # Pedigree receipt statuses can have other verified statuses; retain the
 # original requirement of existence and non-NEEDS_REPARSE, separate audit.
 no_pedigree=c.execute("SELECT count(*) FROM horses h LEFT JOIN pedigree_receipts p ON p.horse_id=h.horse_id WHERE p.horse_id IS NULL OR p.status='NEEDS_REPARSE'").fetchone()[0]
 task_issues=dict(c.execute('SELECT status,count(*) FROM tasks GROUP BY status')) if 'tasks' in t else {}
 open_issues=c.execute("SELECT count(*) FROM issues WHERE status='OPEN'").fetchone()[0] if 'issues' in t else 0
 laps_flat=c.execute("SELECT count(DISTINCT r.race_id) FROM races r JOIN laps l ON l.race_id=r.race_id WHERE r.race_type='FLAT'").fetchone()[0]
 flat=c.execute("SELECT count(*) FROM races WHERE race_type='FLAT'").fetchone()[0]
 payout_races=c.execute('SELECT count(DISTINCT race_id) FROM payouts').fetchone()[0]
 if 'official_html_races' in t and 'official_html_receipts' in t:
  html_good=c.execute('''SELECT count(*) FROM races r
      JOIN official_html_races h ON h.race_id=r.race_id
      JOIN official_html_receipts x ON x.race_id=r.race_id
      WHERE x.status='PASS' AND x.source_sha256=h.source_sha256
        AND h.weather IS NOT NULL AND h.weather<>''
        AND h.going IN ('良','稍重','重','不良')
        AND h.condition_text IS NOT NULL AND h.condition_text<>''
        AND h.class_text IS NOT NULL AND h.class_text<>'' ''').fetchone()[0]
 else:html_good=0
 invalid_html_going=total-html_good
 blinkers_seen=_count(c,'official_html_runners') if 'official_html_runners' in t else 0
 bad_blinkers=c.execute('''SELECT count(*) FROM official_html_runners b
   LEFT JOIN official_html_receipts h ON h.race_id=b.race_id
   LEFT JOIN runners r ON r.race_id=b.race_id AND r.horse_number=b.horse_number
   WHERE r.race_id IS NULL OR h.race_id IS NULL OR h.status<>'PASS'
       OR h.source_sha256<>b.source_sha256
       OR (b.blinker_confirmed NOT IN (1) AND b.cancellation_status IS NULL)''').fetchone()[0] if 'official_html_runners' in t else 0
 stage_failures={k:v.get('status') for k,v in stages.items() if v.get('status')=='ERROR'}
 track_required=year>=2018
 track_complete=not track_required or stages.get('track',{}).get('status')=='PASS'
 blockers=[]
 if any(missing.values()):blockers.append('MISSING_CORE_RUNNERS')
 if no_pedigree:blockers.append('INCOMPLETE_PEDIGREE_RECEIPTS')
 if any(s!='PASS' for s in task_issues):blockers.append('CORE_TASK_NOT_PASS')
 if open_issues:blockers.append('OPEN_ISSUES')
 if laps_flat!=flat:blockers.append('FLAT_LAPS_NOT_COMPLETE')
 if payout_races!=total:blockers.append('RACE_PAYOUT_COVERAGE')
 if html_good!=total:blockers.append('HTML_FIELDS_NOT_ALL_VERIFIED')
 if stage_failures:blockers.append('STAGE_ERROR')
 if stages.get('core',{}).get('status') not in (None,'PASS'):blockers.append('CORE_UPDATE_INCOMPLETE')
 if bad_blinkers:blockers.append('BLINKER_PROVENANCE_FAILED')
 if not track_complete:blockers.append('OFFICIAL_MEASUREMENTS_NOT_COMPLETE')
 return dict(status='CERTIFIED' if not blockers else 'NOT_CERTIFIED', year=year,
     engine=VERSION, checked_at=dt.datetime.now(dt.timezone.utc).isoformat(),
     source_integrity='ok', source_races=total, core_counts=counts,
     missing_core_runner_rows=missing, missing_pedigree_receipts=no_pedigree,
     core_task_statuses=task_issues, open_issues=open_issues,
     flat_races=flat, flat_races_with_laps=laps_flat,
     html_blinker_positive=blinkers_seen, blinker_provenance_mismatches=bad_blinkers,
     races_with_payouts=payout_races, html_races_with_verified_required_fields=html_good,
     html_required_fields_remaining=invalid_html_going, stages=stages,
     blockers=blockers, restricted_pdf_policy='No PDF result/course supplemental fields; only JRA official moisture/cushion measurements from published period.',
     timing='Historical result HTML is post-event; not a pre-race snapshot.',
     coverage_scope='All races recorded in this MASTER. Annual race-calendar completeness requires separate source-list audit.')


def clean_snapshot(c,year):
 """Operate on copied SQLite only. Keep update-compatible technical tables.

 Any obsolete PDF course, owner, breeder, birthplace, etc. is dropped. Track
 measurement pipeline retains its receipt bookkeeping, but course letters
 are scrubbed from the final certified file.
 """
 if c.execute('PRAGMA foreign_key_check').fetchall():raise ValueError('PRE_CLEAN_FOREIGN_KEYS')
 names=_tables(c)
 c.execute('PRAGMA foreign_keys=OFF')
 with c:
  # Strip old mixed-column racing PDF supplements and obsolete A-D contextual
  # tables entirely. Keep only the separate moisture/cushion archive input.
  for table in sorted(names):
   if table.startswith(OBSOLETE_PREFIXES) or table in UNWANTED_TABLES:
    c.execute('DROP TABLE IF EXISTS "'+table+'"')
  if 'official_track_daily' in names:
   cols={r[1] for r in c.execute('PRAGMA table_info(official_track_daily)')}
   if 'used_turf_course' in cols:
    c.execute('UPDATE official_track_daily SET used_turf_course=NULL')
  if 'metadata' in names:
   c.execute("DELETE FROM metadata WHERE key LIKE 'official_expansion%' OR key LIKE 'legacy_track%' OR key='track_enrichment_audit'")
  c.execute('''CREATE TABLE IF NOT EXISTS official_html_runners (
     race_id TEXT NOT NULL,horse_number INTEGER NOT NULL,
     blinker_confirmed INTEGER,cancellation_status TEXT,
     source_url TEXT NOT NULL,source_sha256 TEXT NOT NULL,
     timing_status TEXT NOT NULL,verified_at TEXT NOT NULL,
     PRIMARY KEY(race_id,horse_number),
     FOREIGN KEY(race_id,horse_number) REFERENCES runners(race_id,horse_number))''')
  for view in ('race_summary','runner_summary','race_laps','race_payouts','race_sectionals','track_measurements'):
   c.execute('DROP VIEW IF EXISTS '+view)
  c.execute('''CREATE VIEW race_summary AS
     SELECT r.race_id,r.race_date,r.track,r.race_number,r.race_type,
       json_extract(r.payload_json,'$.surface') AS surface,
       json_extract(r.payload_json,'$.distance_m') AS distance_m,
       json_extract(r.payload_json,'$.race_name') AS race_name,
       json_extract(r.payload_json,'$.grade') AS grade,
       json_extract(r.payload_json,'$.post_time') AS post_time,
       h.weather,h.going,h.class_text,h.condition_text,
       h.source_url AS official_html_url
     FROM races r LEFT JOIN official_html_races h ON h.race_id=r.race_id''')
  c.execute('''CREATE VIEW runner_summary AS
     SELECT e.race_id,e.horse_number,e.horse_id,
       json_extract(e.payload_json,'$.horse_name') AS horse_name,
       json_extract(e.payload_json,'$.frame_no') AS frame_no,
       json_extract(e.payload_json,'$.sex_age') AS sex_age,
       json_extract(e.payload_json,'$.jockey_name') AS jockey_name,
       json_extract(e.payload_json,'$.trainer_name') AS trainer_name,
       json_extract(e.payload_json,'$.assigned_weight_kg') AS assigned_weight_kg,
       json_extract(e.payload_json,'$.body_weight_kg') AS body_weight_kg,
       json_extract(e.payload_json,'$.body_weight_change_kg') AS body_weight_change_kg,
       json_extract(x.payload_json,'$.finish_position') AS finish_position,
       json_extract(x.payload_json,'$.finish_status') AS finish_status,
       json_extract(x.payload_json,'$.finish_time') AS finish_time,
       json_extract(x.payload_json,'$.final_3f') AS runner_last_3f,
       json_extract(x.payload_json,'$.popularity') AS popularity,
       o.win_odds,
       CASE WHEN b.blinker_confirmed=1 THEN 1 END AS blinker_worn_confirmed
     FROM runners e
       LEFT JOIN results x ON x.race_id=e.race_id AND x.horse_number=e.horse_number
       LEFT JOIN win_odds o ON o.race_id=e.race_id AND o.horse_number=e.horse_number
       LEFT JOIN official_html_runners b ON b.race_id=e.race_id AND b.horse_number=e.horse_number''')
  c.execute('''CREATE VIEW race_laps AS
     SELECT race_id,lap_index,
     json_extract(payload_json,'$.lap_time_seconds') AS lap_time_seconds
     FROM laps''')
  c.execute('''CREATE VIEW race_sectionals AS
      WITH ranked AS (
        SELECT race_id,lap_index,
          CAST(json_extract(payload_json,'$.lap_time_seconds') AS REAL) AS sec,
          ROW_NUMBER() OVER (PARTITION BY race_id ORDER BY lap_index DESC) AS rn
        FROM laps
      )
      SELECT race_id,
        CASE WHEN COUNT(CASE WHEN rn<=3 THEN sec END)=3
          THEN ROUND(SUM(CASE WHEN rn<=3 THEN sec END),1) END AS last_3f_seconds,
        CASE WHEN COUNT(CASE WHEN rn<=4 THEN sec END)=4
          THEN ROUND(SUM(CASE WHEN rn<=4 THEN sec END),1) END AS last_4f_seconds,
        'DERIVED_FROM_OFFICIAL_RACE_LAPS' AS source_basis
      FROM ranked GROUP BY race_id''')
  c.execute('''CREATE VIEW race_payouts AS
     SELECT race_id,bet_type,line_number,
       json_extract(payload_json,'$.combination_text') AS combination,
       json_extract(payload_json,'$.payout_yen') AS payout_yen,
       json_extract(payload_json,'$.payout_popularity') AS payout_popularity,
       json_extract(payload_json,'$.special_status') AS special_status
     FROM payouts''')
  if 'official_track_daily' in names:
   # Long-format measurements: no synthetic blank cushion values in years
   # preceding official publication; all rows correspond to observed values.
   metric_map=[
    ('TURF_CUSHION','turf_cushion'),
    ('TURF_MOISTURE_GOAL','turf_goal_moisture'),
    ('TURF_MOISTURE_4C','turf_4c_moisture'),
    ('DIRT_MOISTURE_GOAL','dirt_goal_moisture'),
    ('DIRT_MOISTURE_4C','dirt_4c_moisture'),
   ]
   arms=[f"SELECT race_date,track,'{name}' AS metric,{col} AS value,source_url FROM official_track_daily WHERE {col} IS NOT NULL"
         for name,col in metric_map]
   c.execute('CREATE VIEW track_measurements AS '+' UNION ALL '.join(arms))
  else:
   c.execute('''CREATE VIEW track_measurements AS
       SELECT CAST(NULL AS TEXT) AS race_date,CAST(NULL AS TEXT) AS track,
       CAST(NULL AS TEXT) AS metric,CAST(NULL AS REAL) AS value,
       CAST(NULL AS TEXT) AS source_url WHERE 0''')
 c.execute('PRAGMA foreign_keys=ON')
 if c.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise ValueError('CLEAN_INTEGRITY_FAILED')
 if c.execute('PRAGMA foreign_key_check').fetchall():raise ValueError('CLEAN_FOREIGN_KEYS_FAILED')
 # Fail if leaked abandoned supplemental tables or official course labels.
 for table in _tables(c):
  if table.startswith(OBSOLETE_PREFIXES) or table in UNWANTED_TABLES:raise ValueError('OBSOLETE_TABLE_RETAINED:'+table)
 if 'official_track_daily' in _tables(c):
  if c.execute('SELECT count(*) FROM official_track_daily WHERE used_turf_course IS NOT NULL').fetchone()[0]:
   raise ValueError('COURSE_LETTERS_LEAKED')


def export_master(year,db,output,stages):
 output=Path(output);output.mkdir(parents=True,exist_ok=True)
 db=Path(db)
 source=sqlite3.connect(db)
 try:
  audit=audit_source(source,year,stages)
  (output/f'unified_audit_{year}.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
  dest=output/f'{year}_JRA_MASTER.zip'
  if audit['status']!='CERTIFIED':
   if dest.exists():dest.unlink()
   print('MASTER_NOT_CERTIFIED',json.dumps({'year':year,'blockers':audit['blockers'],'html_remaining':audit['html_required_fields_remaining']},ensure_ascii=False),flush=True)
   return audit
  with tempfile.TemporaryDirectory(prefix='jra_certified_') as temporary:
   snapshot=Path(temporary)/'MASTER.sqlite3'
   target=sqlite3.connect(snapshot)
   try:source.backup(target,pages=1024)
   finally:target.close()
   clean=sqlite3.connect(snapshot)
   try:
    clean_snapshot(clean,year)
    if any(_count(clean,t)!=v for t,v in audit['core_counts'].items()):
     raise ValueError('CORE_TABLE_COUNTS_CHANGED')
    if _count(clean,'race_summary')!=audit['source_races']:raise ValueError('RACE_SUMMARY_COUNT_CHANGED')
    if _count(clean,'runner_summary')!=audit['core_counts']['runners']:raise ValueError('RUNNER_SUMMARY_COUNT_CHANGED')
    if _count(clean,'race_laps')!=audit['core_counts']['laps']:raise ValueError('LAPS_COUNT_CHANGED')
    if _count(clean,'race_payouts')!=audit['core_counts']['payouts']:raise ValueError('PAYOUTS_COUNT_CHANGED')
    if _count(clean,'race_sectionals')!=audit['flat_races']:raise ValueError('SECTIONALS_RACE_COUNT_CHANGED')
    clean.execute('PRAGMA wal_checkpoint(TRUNCATE)')
   finally:clean.close()
   content_hash=hashlib.sha256(snapshot.read_bytes()).hexdigest()
   manifest={'engine':VERSION,'year':year,'status':'CERTIFIED',
             'master_sha256':content_hash,'source':'JRA_OFFICIAL_ONLY',
             'source_races':audit['source_races'],
             'core_counts':audit['core_counts'],
             'available_views':['race_summary','runner_summary','race_laps','race_sectionals','race_payouts','track_measurements'],
             'source_policy':'RACE/ODDS/PEDIGREE/RESULT HTML; ONLY OFFICIAL MEASUREMENTS FROM PDF',
             'post_event_warning':'Historic JRA results are not proof of pre-race availability.',
             'coverage_scope':'Recorded races verified; future races and external race-calendar completeness not implied.',
             'blinker_policy':'HTML explicit wearing markers only; missing marker means UNKNOWN, never false.'}
   (Path(temporary)/'AUDIT.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
   (Path(temporary)/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
   (Path(temporary)/'README.txt').write_text('JRA annual certified master. Open MASTER.sqlite3 and use race_summary, runner_summary, race_laps, race_sectionals (derived), race_payouts, track_measurements. Blinkers are HTML-positive-only (runner_summary.blinker_worn_confirmed=1 or NULL). 2010-17 track_measurements has no rows (not published). Other internal tables enable incremental GitHub updates. No A-D course, owner or breeder supplemental columns are adopted.\n',encoding='utf8')
   stage=output/(dest.name+'.tmp')
   with zipfile.ZipFile(stage,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name in ('MASTER.sqlite3','AUDIT.json','manifest.json','README.txt'):
     z.write(Path(temporary)/name,name)
   with zipfile.ZipFile(stage) as z:
    if z.testzip() is not None:raise ValueError('ZIP_FAILED_CRC')
   stage.replace(dest)
   (output/(dest.name+'.sha256')).write_text(hashlib.sha256(dest.read_bytes()).hexdigest()+'  '+dest.name+'\n',encoding='utf8')
   print('CERTIFIED_MASTER',dest,'races',audit['source_races'],'bytes',dest.stat().st_size,flush=True)
  return audit
 finally:source.close()
