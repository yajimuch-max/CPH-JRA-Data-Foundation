from __future__ import annotations

import hashlib
import json
from datetime import datetime

from .pipeline import now
from .seed_discovery import SeedDiscovery


class YearSeedPlanFailure(RuntimeError):
    pass


class YearSeedPlanRunner:
    """Checkpointed discovery of one result-detail seed URL per JRA race date."""

    def __init__(self, pipeline):
        self.pipeline = pipeline
        self.conn = pipeline.conn

    def _manifest(self, year: int):
        row = self.conn.execute(
            "SELECT manifest_id,race_day_count FROM year_schedule_manifests "
            "WHERE year=? ORDER BY created_at DESC LIMIT 1", (year,)
        ).fetchone()
        if row is None:
            raise YearSeedPlanFailure("YEAR_MANIFEST_NOT_FOUND")
        return row

    def ensure_plan(self, year: int) -> str:
        manifest = self._manifest(year)
        digest = hashlib.sha256(f"{manifest['manifest_id']}|RESULT-SEED-v1".encode()).hexdigest()
        plan_id = f"YEAR-SEED-{year}-{digest[:16]}"
        stamp = now()
        self.conn.execute(
            "INSERT OR IGNORE INTO year_seed_plans VALUES(?,?,?,?,?,?,?)",
            (plan_id, year, manifest["manifest_id"], stamp, stamp, "PLANNED", manifest["race_day_count"]),
        )
        days = self.conn.execute(
            "SELECT race_date,half_year FROM year_race_days WHERE manifest_id=? ORDER BY race_date",
            (manifest["manifest_id"],),
        ).fetchall()
        self.conn.executemany(
            "INSERT OR IGNORE INTO year_seed_items"
            "(plan_id,race_date,half_year,ordinal,status) VALUES(?,?,?,?, 'PENDING')",
            [(plan_id, row["race_date"], row["half_year"], i) for i, row in enumerate(days, 1)],
        )
        self.conn.commit()
        return plan_id

    def run(self, year: int, period: str = "all", max_dates_this_run: int = 1,
            cache_only: bool = False, retry_failed: bool = False,
            date_from: str | None = None, date_to: str | None = None) -> dict:
        if period not in {"all", "h1", "h2"}:
            raise YearSeedPlanFailure("YEAR_SEED_PERIOD_INVALID")
        if max_dates_this_run < 1 or max_dates_this_run > 31:
            raise YearSeedPlanFailure("MAX_DATES_THIS_RUN_OUT_OF_RANGE")
        for boundary in (date_from, date_to):
            if boundary:
                try:
                    parsed = datetime.strptime(boundary, "%Y-%m-%d")
                except ValueError as exc:
                    raise YearSeedPlanFailure("YEAR_SEED_DATE_RANGE_INVALID") from exc
                if parsed.year != year:
                    raise YearSeedPlanFailure("YEAR_SEED_DATE_RANGE_YEAR_MISMATCH")
        if date_from and date_to and date_from > date_to:
            raise YearSeedPlanFailure("YEAR_SEED_DATE_RANGE_REVERSED")
        plan_id = self.ensure_plan(year)
        # A process/WORK termination can leave the current date RUNNING. It was
        # never committed as PASS, so return it to the resumable queue.
        self.conn.execute(
            "UPDATE year_seed_items SET status='PENDING',completed_at=?,reason_codes_json=? "
            "WHERE plan_id=? AND status='RUNNING'",
            (now(), json.dumps(["INTERRUPTED_RUN_RECOVERED"]), plan_id),
        )
        self.conn.commit()
        clauses = ["plan_id=?", "status IN ('PENDING'" + (",'FAIL'" if retry_failed else "") + ")"]
        params: list[object] = [plan_id]
        if period != "all":
            clauses.append("half_year=?")
            params.append(period.upper())
        if date_from:
            clauses.append("race_date>=?")
            params.append(date_from)
        if date_to:
            clauses.append("race_date<=?")
            params.append(date_to)
        rows = self.conn.execute(
            "SELECT race_date FROM year_seed_items WHERE " + " AND ".join(clauses) +
            " ORDER BY ordinal LIMIT ?", (*params, max_dates_this_run),
        ).fetchall()
        self.conn.execute("UPDATE year_seed_plans SET status='RUNNING',updated_at=? WHERE plan_id=?", (now(), plan_id))
        self.conn.commit()
        processed = passed = failed = network_requests = 0
        discovery = SeedDiscovery(self.pipeline)
        for row in rows:
            race_date = row["race_date"]
            self.conn.execute(
                "UPDATE year_seed_items SET status='RUNNING',attempts=attempts+1,started_at=?,"
                "completed_at=NULL,reason_codes_json='[]' WHERE plan_id=? AND race_date=?",
                (now(), plan_id, race_date),
            )
            self.conn.commit()
            processed += 1
            try:
                result = discovery.discover(race_date, cache_only=cache_only)
            except Exception as exc:
                failed += 1
                reason = str(exc) or type(exc).__name__
                self.conn.execute(
                    "UPDATE year_seed_items SET status='FAIL',completed_at=?,reason_codes_json=? "
                    "WHERE plan_id=? AND race_date=?",
                    (now(), json.dumps([reason], ensure_ascii=False), plan_id, race_date),
                )
                self.conn.commit()
            else:
                passed += 1
                network_requests += result["network_request_count"]
                self.conn.execute(
                    "UPDATE year_seed_items SET status='PASS',seed_url=?,completed_at=?,reason_codes_json='[]' "
                    "WHERE plan_id=? AND race_date=?",
                    (result["seed_url"], now(), plan_id, race_date),
                )
                self.conn.commit()
        summary = self.audit(year, plan_id)
        final_status = "PASS" if summary["pass_count"] == summary["expected_dates"] else "PARTIAL"
        self.conn.execute("UPDATE year_seed_plans SET status=?,updated_at=? WHERE plan_id=?", (final_status, now(), plan_id))
        self.conn.commit()
        return {**self.audit(year, plan_id), "requested_period": period.upper(),
                "max_dates_this_run": max_dates_this_run, "processed_this_run": processed,
                "passed_this_run": passed, "failed_this_run": failed,
                "network_request_count": network_requests,
                "mode": "CACHE_ONLY" if cache_only else "ONLINE",
                "date_from": date_from, "date_to": date_to}

    def audit(self, year: int, plan_id: str | None = None) -> dict:
        if plan_id is None:
            row = self.conn.execute(
                "SELECT plan_id FROM year_seed_plans WHERE year=? ORDER BY created_at DESC LIMIT 1", (year,)
            ).fetchone()
            if row is None:
                raise YearSeedPlanFailure("YEAR_SEED_PLAN_NOT_FOUND")
            plan_id = row["plan_id"]
        plan = self.conn.execute("SELECT * FROM year_seed_plans WHERE plan_id=?", (plan_id,)).fetchone()
        if plan is None or plan["year"] != year:
            raise YearSeedPlanFailure("YEAR_SEED_PLAN_NOT_FOUND")
        counts = {row["status"]: row["n"] for row in self.conn.execute(
            "SELECT status,COUNT(*) n FROM year_seed_items WHERE plan_id=? GROUP BY status", (plan_id,)
        )}
        total = sum(counts.values())
        reasons = []
        if total != plan["expected_dates"]:
            reasons.append("YEAR_SEED_ITEM_COUNT_MISMATCH")
        orphan = self.conn.execute(
            "SELECT COUNT(*) FROM year_seed_items i LEFT JOIN result_seed_urls u USING(race_date) "
            "WHERE i.plan_id=? AND i.status='PASS' AND u.race_date IS NULL", (plan_id,)
        ).fetchone()[0]
        if orphan:
            reasons.append("YEAR_SEED_PASS_WITHOUT_URL")
        reuse = self.conn.execute(
            "SELECT COUNT(DISTINCT u.entry_snapshot_id),COUNT(DISTINCT u.month_index_snapshot_id),"
            "COUNT(DISTINCT u.race_selection_snapshot_id) FROM year_seed_items i "
            "JOIN result_seed_urls u USING(race_date) WHERE i.plan_id=? AND i.status='PASS'", (plan_id,)
        ).fetchone()
        return {"status": plan["status"], "audit_status": "PASS" if not reasons else "FAIL",
                "reason_codes": reasons, "plan_id": plan_id, "year": year,
                "expected_dates": plan["expected_dates"], "item_count": total,
                "pass_count": counts.get("PASS", 0), "pending_count": counts.get("PENDING", 0),
                "fail_count": counts.get("FAIL", 0), "running_count": counts.get("RUNNING", 0),
                "distinct_entry_snapshots": reuse[0], "distinct_month_index_snapshots": reuse[1],
                "distinct_race_selection_snapshots": reuse[2]}
