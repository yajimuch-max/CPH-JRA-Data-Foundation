"""Resumable, observed-link-only collection for new 2011--2017 masters.

No legacy import or post-hoc RAW reaudit is needed: validate each response
before integration and keep only provenance and discovery checkpoints.
"""
import json,re
from datetime import date
from .network import Deferred
from .racing import decode_jra,form,links,integrate_result,integrate_odds,odds_cname
from .jra_parser import TRACK_CODE

RESULT_URL='https://www.jra.go.jp/JRADB/accessS.html'
ODDS_URL='https://www.jra.go.jp/JRADB/accessO.html'
ENTRY='pw01skl00999999/B3'

def cached(s,key):
 row=s.c.execute('SELECT value FROM metadata WHERE key=?',(key,)).fetchone()
 return json.loads(row[0]) if row else None

def month_task(year,month,start,end):
 return f'FRESH_MONTH_{year}_{month:02d}_{start}_{end}'

def race_identity(cname,year,month,start,end):
 m=re.fullmatch(r'pw01sde10(?P<track>\d{2})(?P<year>\d{4})\d{4}(?P<race>\d{2})(?P<date>\d{8})/[0-9A-F]{2}',cname)
 if not m or m['track'] not in TRACK_CODE:raise ValueError('INVALID_OBSERVED_RESULT_CNAME')
 d=m['date'];day=f'{d[:4]}-{d[4:6]}-{d[6:]}'
 date.fromisoformat(day)
 if m['year']!=str(year) or d[:4]!=str(year) or int(d[4:6])!=month or not start<=day<=end or not 1<=int(m['race'])<=12:
  raise ValueError('OBSERVED_RESULT_OUTSIDE_REQUESTED_RANGE')
 return f'{day}-{TRACK_CODE[m["track"]]}-{int(m["race"]):02d}'

class LimitedClient:
 def __init__(self,client,limit):self.client=client;self.limit=limit;self.requests=0
 def request(self,*args):
  if self.requests>=self.limit:raise Deferred('SOURCE_LIMIT_CHECKPOINT')
  self.requests+=1;return self.client.request(*args)
 def valid(self,*args):return self.client.valid(*args)

def discover(s,client,year,month,start,end,refresh=False):
 prefix=f'fresh_discovery_{year}_{month:02d}_{start}_{end}'
 complete=cached(s,prefix)
 if complete is not None and not refresh:return complete['results']
 index=cached(s,prefix+'_index')
 if index is None or refresh:
  entry=cached(s,f'fresh_search_entry_{year}')
  if entry is None or refresh:
   body,sid,p=client.request(RESULT_URL,'RESULT_SEARCH_ENTRY',form(ENTRY))
   text=decode_jra(body)
   tokens=dict(re.findall(r'objParam\["(\d{4})"\]\s*=\s*"([0-9A-F]{2})"',text))
   if f'{year%100:02d}{month:02d}' not in tokens:raise ValueError('OFFICIAL_MONTH_TOKEN_NOT_FOUND')
   entry={'tokens':tokens,'source_id':sid};s.meta(f'fresh_search_entry_{year}',entry);client.valid(sid,p)
  token=entry['tokens'].get(f'{year%100:02d}{month:02d}')
  if not token:raise ValueError('OFFICIAL_MONTH_TOKEN_NOT_FOUND')
  body,sid,p=client.request(RESULT_URL,'RESULT_MONTH_INDEX',form(f'pw01skl10{year:04d}{month:02d}/'+token))
  meetings=[]
  for cname in links(body,'srl'):
   m=re.search(r'(\d{8})/[0-9A-F]{2}$',cname)
   if not m:raise ValueError('MEETING_DATE_UNPARSEABLE')
   d=m[1];day=f'{d[:4]}-{d[4:6]}-{d[6:]}'
   date.fromisoformat(day)
   if d[:4]!=str(year) or int(d[4:6])!=month:raise ValueError('MONTH_INDEX_DATE_MISMATCH')
   if start<=day<=end:meetings.append(cname)
  if not meetings:raise ValueError('OFFICIAL_MONTH_MEETINGS_EMPTY_REQUIRES_REVIEW')
  index={'meetings':meetings,'source_id':sid};s.meta(prefix+'_index',index);client.valid(sid,p)
 result=[]
 for cname in index['meetings']:
  key='fresh_selection_'+cname;selection=cached(s,key)
  if selection is None or refresh:
   body,sid,p=client.request(RESULT_URL,'RESULT_RACE_SELECTION',form(cname));found=links(body,'sde')
   if not found:raise ValueError('MEETING_RESULTS_EMPTY_REQUIRES_REVIEW')
   for rc in found:
    race_identity(rc,year,month,start,end)
    if re.search(r'\d{8}/[0-9A-F]{2}$',rc)[0].split('/')[0]!=re.search(r'\d{8}/[0-9A-F]{2}$',cname)[0].split('/')[0]:
     raise ValueError('RESULT_SELECTION_DATE_MISMATCH')
   selection={'results':found,'source_id':sid};s.meta(key,selection);client.valid(sid,p)
  result.extend(selection['results'])
 result=sorted(set(result))
 s.meta(prefix,{'results':result,'index_source_id':index['source_id']})
 return result

def collect(s,client,year,months,start,end,refresh=False,max_sources=12000):
 client=LimitedClient(client,max_sources);errors=[];completed=0
 goal=cached(s,'fresh_collection_goal')
 if goal:
  goal['status']='BODY_IN_PROGRESS';s.meta('fresh_collection_goal',goal)
 for month in months:
  mk=month_task(year,month,start,end)
  if not s.c.execute('SELECT 1 FROM tasks WHERE task_key=?',(mk,)).fetchone():s.task(mk,'PENDING')
 for month in months:
  mk=month_task(year,month,start,end)
  if s.done(mk) and not refresh:continue
  try:
   cnames=discover(s,client,year,month,start,end,refresh)
   for cname in cnames:
    tk='FRESH_RACE_'+cname;rk='FRESH_RESULT_'+cname
    if not s.c.execute('SELECT 1 FROM tasks WHERE task_key=?',(tk,)).fetchone():s.task(tk,'PENDING')
   for cname in cnames:
    tk='FRESH_RACE_'+cname;rk='FRESH_RESULT_'+cname
    if s.done(tk) and not refresh:continue
    try:
     rid=race_identity(cname,year,month,start,end)
     checkpoint=cached(s,'fresh_result_'+cname)
     if refresh or not s.done(rk) or checkpoint is None:
      body,sid,p=client.request(RESULT_URL,'RACE_RESULT',form(cname))
      oc=odds_cname(body)
      actual,_=integrate_result(s,body,sid,rid)
      checkpoint={'race_id':actual,'odds_cname':oc,'result_source_id':sid}
      s.meta('fresh_result_'+cname,checkpoint);s.task(rk,'PASS');client.valid(sid,p)
     if checkpoint['race_id']!=rid:raise ValueError('RESULT_CHECKPOINT_ID_MISMATCH')
     # The odds token was observed in the validated result response, never guessed.
     if not re.fullmatch(r'pw151ou[^\s\"\x27<>]+/[0-9A-F]{2}',checkpoint['odds_cname']):raise ValueError('INVALID_OBSERVED_ODDS_CNAME')
     body,sid,p=client.request(ODDS_URL,'FINAL_WIN_ODDS',form(checkpoint['odds_cname']))
     integrate_odds(s,body,sid,rid);client.valid(sid,p)
     s.task(tk,'PASS');s.resolve(tk);completed+=1;print('RACE_PASS',rid,flush=True)
    except Deferred as e:
     s.task(tk,'DEFERRED',str(e));raise
    except Exception as e:
     s.task(tk,'FAIL',str(e));s.issue(tk,'RACE_FETCH_OR_VALIDATION',{'error':str(e),'official_cname':cname});errors.append(str(e))
   if all(s.done('FRESH_RACE_'+c) for c in cnames):s.task(mk,'PASS');s.resolve(mk)
   else:s.task(mk,'PENDING','Race acquisition/validation remains incomplete')
  except Deferred as e:s.task(mk,'DEFERRED',str(e));break
  except Exception as e:
   s.task(mk,'FAIL',str(e));s.issue(mk,'OFFICIAL_DISCOVERY',{'error':str(e)});errors.append(str(e))
 if goal:
  goal['status']='BODY_COMPLETE' if all(s.done(month_task(goal['year'],m,goal['start'],goal['end'])) for m in goal['months']) else 'BODY_IN_PROGRESS'
  s.meta('fresh_collection_goal',goal)
 return {'completed_races':completed,'requested_sources':client.requests,'errors':errors}
