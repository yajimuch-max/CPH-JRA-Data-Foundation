"""Regressions for the 2019-06 JRA class nomenclature change.

Only tests officially printed race_title text. The tests DO NOT turn
race payload / historic summaries into purported HTML observations.
"""
import unittest
from jra_master.html_first import _html_fields


def parse(title):
    body=(f'<html><div class="race_title">{title}</div></html>').encode('cp932')
    condition, klass, _ = _html_fields(body, None)
    return condition, klass

class Class2019IncrementalTests(unittest.TestCase):
    def test_pre_2019(self):
        c, k = parse('サラ系3歳未勝利 サラ系3歳 未勝利 [指定] 馬齢 コース：1,600 メートル')
        self.assertIn('サラ系3歳', c)
        self.assertEqual(k, '未勝利')

    def test_post_2019_maiden(self):
        c, k = parse('3歳未勝利 3歳 未勝利 牝［指定］ 馬齢 コース：1,600 メートル')
        self.assertIn('3歳', c)
        self.assertEqual(k, '未勝利')

    def test_post_2019_classes(self):
        for rank in range(1,4):
            with self.subTest(rank=rank):
                c,k=parse(f'青葉特別 3歳以上 {rank}勝クラス （混合） 定量 コース：2,000 メートル')
                self.assertEqual(k, f'{rank}勝クラス')

    def test_post_2019_open_and_jumps(self):
        self.assertEqual(parse('第100回有馬記念 3歳以上 オープン （国際）コース：2,500メートル')[1], 'オープン')
        self.assertEqual(parse('障害3歳以上未勝利 障害3歳以上 未勝利 コース：3,000メートル')[1], '未勝利')

    def test_unrelated_page_body_not_scanned(self):
        self.assertEqual(parse('レース名のみ')[0], None)

if __name__=='__main__': unittest.main()
