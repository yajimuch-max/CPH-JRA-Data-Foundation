import unittest, tempfile, sqlite3, json, hashlib
from pathlib import Path
from unittest.mock import patch
from jra_master.track_enrichment import (extract_legacy,extract_legacy_text_fallback,schema)
from jra_master.track_action import sync_year

ROWS=[['場所','金曜日','土曜日','火曜日'],
 ['芝コース含水率','ゴール前','10.2','13.1','10.9'],
 ['', '４コーナー','9.0','11.6','9.8'],
 ['ダートコース含水率','ゴール前','12.1','17.3','11.7'],
 ['', '４コーナー','12.2','17.6','11.2']]
SPAN='2018年9月28日から10月2日の含水率'
URL='https://www.jra.go.jp/keiba/baba/archive/2018pdf/hanshin04.pdf'
class FakeTable:
    bbox=(0,100,300,400)
    def extract(self):return ROWS
class FakePage:
    def find_tables(self,**kw):return [FakeTable()]
    def extract_text_lines(self):return [{'top':10,'text':SPAN}]
    def extract_text(self):return '\n'.join([SPAN,'場所 金曜日 土曜日 火曜日',
        '芝コース含水率 ゴール前 10.2 13.1 10.9','４コーナー 9.0 11.6 9.8',
        'ダートコース含水率 ゴール前 12.1 17.3 11.7','４コーナー 12.2 17.6 11.2'])
class Tests(unittest.TestCase):
 def test_irregular_pdf_table(self):
  rows=extract_legacy(FakePage(),2018,'阪神',URL,'my-sha',1)
  self.assertEqual([r['date'] for r in rows],['2018-09-28','2018-09-29','2018-10-02'])
  self.assertEqual([(r['turf_goal'],r['dirt_fourth']) for r in rows],[(10.2,12.2),(13.1,17.6),(10.9,11.2)])
 def test_irregular_pdf_text_fallback(self):
  rows=extract_legacy_text_fallback(FakePage(),2018,'阪神',URL,'my-sha',1)
  self.assertEqual([r['date'] for r in rows],['2018-09-28','2018-09-29','2018-10-02'])
 def test_missing_date_forces_reparse_despite_same_receipt(self):
  import jra_master.track_action as ta
  with tempfile.TemporaryDirectory() as td:
   d=Path(td)/'MASTER.sqlite3'
   c=sqlite3.connect(d)
   c.executescript('''create table races(race_id text primary key,race_date text,track text,payload_json text);
    create table runners(race_id text);create table results(race_id text);
    create table win_odds(race_id text);create table pedigree(horse_id text);''')
   c.execute('insert into races values(?,?,?,?)',('r1','2018-09-29','阪神',json.dumps({'surface':'芝'})))
   c.execute('insert into races values(?,?,?,?)',('r2','2018-10-02','阪神',json.dumps({'surface':'芝'})))
   schema(c)
   fake_pdf=b'%PDF-1.4\nfake stream';digest=hashlib.sha256(fake_pdf).hexdigest()
   c.execute('insert into official_track_pdf_receipts values (?,?,?,?,?,?,?)',(URL,'阪神',digest,'PASS',10,'2026-10-09T00:00:00Z',None))
   c.commit();c.close()
   def fake_observations(track,url,p):
    return [{'date':dt,'track':'阪神','source_url':URL,'source_sha256':digest,'source_page':1,'raw_format':'LEGACY_GROUP','used_course':None,'cushion_time':None,'cushion':None,'moisture_time':None,'turf_goal':v[0],'turf_fourth':v[1],'dirt_goal':v[2],'dirt_fourth':v[3]} for dt,v in [('2018-09-29',(13.1,11.6,17.3,17.6)),('2018-10-02',(10.9,9.8,11.7,11.2))]]
   class Response:
    content=fake_pdf
    def raise_for_status(self):return None
   class FakeSession:
    headers={}
    def get(self,*args,**kw):return Response()
   with patch('jra_master.track_enrichment.get_archive_links',return_value=[('阪神',URL)]),patch('jra_master.track_enrichment.extract_observations',side_effect=fake_observations),patch('requests.Session',return_value=FakeSession()):
    out=sync_year(2018,d,cache_root=Path(td)/'cache',throttle=0,budget_seconds=500)
   self.assertEqual(out['status'],'PASS',out)
   self.assertEqual(out['missing_race_track_days'],0)
   self.assertEqual(out['pdf_forced_gap_reparse'],1)
   c=sqlite3.connect(d);self.assertEqual(c.execute('select count(*) from official_track_daily').fetchone()[0],2)
   c.close()
if __name__=='__main__':unittest.main()
