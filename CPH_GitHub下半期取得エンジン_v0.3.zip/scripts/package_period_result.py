from __future__ import annotations
import argparse, hashlib, json, zipfile
from pathlib import Path

def main() -> int:
    p = argparse.ArgumentParser()
    for name in ("year", "period", "status", "data_root", "reports_root", "delivery_root"):
        p.add_argument(f"--{name.replace('_', '-')}", required=True)
    a = p.parse_args()
    data, reports, delivery = map(lambda x: Path(x).resolve(), (a.data_root, a.reports_root, a.delivery_root))
    delivery.mkdir(parents=True, exist_ok=True)
    base = f"CPH_JRA公式データ_{a.year}年_下半期_{a.period.replace('/', '-')}_CHECKPOINT"
    (reports / "実行状態.json").write_text(json.dumps({
        "status": a.status, "year": int(a.year), "period": a.period,
        "purpose": "GitHub Actions 下半期連続取得", "runner_version": "v0.3",
        "data_foundation_id": "CPH-JRA-DF-v0.14.0"
    }, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    zpath = delivery / f"{base}.zip"
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for root, prefix in ((reports, "reports"), (data, "data")):
            if root.exists():
                for path in sorted(x for x in root.rglob("*") if x.is_file()):
                    zf.write(path, Path(prefix) / path.relative_to(root))
    digest = hashlib.sha256(zpath.read_bytes()).hexdigest()
    (delivery / f"{base}_SHA256.txt").write_text(f"{digest}  {zpath.name}\n", encoding="utf-8")
    print(json.dumps({"zip": str(zpath), "sha256": digest}, ensure_ascii=False)); return 0

if __name__ == "__main__": raise SystemExit(main())
