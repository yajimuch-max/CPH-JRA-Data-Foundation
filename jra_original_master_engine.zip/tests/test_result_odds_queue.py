import tempfile,unittest,json
from unittest.mock import patch
from jra_master.store import Store
from jra_master.racing import queue_result_final_odds
class QueueTests(unittest.TestCase):
 def test_exact_observed_link_checkpointed_and_not_duplicated(self):
  with tempfile.TemporaryDirectory() as t:
   s=Store(t+'/db');q=[]
   with patch('jra_master.racing.odds_cname',return_value='pw151ouX/AB'):
    queue_result_final_odds(s,b'official','R','source',q);queue_result_final_odds(s,b'official','R','source',q)
   self.assertEqual(len(q),1);self.assertEqual(json.loads(s.c.execute("SELECT value FROM metadata WHERE key='pending_official_reaudit'").fetchone()[0]),q)
   self.assertEqual(q[0]['observed_from_source_id'],'source');s.task(q[0]['task_key'],'PASS')
   with patch('jra_master.racing.odds_cname') as parse:queue_result_final_odds(s,b'official','R','source',[]);parse.assert_not_called()
   s.c.close()
 def test_missing_link_never_invented(self):
  with tempfile.TemporaryDirectory() as t:
   s=Store(t+'/db');q=[]
   with self.assertRaisesRegex(RuntimeError,'LINK_NOT_FOUND'):queue_result_final_odds(s,b'<html>none</html>','R','source',q)
   self.assertEqual(q,[]);s.c.close()
