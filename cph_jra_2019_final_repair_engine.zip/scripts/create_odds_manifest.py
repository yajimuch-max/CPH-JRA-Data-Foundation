#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import sqlite3
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--db", type=Path, required=True)
    parser.add_argument("--year", type=int, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    con = sqlite3.connect(args.db)
    rows = con.execute(
        """
        SELECT
            CAST(substr(r.race_date, 1, 4) AS INTEGER) AS year,
            CAST(substr(r.race_date, 6, 2) AS INTEGER) AS month,
            r.race_key,
            r.race_date,
            r.track,
            r.race_no,
            s.final_url,
            COUNT(e.horse_no) AS expected_horses
        FROM races_pre_race r
        JOIN race_entries_pre_race e ON e.race_key = r.race_key
        JOIN raw_snapshots s ON s.snapshot_id = r.source_snapshot_id
        WHERE substr(r.race_date, 1, 4) = ?
        GROUP BY r.race_key
        ORDER BY r.race_date, r.track, r.race_no
        """,
        (str(args.year),),
    ).fetchall()
    con.close()
    if not rows:
        raise SystemExit("ODDS_MANIFEST_EMPTY")
    if any(not row[6] for row in rows):
        raise SystemExit("ODDS_MANIFEST_RESULT_URL_MISSING")

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.writer(fh)
        writer.writerow(
            ["year", "month", "race_key", "race_date", "track", "race_no", "result_url", "expected_horses"]
        )
        writer.writerows(rows)
    print(f"manifest={args.output} races={len(rows)}")


if __name__ == "__main__":
    main()
