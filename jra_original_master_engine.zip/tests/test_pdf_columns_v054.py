"""Conservative guards for historical two-column JRA PDF reports."""
import unittest
from jra_master.official_expansion import extract_pdf_pages, extract_blocks, conditions

class FakeClip:
    def __init__(self,t):self.t=t
    def extract_text(self):return self.t

class FakePage:
    width=842;height=595
    def __init__(self,l,r):self.l=l;self.r=r
    def extract_text(self):return self.l+'\n'+self.r
    def crop(self,box):return FakeClip(self.l if box[0]==0 else self.r)

class FakePDF:
    def __init__(self,pages):self.pages=pages

def header(no):return f'03025 2月4日 晴 良 (24東京1)第3日 第{no}競走'

class ColumnTests(unittest.TestCase):
    def test_two_columns_separate_and_summary_preserved(self):
        p=FakePDF([FakePage(header(1)+'\n発走10時\n未勝利;負担重量は馬齢重量',header(2)+'\n発走11時\n新馬;負担重量は馬齢重量'),
                   FakePage('2月4日（土曜日） 競走回数12回','晴 馬場 (芝Dコース) 良 (ダート)良')])
        pages=extract_pdf_pages(p,2012)
        self.assertEqual(len(pages),3)
        blocks=extract_blocks(pages,2012,'東京',1,3)
        self.assertEqual([b['no'] for b in blocks],[1,2])
        self.assertEqual(conditions(blocks[0]['lines'])[1],'未勝利')
        self.assertEqual(conditions(blocks[1]['lines'])[1],'新馬')
        self.assertIn('芝Dコース',pages[-1][1])

    def test_unreadable_official_text_not_saved_as_valid(self):
        text,klass=conditions([header(7),'発走13時','500万円以下;負担重量は57(cid:3),牝馬2(cid:3)減','本 賞 100000円'])
        self.assertIsNone(text)
        self.assertEqual(klass,'500万円以下')

if __name__=='__main__':unittest.main()
