from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

from . import SCHEMA_VERSION
from .model import ParsedRace, ScheduleRace, ValidationIssue


SCHEMA_SQL = """
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS metadata (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS pipeline_runs (
  run_id TEXT PRIMARY KEY,
  race_date TEXT NOT NULL,
  mode TEXT NOT NULL CHECK(mode IN ('ONLINE','CACHE_ONLY','REPARSE')),
  started_at TEXT NOT NULL,
  completed_at TEXT,
  status TEXT NOT NULL CHECK(status IN ('RUNNING','PASS','FAIL')),
  stage TEXT NOT NULL,
  reason_codes_json TEXT NOT NULL DEFAULT '[]'
);
CREATE TABLE IF NOT EXISTS schedule_manifests (
  manifest_id TEXT PRIMARY KEY,
  race_date TEXT NOT NULL,
  source_snapshot_id INTEGER NOT NULL,
  created_at TEXT NOT NULL,
  expected_flat_races INTEGER NOT NULL,
  manifest_sha256 TEXT NOT NULL,
  FOREIGN KEY(source_snapshot_id) REFERENCES raw_snapshots(snapshot_id)
);
CREATE TABLE IF NOT EXISTS schedule_races (
  manifest_id TEXT NOT NULL,
  race_key TEXT NOT NULL,
  race_date TEXT NOT NULL,
  track TEXT NOT NULL,
  meeting_label TEXT NOT NULL,
  race_no INTEGER NOT NULL,
  race_name TEXT NOT NULL,
  surface TEXT NOT NULL CHECK(surface IN ('芝','ダート','障害')),
  distance_m INTEGER NOT NULL,
  post_time TEXT NOT NULL,
  is_flat INTEGER NOT NULL CHECK(is_flat IN (0,1)),
  PRIMARY KEY(manifest_id, race_key),
  FOREIGN KEY(manifest_id) REFERENCES schedule_manifests(manifest_id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS raw_snapshots (
  snapshot_id INTEGER PRIMARY KEY AUTOINCREMENT,
  request_url TEXT NOT NULL,
  final_url TEXT NOT NULL,
  requested_at TEXT NOT NULL,
  responded_at TEXT NOT NULL,
  http_status INTEGER NOT NULL,
  content_type TEXT,
  content_encoding TEXT,
  entity_bytes INTEGER NOT NULL,
  entity_sha256 TEXT NOT NULL,
  storage_encoding TEXT NOT NULL DEFAULT 'identity',
  stored_bytes INTEGER,
  storage_sha256 TEXT,
  relative_path TEXT NOT NULL UNIQUE,
  fetcher_version TEXT NOT NULL,
  source_role TEXT NOT NULL,
  cache_key TEXT NOT NULL,
  request_method TEXT NOT NULL DEFAULT 'GET',
  request_body TEXT,
  request_body_sha256 TEXT,
  UNIQUE(request_url, entity_sha256)
);
CREATE INDEX IF NOT EXISTS idx_raw_cache_key ON raw_snapshots(cache_key);
CREATE TABLE IF NOT EXISTS races_pre_race (
  race_key TEXT PRIMARY KEY,
  race_date TEXT NOT NULL,
  track TEXT NOT NULL,
  meeting_label TEXT NOT NULL,
  race_no INTEGER NOT NULL,
  race_name TEXT NOT NULL,
  surface TEXT NOT NULL CHECK(surface IN ('芝','ダート')),
  distance_m INTEGER NOT NULL,
  course_detail TEXT,
  post_time TEXT NOT NULL,
  grade TEXT,
  source_snapshot_id INTEGER NOT NULL,
  asof_quality TEXT NOT NULL CHECK(asof_quality IN ('TRUE_PRE_RACE_SNAPSHOT','HISTORICAL_RESULT_DERIVED')),
  parser_version TEXT NOT NULL,
  FOREIGN KEY(source_snapshot_id) REFERENCES raw_snapshots(snapshot_id)
);
CREATE TABLE IF NOT EXISTS race_entries_pre_race (
  race_key TEXT NOT NULL,
  horse_no INTEGER NOT NULL,
  frame_no INTEGER,
  horse_id TEXT NOT NULL,
  horse_name TEXT NOT NULL,
  sex_age TEXT,
  assigned_weight_kg REAL,
  jockey_id TEXT,
  jockey_name TEXT,
  trainer_id TEXT,
  trainer_name TEXT,
  body_weight_kg INTEGER,
  body_weight_change_kg INTEGER,
  PRIMARY KEY(race_key, horse_no),
  UNIQUE(race_key, horse_id),
  FOREIGN KEY(race_key) REFERENCES races_pre_race(race_key) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS race_results (
  race_key TEXT NOT NULL,
  horse_no INTEGER NOT NULL,
  finish_status TEXT NOT NULL,
  finish_position INTEGER,
  finish_time TEXT,
  margin TEXT,
  corner_positions_json TEXT NOT NULL,
  final_3f REAL,
  weather TEXT,
  track_condition TEXT,
  source_snapshot_id INTEGER NOT NULL,
  parser_version TEXT NOT NULL,
  PRIMARY KEY(race_key, horse_no),
  FOREIGN KEY(race_key, horse_no) REFERENCES race_entries_pre_race(race_key, horse_no) ON DELETE CASCADE,
  FOREIGN KEY(source_snapshot_id) REFERENCES raw_snapshots(snapshot_id)
);
CREATE TABLE IF NOT EXISTS data_quality_events (
  event_id INTEGER PRIMARY KEY AUTOINCREMENT,
  run_id TEXT NOT NULL,
  race_key TEXT,
  stage TEXT NOT NULL,
  event_class TEXT NOT NULL CHECK(event_class IN ('SOURCE_MISSING','SOURCE_FETCH_FAILURE','PARSE_FAILURE','VALIDATION_FAILURE','EXPECTED_NULL','IMPORT_FAILURE','AUDIT_FAILURE')),
  code TEXT NOT NULL,
  field_path TEXT,
  message TEXT NOT NULL,
  created_at TEXT NOT NULL,
  FOREIGN KEY(run_id) REFERENCES pipeline_runs(run_id)
);
CREATE TABLE IF NOT EXISTS import_audit (
  run_id TEXT NOT NULL,
  race_key TEXT NOT NULL,
  source_snapshot_id INTEGER NOT NULL,
  parser_version TEXT NOT NULL,
  transaction_status TEXT NOT NULL CHECK(transaction_status IN ('COMMITTED','ROLLED_BACK')),
  entry_count INTEGER NOT NULL,
  result_count INTEGER NOT NULL,
  imported_at TEXT NOT NULL,
  PRIMARY KEY(run_id, race_key),
  FOREIGN KEY(run_id) REFERENCES pipeline_runs(run_id),
  FOREIGN KEY(source_snapshot_id) REFERENCES raw_snapshots(snapshot_id)
);
CREATE TABLE IF NOT EXISTS batch_runs (
  batch_id TEXT PRIMARY KEY,
  plan_sha256 TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('PLANNED','RUNNING','PASS','PARTIAL','STOPPED')),
  max_total_bytes INTEGER NOT NULL,
  reserve_free_bytes INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS batch_items (
  batch_id TEXT NOT NULL,
  race_date TEXT NOT NULL,
  bootstrap_url TEXT NOT NULL,
  ordinal INTEGER NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('PENDING','RUNNING','PASS','FAIL','CAPACITY_STOP')),
  attempts INTEGER NOT NULL DEFAULT 0,
  pipeline_run_id TEXT,
  started_at TEXT,
  completed_at TEXT,
  reason_codes_json TEXT NOT NULL DEFAULT '[]',
  PRIMARY KEY(batch_id, race_date),
  FOREIGN KEY(batch_id) REFERENCES batch_runs(batch_id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS year_schedule_manifests (
  manifest_id TEXT PRIMARY KEY,
  year INTEGER NOT NULL,
  created_at TEXT NOT NULL,
  race_day_count INTEGER NOT NULL,
  manifest_sha256 TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS year_calendar_sources (
  manifest_id TEXT NOT NULL,
  month INTEGER NOT NULL CHECK(month BETWEEN 1 AND 12),
  source_snapshot_id INTEGER NOT NULL,
  PRIMARY KEY(manifest_id, month),
  FOREIGN KEY(manifest_id) REFERENCES year_schedule_manifests(manifest_id) ON DELETE CASCADE,
  FOREIGN KEY(source_snapshot_id) REFERENCES raw_snapshots(snapshot_id)
);
CREATE TABLE IF NOT EXISTS year_race_days (
  manifest_id TEXT NOT NULL,
  race_date TEXT NOT NULL,
  day_label TEXT NOT NULL,
  meeting_labels_json TEXT NOT NULL,
  tracks_json TEXT NOT NULL,
  half_year TEXT NOT NULL CHECK(half_year IN ('H1','H2')),
  PRIMARY KEY(manifest_id, race_date),
  FOREIGN KEY(manifest_id) REFERENCES year_schedule_manifests(manifest_id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS result_seed_urls (
  race_date TEXT PRIMARY KEY,
  seed_url TEXT NOT NULL,
  meeting_cname TEXT NOT NULL,
  entry_snapshot_id INTEGER NOT NULL,
  month_index_snapshot_id INTEGER NOT NULL,
  race_selection_snapshot_id INTEGER NOT NULL,
  discovered_at TEXT NOT NULL,
  FOREIGN KEY(entry_snapshot_id) REFERENCES raw_snapshots(snapshot_id),
  FOREIGN KEY(month_index_snapshot_id) REFERENCES raw_snapshots(snapshot_id),
  FOREIGN KEY(race_selection_snapshot_id) REFERENCES raw_snapshots(snapshot_id)
);
CREATE TABLE IF NOT EXISTS year_seed_plans (
  plan_id TEXT PRIMARY KEY,
  year INTEGER NOT NULL,
  year_manifest_id TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('PLANNED','RUNNING','PARTIAL','PASS')),
  expected_dates INTEGER NOT NULL,
  FOREIGN KEY(year_manifest_id) REFERENCES year_schedule_manifests(manifest_id)
);
CREATE TABLE IF NOT EXISTS year_seed_items (
  plan_id TEXT NOT NULL,
  race_date TEXT NOT NULL,
  half_year TEXT NOT NULL CHECK(half_year IN ('H1','H2')),
  ordinal INTEGER NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('PENDING','RUNNING','PASS','FAIL')),
  attempts INTEGER NOT NULL DEFAULT 0,
  seed_url TEXT,
  started_at TEXT,
  completed_at TEXT,
  reason_codes_json TEXT NOT NULL DEFAULT '[]',
  PRIMARY KEY(plan_id, race_date),
  FOREIGN KEY(plan_id) REFERENCES year_seed_plans(plan_id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_year_seed_items_status
  ON year_seed_items(plan_id, half_year, status, ordinal);
CREATE TABLE IF NOT EXISTS month_collection_runs (
  plan_id TEXT PRIMARY KEY,
  year INTEGER NOT NULL,
  month INTEGER NOT NULL CHECK(month BETWEEN 1 AND 12),
  year_manifest_id TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('PLANNED','RUNNING','PARTIAL','PASS')),
  expected_dates INTEGER NOT NULL,
  FOREIGN KEY(year_manifest_id) REFERENCES year_schedule_manifests(manifest_id)
);
CREATE TABLE IF NOT EXISTS month_collection_items (
  plan_id TEXT NOT NULL,
  race_date TEXT NOT NULL,
  ordinal INTEGER NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('PENDING','RUNNING','PASS','FAIL')),
  phase TEXT NOT NULL CHECK(phase IN ('PENDING','SEED','IMPORT','AUDIT','COMPLETE')),
  attempts INTEGER NOT NULL DEFAULT 0,
  pipeline_run_id TEXT,
  started_at TEXT,
  completed_at TEXT,
  reason_codes_json TEXT NOT NULL DEFAULT '[]',
  PRIMARY KEY(plan_id, race_date),
  FOREIGN KEY(plan_id) REFERENCES month_collection_runs(plan_id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_month_collection_items_status
  ON month_collection_items(plan_id, status, ordinal);
"""


def connect(path: Path) -> sqlite3.Connection:
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    conn.executescript(SCHEMA_SQL)
    columns = {row[1] for row in conn.execute("PRAGMA table_info(raw_snapshots)")}
    for name, ddl in (
        ("storage_encoding", "TEXT NOT NULL DEFAULT 'identity'"),
        ("stored_bytes", "INTEGER"),
        ("storage_sha256", "TEXT"),
        ("request_method", "TEXT NOT NULL DEFAULT 'GET'"),
        ("request_body", "TEXT"),
        ("request_body_sha256", "TEXT"),
    ):
        if name not in columns:
            conn.execute(f"ALTER TABLE raw_snapshots ADD COLUMN {name} {ddl}")
    conn.execute("INSERT OR REPLACE INTO metadata(key,value) VALUES('schema_version',?)", (SCHEMA_VERSION,))
    conn.commit()
    return conn


@contextmanager
def race_transaction(conn: sqlite3.Connection) -> Iterator[None]:
    conn.execute("SAVEPOINT race_import")
    try:
        yield
    except Exception:
        conn.execute("ROLLBACK TO race_import")
        conn.execute("RELEASE race_import")
        raise
    else:
        conn.execute("RELEASE race_import")


def insert_manifest(conn: sqlite3.Connection, manifest_id: str, snapshot_id: int, created_at: str,
                    manifest_hash: str, races: list[ScheduleRace]) -> None:
    conn.execute("DELETE FROM schedule_races WHERE manifest_id=?", (manifest_id,))
    conn.execute("DELETE FROM schedule_manifests WHERE manifest_id=?", (manifest_id,))
    conn.execute(
        "INSERT INTO schedule_manifests VALUES(?,?,?,?,?,?)",
        (manifest_id, races[0].race_date, snapshot_id, created_at, sum(r.is_flat for r in races), manifest_hash),
    )
    conn.executemany(
        "INSERT INTO schedule_races VALUES(?,?,?,?,?,?,?,?,?,?,?)",
        [(manifest_id, r.race_key, r.race_date, r.track, r.meeting_label, r.race_no, r.race_name,
          r.surface, r.distance_m, r.post_time, int(r.is_flat)) for r in races],
    )


def import_race(conn: sqlite3.Connection, parsed: ParsedRace, snapshot_id: int, parser_version: str,
                asof_quality: str = "HISTORICAL_RESULT_DERIVED") -> None:
    conn.execute("DELETE FROM races_pre_race WHERE race_key=?", (parsed.race_key,))
    conn.execute(
        "INSERT INTO races_pre_race VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (parsed.race_key, parsed.race_date, parsed.track, parsed.meeting_label, parsed.race_no,
         parsed.race_name, parsed.surface, parsed.distance_m, parsed.course_detail, parsed.post_time,
         parsed.grade, snapshot_id, asof_quality, parser_version),
    )
    conn.executemany(
        "INSERT INTO race_entries_pre_race VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
        [(parsed.race_key, e.horse_no, e.frame_no, e.horse_id, e.horse_name, e.sex_age,
          e.assigned_weight_kg, e.jockey_id, e.jockey_name, e.trainer_id, e.trainer_name,
          e.body_weight_kg, e.body_weight_change_kg) for e in parsed.entries],
    )
    by_no = {r.horse_no: r for r in parsed.results}
    conn.executemany(
        "INSERT INTO race_results VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
        [(parsed.race_key, e.horse_no, by_no[e.horse_no].finish_status, by_no[e.horse_no].finish_position,
          by_no[e.horse_no].finish_time, by_no[e.horse_no].margin,
          json.dumps(by_no[e.horse_no].corner_positions, separators=(",", ":")), by_no[e.horse_no].final_3f,
          parsed.weather, parsed.track_condition, snapshot_id, parser_version) for e in parsed.entries],
    )


def record_quality(conn: sqlite3.Connection, run_id: str, stage: str, event_class: str,
                   code: str, message: str, created_at: str, race_key: str | None = None,
                   field_path: str | None = None) -> None:
    conn.execute(
        "INSERT INTO data_quality_events(run_id,race_key,stage,event_class,code,field_path,message,created_at) VALUES(?,?,?,?,?,?,?,?)",
        (run_id, race_key, stage, event_class, code, field_path, message, created_at),
    )
