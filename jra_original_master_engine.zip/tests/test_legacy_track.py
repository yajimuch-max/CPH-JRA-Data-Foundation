import json
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from jra_master import legacy_track as lt
from jra_master.track_enrichment import schema as base_schema, populate_context

INDEX_URL='https://www.jra.go.jp/datafile/seiseki/report/2017/2017-1tokyo1.pdf'
SAMPLE='''03001 1月28日 晴 良 (29東京1)第1日 第1競走 サラブレッド系3歳
発走10時10分 (ダート・左)
コースレコード 不良 不良
03002 1月28日 晴 良 (29東京1)第1日 第2競走 サラブレッド系3歳
発走10時40分 (芝・左)
コースレコード 不良 不良
'''
LAST='''(29東京1)第1日 1月28日(土曜日) 晴 馬場 (芝Dコース)
(ダート) 良 良'''

class LegacyTests(unittest.TestCase):
 def test_parse_real_2017_layout_and_no_course_record_leak(self):
  day, rows, course = lt.parse_report_pages([(1,SAMPLE),(7,LAST)],2017,'東京',INDEX_URL,'sha')
  self.assertEqual(day,'2017-01-28')
  self.assertEqual([(r['race_number'],r['surface'],r['going']) for r in rows],[(1,'ダート','良'),(2,'芝','良')])
  self.assertEqual(course,'D')
 def test_parser_rejects_unverified_surface_and_track(self):
  with self.assertRaises(ValueError):lt.parse_report_pages([(1,'1月28日 晴 良 (29中山1)第1日 第1競走')],2017,'東京',INDEX_URL,'sha')
 def test_2010_meeting_cover_only_not_fabricated_going(self):
  cover='第1回 東京競馬成績集計表 （平成22年1月30日～2月21日8日間）\n馬場について 本競馬は，Dコースを使用して競走を施行した。'
  self.assertEqual(lt.parse_2010_meeting([(1,cover)],2010,'東京','https://www.jra.go.jp/datafile/seiseki/report/2010/1tokyo.pdf'),
                   ('2010-01-30','2010-02-21',1,'D'))
 def test_2010_course_adds_only_verified_turf(self):
  c=sqlite3.connect(':memory:');c.execute('PRAGMA foreign_keys=ON')
  c.execute('CREATE TABLE races(race_id TEXT PRIMARY KEY,race_date TEXT,track TEXT,race_number INTEGER,payload_json TEXT)')
  for race,day,venue,meet,surf in [('a','2010-01-30','東京','1回東京1日','芝'),('b','2010-01-31','東京','1回東京2日','ダート'),('c','2010-02-07','東京','1回東京4日','芝'),('d','2010-02-20','東京','2回東京1日','芝')]:
   c.execute('INSERT INTO races VALUES(?,?,?,?,?)',(race,day,venue,1,json.dumps({'surface':surf,'meeting_label':meet})))
  base_schema(c);lt.schema(c)
  n=lt._apply_2010_course(c,'2010-01-30','2010-02-21',1,'東京','D','https://www.jra.go.jp/datafile/seiseki/report/2010/1tokyo.pdf','h')
  self.assertEqual(n,2)
  self.assertEqual(c.execute('SELECT count(*) FROM official_legacy_race_values WHERE used_turf_course="D" AND going IS NULL').fetchone()[0],2)
  lt.overlay_context(c)
  self.assertIsNone(c.execute("SELECT going_from_legacy_report_pdf FROM official_race_track_context WHERE race_id='a'").fetchone()[0])
  self.assertEqual(c.execute("SELECT used_turf_course FROM official_race_track_context WHERE race_id='a'").fetchone()[0],'D')
  c.close()
 def test_index_discovers_both_index_formats(self):
  class Response:
   def __init__(self,txt,url):self.content=txt.encode();self.url=url
   def raise_for_status(self):pass
  class Session:
   def get(self,url,timeout):
    year=int(url.split('/')[-1][:4]);names=['1tokyo.pdf','1tokyo1.pdf','2010-1tokyo1.pdf'] if year==2010 else ['2017-1tokyo1.pdf','1tokyo.pdf']
    return Response(''.join('<a href="'+str(year)+'/'+n+'">PDF</a>' for n in names),url)
  self.assertEqual(len(lt.official_report_links(2010,Session())),1)
  self.assertEqual(len(lt.official_report_links(2017,Session())),1)
 def _db(self,conn):
  conn.execute('PRAGMA foreign_keys=ON')
  conn.execute('''CREATE TABLE races(race_id TEXT PRIMARY KEY,race_date TEXT,track TEXT,race_number INTEGER,payload_json TEXT)''')
  for no,surf in [(1,'ダート'),(2,'芝')]:
   conn.execute('INSERT INTO races VALUES(?,?,?,?,?)',(str(no),'2017-01-28','東京',no,json.dumps({'surface':surf,'track_condition_turf':'良' if surf=='芝' else None})))
  base_schema(conn);lt.schema(conn)
 def test_additive_idempotence_and_refresh_context(self):
  c=sqlite3.connect(':memory:');self._db(c)
  _,rs,co=lt.parse_report_pages([(1,SAMPLE),(7,LAST)],2017,'東京',INDEX_URL,'abc')
  count,done,exp=lt._apply(c,'2017-01-28','東京',rs,co,INDEX_URL,'abc')
  self.assertEqual((count,done,exp),(2,True,2))
  self.assertEqual(lt._apply(c,'2017-01-28','東京',rs,co,INDEX_URL,'abc'),(2,True,2))
  self.assertEqual(c.execute('SELECT count(*) FROM official_legacy_race_values').fetchone()[0],2)
  populate_context(c)
  self.assertEqual(c.execute("SELECT going_from_legacy_report_pdf FROM official_race_track_context WHERE race_id='1'").fetchone()[0],'良')
  self.assertEqual(c.execute("SELECT used_turf_course FROM official_race_track_context WHERE race_id='2'").fetchone()[0],'D')
  self.assertEqual(c.execute('SELECT count(*) FROM races').fetchone()[0],2)
  c.close()
 def test_conflicting_original_never_overwritten(self):
  c=sqlite3.connect(':memory:');self._db(c)
  c.execute('UPDATE races SET payload_json=? WHERE race_id=?',(json.dumps({'surface':'芝','track_condition_turf':'不良'}),'2'))
  _,rs,co=lt.parse_report_pages([(1,SAMPLE),(7,LAST)],2017,'東京',INDEX_URL,'abc')
  with self.assertRaisesRegex(ValueError,'CORE_GOING_CONFLICT'):
   lt._apply(c,'2017-01-28','東京',rs,co,INDEX_URL,'abc')
  self.assertEqual(c.execute('SELECT count(*) FROM official_legacy_race_values').fetchone()[0],0)
  c.close()

if __name__=='__main__':unittest.main()
