import os,subprocess,json
from pathlib import Path
from datetime import datetime,timezone,timedelta
from jra_master.cli import main
Y=int(os.environ['TARGET_YEAR']);mode=os.environ['MODE'];release=os.environ.get('BASE_RELEASE_TAG','');base=os.environ.get('BASE_ASSET_NAME','');start=os.environ.get('START_DATE','');end=os.environ.get('END_DATE','');months=os.environ.get('MONTHS','');limit=os.environ.get('MAX_HORSES','500')
if not 2018<=Y<=2100:raise SystemExit('Invalid year')
db=Path('state')/str(Y)/'MASTER.sqlite3';input_path=None
if release:
 if not base or Path(base).name!=base:raise SystemExit('Exact baseline asset filename required')
 Path('inputs').mkdir(exist_ok=True)
 subprocess.run(['gh','release','download',release,'--repo',os.environ['GITHUB_REPOSITORY'],'--pattern',base,'--dir','inputs','--clobber'],check=True)
 input_path=Path('inputs')/base
common=['--year',str(Y),'--db',str(db),'--output','delivery']
if mode=='preflight':raise SystemExit(main(common+['--mode','preflight']))
if not db.exists() and input_path:main(common+['--mode','bootstrap','--input',str(input_path)])
if mode=='bootstrap':
 if not db.exists():raise SystemExit('Baseline release asset or prior state required')
 raise SystemExit(main(common+['--mode','export']))
args=common+['--mode',mode,'--max-horses',limit,'--max-sources',os.environ.get('MAX_SOURCES','500'),'--budget-seconds','9000']
if input_path:args+=['--input',str(input_path)]
if mode=='reaudit' and not input_path:raise SystemExit('Reaudit requires baseline release asset (saved RAW)')
if mode=='update':
 if start:args+=['--start',start]
 if end:args+=['--end',end]
 if months:args+=['--months',months]
 if os.environ.get('REFRESH')=='true':args+=['--refresh']
if os.environ.get('WITH_PEDIGREE')=='true':args+=['--with-pedigree']
raise SystemExit(main(args))
