
from __future__ import annotations
import argparse, json, uuid
from datetime import datetime, timezone
from pathlib import Path

from cph_jra_df.pipeline import Pipeline
from cph_jra_df.seed_discovery import SeedDiscovery

def now():
    return datetime.now(timezone.utc).isoformat(timespec="microseconds")

def cache_miss(exc: Exception) -> bool:
    return "CACHE_MISS" in str(exc)

def recover_seed(pipe: Pipeline, race_date: str) -> tuple[str, str]:
    # Missing seed means the original month run stopped before result_seed_urls
    # was populated.  Repair ONLY this unfinished date.
    discovery = SeedDiscovery(pipe)
    try:
        result = discovery.discover(race_date, cache_only=True)
        return result["seed_url"], "SEED_CACHE_ONLY"
    except Exception as exc:
        if not cache_miss(exc):
            # A missing result_seed_urls row may still have incomplete cache
            # from the original fetch failure.  For an unfinished date only,
            # permit one online seed discovery attempt rather than treating
            # SEED_MISSING as unrecoverable.
            pass
    result = discovery.discover(race_date, cache_only=False)
    return result["seed_url"], "SEED_ONLINE"

def main() -> int:
    p=argparse.ArgumentParser()
    p.add_argument("--data-root", required=True)
    p.add_argument("--year", type=int, default=2018)
    a=p.parse_args()

    pipe=Pipeline(Path(a.data_root).resolve(), workers=1)
    try:
        days=pipe.conn.execute(
            "SELECT d.race_date,u.seed_url "
            "FROM year_race_days d "
            "LEFT JOIN result_seed_urls u ON u.race_date=d.race_date "
            "WHERE substr(d.race_date,1,4)=? ORDER BY d.race_date",
            (str(a.year),),
        ).fetchall()

        reused=[]
        repaired=[]
        failures=[]

        for row in days:
            race_date=row["race_date"]
            seed_url=row["seed_url"]

            # Never rewrite an already-good day.
            passed=pipe.conn.execute(
                "SELECT 1 FROM pipeline_runs WHERE race_date=? AND status='PASS' "
                "AND stage='AUDIT' AND mode IN ('ONLINE','CACHE_ONLY') LIMIT 1",
                (race_date,),
            ).fetchone()
            if passed:
                reused.append(race_date)
                continue

            seed_via="EXISTING_SEED"
            if not seed_url:
                try:
                    seed_url, seed_via = recover_seed(pipe, race_date)
                except Exception as exc:
                    failures.append({
                        "date": race_date,
                        "phase": "SEED_RECOVERY",
                        "error": str(exc),
                    })
                    continue

            # First prove from cache if possible.
            try:
                r=pipe.run(race_date,seed_url,cache_only=True)
                if r.get("status")!="PASS":
                    raise RuntimeError(f"CACHE_STATUS:{r.get('status')}")
                repaired.append({
                    "date":race_date,
                    "seed_via":seed_via,
                    "data_via":"CACHE_ONLY",
                })
                continue
            except Exception as exc:
                if not cache_miss(exc):
                    failures.append({
                        "date":race_date,
                        "phase":"CACHE_ONLY",
                        "seed_via":seed_via,
                        "error":str(exc),
                    })
                    continue

            # Only a genuine cache miss may use online data retrieval.
            try:
                r=pipe.run(race_date,seed_url,cache_only=False)
                if r.get("status")!="PASS":
                    raise RuntimeError(f"ONLINE_STATUS:{r.get('status')}")
                proof=pipe.run(race_date,seed_url,cache_only=True)
                if proof.get("status")!="PASS":
                    raise RuntimeError(f"CACHE_PROOF:{proof.get('status')}")
                repaired.append({
                    "date":race_date,
                    "seed_via":seed_via,
                    "data_via":"ONLINE_THEN_CACHE",
                })
            except Exception as exc:
                failures.append({
                    "date":race_date,
                    "phase":"ONLINE_FILL_OR_CACHE_PROOF",
                    "seed_via":seed_via,
                    "error":str(exc),
                })

        if failures:
            print(json.dumps({
                "status":"FAIL",
                "reused":len(reused),
                "repaired":repaired,
                "failures":failures,
            },ensure_ascii=False,indent=2))
            return 1

        # Full no-network proof after repairing the two failed dates.
        reparse_pass=0
        reparse_failures=[]
        for row in days:
            try:
                r=pipe.reparse(row["race_date"])
                if r.get("status")=="PASS":
                    reparse_pass+=1
                else:
                    reparse_failures.append({
                        "date":row["race_date"],"result":r
                    })
            except Exception as exc:
                reparse_failures.append({
                    "date":row["race_date"],"error":str(exc)
                })

        if reparse_pass!=len(days) or reparse_failures:
            print(json.dumps({
                "status":"FAIL",
                "reparse_pass":reparse_pass,
                "reparse_failures":reparse_failures,
            },ensure_ascii=False,indent=2))
            return 1

        # Preserve historical FAIL/PARTIAL plans; append PASS evidence only for
        # months that do not already have a PASS collection.
        manifest=pipe.conn.execute(
            "SELECT manifest_id FROM year_schedule_manifests WHERE year=?",
            (a.year,),
        ).fetchone()
        if manifest is None:
            raise SystemExit("YEAR_MANIFEST_MISSING")

        stamp=now()
        added=[]
        for month in range(1,13):
            if pipe.conn.execute(
                "SELECT 1 FROM month_collection_runs "
                "WHERE year=? AND month=? AND status='PASS' LIMIT 1",
                (a.year,month),
            ).fetchone():
                continue

            dates=[r[0] for r in pipe.conn.execute(
                "SELECT race_date FROM year_race_days "
                "WHERE race_date LIKE ? ORDER BY race_date",
                (f"{a.year}-{month:02d}-%",),
            ).fetchall()]
            plan=f"MONTH-RECOVERY-{a.year}-{month:02d}-{uuid.uuid4().hex[:10]}"
            pipe.conn.execute(
                "INSERT INTO month_collection_runs"
                "(plan_id,year,month,year_manifest_id,created_at,updated_at,status,expected_dates)"
                " VALUES(?,?,?,?,?,?,?,?)",
                (plan,a.year,month,manifest["manifest_id"],
                 stamp,stamp,"PASS",len(dates)),
            )
            for i,d in enumerate(dates,1):
                run=pipe.conn.execute(
                    "SELECT run_id FROM pipeline_runs "
                    "WHERE race_date=? AND status='PASS' "
                    "AND mode IN ('ONLINE','CACHE_ONLY') "
                    "ORDER BY completed_at DESC LIMIT 1",
                    (d,),
                ).fetchone()
                if run is None:
                    raise SystemExit(f"PASS_EVIDENCE_MISSING:{d}")
                pipe.conn.execute(
                    "INSERT INTO month_collection_items"
                    "(plan_id,race_date,ordinal,status,phase,attempts,pipeline_run_id,"
                    "started_at,completed_at,reason_codes_json)"
                    " VALUES(?,?,?,?,?,?,?,?,?,?)",
                    (plan,d,i,"PASS","AUDIT",1,run["run_id"],
                     stamp,stamp,"[]"),
                )
            added.append(month)
        pipe.conn.commit()

        print(json.dumps({
            "status":"PASS",
            "race_days":len(days),
            "reused":len(reused),
            "repaired":repaired,
            "reparse_pass":reparse_pass,
            "recovery_month_pass_added":added,
            "history_policy":"past FAIL/PARTIAL rows retained",
        },ensure_ascii=False,indent=2))
        return 0
    finally:
        pipe.close()

if __name__=="__main__":
    raise SystemExit(main())
