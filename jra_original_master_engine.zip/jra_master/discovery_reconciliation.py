"""Resolve deferred discovery tasks only after a verified covering collection."""
import datetime
import json
import re

from .store import encode, now

KEY = re.compile(r'DISCOVER_(\d{4})_(\d{2})_(\d{4}-\d{2}-\d{2})_(\d{4}-\d{2}-\d{2})')


def reconcile_discovery_tasks(connection, year):
    tasks = connection.execute(
        'SELECT task_key,status,updated_at,message FROM tasks'
    ).fetchall()
    statuses = {row[0]: row[1] for row in tasks}
    candidates = []
    for row in tasks:
        match = KEY.fullmatch(row[0])
        if not match or int(match[1]) != year:
            continue
        try:
            start = datetime.date.fromisoformat(match[3])
            end = datetime.date.fromisoformat(match[4])
        except ValueError:
            continue
        if start > end:
            continue
        candidates.append((row, match[2], start, end))

    def links(task_key):
        record = connection.execute(
            'SELECT value FROM metadata WHERE key=?', ('links_' + task_key,)
        ).fetchone()
        try:
            value = json.loads(record[0]) if record else None
        except (ValueError, TypeError):
            return None
        if not isinstance(value, list) or not value or not all(isinstance(x, str) and x for x in value):
            return None
        return set(value)

    resolved = []
    for old, month, start, end in candidates:
        if old[1] != 'DEFERRED':
            continue
        old_links = links(old[0])
        for replacement, other_month, other_start, other_end in candidates:
            if (replacement[1] != 'PASS' or other_month != month
                    or other_start > start or other_end < end
                    or not old[2] or not replacement[2] or replacement[2] <= old[2]):
                continue
            verified_links = links(replacement[0])
            if (not verified_links or (old_links and not old_links.issubset(verified_links))
                    or any(statuses.get('RACE_' + link) != 'PASS' for link in verified_links)):
                continue
            evidence = dict(previous_task=dict(zip(
                ['task_key', 'status', 'updated_at', 'message'], old)),
                covering_task=replacement[0], verified_race_tasks=len(verified_links),
                reconciled_at=now())
            with connection:
                connection.execute('INSERT OR REPLACE INTO metadata VALUES (?,?)',
                    ('discovery_reconciliation:' + old[0], encode(evidence)))
                connection.execute('UPDATE tasks SET status=?,updated_at=?,message=? WHERE task_key=?',
                    ('PASS', evidence['reconciled_at'],
                     'SUPERSEDED_BY_VERIFIED_DISCOVERY:' + replacement[0], old[0]))
            resolved.append(evidence)
            break
    return resolved
