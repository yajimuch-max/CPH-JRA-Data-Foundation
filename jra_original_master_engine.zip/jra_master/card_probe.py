"""Read-only capture of observed official card links; never run predictions."""
from pathlib import Path
import re,gzip,json
from .racing import form
from .jra_parser import decode_jra,compact_text
from .store import sha,now
from bs4 import BeautifulSoup
URL='https://www.jra.go.jp/JRADB/accessD.html'
# Observed in the supplied official search-entry HTML navigation.
ENTRY='pw01dli00/F3'
def observed_card_links(body):
 return sorted(set(re.findall(r'(pw01(?:drl|dde)[^\s\"\x27)<>]+)',decode_jra(body))))
def probe(client,year,output,limit=16):
 out=Path(output);out.mkdir(parents=True,exist_ok=True)
 report={'diagnostic_only':True,'probe_kind':'OFFICIAL_CARD_HTML_CAPTURE','year':year,'started_at':now(),'existing_MASTER_changed':False,'pedigree_fetched':False,'odds_fetched':False,'predictions_run':False,'live_pre_race_capability_verified':False,'pages':[],'errors':[],'unparsed_links':[]}
 queue=[(ENTRY,0)];seen=set()
 try:
  while queue and len(seen)<limit:
   cname,depth=queue.pop(0)
   if cname in seen:continue
   seen.add(cname)
   try:
    body,sid,path=client.request(URL,'CARD_PROBE',form(cname));number=len(report['pages']);name=f'{number:03d}_card_page.bin.gz';(out/name).write_bytes(gzip.compress(body,mtime=0));soup=BeautifulSoup(decode_jra(body),'lxml');title=compact_text(soup.title) if soup.title else '';links=observed_card_links(body)
    src=client.s.c.execute('select * from source_records where source_id=?',(sid,)).fetchone()
    item={'file':name,'request_cname':cname,'depth':depth,'entity_bytes':len(body),'entity_sha256':sha(body),'title':title,'observed_child_links':links,'requested_at':src['requested_at'] if src else None,'responded_at':src['responded_at'] if src else None,'http_status':src['http_status'] if src else None,'race_card_candidate':cname.startswith('pw01dde') and '出馬表' in title,'source_url':URL}
    report['pages'].append(item);client.valid(sid,path)
    if 'パラメータエラー' in title:report['errors'].append(cname+': JRA_PARAMETER_ERROR_PAGE');continue
    if depth<2:
     for link in links:
      dates=re.findall(r'(\d{8})/[0-9A-F]{2}$',link)
      if dates and dates[0][:4]!=str(year):continue
      if link not in seen and (link,depth+1) not in queue:queue.append((link,depth+1))
   except Exception as exc:report['errors'].append(cname+': '+type(exc).__name__+': '+str(exc))
 except Exception as exc:report['errors'].append(type(exc).__name__+': '+str(exc))
 finally:
  report['completed_at']=now();report['race_card_candidates']=sum(p['race_card_candidate'] for p in report['pages']);report['remaining_links']=len(queue);report['request_limit']=limit
  report['status']='CAPTURE_ERROR' if report['errors'] else 'CARD_HTML_CAPTURED_NOT_VALIDATED' if report['race_card_candidates'] else 'NO_RACE_CARD_CAPTURED'
  (out/'SUMMARY.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
 return report
