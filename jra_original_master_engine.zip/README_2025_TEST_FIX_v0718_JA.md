# v0.7.1.8：2025年オフライン自己検査の停止を修正

スクリーンショットのエラー：`tests/test_2025_modern_archive_v0717.py` が `pytest` を import していたため、GitHubの `unittest discover` で `ModuleNotFoundError: No module named pytest` が発生。

## 修正
- 2025年新規テスト8件を `unittest` に置き換え、pytestがなくても全件実行できるよう変更
- テスト依存の再混入を防ぐガード1件追加
- 本体はバージョン表記以外変更なし（PDF解析・差分更新・馬名照合・state復元はv0.7.1.7を維持）
- YML/requirements変更なし。既存stateを使い `year=2025, mode=update, with_track=true, with_official=true, refresh=false, reset_from_release=false, resume_run_id=空欄` を再実行

## 結果の確認
- `オフライン自己検査` PASS
- `前回stateを自動復元` PASS
- 馬場PDF36本PASS、馬場288開催単位の不足0
- `CERTIFIED` はGitHub上でこれらが通った後に判定する

## 注意
この修正の検証はローカルのunittest。JRA公式PDF36本のGitHub実取得は未検証。
