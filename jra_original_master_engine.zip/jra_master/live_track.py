"""Strict JRA race-day track observation capture (2026+).

Source: current https://www.jra.go.jp/keiba/baba/ pages only. A captured
HTML response is NOT a historical archive or proof of its publication time.
Never infer absent cushion numbers from the 12/10/8/7 reference gauge.
"""
from __future__ import annotations
import datetime as dt
import hashlib
import json
import re
import sqlite3
from pathlib import Path
from zoneinfo import ZoneInfo
from bs4 import BeautifulSoup

JST = ZoneInfo('Asia/Tokyo')
URLS = tuple('https://www.jra.go.jp/keiba/baba/' + x for x in ('','index2.html','index3.html'))
TRACKS = {'札幌','函館','福島','新潟','東京','中山','中京','京都','阪神','小倉'}
NUM = re.compile(r'^\d{1,2}(?:\.\d+)?$')
DATE_HEAD = re.compile(r'第\s*\d+\s*回\s*(?P<track>札幌|函館|福島|新潟|東京|中山|中京|京都|阪神|小倉)\s*競馬\s*第\s*\d+\s*日(?P<eve>前日)?\s*[（(]\s*(?P<year>20\d\d)\s*年\s*(?P<month>\d{1,2})\s*月\s*(?P<day>\d{1,2})\s*日\s*[（(](?P<weekday>[月火水木金土日])曜')
VALUES = ('turf_cushion','turf_goal_moisture','turf_4c_moisture','dirt_goal_moisture','dirt_4c_moisture')


def _normalize(value):
    import unicodedata
    return re.sub(r'\s+','',unicodedata.normalize('NFKC',str(value or '')))


def _measures(page):
    """Only use JRA table with explicitly labelled two-row measurements."""
    markers=page.find_all(string=re.compile('ゴール前と4コーナーの含水率'))
    if len(markers)!=1:
        return None
    t=markers[0].find_next('table')
    if t is None:return None
    head=_normalize(t.get_text(' ',strip=True))
    if 'ゴール前' not in head or '4コーナー' not in head:return None
    rows={}
    for tr in t.select('tr'):
        cells=[_normalize(cell.get_text(' ',strip=True)) for cell in tr.find_all(['th','td'])]
        if len(cells)!=3 or cells[0] not in ('芝','ダート') or cells[0] in rows:continue
        if not all(NUM.fullmatch(v) for v in cells[1:]):continue
        vals=[float(v) for v in cells[1:]]
        if not all(0<=v<=60 for v in vals):continue
        rows[cells[0]]=vals
    if set(rows)!={'芝','ダート'}:return None
    return {'turf_goal_moisture':rows['芝'][0], 'turf_4c_moisture':rows['芝'][1],
            'dirt_goal_moisture':rows['ダート'][0], 'dirt_4c_moisture':rows['ダート'][1]}


def _cushion(page):
    """Find an *explicit* measured decimal, never JRA's integer gauge labels.

    The published page may render the actual value in a script/canvas. If the
    semantic HTML does not unambiguously expose it, preserve PARTIAL status.
    """
    title=page.find(string=lambda t: t is not None and _normalize(t)=='クッション値')
    if title is None:return None
    # Only the measurement block prior to the printed 12/10/8/7 reference gauge.
    parent=title.parent
    following=[]
    for element in parent.next_elements:
        if element is parent:continue
        if getattr(element,'name',None) in ('h2','h3'):break
        if getattr(element,'name',None) in ('script','style'):continue
        if isinstance(element,str):
            raw=_normalize(element)
            if any(stop in raw for stop in ('クッション値とクッション性','芝馬場のクッション値')):break
            if NUM.fullmatch(raw) and '.' in raw:
                n=float(raw)
                if 3<=n<=20:following.append(n)
            if raw=='12' and not following:break
        if len(following)>1:break
    return following[0] if len(following)==1 else None


def parse_live_html(body: bytes, url: str, target_date: str):
    """Return exact-date observation or None. No 'Friday for Sunday' leakage."""
    if url not in URLS:raise ValueError('Non-JRA or non-allowlisted page')
    doc=BeautifulSoup(body,'html.parser')
    heads=[_normalize(h.get_text(' ',strip=True)) for h in doc.find_all(['h1','h2','h3'])]
    matches=[m for text in heads for m in [DATE_HEAD.search(text)] if m]
    if len(matches)!=1:return None
    m=matches[0]
    if m['eve']:return None
    try:day=dt.date(int(m['year']),int(m['month']),int(m['day'])).isoformat()
    except ValueError:return None
    if day!=target_date or m['track'] not in TRACKS:return None
    if '月火水木金土日'[dt.date.fromisoformat(day).weekday()]!=m['weekday']:
        return None
    metrics=_measures(doc)
    if metrics is None:return {'date':day,'track':m['track'],'metrics':{},'status':'UNVERIFIED_HTML_LAYOUT'}
    metrics['turf_cushion']=_cushion(doc)
    return {'date':day,'track':m['track'],'metrics':metrics,
            'status':'COMPLETE' if all(metrics.get(x) is not None for x in VALUES) else 'PARTIAL_VALUES'}


def _store_snapshot(c, record, source_url, digest, fetched_at, requested_at):
    key='JRA_LIVE_TRACK:'+record['date']+':'+record['track']+':'+digest
    evidence={'date':record['date'],'track':record['track'],'url':source_url,
              'sha256':digest,'requested_at':requested_at,'fetched_at':fetched_at,
              'metrics':record['metrics'],
              'status':record['status'],'actual_published_at':None,
              'notice':'Actual publication time unknown; fetched_at is observation time, not publication time.'}
    c.execute('''INSERT OR IGNORE INTO supplemental_records
        (table_name,item_key,race_id,horse_id,payload_json) VALUES(?,?,?,?,?)''',
        ('official_track_live_snapshots',key,None,None,json.dumps(evidence,ensure_ascii=False,sort_keys=True)))
    if record['status'] not in ('COMPLETE','PARTIAL_VALUES'):
        return 'SNAPSHOT_ONLY'
    if not all(record['metrics'].get(k) is not None for k in VALUES[1:]):
        return 'SNAPSHOT_ONLY'
    # Do not overwrite already PDF-reconciled values with transient live HTML.
    old=c.execute('''SELECT source_url,source_sha256,source_basis,
       turf_cushion,turf_goal_moisture,turf_4c_moisture,dirt_goal_moisture,dirt_4c_moisture
       FROM official_track_daily WHERE race_date=? AND track=?''',(record['date'],record['track'])).fetchone()
    if old and old[2]!='JRA_OFFICIAL_LIVE_HTML':return 'ARCHIVE_ALREADY_VERIFIED'
    fields=[record['metrics'][k] for k in VALUES]
    if old:
        if old[1]==digest:return 'UNCHANGED'
        before=old[3:]
        if tuple(before)!=tuple(fields):
            c.execute('''INSERT INTO official_track_revisions
                 (race_date,track,before_json,after_json,previous_sha256,new_sha256,observed_at)
                 VALUES(?,?,?,?,?,?,?)''',
                 (record['date'],record['track'],json.dumps(list(before)),json.dumps(fields),old[1],digest,fetched_at))
    cols=('race_date','track','source_url','source_sha256','source_page','archive_format',
          'used_turf_course','cushion_measured_time','turf_cushion','moisture_measured_time',
          'turf_goal_moisture','turf_4c_moisture','dirt_goal_moisture','dirt_4c_moisture',
          'actual_published_at','planned_publication_time','source_basis','timing_status')
    val=(record['date'],record['track'],source_url,digest,0,'LIVE_HTML',None,None,
         fields[0],None,fields[1],fields[2],fields[3],fields[4],
         None,'09:30_APPROX','JRA_OFFICIAL_LIVE_HTML','OBSERVED_AT_FETCH_NOT_PROVEN_PUBLISHED_AT')
    c.execute('''INSERT INTO official_track_daily ('''+','.join(cols)+''') VALUES ('''+','.join('?' for _ in cols)+''')
              ON CONFLICT(race_date,track) DO UPDATE SET '''+
              ','.join(f'{k}=excluded.{k}' for k in cols[2:]),val)
    return 'LIVE_RECORDED' if record['status']=='COMPLETE' else 'LIVE_PARTIAL_RECORDED'


def capture_live(year, db_path, output='delivery', *, day=None, now=None, session=None, urls=URLS):
    """Capture ONLY current Japan-local race day, after 09:30 JST.

    Testable with deterministic injected HTTP session and clock. Errors remain
    explicit; never reconstruct previous days from the current rotating page.
    """
    injected_clock=now is not None
    now=now or dt.datetime.now(JST)
    if now.tzinfo is None:raise ValueError('aware clock required')
    now=now.astimezone(JST)
    today=now.date().isoformat()
    day=day or today
    if day!=today:raise ValueError('Historical live observation prohibited')
    if int(day[:4])!=year:raise ValueError('State year differs from live date')
    if (now.hour,now.minute)<(9,30):
        return {'status':'TOO_EARLY','day':day,'records':[]}
    import requests
    from .track_enrichment import schema
    s=session or requests.Session()
    if session is None:s.headers['User-Agent']='Mozilla/5.0 (compatible; JRA research provenance capture)'
    db_path=Path(db_path)
    if not db_path.is_file():raise FileNotFoundError('Existing state required; no implicit bootstrap')
    saved=[];errors=[]
    with sqlite3.connect(db_path) as c:
        schema(c)
        if not {'supplemental_records','races'}.issubset({r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}):
            raise ValueError('Expected existing JRA master state')
        for url in urls:
            try:
                if url not in URLS:raise ValueError('Invalid JRA live URL')
                requested_at=now.isoformat() if injected_clock else dt.datetime.now(JST).isoformat()
                response=s.get(url,timeout=35)
                response.raise_for_status()
                fetched_at=now.isoformat() if injected_clock else dt.datetime.now(JST).isoformat()
                payload=response.content
                if not isinstance(payload,bytes) or not payload.lstrip().startswith(b'<'):
                    raise ValueError('Expected HTML from JRA')
                data=parse_live_html(payload,url,day)
                if data is None:
                    saved.append({'url':url,'status':'NO_SAME_DAY_RACE_PAGE'});continue
                digest=hashlib.sha256(payload).hexdigest()
                with c:result=_store_snapshot(c,data,url,digest,fetched_at,requested_at)
                saved.append({'url':url,'track':data['track'],'day':day,'status':result,
                              'parse_status':data['status'],'requested_at':requested_at,
                              'fetched_at':fetched_at,'source_sha256':digest})
            except Exception as e:
                errors.append({'url':url,'error':f'{type(e).__name__}: {e}'})
    status='LIVE_CAPTURED' if any(x['status'] in ('LIVE_RECORDED','UNCHANGED','ARCHIVE_ALREADY_VERIFIED') for x in saved) else 'PARTIAL'
    report={'status':status,'year':year,'day':day,'fetched_at':now.isoformat(),
            'records':saved,'errors':errors,
            'publication_time_verified':False,'post_event_pdf_verified':False}
    out=Path(output);out.mkdir(parents=True,exist_ok=True)
    (out/f'live_track_audit_{year}_{day}.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    return report
