from __future__ import annotations

from collections import Counter

from .model import ParsedRace, ScheduleRace, ValidationIssue


def validate_manifest(races: list[ScheduleRace]) -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []
    flat = [r for r in races if r.is_flat]
    if not flat:
        issues.append(ValidationIssue("NO_FLAT_RACES", "ERROR", "Schedule Manifestに平地競走がありません"))
    keys = [r.race_key for r in races]
    if len(keys) != len(set(keys)):
        issues.append(ValidationIssue("DUPLICATE_SCHEDULE_RACE", "ERROR", "Schedule Manifestのrace_keyが重複しています"))
    by_track: dict[str, list[int]] = {}
    for race in races:
        by_track.setdefault(race.track, []).append(race.race_no)
    for track, numbers in by_track.items():
        if numbers != sorted(numbers) or len(numbers) != len(set(numbers)):
            issues.append(ValidationIssue("RACE_NUMBER_SET_INVALID", "ERROR", f"{track}のRace番号集合が不正です"))
    return issues


def schedule_order_change_keys(schedules: dict[str, ScheduleRace],
                               parsed: dict[str, ParsedRace]) -> set[str]:
    """Detect an exact, same-track permutation of programme race conditions."""
    by_track: dict[str, list[str]] = {}
    for key, schedule in schedules.items():
        actual = parsed.get(key)
        if actual is not None and (schedule.surface != actual.surface or
                                   schedule.distance_m != actual.distance_m):
            by_track.setdefault(schedule.track, []).append(key)
    allowed: set[str] = set()
    for keys in by_track.values():
        if len(keys) < 2:
            continue
        # Historical programme and result pages can spell the race name
        # differently.  Race identity is already fixed by date/track/number,
        # so only accept an exact same-track permutation of the objective
        # surface/distance conditions.
        programme = Counter((schedules[k].surface, schedules[k].distance_m)
                            for k in keys)
        actual = Counter((parsed[k].surface, parsed[k].distance_m)
                         for k in keys)
        if programme == actual:
            allowed.update(keys)
    return allowed


def validate_race(schedule: ScheduleRace, parsed: ParsedRace,
                  schedule_order_changed: bool = False) -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []
    key = schedule.race_key
    checks = [(parsed.race_key == key, "RACE_KEY_MISMATCH",
               f"expected={key} actual={parsed.race_key}"),
              (len(parsed.entries) == len(parsed.results), "ENTRY_RESULT_COUNT_MISMATCH",
               "entry/result数が一致しません")]
    if schedule_order_changed:
        issues.append(ValidationIssue(
            "SCHEDULE_ACTUAL_RACE_ORDER_CHANGED", "INFO",
            f"programme={schedule.race_name}/{schedule.surface}/{schedule.distance_m} "
            f"official_result={parsed.race_name}/{parsed.surface}/{parsed.distance_m}", key))
    else:
        checks.extend([
            (parsed.surface == schedule.surface, "SURFACE_MISMATCH",
             f"expected={schedule.surface} actual={parsed.surface}"),
            (parsed.distance_m == schedule.distance_m, "DISTANCE_MISMATCH",
             f"expected={schedule.distance_m} actual={parsed.distance_m}"),
        ])
    for passed, code, message in checks:
        if not passed:
            issues.append(ValidationIssue(code, "ERROR", message, key))
    if parsed.post_time != schedule.post_time:
        # The calendar explicitly describes times as advance programme data. The official
        # result page is authoritative for the actual post time; retain the discrepancy.
        issues.append(ValidationIssue("SCHEDULE_ACTUAL_POST_TIME_CHANGED", "INFO",
                                      f"programme={schedule.post_time} official_result={parsed.post_time}", key))
    horse_nos = [e.horse_no for e in parsed.entries]
    horse_ids = [e.horse_id for e in parsed.entries]
    result_nos = [r.horse_no for r in parsed.results]
    if len(horse_nos) != len(set(horse_nos)):
        issues.append(ValidationIssue("DUPLICATE_HORSE_NO", "ERROR", "馬番が重複しています", key))
    if len(horse_ids) != len(set(horse_ids)):
        issues.append(ValidationIssue("DUPLICATE_HORSE_ID", "ERROR", "horse_idが重複しています", key))
    if set(horse_nos) != set(result_nos):
        issues.append(ValidationIssue("RESULT_MAPPING_MISMATCH", "ERROR", "全頭結果対応に失敗しました", key))
    allowed_statuses = {"FINISHED", "取消", "除外", "中止"}
    for result in parsed.results:
        if result.finish_status not in allowed_statuses:
            issues.append(ValidationIssue("FINISH_STATUS_UNKNOWN", "ERROR",
                                          f"horse_no={result.horse_no} status={result.finish_status}", key))
        if result.finish_status == "FINISHED" and result.finish_position is None:
            issues.append(ValidationIssue("FINISHED_POSITION_MISSING", "ERROR",
                                          f"horse_no={result.horse_no}", key))
        if result.finish_status != "FINISHED" and result.finish_position is not None:
            issues.append(ValidationIssue("NON_FINISH_POSITION_PRESENT", "ERROR",
                                          f"horse_no={result.horse_no} status={result.finish_status}", key))
    finished = [r for r in parsed.results if r.finish_status == "FINISHED"]
    by_position: dict[int, list] = {}
    for result in finished:
        if result.finish_position is not None:
            by_position.setdefault(result.finish_position, []).append(result)
    expected_position = 1
    for position in sorted(by_position):
        group = by_position[position]
        if position != expected_position:
            issues.append(ValidationIssue("FINISH_POSITION_SEQUENCE_INVALID", "ERROR",
                                          f"expected={expected_position} actual={position}", key))
        if len(group) > 1:
            times = {r.finish_time for r in group}
            if len(times) != 1 or None in times:
                issues.append(ValidationIssue("DEAD_HEAT_TIME_MISMATCH", "ERROR",
                                              f"position={position}", key))
            if not any(r.margin == "同着" for r in group):
                issues.append(ValidationIssue("DEAD_HEAT_MARKER_MISSING", "ERROR",
                                              f"position={position}", key))
        expected_position = position + len(group)
    for entry in parsed.entries:
        if entry.body_weight_kg is None:
            issues.append(ValidationIssue("BODY_WEIGHT_EXPECTED_NULL", "INFO", "公式結果表に馬体重数値がありません", key))
        if entry.jockey_id is None:
            issues.append(ValidationIssue("JOCKEY_ID_EXPECTED_NULL", "INFO", "騎手IDが取得できません", key))
    return issues
