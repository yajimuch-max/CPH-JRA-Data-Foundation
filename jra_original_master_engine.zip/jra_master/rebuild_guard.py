"""Prevent stale-cache reuse and training on incomplete or future source data."""
import json,hashlib
from pathlib import Path
from .person_identity import VERSION as PERSON_VERSION

def fingerprint(source_hashes,person_catalogue_sha256,feature_spec_sha256,columns,recipe,boundaries):
 data=dict(source_hashes=sorted(source_hashes),person_catalogue_sha256=person_catalogue_sha256,person_protocol=PERSON_VERSION,feature_spec_sha256=feature_spec_sha256,columns=list(columns),recipe=recipe,boundaries=boundaries)
 return hashlib.sha256(json.dumps(data,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()

def require_ready(audit,model_year,boundaries):
 expected=dict(selection_fit_end=model_year-3,selection_year=model_year-2,fit_end=model_year-2,calibration_year=model_year-1)
 if boundaries!=expected:raise ValueError('INVALID_ANNUAL_BOUNDARIES')
 if not audit.get('raw_history_ready') or any(audit.get('remaining_active_unresolved_people',{}).values()):raise ValueError('INCOMPLETE_PERSON_HISTORY')
 if not audit.get('causal_features_ready') or audit.get('person_protocol')!=PERSON_VERSION:raise ValueError('CAUSAL_PERSON_FEATURES_NOT_REBUILT')
 if not audit.get('training_run_permitted'):raise ValueError('TRAINING_NOT_ADMITTED')
 years=audit.get('source_years',[])
 if not years or max(years)>=model_year:raise ValueError('FUTURE_SELECTION_DATA')
 if not set(range(2010,model_year)).issubset(years):raise ValueError('INCOMPLETE_SOURCE_YEARS')
 return True

def validate_feature_times(frame,max_target_year):
 import datetime
 rows=frame.to_dict('records') if hasattr(frame,'to_dict') else frame
 for row in rows:
  try:
   target=datetime.date.fromisoformat(str(row['race_date'])[:10]);cut=datetime.date.fromisoformat(str(row['history_cutoff'])[:10])
  except (ValueError,KeyError,TypeError):raise ValueError('NONCAUSAL_HISTORY_CUTOFF')
  if cut>=target:raise ValueError('NONCAUSAL_HISTORY_CUTOFF')
  if target.year>max_target_year:raise ValueError('FUTURE_TARGET_ROWS')

def reusable_cache(path,expected_input_fingerprint):
 path=Path(path);meta=path.with_suffix(path.suffix+'.inputs.json')
 if not path.exists() or not meta.exists():return False
 data=json.loads(meta.read_text())
 if data.get('input_fingerprint')!=expected_input_fingerprint:return False
 return data.get('artifact_sha256')==hashlib.sha256(path.read_bytes()).hexdigest()
