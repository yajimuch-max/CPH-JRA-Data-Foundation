"""JRA official all-in-one incremental runner (2021-23 unknown-progress safe).

No limits on ZIP byte size. Never edits the source release. Native state remains
checkpointable even when individual stages are incomplete.
"""
from __future__ import annotations
import datetime as dt
import hashlib
import json
import time
import sqlite3
import tempfile
import zipfile
from pathlib import Path

VERSION='JRA_MASTER_HTML_UNIFIED_v0.7.1.8'
CORE=('races','horses','runners','results','win_odds','payouts','laps','corners','pedigree', 'pedigree_receipts')

def _counts(c, tables):
    known={r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    return {t:c.execute(f'SELECT COUNT(*) FROM {t}').fetchone()[0] if t in known else None for t in tables}

def _meta(c, key):
    row=c.execute('SELECT value FROM metadata WHERE key=?',(key,)).fetchone()
    if not row:return None
    try:return json.loads(row[0])
    except (ValueError,TypeError):return row[0]

def final_export(year,db,output,stages):
    # Clean, read-friendly, update-compatible export; stage remains resumable.
    from .unified_export import export_master
    return export_master(year,db,output,stages)

def _documented_2010_limit_only(year, db, audit, stages):
    """Mark a run done only if 2010's unsupported fields are the ONLY gap.

    The independent annual data audit stays PARTIAL. We never hide an incomplete
    download, an unverified course, or a core/SQLite integrity failure.
    """
    if year != 2010 or audit.get('status') != 'PARTIAL':
        return False
    if (stages.get('core',{}).get('status') != 'PASS' or
        stages.get('track',{}).get('status') != 'MERGED_WITH_OFFICIAL' or
        stages.get('official_expansion',{}).get('status') != 'PARTIAL' or
        stages.get('official_expansion',{}).get('exit_code') != 0):
        return False
    if (audit.get('sqlite_integrity') != 'ok' or audit.get('foreign_keys') or
        any(audit.get('runner_coverage_gaps',{}).values()) or
        audit.get('missing_pedigree_receipts',1) != 0 or
        any(k != 'PASS' for k in audit.get('task_status_counts',{})) or
        audit.get('issue_status_counts',{}).get('OPEN',0) != 0):
        return False
    report=audit.get('last_official_expansion_audit')
    if not isinstance(report,dict) or report.get('year') != 2010:
        return False
    total=report.get('pdf_index_count')
    if (not isinstance(total,int) or total <= 0 or
        report.get('pending_pdfs') != 0 or
        report.get('deferred_due_to_budget') != 0 or
        report.get('failed_this_run') != [] or
        report.get('receipt_status_counts') != {'PARTIAL':total} or
        report.get('2010_note') != '2010 official meeting PDF has a different structure; only validated meeting course is imported.'):
        return False
    try:
        with sqlite3.connect(db) as c:
            race_count=c.execute("SELECT COUNT(*) FROM races WHERE json_extract(payload_json,'$.surface')='芝'").fetchone()[0]
            verified=c.execute("""SELECT COUNT(*) FROM races r
                  JOIN official_legacy_race_values x ON x.race_id=r.race_id
                 WHERE json_extract(r.payload_json,'$.surface')='芝'
                   AND x.used_turf_course IN ('A','B','C','D')""").fetchone()[0]
            receipt_count=c.execute("SELECT COUNT(*) FROM official_expansion_receipts WHERE year=2010 AND status='PARTIAL'").fetchone()[0]
        return bool(race_count and verified == race_count and receipt_count == total)
    except (sqlite3.DatabaseError,OSError):
        return False

def run_full_update(*,year,db,output,core_args,core_main,with_track=True,with_official=True,refresh=False):
    """Checkpointed three-stage update. Core -> moisture PDFs -> verified result HTML.

    Historical PDF course/runner parsing is deliberately NOT retried in update:
    its older mixed-column extractor has known unsafe results for 2011-2013.
    Existing values remain in provenance-only legacy tables until audited.
    """
    started_at=time.monotonic()
    stages={};has_error=False
    try:
        result=core_main(core_args)
        stages['core']={'status':'PASS' if result==0 else 'PARTIAL','exit_code':result}
        if result not in (0,2):
            stages['core']['status']='ERROR';has_error=True
    except Exception as e:
        stages['core']={'status':'ERROR','reason':str(e)[:300]};has_error=True
    if not has_error and with_track and year>=2018:
        from .track_action import run_track
        try:
            x=run_track(year,db,output,refresh_all=refresh,budget_seconds=1500,export_master=False)
            report_path=Path(output)/f'track_audit_{year}.json'
            report=json.loads(report_path.read_text(encoding='utf-8')) if report_path.exists() else {}
            stages['track']={'status':report.get('status','PARTIAL'),'exit_code':x}
            if report.get('status')=='ERROR':has_error=True
        except Exception as e:
            stages['track']={'status':'ERROR','reason':str(e)[:300]};has_error=True
    elif with_track:
        stages['track']={'status':'NOT_PUBLISHED_BEFORE_2018' if year<2018 else 'DEFERRED'}
    if not has_error and with_official:
        from .html_first import run as html_run
        try:
            # Keep at least ~30 minutes before the GitHub 240-minute hard limit.
            # The HTML budget is SHARED with the earlier core/track stages.
            remaining_seconds=int(12600-(time.monotonic()-started_at))
            if remaining_seconds < 150:
                stages['official_html']={'status':'DEFERRED_FOR_SAFE_CHECKPOINT',
                    'reason':'Earlier stages consumed the safe execution window.'}
            else:
                html=html_run(year,db,output,budget_seconds=min(12000,remaining_seconds),
                    max_pages=int(__import__("os").environ.get("MAX_HTML_PAGES","4000")),refresh=refresh)
                stages['official_html']={'status':html['status'],
                     'verified':html['verified_html_races'],'remaining':html['remaining'],
                     'failed_receipts':html['failed_receipts']}
                if not html['known_official_html_urls'] or html.get('stopped_for_safety',False) or html['failed_this_run']>=100:
                    has_error=True;stages['official_html']['status']='ERROR'
        except Exception as e:
            stages['official_html']={'status':'ERROR','reason':str(e)[:300]};has_error=True
    if Path(db).exists():
        try:
            audit=final_export(year,db,output,stages)
            print('UPDATE_STAGES',json.dumps(stages,ensure_ascii=False),flush=True)
        except Exception as e:
            print('UNIFIED_EXPORT_FAILED',repr(e),flush=True);return 2
    else:return 2
    # A resumable PARTIAL caused by time budget is a warning, not a failed run.
    # Critical errors remain nonzero. AUDIT.json never calls it complete.
    return 2 if has_error else 0
