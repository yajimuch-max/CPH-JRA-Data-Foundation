"""Version 0.7 regressions for historical mixed turf/dirt result headers."""
import unittest
from unittest.mock import patch
from jra_master.html_first import surface_conditions,validated
from jra_master.model import ParsedRace,RaceEntry,RaceResult


def html(header):
    return f'''<html><div class="race_header">{header}</div>
    <div class="race_title">サラ系3歳 未勝利 （指定） 馬齢 コース：1,400メートル（ダート・左）</div>
    <table><thead><tr><th class="place">着順</th></tr></thead>
    <tbody><tr><td class="num">1</td><td class="horse">馬A</td><td class="place">1</td></tr></tbody></table>
    </html>'''.encode('cp932')

class JraSurfaceHeaderTests(unittest.TestCase):
    def test_separate_explicit_turf_and_dirt(self):
        b=html('<div class="turf"><span class="txt">良</span></div><div class="dirt"><span class="txt">不良</span></div>')
        self.assertEqual(surface_conditions(b),{'芝':'良','ダート':'不良'})
    def test_inline_result_header(self):
        self.assertEqual(surface_conditions(html('天候曇 芝稍重 ダート重'))['ダート'],'重')
    def test_img_alt_label(self):
        self.assertEqual(surface_conditions(html('<img alt="ダート"/> 稍重 <img alt="芝"/> 良'))['ダート'],'稍重')
    def test_conflict_is_rejected(self):
        with self.assertRaisesRegex(ValueError,'GOING_CONFLICT'):
            surface_conditions(html('芝良 ダート良 ダート不良'))
    def test_dirt_never_uses_turf_going(self):
        b=html('<div class="turf"><span class="txt">良</span></div>')
        parsed=ParsedRace('2010-01-05','中山','1回中山1日',1,'未勝利','ダート',1400,'ダート右','10:00','晴','良',None,
            [RaceEntry(1,1,'HORSE1','馬A','牡3',56,None,None,None,None,450,None)],
            [RaceResult(1,'FINISHED',1,'1:26.0',None,[],38.8)])
        known={'race':{'race_date':'2010-01-05','track':'中山','race_number':1,'race_type':'FLAT'},'surface':'ダート','distance_m':1400,'horses':{1:'HORSE1'}}
        with patch('jra_master.html_first.parse_result',return_value=parsed):
            with self.assertRaisesRegex(ValueError,'GOING_UNVERIFIED'):
                validated(b,'2010-01-05-中山-01',known)
    def test_dirt_only_dirt_used(self):
        b=html('天候晴 芝良 ダート重')
        parsed=ParsedRace('2010-01-05','中山','1回中山1日',1,'未勝利','ダート',1400,'ダート右','10:00','晴','良',None,
            [RaceEntry(1,1,'HORSE1','馬A','牡3',56,None,None,None,None,450,None)],
            [RaceResult(1,'FINISHED',1,'1:26.0',None,[],38.8)])
        known={'race':{'race_date':'2010-01-05','track':'中山','race_number':1,'race_type':'FLAT'},'surface':'ダート','distance_m':1400,'horses':{1:'HORSE1'}}
        with patch('jra_master.html_first.parse_result',return_value=parsed):
            self.assertEqual(validated(b,'2010-01-05-中山-01',known)['going'],'重')

if __name__=='__main__':unittest.main()
