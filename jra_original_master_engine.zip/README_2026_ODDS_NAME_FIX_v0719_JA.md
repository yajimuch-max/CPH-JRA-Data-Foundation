# 2026年10月4日までの差分更新 — v0.7.1.9

## 更新理由
- 2026年9月6日・阪神11R、馬番8、馬ID `2020190007` のJRA公式最終単勝オッズ画面で、正式馬名 `ファストネットワーク` の表示が `ファストネットワー` と短縮される。
- 2026年 state に保存された公式血統照合はPASS、horse_id・正式名・オッズ表示名の組が特定できている。
- v0.7.1.8はこの組み合わせを許可せず、`ODDS_HORSE_NAME_MISMATCH` としてFAILを記録した。

## 更新箇所
- `jra_master/racing.py` の厳密3点一致による特例リストに **該当する1頭の表示名のみ**追加。
- `jra_master/unified_export.py`, `jra_master/full_update.py` のエンジン表示を v0.7.1.9 に更新。
- テスト `tests/test_2026_odds_name_v0719.py` を追加。
- 出典・馬場PDF・データスキーマ・YML・リリース復元・差分取得ロジックは変更しない。

## 2026/10/04までの状態（アップロード2026年stateでの確認）
- レース2,658件、出走馬・結果・単勝オッズ36,706件ずつ。
- 公式HTML2,658/2,658 PASS（前回不足155件解消）。
- 現行スコープ `2026-01-01`〜`2026-10-04` の各月 DISCOVER はPASS、10月4日より後のレースなし。
- 馬場データ 218/222開催単位、10月3・4日の東京・京都の計4開催単位がまだ不足。JRAアーカイブに第4回東京・第4回京都PDFは、調査時に掲載を確認できず。公式データが出るまで作成・補完しない。
- 旧スコープ（10月10・11日まで）の TIME_BUDGET_CHECKPOINT が2件残る。今回の修正は削除・書換えしない。
- 年度途中であり、2026年正式原本のCERTIFIEDは今回確定しない。

## GitHub
リポジトリの固定名 `jra_original_master_engine.zip` を、このZIPで上書きする。
ワークフローYMLの変更は不要。既存 state を削除しない。

year = 2026
mode = update
start_date = 2026-01-01
end_date = 2026-10-04
months = 空欄
with_track = true
with_official = true
refresh = false
reset_from_release = false
resume_run_id = 空欄

上記の入力名が実際のGitHub Workflow UIと一致することを確認し、必要ならUI表記の大文字に合わせる。

## 検証範囲
- unittest 211件 PASS。
- 2026年stateをコピーしたオフライン模擬再投入では対象レース16頭を照合、同一投入を2回繰り返しても主要レコード件数変化なし。馬番8のodds payload表示名を変更する通常のrevision 1件が追加された。
- PDF実取得、JRA HTML実通信、GitHub Actions本番は未実施。公式PDF不足がある状態でCERTIFIEDを約束しない。
