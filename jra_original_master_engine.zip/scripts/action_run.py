import os,subprocess,json,tempfile,sqlite3
from jra_master.importer import Archive,bootstrap
from jra_master.store import Store
from pathlib import Path
from datetime import datetime,timezone,timedelta
from jra_master.cli import main
Y=int(os.environ['TARGET_YEAR']);mode=os.environ['MODE'];release=os.environ.get('BASE_RELEASE_TAG','');base=os.environ.get('BASE_ASSET_NAME','');start=os.environ.get('START_DATE','');end=os.environ.get('END_DATE','');months=os.environ.get('MONTHS','');limit=os.environ.get('MAX_HORSES','500')
if not 2010<=Y<=2100:raise SystemExit('Invalid year (2010 or later required)')
db=Path('state')/str(Y)/'MASTER.sqlite3';input_path=None
if release and mode!='diagnose' and (mode in ['bootstrap','reaudit'] or not db.exists()):
 if not base or Path(base).name!=base:raise SystemExit('Exact baseline asset filename required')
 Path('inputs').mkdir(exist_ok=True)
 subprocess.run(['gh','release','download',release,'--repo',os.environ['GITHUB_REPOSITORY'],'--pattern',base,'--dir','inputs','--clobber'],check=True)
 input_path=Path('inputs')/base
common=['--year',str(Y),'--db',str(db),'--output','delivery']
if mode=='preflight':raise SystemExit(main(common+['--mode','preflight']))
# Explicit bootstrap with a compact original MASTER adopts the reviewed file,
# even when an older Actions state was restored. Legacy RAW inputs keep prior behavior.
if mode=='bootstrap' and input_path:
 archive=Archive(input_path)
 try:
  names={r[0] for r in archive.c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
  compact='source_records' in names and 'pedigree_receipts' in names
 finally:archive.close()
 if compact:
  db.parent.mkdir(parents=True,exist_ok=True)
  with tempfile.TemporaryDirectory(dir=db.parent,prefix='reviewed_import_') as stage:
   candidate=Path(stage)/'MASTER.sqlite3';store=Store(candidate)
   try:
    bootstrap(store,input_path,Y)
    audit=store.audit()
    if audit['integrity']!='ok' or audit['foreign_keys']:raise ValueError('REVIEWED_MASTER_INVALID')
   finally:store.c.close()
   # The previous state remains in its original Actions artifact.
   for suffix in ['-journal','-wal','-shm']:
    if Path(str(db)+suffix).exists():raise ValueError('STATE_SIDECAR_PRESENT')
   os.replace(candidate,db)
  print('REVIEWED_COMPACT_MASTER_ADOPTED',flush=True)
if not db.exists() and input_path:main(common+['--mode','bootstrap','--input',str(input_path)])
if mode=='bootstrap':
 if not db.exists():raise SystemExit('Baseline release asset or prior state required')
 raise SystemExit(main(common+['--mode','export']))
args=common+['--mode',mode,'--max-horses',limit,'--max-sources',os.environ.get('MAX_SOURCES','500'),'--budget-seconds','9000']
if input_path:args+=['--input',str(input_path)]
# Optional explicit local donor ZIP, e.g. materialized by a custom workflow.
if os.environ.get('PEDIGREE_FROM'):args+=['--pedigree-from',os.environ['PEDIGREE_FROM']]
if mode=='reaudit' and not input_path:raise SystemExit('Reaudit requires baseline release asset (saved RAW)')
if mode in ['update','diagnose']:
 if start:args+=['--start',start]
 if end:args+=['--end',end]
 if months:args+=['--months',months]
 if os.environ.get('REFRESH')=='true':args+=['--refresh']
if os.environ.get('WITH_PEDIGREE')=='true':args+=['--with-pedigree']
raise SystemExit(main(args))
