"""JRA HTML-first, fail-closed supplementary evidence pipeline.

Uses a REAL prior JRA result CNAME stored in race_sources/source_records. Never
fabricates query tokens. Never changes races/runners/results/odds/pedigree.
HTML race-result information is POST-EVENT and not a witnessed pre-race snapshot.
Previous PDF-derived rows are retained but excluded from HTML-verified evidence.
"""
from __future__ import annotations
import datetime as dt
import gzip
import hashlib
import json
import re
import sqlite3
import tempfile
import time
from pathlib import Path
from urllib.parse import parse_qs, urlencode
from bs4 import BeautifulSoup
from .store import Store
from .network import Client, Deferred, FetchError
from .jra_parser import decode_jra, parse_result, ParseFailure, compact_text, TRACK_CODE

VERSION='JRA_HTML_FIRST_0.7.1.1'
CNAME=re.compile(r'^pw01sde10(?P<track>\d{2})(?P<year>\d{4})(?P<meeting>\d{2})(?P<day>\d{2})(?P<race>\d{2})(?P<date>\d{8})/(?P<token>[0-9A-Fa-f]{2})$')
CORE=('races','horses','runners','results','win_odds','payouts','laps','corners','pedigree','pedigree_receipts')
# From 2019-06-01 JRA dropped the サラ系 prefix in race conditions.
# Match the age-based OFFICIAL race_title text only; never infer it from
# cached results, race-class metadata, or unrelated HTML body text.
CONDITION=re.compile(r'(?:サラ系\s*)?(?:障害\s*)?[2-9]歳(?:以上)?[^\n]{0,160}?(?=コース\s*[:：]|本賞金|決勝写真|$)')

def utc():return dt.datetime.now(dt.timezone.utc).isoformat()
def digest(b):return hashlib.sha256(b).hexdigest()
def core_counts(c):return {t:c.execute('SELECT count(*) FROM '+t).fetchone()[0] for t in CORE}

def schema(c):
 c.executescript('''
 CREATE TABLE IF NOT EXISTS official_html_receipts(
   race_id TEXT PRIMARY KEY REFERENCES races(race_id), source_url TEXT NOT NULL,
   source_sha256 TEXT, parser_version TEXT NOT NULL, status TEXT NOT NULL,
   reason TEXT, checked_at TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS official_html_races(
   race_id TEXT PRIMARY KEY REFERENCES races(race_id), weather TEXT,
   going TEXT, condition_text TEXT, class_text TEXT, source_url TEXT NOT NULL,
   source_sha256 TEXT NOT NULL, timing_status TEXT NOT NULL,
   verified_at TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS official_html_runners(
   race_id TEXT NOT NULL, horse_number INTEGER NOT NULL,
   blinker_confirmed INTEGER, cancellation_status TEXT,
   source_url TEXT NOT NULL, source_sha256 TEXT NOT NULL,
   timing_status TEXT NOT NULL, verified_at TEXT NOT NULL,
   PRIMARY KEY(race_id,horse_number),
   FOREIGN KEY(race_id,horse_number) REFERENCES runners(race_id,horse_number));
 CREATE TABLE IF NOT EXISTS official_html_revisions(
   id INTEGER PRIMARY KEY, target TEXT NOT NULL, key TEXT NOT NULL,
   old_json TEXT NOT NULL, new_json TEXT NOT NULL, recorded_at TEXT NOT NULL);
 ''')

def valid_existing_cname(request_body,race_id):
 """Accept only an EXACT token observed in source records and matching race key."""
 if not request_body or not re.fullmatch(r'cname=[A-Za-z0-9%]+',request_body):return None
 vals=parse_qs(request_body,keep_blank_values=False)
 if len(vals)!=1 or list(vals)!=['cname'] or len(vals['cname'])!=1:return None
 candidate=vals['cname'][0];m=CNAME.fullmatch(candidate)
 if not m:return None
 d=m['date'];key=f'{d[:4]}-{d[4:6]}-{d[6:]}-{TRACK_CODE.get(m["track"],"?")}-{int(m["race"]):02d}'
 if int(m['year'])!=int(d[:4]) or key!=race_id:return None
 return request_body

def source_index(c,year):
 """Previously observed CNAME URL/post body only. Unavailable => UNRESOLVED."""
 result={}
 query='''SELECT rs.race_id,s.metadata_json,s.url FROM race_sources rs
          JOIN source_records s ON rs.source_id=s.source_id
          JOIN races r ON r.race_id=rs.race_id
          WHERE r.race_date LIKE ? AND rs.role='RESULT_HTML' AND s.role='RACE_RESULT'
          ORDER BY rs.race_id'''
 for rid,raw,url in c.execute(query,(f'{year}-%',)):
  if url!='https://www.jra.go.jp/JRADB/accessS.html':continue
  try:body=json.loads(raw).get('request_body')
  except (ValueError,TypeError):continue
  if valid_existing_cname(body,rid):result.setdefault(rid,body)
 return result

def _normalize_text(s):return re.sub(r'\s+',' ',s or '').strip()

def _html_fields(html_bytes,parsed):
 soup=BeautifulSoup(decode_jra(html_bytes),'lxml')
 race_title=soup.select_one('.race_title')
 if race_title is None:raise ValueError('RACE_TITLE_ABSENT')
 # Condition must include an exact, bounded JRA race-type phrase, not table contents.
 title_text=_normalize_text(race_title.get_text(' ',strip=True))
 found=CONDITION.search(title_text)
 condition=found.group(0).strip() if found else None
 if condition and (len(condition)>160 or '払戻' in condition or '着順' in condition):condition=None
 cls=None
 if condition:
  # Class is a substring explicitly printed in the JRA condition text.
  for token in ('3勝クラス','2勝クラス','1勝クラス','1600万円以下','1000万円以下','500万円以下',
                'オープン','未勝利','新馬'):
   if token in condition:cls=token;break
 # A race-result page shows blinkers through explicit markings. Absence is UNKNOWN.
 runners={}
 for t in soup.find_all('table'):
  if not (t.select_one('thead th.place') and t.select_one('tbody td.horse')):continue
  for tr in t.select('tbody tr'):
   num=tr.select_one('td.num');horse=tr.select_one('td.horse')
   if num is None or horse is None:continue
   m=re.search(r'\d+',compact_text(num))
   if not m:continue
   no=int(m.group(0));place=tr.select_one('td.place');st=compact_text(place) if place else ''
   kind=next((x for x in ('出走取消','競走除外') if x in st),None)
   marker=False
   for el in tr.select('img[alt],span[title],abbr[title]'):
    alt=el.get('alt','')+' '+el.get('title','')
    if 'ブリンカー' in alt:marker=True
   # Never infer absence of blinkers from lack of marking.
   if marker or kind:runners[no]={'blinker_confirmed':1 if marker else None,'cancellation_status':kind}
  break
 return condition,cls,runners

def surface_conditions(html_bytes):
 """Extract two *separate* JRA official header going values (no cross-surface fallback).

 JRA results present 芝 and ダート together in the header. Different historical
 HTML variants wrap those in different elements, so do not rely on .dirt .txt.
 Ambiguous results are rejected instead of guessed from a turf race.
 """
 soup=BeautifulSoup(decode_jra(html_bytes),'lxml')
 header=soup.select_one('.race_header')
 if header is None:return {}
 found={'芝':set(),'ダート':set()}
 for element in header.find_all(True):
  classes={str(x).lower() for x in element.get('class',[])}
  label=None
  if 'dirt' in classes or 'dirt_condition' in classes or 'dirt_status' in classes:label='ダート'
  if 'turf' in classes or 'turf_condition' in classes or 'turf_status' in classes:label='芝'
  if label:
   raw=_normalize_text(element.get_text(' ',strip=True))
   values=re.findall(r'(?<![ぁ-んァ-ン一-龥])(稍重|不良|重|良)(?![ぁ-んァ-ン一-龥])',raw)
   if not values and raw in ('良','稍重','重','不良'):values=[raw]
   found[label].update(values)
 # Explicit labels in a combined header, including image alt text which
 # BeautifulSoup.get_text() discards. Only scan the actual race header.
 fragments=[]
 for item in header.descendants:
  if getattr(item,'name',None)=='img':
   fragments.append(str(item.get('alt','')))
  elif isinstance(item,str):fragments.append(item)
 combined=_normalize_text(' '.join(fragments))
 for label in found:
  for match in re.finditer(re.escape(label)+r'\s*(?:馬場状態)?\s*[:：]?\s*(稍重|不良|重|良)(?![ぁ-んァ-ン一-龥])',combined):
   found[label].add(match.group(1))
 for label,values in found.items():
  if len(values)>1:raise ValueError('OFFICIAL_GOING_CONFLICT_'+label)
 return {label:next(iter(v)) for label,v in found.items() if len(v)==1}

def validated(html_bytes,rid,known):
 row=known['race']; parsed=parse_result(html_bytes,expected_date=row['race_date'])
 if (parsed.track!=row['track'] or parsed.race_no!=row['race_number'] or
     parsed.surface!=known['surface'] or parsed.distance_m!=known['distance_m']):
  raise ValueError('HTML_RACE_HEADER_MISMATCH')
 if row['race_type'] in ('OBSTACLE','JUMP') and parsed.surface!='障害':raise ValueError('OBSTACLE_MISMATCH')
 # Cross-check at least one runner against the master, including its official ID.
 present={e.horse_no:e.horse_id for e in parsed.entries}
 correct=sum(1 for k,v in present.items() if known['horses'].get(k)==v)
 if not present or any(known['horses'].get(k)!=v for k,v in present.items()):
  raise ValueError('HTML_RUNNER_IDENTITIES_MISMATCH')
 if correct<max(1,len(known['horses'])-2):
  raise ValueError(f'HTML_RUNNER_COVERAGE_INCOMPLETE:{correct}/{len(known["horses"])}')
 condition,cls,extra=_html_fields(html_bytes,parsed)
 # Per-surface header values. Older parser wrongly looked at turf first
 # and omitted dirt even though the official page shows both conditions.
 surface_key='ダート' if known['surface']=='ダート' else '芝'
 both=surface_conditions(html_bytes)
 going=both.get(surface_key)
 if going is None and surface_key=='芝' and parsed.track_condition in ('良','稍重','重','不良'):
  going=parsed.track_condition
 if going not in ('良','稍重','重','不良'):
  raise ValueError('OFFICIAL_GOING_UNVERIFIED_'+surface_key)
 if surface_key=='芝' and parsed.track_condition in ('良','稍重','重','不良') and going!=parsed.track_condition:
  raise ValueError('OFFICIAL_TURF_GOING_CONFLICT')
 if not condition or not cls:
  raise ValueError('OFFICIAL_CONDITION_CLASS_UNVERIFIED')
 return {'weather':parsed.weather,'going':going,'condition_text':condition,
         'class_text':cls,'runner_details':extra}

def get_known(c,rid):
 c.row_factory=sqlite3.Row
 row=c.execute('SELECT * FROM races WHERE race_id=?',(rid,)).fetchone()
 if row is None:raise ValueError('UNKNOWN_RACE')
 base=json.loads(row['payload_json'])
 if row['race_type'] in ('OBSTACLE','JUMP') or base.get('surface')=='障害':surface='障害'
 else:surface=base.get('surface')
 return {'race':dict(row),'surface':surface,'distance_m':base.get('distance_m'),
         'horses':dict(c.execute('SELECT horse_number,horse_id FROM runners WHERE race_id=?',(rid,)))}

def upsert(c,table,pk,record):
 columns=list(record);existing=c.execute('SELECT * FROM '+table+' WHERE '+ ' AND '.join(f'{k}=?' for k in pk),tuple(record[k] for k in pk)).fetchone()
 if existing is None:
  c.execute(f"INSERT INTO {table} ({','.join(columns)}) VALUES ({','.join('?' for _ in columns)})",list(record.values()));return
 old=dict(existing);new=dict(old)
 for k,v in record.items():
  if v is not None:new[k]=v
 if old==new or all(old[k]==new[k] for k in new if k not in ('verified_at',)):
  return
 keys={k:record[k] for k in pk}
 c.execute('INSERT INTO official_html_revisions(target,key,old_json,new_json,recorded_at) VALUES (?,?,?,?,?)',
           (table,json.dumps(keys,ensure_ascii=False),json.dumps(old,ensure_ascii=False),json.dumps(new,ensure_ascii=False),utc()))
 changed=[k for k in new if k not in pk]
 c.execute(f"UPDATE {table} SET "+','.join(k+'=?' for k in changed)+' WHERE '+' AND '.join(k+'=?' for k in pk),
           [new[k] for k in changed]+[record[k] for k in pk])

def apply(c,rid,body,source_url):
 known=get_known(c,rid);fields=validated(body,rid,known);h=digest(body);stamp=utc()
 race={'race_id':rid,**{k:fields[k] for k in ('weather','going','condition_text','class_text')},
       'source_url':source_url,'source_sha256':h,'timing_status':'POST_EVENT_RESULT_NOT_VERIFIED_PRE_RACE',
       'verified_at':stamp}
 with c:
  upsert(c,'official_html_races',['race_id'],race)
  for no,attrs in fields['runner_details'].items():
   if no not in known['horses']:raise ValueError('UNRECOGNIZED_HORSE_NUMBER')
   upsert(c,'official_html_runners',['race_id','horse_number'],{'race_id':rid,'horse_number':no,
           **attrs,'source_url':source_url,'source_sha256':h,
           'timing_status':'POST_EVENT_RESULT_NOT_VERIFIED_PRE_RACE','verified_at':stamp})
  c.execute('''INSERT INTO official_html_receipts VALUES (?,?,?,?,?,?,?)
      ON CONFLICT(race_id) DO UPDATE SET source_url=excluded.source_url,
      source_sha256=excluded.source_sha256,parser_version=excluded.parser_version,
      status=excluded.status,reason=excluded.reason,checked_at=excluded.checked_at''',
      (rid,source_url,h,VERSION,'PASS',None,stamp))
 return fields

def run(year,db,out='delivery',budget_seconds=3400,max_pages=700,refresh=False,offline=False):
 db=Path(db);out=Path(out);out.mkdir(parents=True,exist_ok=True)
 if not db.exists():raise FileNotFoundError('YEAR_STATE_REQUIRED')
 s=Store(db)
 try:
  c=s.c;schema(c);before=core_counts(c);index=source_index(c,year)
  total=c.execute('SELECT count(*) FROM races WHERE race_date LIKE ?',(f'{year}-%',)).fetchone()[0]
  cache=Path('jra_html_cache')/str(year);cache.mkdir(parents=True,exist_ok=True)
  results={'year':year,'version':VERSION,'total_races':total,'known_official_html_urls':len(index),
           'processed_this_run':0,'reused_receipts':0,'cache_reparsed':0,'fetched_this_run':0,
           'failed_this_run':0,'examples':[],'remaining':None,'status':'PARTIAL',
           'consecutive_failures':0,'stopped_for_safety':False,
           'legacy_pdf_evidence_policy':'DISCARDED_FROM_CERTIFIED_OUTPUT',
           'source_policy':'JRA_OFFICIAL_HTML_ONLY_FOR_THIS_STAGE',
           'publication_policy':'POST_EVENT_NOT_PROVEN_PRE_RACE'}
  deadline=time.monotonic()+max(60,budget_seconds)
  with tempfile.TemporaryDirectory(prefix='jra_html_tmp_') as tmp:
   client=Client(s,tmp,max(60,budget_seconds),jra_interval=2)
   for rid,body_param in index.items():
    receipt=c.execute('SELECT parser_version,status,source_sha256 FROM official_html_receipts WHERE race_id=?',(rid,)).fetchone()
    if not refresh and receipt and receipt[1]=='PASS':
     previous=c.execute('SELECT weather,going,condition_text,class_text,source_sha256 FROM official_html_races WHERE race_id=?',(rid,)).fetchone()
     if (previous and all(previous[:4]) and previous[1] in ('良','稍重','重','不良')
         and previous[4] and previous[4]==receipt[2]):
      # Reuse genuine previous evidence WITHOUT relabeling its parser version,
      # timestamp or provenance. Missing fields are the ONLY HTML candidates.
      results['reused_receipts']+=1;continue
    if results['processed_this_run']>=max_pages or time.monotonic()+70>=deadline:break
    url='https://www.jra.go.jp/JRADB/accessS.html'
    cache_key=digest(rid.encode());path=cache/(cache_key+'.bin.gz')
    html=None;from_cache=False
    if not refresh and path.exists() and receipt and receipt[2]:
     try:
      buf=gzip.decompress(path.read_bytes())
      if digest(buf)==receipt[2]:html=buf;from_cache=True
     except (OSError,EOFError):pass
    try:
     if html is None:
      if offline:break
      html,sid,temp=client.request(url,'OFFICIAL_HTML_FIRST',body=body_param)
      results['fetched_this_run']+=1
     else:results['cache_reparsed']+=1
     fields=apply(c,rid,html,url+'?'+body_param.replace('cname=','CNAME='))
     results['consecutive_failures']=0
     path.write_bytes(gzip.compress(html,mtime=0))
     if not from_cache:client.valid(sid,temp)
    except Deferred:break
    except Exception as exc:
     message=f'{rid}: {type(exc).__name__}: {exc}'
     results['failed_this_run']+=1
     results['consecutive_failures']+=1
     if len(results['examples'])<15:results['examples'].append(message[:350])
     # Do NOT mark an unverified record as complete, and do not replace any old verified rows.
     with c:
      c.execute('''INSERT INTO official_html_receipts VALUES (?,?,?,?,?,?,?)
      ON CONFLICT(race_id) DO UPDATE SET status=excluded.status,reason=excluded.reason,
      parser_version=excluded.parser_version,checked_at=excluded.checked_at''',
      (rid,url+'?'+body_param.replace('cname=','CNAME='),digest(html) if html else None,
       VERSION,'FAILED',message[:500],utc()))
     if html is not None:path.write_bytes(gzip.compress(html,mtime=0))
     if html is not None and not from_cache and 'sid' in locals():
      client.valid(sid,temp)
    results['processed_this_run']+=1
    if results['processed_this_run']%100==0:
     print('HTML_PROGRESS',json.dumps({'year':year,'processed':results['processed_this_run'],'fetched':results['fetched_this_run'],'reused':results['reused_receipts'],'failed':results['failed_this_run']},ensure_ascii=False),flush=True)
    if results['consecutive_failures']>=20:
     results['stopped_for_safety']=True
     break
  if core_counts(c)!=before:raise RuntimeError('CORE_TABLE_MUTATED')
  if c.execute('PRAGMA integrity_check').fetchone()[0]!='ok' or c.execute('PRAGMA foreign_key_check').fetchall():
   raise RuntimeError('INTEGRITY_FAILURE')
  # All verified previous parser versions remain valid; a parser upgrade
  # MUST NOT force every previously completed race to be fetched again.
  completed=c.execute("""SELECT COUNT(*) FROM official_html_receipts x
      JOIN official_html_races h ON h.race_id=x.race_id
      JOIN races r ON r.race_id=x.race_id
      WHERE r.race_date LIKE ? AND x.status='PASS'
        AND x.source_sha256=h.source_sha256
        AND h.weather IS NOT NULL AND h.weather<>''
        AND h.going IN ('良','稍重','重','不良')
        AND h.condition_text IS NOT NULL AND h.condition_text<>''
        AND h.class_text IS NOT NULL AND h.class_text<>''""",(f'{year}-%',)).fetchone()[0]
  failed=c.execute("SELECT COUNT(*) FROM official_html_receipts WHERE status='FAILED' AND race_id IN (SELECT race_id FROM races WHERE race_date LIKE ?)",(f'{year}-%',)).fetchone()[0]
  coverage={}
  for col in ('weather','going','condition_text','class_text'):
   coverage[col]=c.execute(f'SELECT COUNT(*) FROM official_html_races WHERE {col} IS NOT NULL AND {col} != ?',('',)).fetchone()[0]
  coverage['blinker_positive']=c.execute('SELECT COUNT(*) FROM official_html_runners WHERE blinker_confirmed=1').fetchone()[0]
  coverage['cancellation_explicit']=c.execute('SELECT COUNT(*) FROM official_html_runners WHERE cancellation_status IS NOT NULL').fetchone()[0]
  results.update({'field_coverage':coverage,'not_implemented_from_HTML':['turf_A_B_C_D','owner','breeder','birthplace','cancellation_reason'],
                  'verified_html_races':completed,'failed_receipts':failed,
                  'remaining':total-completed,'missing_source_links':total-len(index),
                  'status':'BLOCKED_SOURCE_FORMAT' if results['stopped_for_safety'] else ('PASS' if total>0 and completed==total and failed==0 else 'PARTIAL'),'checked_at':utc(),
                  'core_unchanged':True,'sqlite_integrity':'ok'})
  with c:c.execute('INSERT OR REPLACE INTO metadata(key,value) VALUES (?,?)',
                   ('official_html_first_audit',json.dumps(results,ensure_ascii=False)))
  (out/f'official_html_audit_{year}.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
  print('HTML_FIRST_AUDIT',json.dumps(results,ensure_ascii=False),flush=True)
  return results
 finally:s.c.commit();s.c.close()
