"""Recover three unqueued races from observed official day-selection links."""
import json,re
from urllib.parse import urlencode
from .store import now
from .network import Deferred
# These navigation tokens were present in original 2022 RAW source 118.
# No result or odds checksum is generated from race numbers.
DAYS=[('20220115','pw01srl10102022010120220115/10',[4,5]),('20220116','pw01srl10102022010220220116/FE',[4])]
LEGACY_SELECTION_HASH='2ee3b030508e5ca4f10b8a1335411934462b8331fa8520b691dfdd1335da826b'
def result_links(body,date,numbers):
 from .racing import links
 out={}
 for token in links(body,'sde'):
  match=re.fullmatch(r'pw01sde10(?P<track>\d{2})(?P<year>\d{4})(?P<meeting>\d{4})(?P<race>\d{2})(?P<date>\d{8})/[0-9A-F]{2}',token)
  if not match or match['track']!='10' or match['year']!='2022' or match['date']!=date:continue
  no=int(match['race'])
  if no not in numbers:continue
  if no in out and out[no]!=token:raise ValueError('AMBIGUOUS_OFFICIAL_RESULT_LINK')
  out[no]=token
 if set(out)!=set(numbers):raise ValueError('OFFICIAL_RESULT_LINKS_INCOMPLETE')
 return out

def prepare(s,client):
 year=s.c.execute("select value from metadata where key='year'").fetchone()
 if not year or json.loads(year[0])!=2022:return
 from .racing import form
 row=s.c.execute("select value from metadata where key='pending_official_reaudit'").fetchone()
 if not row:return
 queue=json.loads(row[0]);s.meta('require_final_odds_completion',True)
 for date,token,numbers in DAYS:
  wanted=[]
  for no in numbers:
   rid=f'{date[:4]}-{date[4:6]}-{date[6:]}-小倉-{no:02d}'
   if not s.c.execute('select 1 from races where race_id=?',(rid,)).fetchone():continue
   key='REAUDIT_RECOVER_2022_RESULT_'+rid
   if s.done('REAUDIT_FINAL_ODDS_'+rid) or any(i['race_id']==rid and i['kind']=='RESULT' for i in queue):continue
   if not s.done(key):s.task(key,'PENDING','Legacy PDF race not queued; observed official selection link required')
   wanted.append((no,rid,key))
  if not wanted:continue
  dk='DISCOVER_2022_OFFICIAL_DAY_'+date
  try:
   body,sid,path=client.request('https://www.jra.go.jp/JRADB/accessS.html','OFFICIAL_RESULT_SELECTION_RECOVERY',form(token))
   observed=result_links(body,date,[r[0] for r in wanted])
   for no,rid,key in wanted:
    queue.append({'task_key':key,'race_id':rid,'kind':'RESULT','url':'https://www.jra.go.jp/JRADB/accessS.html?'+urlencode({'CNAME':observed[no]}),'observed_from_source_id':sid})
   s.meta('pending_official_reaudit',queue)
   s.meta('recovery_selection_'+date,{'selection_cname':token,'navigation_observed_in':'original 2022 RAW source 118','legacy_stored_sha256':LEGACY_SELECTION_HASH,'actual_selection_source_id':sid,'linked_races':[r[1] for r in wanted],'integrated_at':now()})
   client.valid(sid,path);s.task(dk,'PASS');s.resolve(dk)
  except Deferred as e:s.task(dk,'DEFERRED',str(e));break
  except Exception as e:
   s.task(dk,'FAIL',str(e));s.issue(dk,'OFFICIAL_LINK_DISCOVERY',{'error':str(e),'observed_selection_cname':token})
