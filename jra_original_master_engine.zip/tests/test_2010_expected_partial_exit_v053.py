"""Regression: 2010 expected limitation must not be a red Actions failure.

Only all-PDFs-processed, all-turf-courses-verified and perfect core may exit 0;
audit must stay PARTIAL, and any actual loss must still exit nonzero.
"""
import sqlite3
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from jra_master import full_update as m

class Expected2010LimitTests(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.TemporaryDirectory()
        self.db = Path(self.dir.name) / 'master.sqlite3'
        with sqlite3.connect(self.db) as c:
            c.executescript('''
                CREATE TABLE races (race_id TEXT PRIMARY KEY, payload_json TEXT);
                CREATE TABLE official_legacy_race_values (race_id TEXT PRIMARY KEY,used_turf_course TEXT);
                CREATE TABLE official_expansion_receipts (source_url TEXT PRIMARY KEY, year INTEGER, status TEXT);
                CREATE TABLE metadata (key TEXT PRIMARY KEY,value TEXT);
                INSERT INTO races VALUES ('r1','{"surface":"芝"}');
                INSERT INTO official_legacy_race_values VALUES ('r1','A');
                INSERT INTO official_expansion_receipts VALUES ('pdf1',2010,'PARTIAL');
            ''')
        self.report = dict(year=2010,status='PARTIAL',pdf_index_count=1,pending_pdfs=0,
                           deferred_due_to_budget=0,failed_this_run=[],
                           receipt_status_counts={'PARTIAL':1},
                           **{'2010_note':'2010 official meeting PDF has a different structure; only validated meeting course is imported.'})
        self.stages={'core':{'status':'PASS','exit_code':0},
                     'track':{'status':'MERGED_WITH_OFFICIAL'},
                     'official_expansion':{'status':'PARTIAL','exit_code':0}}
        self.audit=dict(status='PARTIAL',sqlite_integrity='ok',foreign_keys=[],
                        runner_coverage_gaps={'results':0,'win_odds':0},
                        missing_pedigree_receipts=0,task_status_counts={'PASS':12},
                        issue_status_counts={},last_official_expansion_audit=self.report)
        with sqlite3.connect(self.db) as c:
            c.execute('INSERT INTO metadata VALUES (?,?)',('official_expansion_audit',json.dumps(self.report)))
    def tearDown(self):self.dir.cleanup()
    def test_known_limit_complete(self):
        self.assertTrue(m._documented_2010_limit_only(2010,self.db,self.audit,self.stages))
    def test_other_year_partial_must_fail(self):
        self.assertFalse(m._documented_2010_limit_only(2011,self.db,self.audit,self.stages))
    def test_missing_course_must_fail(self):
        with sqlite3.connect(self.db) as c:c.execute('DELETE FROM official_legacy_race_values')
        self.assertFalse(m._documented_2010_limit_only(2010,self.db,self.audit,self.stages))
    def test_failed_pdf_must_fail(self):
        self.report['failed_this_run']=['broken pdf']
        self.assertFalse(m._documented_2010_limit_only(2010,self.db,self.audit,self.stages))
    def test_core_partial_must_fail(self):
        self.stages['core']['status']='PARTIAL'
        self.assertFalse(m._documented_2010_limit_only(2010,self.db,self.audit,self.stages))
    def test_missing_pedigree_must_fail(self):
        self.audit['missing_pedigree_receipts']=2
        self.assertFalse(m._documented_2010_limit_only(2010,self.db,self.audit,self.stages))
    def test_known_limit_exit0_audit_still_partial(self):
        from jra_master import html_first
        data={'status':'PARTIAL','known_official_html_urls':10,'verified_html_races':3,'remaining':7,'failed_receipts':0,'failed_this_run':0}
        with patch.object(html_first,'run',return_value=data),patch.object(m,'final_export',return_value=self.audit):
            code=m.run_full_update(year=2010,db=self.db,output=self.dir.name,core_args=[],core_main=lambda _:0)
        self.assertEqual(code,0)
        self.assertEqual(self.audit['status'],'PARTIAL')
    def test_actual_failure_exit2(self):
        from jra_master import html_first
        data={'status':'ERROR','known_official_html_urls':10,'verified_html_races':3,'remaining':7,'failed_receipts':100,'failed_this_run':100}
        with patch.object(html_first,'run',return_value=data),patch.object(m,'final_export',return_value=self.audit):
            code=m.run_full_update(year=2010,db=self.db,output=self.dir.name,core_args=[],core_main=lambda _:0)
        self.assertEqual(code,2)

if __name__=='__main__':unittest.main()
