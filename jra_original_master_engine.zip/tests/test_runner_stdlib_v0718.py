"""Ensure Github Actions unittest discover can load all tests without pytest."""
import ast
from pathlib import Path
from unittest import TestCase

class TestRunnerDependencies(TestCase):
    def test_no_pytest_imports_in_engine_tests(self):
        for file in Path(__file__).parent.glob('test_*.py'):
            with self.subTest(file=file.name):
                tree=ast.parse(file.read_text(encoding='utf-8'),filename=str(file))
                imports=[n for n in ast.walk(tree) if isinstance(n,(ast.Import,ast.ImportFrom))]
                modules=[a.name for n in imports if isinstance(n,ast.Import) for a in n.names]
                modules.extend(n.module or '' for n in imports if isinstance(n,ast.ImportFrom))
                self.assertNotIn('pytest',modules)
