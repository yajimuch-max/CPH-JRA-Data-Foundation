from __future__ import annotations

import hashlib
import json
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from .pipeline import now


class BatchPlanFailure(RuntimeError):
    pass


@dataclass(frozen=True)
class BatchItem:
    race_date: str
    bootstrap_url: str


def load_plan(path: Path) -> tuple[str, str, list[BatchItem]]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    raw_items = payload.get("dates")
    if not isinstance(raw_items, list) or not raw_items:
        raise BatchPlanFailure("BATCH_PLAN_EMPTY")
    items = [BatchItem(str(x["date"]), str(x["bootstrap_url"])) for x in raw_items]
    dates = [x.race_date for x in items]
    if len(dates) != len(set(dates)):
        raise BatchPlanFailure("BATCH_PLAN_DUPLICATE_DATE")
    year = payload.get("year")
    if year is not None and any(not date.startswith(f"{int(year):04d}-") for date in dates):
        raise BatchPlanFailure("BATCH_PLAN_YEAR_MISMATCH")
    canonical = json.dumps(
        [{"date": x.race_date, "bootstrap_url": x.bootstrap_url} for x in items],
        ensure_ascii=False, sort_keys=True, separators=(",", ":"),
    ).encode("utf-8")
    digest = hashlib.sha256(canonical).hexdigest()
    return f"DFBATCH-{digest[:20]}", digest, items


class BatchRunner:
    """Date-level checkpoint runner. It never hides a failed or skipped date."""

    def __init__(self, pipeline, max_total_bytes: int, reserve_free_bytes: int):
        self.pipeline = pipeline
        self.conn = pipeline.conn
        self.root = pipeline.root
        self.max_total_bytes = int(max_total_bytes)
        self.reserve_free_bytes = int(reserve_free_bytes)
        if self.max_total_bytes <= 0 or self.reserve_free_bytes < 0:
            raise BatchPlanFailure("INVALID_CAPACITY_POLICY")

    def stored_bytes(self) -> int:
        return int(self.conn.execute("SELECT COALESCE(SUM(stored_bytes),0) FROM raw_snapshots").fetchone()[0])

    def estimate_next_date_bytes(self) -> int:
        rows = self.conn.execute(
            "SELECT race_date, SUM(stored_bytes) FROM ("
            "SELECT DISTINCT pr.race_date, rs.snapshot_id, rs.stored_bytes "
            "FROM pipeline_runs pr JOIN import_audit ia ON ia.run_id=pr.run_id "
            "JOIN raw_snapshots rs ON rs.snapshot_id=ia.source_snapshot_id "
            "WHERE pr.status='PASS' AND ia.transaction_status='COMMITTED') "
            "GROUP BY race_date"
        ).fetchall()
        samples = sorted(int(r[1] or 0) for r in rows if int(r[1] or 0) > 0)
        if not samples:
            return 512 * 1024
        # Result pages dominate storage; add 10% headroom for schedule and variance.
        return (samples[len(samples) // 2] * 110 + 99) // 100

    def capacity_check(self) -> dict:
        stored = self.stored_bytes()
        estimate = self.estimate_next_date_bytes()
        free = shutil.disk_usage(self.root).free
        reasons = []
        if stored + estimate > self.max_total_bytes:
            reasons.append("MAX_TOTAL_BYTES_WOULD_BE_EXCEEDED")
        if free - estimate < self.reserve_free_bytes:
            reasons.append("FREE_SPACE_RESERVE_WOULD_BE_BREACHED")
        return {"pass": not reasons, "stored_bytes": stored, "estimated_next_date_bytes": estimate,
                "free_bytes": free, "reason_codes": reasons}

    def register(self, batch_id: str, items: list[BatchItem], plan_sha256: str) -> None:
        stamp = now()
        existing = self.conn.execute("SELECT plan_sha256 FROM batch_runs WHERE batch_id=?", (batch_id,)).fetchone()
        if existing and existing[0] != plan_sha256:
            raise BatchPlanFailure("BATCH_ID_PLAN_CONFLICT")
        self.conn.execute(
            "INSERT OR IGNORE INTO batch_runs VALUES(?,?,?,?,?,?,?)",
            (batch_id, plan_sha256, stamp, stamp, "PLANNED", self.max_total_bytes, self.reserve_free_bytes),
        )
        for ordinal, item in enumerate(items, 1):
            self.conn.execute(
                "INSERT OR IGNORE INTO batch_items(batch_id,race_date,bootstrap_url,ordinal,status) VALUES(?,?,?,?,?)",
                (batch_id, item.race_date, item.bootstrap_url, ordinal, "PENDING"),
            )
        self.conn.commit()

    def run(self, batch_id: str, items: list[BatchItem], plan_sha256: str,
            cache_only: bool = False, continue_on_error: bool = True,
            execute: Callable[[BatchItem, bool], dict] | None = None,
            selected_dates: set[str] | None = None) -> dict:
        self.register(batch_id, items, plan_sha256)
        execute = execute or (lambda item, co: self.pipeline.run(item.race_date, item.bootstrap_url, cache_only=co))
        self.conn.execute("UPDATE batch_runs SET status='RUNNING',updated_at=? WHERE batch_id=?", (now(), batch_id))
        self.conn.commit()
        resumed = passed = failed = 0
        stopped = False
        target_items = [item for item in items if selected_dates is None or item.race_date in selected_dates]
        if not target_items:
            raise BatchPlanFailure("BATCH_SEGMENT_EMPTY")
        for item in target_items:
            row = self.conn.execute("SELECT status FROM batch_items WHERE batch_id=? AND race_date=?",
                                    (batch_id, item.race_date)).fetchone()
            if row[0] == "PASS":
                resumed += 1
                continue
            cap = self.capacity_check()
            if not cap["pass"]:
                self.conn.execute(
                    "UPDATE batch_items SET status='CAPACITY_STOP',completed_at=?,reason_codes_json=? WHERE batch_id=? AND race_date=?",
                    (now(), json.dumps(cap["reason_codes"]), batch_id, item.race_date),
                )
                self.conn.commit()
                stopped = True
                break
            self.conn.execute(
                "UPDATE batch_items SET status='RUNNING',attempts=attempts+1,started_at=?,completed_at=NULL,reason_codes_json='[]' "
                "WHERE batch_id=? AND race_date=?", (now(), batch_id, item.race_date),
            )
            self.conn.commit()
            try:
                result = execute(item, cache_only)
                self.conn.execute(
                    "UPDATE batch_items SET status='PASS',pipeline_run_id=?,completed_at=? WHERE batch_id=? AND race_date=?",
                    (result.get("run_id"), now(), batch_id, item.race_date),
                )
                self.conn.commit()
                passed += 1
            except Exception as exc:
                reasons = getattr(exc, "reasons", [type(exc).__name__, str(exc)])
                self.conn.execute(
                    "UPDATE batch_items SET status='FAIL',completed_at=?,reason_codes_json=? WHERE batch_id=? AND race_date=?",
                    (now(), json.dumps(reasons, ensure_ascii=False), batch_id, item.race_date),
                )
                self.conn.commit()
                failed += 1
                if not continue_on_error:
                    break
        counts = {r[0]: r[1] for r in self.conn.execute(
            "SELECT status,COUNT(*) FROM batch_items WHERE batch_id=? GROUP BY status", (batch_id,))}
        target_statuses = [self.conn.execute(
            "SELECT status FROM batch_items WHERE batch_id=? AND race_date=?", (batch_id, x.race_date)
        ).fetchone()[0] for x in target_items]
        segment_status = "STOPPED" if stopped else "PASS" if all(x == "PASS" for x in target_statuses) else "PARTIAL"
        pending = counts.get("PENDING", 0) + counts.get("RUNNING", 0) + counts.get("CAPACITY_STOP", 0)
        status = "STOPPED" if stopped else "PASS" if not counts.get("FAIL", 0) and not pending else "PARTIAL"
        self.conn.execute("UPDATE batch_runs SET status=?,updated_at=? WHERE batch_id=?", (status, now(), batch_id))
        self.conn.commit()
        return {"status": status, "segment_status": segment_status, "batch_id": batch_id,
                "selected_date_count": len(target_items), "passed_this_run": passed,
                "failed_this_run": failed, "resumed_pass_dates": resumed, "item_status_counts": counts,
                "capacity": self.capacity_check()}
