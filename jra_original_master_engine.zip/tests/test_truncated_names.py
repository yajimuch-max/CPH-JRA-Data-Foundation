import unittest,tempfile,json
from unittest.mock import Mock
from jra_master.store import Store,encode
from jra_master.pedigree import collect
class TruncatedNames(unittest.TestCase):
 def setup_store(self,tmp,hid,name):
  s=Store(tmp+'/db');s.c.execute('INSERT INTO horses VALUES (?,?)',(hid,name))
  s.meta('horse_profile_'+hid,'https://www.jra.go.jp/JRADB/accessU.html?CNAME=pw01dud10'+hid+'%2FBE')
  s.source({'source_id':'official','service':'JRA','role':'JRA_PEDIGREE_FOUR_FIELDS','http_status':200});s.c.commit()
  s.task('JRA_PEDIGREE_'+hid,'FAIL','previous mismatch');s.issue('JRA_PEDIGREE_'+hid,'JRA_PEDIGREE_FETCH_OR_VALIDATION',{})
  return s
 def body(self,name):return ('<title>競走馬情報</title><h1><span class="txt">'+name+'</span></h1><dl>'+''.join('<dt>'+x+'</dt><dd>Ancestor</dd>' for x in ['父','母','母の父','母の母'])+'</dl>').encode()
 def test_exact_official_names_corrected_after_validation(self):
  for hid,old,new in [('2018190002','ロマンチックウォリ','ロマンチックウォリアー'),('2020190004','ファンタスティック','ファンタスティックムーン'),('2012190005','ウエスタンエクスプ','ウエスタンエクスプレス'),('2011190004','ビューティーオンリ','ビューティーオンリー')]:
   with self.subTest(hid=hid),tempfile.TemporaryDirectory() as tmp:
    s=self.setup_store(tmp,hid,old);client=Mock();client.request.return_value=(self.body(new),'official','raw')
    self.assertEqual(collect(s,client)['completed'],1)
    self.assertEqual(s.c.execute('SELECT horse_name FROM horses').fetchone()[0],new)
    self.assertEqual(s.c.execute('SELECT old_json FROM revisions WHERE table_name="horses"').fetchone()[0],encode({'horse_id':hid,'horse_name':old}))
    self.assertEqual(s.c.execute('SELECT status FROM issues').fetchone()[0],'RESOLVED')
    client.request.reset_mock();self.assertEqual(collect(s,client)['completed'],0);client.request.assert_not_called();s.c.close()
 def test_wrong_official_body_does_not_change_name(self):
  with tempfile.TemporaryDirectory() as tmp:
   s=self.setup_store(tmp,'2018190002','ロマンチックウォリ');client=Mock();client.request.return_value=(self.body('別の馬'),'official','raw')
   self.assertEqual(collect(s,client)['completed'],0)
   self.assertEqual(s.c.execute('SELECT horse_name FROM horses').fetchone()[0],'ロマンチックウォリ')
   self.assertEqual(s.c.execute('SELECT count(*) FROM pedigree_receipts').fetchone()[0],0);s.c.close()
 def test_western_express_incomplete_body_cannot_change_name(self):
  with tempfile.TemporaryDirectory() as tmp:
   s=self.setup_store(tmp,'2012190005','ウエスタンエクスプ');client=Mock()
   client.request.return_value=(b'<title>JRA</title>','official','raw')
   self.assertEqual(collect(s,client)['completed'],0)
   self.assertEqual(s.c.execute('SELECT horse_name FROM horses').fetchone()[0],'ウエスタンエクスプ')
   self.assertEqual(s.c.execute('SELECT count(*) FROM revisions').fetchone()[0],0);s.c.close()
 def test_western_express_wrong_id_cannot_change_name(self):
  with tempfile.TemporaryDirectory() as tmp:
   s=self.setup_store(tmp,'2012190005','ウエスタンエクスプ');s.meta('horse_profile_2012190005','https://www.jra.go.jp/JRADB/accessU.html?CNAME=pw01dud102012190006%2FCF')
   client=Mock();client.request.return_value=(self.body('ウエスタンエクスプレス'),'official','raw')
   self.assertEqual(collect(s,client)['completed'],0)
   self.assertEqual(s.c.execute('SELECT horse_name FROM horses').fetchone()[0],'ウエスタンエクスプ')
   self.assertEqual(s.c.execute('SELECT count(*) FROM pedigree_receipts').fetchone()[0],0);s.c.close()

 def test_beauty_only_incomplete_body_cannot_change_name(self):
  with tempfile.TemporaryDirectory() as tmp:
   s=self.setup_store(tmp,'2011190004','ビューティーオンリ');client=Mock()
   client.request.return_value=(b'<title>JRA</title>','official','raw')
   self.assertEqual(collect(s,client)['completed'],0)
   self.assertEqual(s.c.execute('SELECT horse_name FROM horses').fetchone()[0],'ビューティーオンリ')
   self.assertEqual(s.c.execute('SELECT count(*) FROM revisions').fetchone()[0],0);s.c.close()
 def test_beauty_only_wrong_id_cannot_change_name(self):
  with tempfile.TemporaryDirectory() as tmp:
   s=self.setup_store(tmp,'2011190004','ビューティーオンリ');s.meta('horse_profile_2011190004','https://www.jra.go.jp/JRADB/accessU.html?CNAME=pw01dud102011190005%2FD0')
   client=Mock();client.request.return_value=(self.body('ビューティーオンリー'),'official','raw')
   self.assertEqual(collect(s,client)['completed'],0)
   self.assertEqual(s.c.execute('SELECT horse_name FROM horses').fetchone()[0],'ビューティーオンリ')
   self.assertEqual(s.c.execute('SELECT count(*) FROM pedigree_receipts').fetchone()[0],0);s.c.close()

 def test_2014_two_names_require_full_profile_validation(self):
  for hid,old,new in [('2010190001','アップウィズザバー','アップウィズザバーズ'),('2010190002','トレーディングレザ','トレーディングレザー')]:
   with self.subTest(hid=hid),tempfile.TemporaryDirectory() as tmp:
    s=self.setup_store(tmp,hid,old);client=Mock();client.request.return_value=(self.body(new),'official','raw')
    self.assertEqual(collect(s,client)['completed'],1)
    self.assertEqual(s.c.execute('SELECT horse_name FROM horses').fetchone()[0],new)
    self.assertEqual(s.c.execute('SELECT count(*) FROM pedigree').fetchone()[0],4)
    self.assertEqual(s.c.execute('SELECT status FROM issues').fetchone()[0],'RESOLVED')
    client.request.reset_mock();self.assertEqual(collect(s,client)['completed'],0);client.request.assert_not_called();s.c.close()
 def test_2014_wrong_id_cannot_change_names(self):
  for hid,old,new in [('2010190001','アップウィズザバー','アップウィズザバーズ'),('2010190002','トレーディングレザ','トレーディングレザー')]:
   with self.subTest(hid=hid),tempfile.TemporaryDirectory() as tmp:
    s=self.setup_store(tmp,hid,old);s.meta('horse_profile_'+hid,'https://www.jra.go.jp/JRADB/accessU.html?CNAME=pw01dud102010190003%2FBE')
    client=Mock();client.request.return_value=(self.body(new),'official','raw')
    self.assertEqual(collect(s,client)['completed'],0)
    self.assertEqual(s.c.execute('SELECT horse_name FROM horses').fetchone()[0],old)
    self.assertEqual(s.c.execute('SELECT count(*) FROM revisions').fetchone()[0],0);s.c.close()
 def test_2014_incomplete_profile_cannot_change_names(self):
  for hid,old in [('2010190001','アップウィズザバー'),('2010190002','トレーディングレザ')]:
   with self.subTest(hid=hid),tempfile.TemporaryDirectory() as tmp:
    s=self.setup_store(tmp,hid,old);client=Mock();client.request.return_value=(b'<title>JRA</title>','official','raw')
    self.assertEqual(collect(s,client)['completed'],0)
    self.assertEqual(s.c.execute('SELECT horse_name FROM horses').fetchone()[0],old)
    self.assertEqual(s.c.execute('SELECT count(*) FROM revisions').fetchone()[0],0);s.c.close()

 def test_blackstairmountain_validated_and_idempotent(self):
  with tempfile.TemporaryDirectory() as tmp:
   s=self.setup_store(tmp,'2005190013','ブラックステアマウ');client=Mock();client.request.return_value=(self.body('ブラックステアマウンテン'),'official','raw')
   self.assertEqual(collect(s,client)['completed'],1);self.assertEqual(s.c.execute('SELECT horse_name FROM horses').fetchone()[0],'ブラックステアマウンテン')
   self.assertEqual(s.c.execute('SELECT status FROM issues').fetchone()[0],'RESOLVED');client.request.reset_mock();self.assertEqual(collect(s,client)['completed'],0);client.request.assert_not_called();s.c.close()
 def test_blackstairmountain_incomplete_body_rejected(self):
  with tempfile.TemporaryDirectory() as tmp:
   s=self.setup_store(tmp,'2005190013','ブラックステアマウ');client=Mock();client.request.return_value=(b'<title>JRA</title>','official','raw')
   self.assertEqual(collect(s,client)['completed'],0);self.assertEqual(s.c.execute('SELECT horse_name FROM horses').fetchone()[0],'ブラックステアマウ');self.assertEqual(s.c.execute('SELECT count(*) FROM revisions').fetchone()[0],0);s.c.close()
 def test_blackstairmountain_wrong_id_rejected(self):
  with tempfile.TemporaryDirectory() as tmp:
   s=self.setup_store(tmp,'2005190013','ブラックステアマウ');s.meta('horse_profile_2005190013','https://www.jra.go.jp/JRADB/accessU.html?CNAME=pw01dud102005190014%2F32');client=Mock();client.request.return_value=(self.body('ブラックステアマウンテン'),'official','raw')
   self.assertEqual(collect(s,client)['completed'],0);self.assertEqual(s.c.execute('SELECT horse_name FROM horses').fetchone()[0],'ブラックステアマウ');self.assertEqual(s.c.execute('SELECT count(*) FROM pedigree_receipts').fetchone()[0],0);s.c.close()
 def test_captainobvious_validated_and_idempotent(self):
  with tempfile.TemporaryDirectory() as tmp:
   s=self.setup_store(tmp,'2005190012','キャプテンオブヴィ');client=Mock();client.request.return_value=(self.body('キャプテンオブヴィアス'),'official','raw')
   self.assertEqual(collect(s,client)['completed'],1);self.assertEqual(s.c.execute('SELECT horse_name FROM horses').fetchone()[0],'キャプテンオブヴィアス')
   self.assertEqual(s.c.execute('SELECT status FROM issues').fetchone()[0],'RESOLVED');client.request.reset_mock();self.assertEqual(collect(s,client)['completed'],0);client.request.assert_not_called();s.c.close()
 def test_captainobvious_incomplete_body_rejected(self):
  with tempfile.TemporaryDirectory() as tmp:
   s=self.setup_store(tmp,'2005190012','キャプテンオブヴィ');client=Mock();client.request.return_value=(b'<title>JRA</title>','official','raw')
   self.assertEqual(collect(s,client)['completed'],0);self.assertEqual(s.c.execute('SELECT horse_name FROM horses').fetchone()[0],'キャプテンオブヴィ');self.assertEqual(s.c.execute('SELECT count(*) FROM revisions').fetchone()[0],0);s.c.close()
 def test_captainobvious_wrong_id_rejected(self):
  with tempfile.TemporaryDirectory() as tmp:
   s=self.setup_store(tmp,'2005190012','キャプテンオブヴィ');s.meta('horse_profile_2005190012','https://www.jra.go.jp/JRADB/accessU.html?CNAME=pw01dud102005190013%2F32');client=Mock();client.request.return_value=(self.body('キャプテンオブヴィアス'),'official','raw')
   self.assertEqual(collect(s,client)['completed'],0);self.assertEqual(s.c.execute('SELECT horse_name FROM horses').fetchone()[0],'キャプテンオブヴィ');self.assertEqual(s.c.execute('SELECT count(*) FROM pedigree_receipts').fetchone()[0],0);s.c.close()
