import tempfile, unittest, sqlite3, json, hashlib
from pathlib import Path
from unittest.mock import patch
from jra_master.verified_2021_pdf import visually_verified_2021, expected_days, ROOT
from jra_master.track_enrichment import upsert_obs,schema
from jra_master.track_action import sync_year

class FakePage:
    images=[{'dummy':True}]
    def extract_text(self):return ''
class FakeDoc:
    pages=[FakePage()]
    def __enter__(self):return self
    def __exit__(self,*args):pass

class Tests(unittest.TestCase):
 def test_day_counts_and_values(self):
  self.assertEqual(len(expected_days('hanshin02.pdf')),18)
  self.assertEqual(len(expected_days('chukyo06.pdf')),9)
  with tempfile.TemporaryDirectory() as t:
   p=Path(t)/'scan.pdf';p.write_bytes(b'%PDF-1.4'+b'x'*1600)
   with patch('pdfplumber.open',return_value=FakeDoc()):
    rows=visually_verified_2021('中京',ROOT+'chukyo06.pdf',p)
   self.assertEqual(len(rows),9)
   sample=[x for x in rows if x['date']=='2021-12-19'][0]
   self.assertEqual((sample['cushion'],sample['turf_goal'],sample['dirt_fourth']),(9.3,14.2,12.6))
   self.assertEqual(sample['source_basis'],'JRA_OFFICIAL_ARCHIVE_PDF_VISUAL_TRANSCRIPTION')
 def test_unverified_url_rejected(self):
  with self.assertRaises(RuntimeError):visually_verified_2021('東京',ROOT+'tokyo01.pdf','x')
 def test_changed_source_rejected(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t)/'scan.pdf';p.write_bytes(b'%PDF-1.4'+b'x'*1600)
   with patch('pdfplumber.open',return_value=FakeDoc()):
    with self.assertRaisesRegex(RuntimeError,'OFFICIAL_PDF_CHANGED'):
     visually_verified_2021('中京',ROOT+'chukyo06.pdf',p,previous_good_sha='0'*64)
 def test_provenance_preserved_in_sqlite(self):
  with sqlite3.connect(':memory:') as db:
   schema(db)
   with tempfile.TemporaryDirectory() as t:
    p=Path(t)/'scan.pdf';p.write_bytes(b'%PDF-1.4'+b'x'*1600)
    with patch('pdfplumber.open',return_value=FakeDoc()):
     rows=visually_verified_2021('中京',ROOT+'chukyo06.pdf',p)
   upsert_obs(db,rows)
   self.assertEqual(db.execute('select count(*) from official_track_daily').fetchone()[0],9)
   self.assertEqual(db.execute('select distinct source_basis from official_track_daily').fetchone()[0],
                    'JRA_OFFICIAL_ARCHIVE_PDF_VISUAL_TRANSCRIPTION')
 def test_ordinary_year_scope_not_modified(self):
  # The specialized fallback never triggers for an archive other than 2021.
  with self.assertRaises(RuntimeError):visually_verified_2021('阪神','https://www.jra.go.jp/keiba/baba/archive/2022pdf/hanshin02.pdf','x')

if __name__=='__main__':unittest.main()
