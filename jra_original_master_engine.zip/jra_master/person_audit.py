"""Field-level admission checks; nullable official IDs are reported separately."""
import json

INACTIVE = ('取消', '除外', 'SCRATCHED', 'EXCLUDED', 'CANCELLED')

def audit_people(c):
    missing_names = {'jockey': 0, 'trainer': 0}
    missing_ids = {'jockey': 0, 'trainer': 0}
    inactive_missing_names = {'jockey': 0, 'trainer': 0}
    examples = []
    for rid, no, raw, result in c.execute('''
        SELECT u.race_id,u.horse_number,u.payload_json,r.payload_json
        FROM runners u LEFT JOIN results r USING(race_id,horse_number)
        ORDER BY u.race_id,u.horse_number'''):
        row = json.loads(raw)
        status = json.loads(result or '{}').get('finish_status')
        for kind in ('jockey', 'trainer'):
            name = row.get(kind + '_name')
            if not isinstance(name, str) or not name.strip():
                target = inactive_missing_names if status in INACTIVE else missing_names
                target[kind] += 1
                if status not in INACTIVE and len(examples) < 20:
                    examples.append({'race_id': rid, 'horse_no': no, 'field': kind + '_name'})
            if not row.get(kind + '_id'):
                missing_ids[kind] += 1
    return dict(status='PASS' if not any(missing_names.values()) else 'MISSING_REQUIRED_NAMES',
                missing_active_names=missing_names,
                missing_official_ids=missing_ids,
                inactive_missing_names=inactive_missing_names,
                examples=examples,
                id_policy='No official profile link means unknown official ID; never fabricate. Model identity mapping requires separate validation.')
