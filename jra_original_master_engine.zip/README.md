# JRA 年別・原本MASTER

2018〜2026年を年度ごとに管理する、エンジン非依存のSQLite原本です。ASTERや別エンジンの入力はこの原本から別途作成します。レース結果・単勝最終オッズ・払戻・ラップ・通過順・出走馬・血統を同じDBに保存します。既存原本の対応は2024/2025型・2026型および本セットの2.0型です。2018〜2023年は実ファイルの構造確認が必要です。未知の形式は停止し、推測して移行しません。

## 保存のルール

- 年度ごとに `MASTER.sqlite3` を1つ。年度内は馬IDで共通管理。同一馬が別年度に入ることは許可します。
- 血統はJRAの父・母・母の父・母の母の4項目。同一年では再取得済みの馬を省略します。5代血統は収録しません。
- RAW本文は監査中の一時ファイルだけ。完了時・エラー時とも削除し、成果物や途中stateには入れません。
- 出典URL、本文ハッシュ、HTTP状態、実際の取得・応答・一時RAW保存・統合時刻、検証結果、修正履歴を残します。旧原本の不明時刻はNULLです。
- 欠損は欠損として保持。未取得・取得失敗・公式に記載なしを分けます。失敗は次回再開できます。
- レース・馬ID・馬名・馬番の一致とDB整合性を確認し、検証を通ったデータを統合します。
- 最終オッズは過去の締切前時点のオッズとは扱いません。予測やエンジン固有の特徴量は保存しません。
- 公式URLは実際の公式ページのリンクから取得。アクセス不能や403を「存在しない」と判定せず、未解決として残します。

## スマホからGitHubで使う

専用の非公開リポジトリを作り、ルートに `jra_original_master_engine.zip`、`.github/workflows/` に `jra_original_master.yml` を置きます。コードZIPの中身をスマホで1ファイルずつ登録する必要はありません。GitHubのWeb画面を使い、必要ならデスクトップ表示にします。

1. Actionsで本workflowを選び、Run workflow → `preflight` を実行。
2. 旧原本ZIPをReleaseの添付ファイルへ登録。例：タグ `inputs-2026`。RAWを含む旧原本は公開しないでください。
3. `year=2026`、`mode=bootstrap`、Releaseタグと元ZIPの正確な名前を入力。最初は `with_pedigree=false`。旧原本の構造化データを移します。
4. `mode=reaudit`、同じ元ZIPを指定して繰り返します。旧RAWで結果・オッズを再検証し、公式の馬ページのリンクも回収。初回は `with_pedigree=false`。完了済みの監査はスキップします。
5. `mode=pedigree`。例 `max_horses=500`。未取得分を取得し、同じ年のMASTERへ統合。件数上限や時間上限に達したら次回続きから実行します。
6. 実行結果のArtifact `jra-original-master-2026` をスマホへダウンロード。中の年別ZIPが新しい原本です。`AUDIT.json`で未取得・失敗・件数を確認。

途中stateは30日で期限が切れます。各回の年別ZIPは自分でダウンロードして保管してください。長く空く時は最新の年別ZIPをReleaseへ置き、stateがなくなった場合はそのZIPを入力に `bootstrap` で復元します。旧RAWでの監査が残っている場合は旧原本も保持します。

## 毎週の追加

`mode=update`、対象年、開始日と終了日を指定し、`with_pedigree=true`。レース・オッズを取得、検証、統合し、新しい馬の血統も取得します。前回の最終開催日から重ねて指定し、訂正確認が必要な週は `refresh=true`。公式ページで公開済みのデータが対象で、ライブオッズ配信ではありません。

新しい年には対象年の空のstateで `update` を開始します。毎回GitHubが途中stateを復元し、年別MASTERへ統合するため、通常はChatGPTへ毎週ファイルを渡す必要はありません。

自動の曜日スケジュールは設定していません。スマホで週ごとに実行してください。失敗時もstateと生成できた成果物を保存します。未完了の成果物は `PARTIAL` と表示します。

## 今ある原本の扱い

旧原本は最初にバックアップし、手作業でRAWだけを削除しないでください。`bootstrap` → `reaudit` → `pedigree` を進め、新原本の件数・元の構造化項目・出典情報・未解決リスト・SQLite整合性を確認してから置き換えます。原本から運用用の重複表や旧DBをそのままコピーせず、対応した主要表の各行を `payload_json` に保持します。旧ファイルに独自追加表がある場合は移行前に確認してください。

RAWの再監査が済んでいない段階で旧RAWを削除すると、その本文を使った再監査はできなくなります。新原本の承認後、旧RAW付きZIPは運用から外し、必要な復元期間だけ別に保管します。

## 手元実行・検証

Python 3.11以上。`pip install .` の後：

```sh
python -m unittest discover -s tests -v
python -m jra_master.cli --year 2026 --mode preflight
python -m jra_master.cli --year 2026 --mode bootstrap --input OLD.zip
python -m jra_master.cli --year 2026 --mode reaudit --input OLD.zip
python -m jra_master.cli --year 2026 --mode pedigree --max-horses 500
python -m jra_master.cli --year 2026 --mode update --start 2026-09-20 --end 2026-09-27 --with-pedigree
```

このセットのテストはオフライン検証です。全年度取得、全馬の血統取得、GitHub Actionsの実稼働を完了したものではありません。サイト構造や公開範囲の変更時には更新が必要です。JRAの利用条件とアクセス制約を守り、403等を回避する認証偽装は行いません。
