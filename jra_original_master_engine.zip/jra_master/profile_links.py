"""Observed official URL references only; pedigree requires the existing body validator."""
import re
from urllib.parse import urlparse,parse_qs
from .store import encode,now
OBSERVED=[('2015103357', 'メイショウドウドウ', 'https://www.jra.go.jp/JRADB/accessU.html?CNAME=pw01dud102015103357%2FCB'), ('2016103092', 'コルドゥーン', 'https://www.jra.go.jp/JRADB/accessU.html?CNAME=pw01dud102016103092%2FC5'), ('2017104698', 'ジロー', 'https://www.jra.go.jp/JRADB/accessU.html?CNAME=pw01dud102017104698%2F18'), ('2017106222', 'ベッサラビア', 'https://www.jra.go.jp/JRADB/accessU.html?CNAME=pw01dud102017106222%2F10'), ('2018105478', 'ヴァリアメンテ', 'https://www.jra.go.jp/JRADB/accessU.html?CNAME=pw01dud102018105478%2F11'), ('2019106387', 'トップスティール', 'https://www.jra.go.jp/JRADB/accessU.html?CNAME=pw01dud102019106387%2FF8'), ('2020100903', 'サンデーヒーロー', 'https://www.jra.go.jp/JRADB/accessU.html?CNAME=pw01dud102020100903%2FB7'), ('2020103535', 'アルファインディ', 'https://www.jra.go.jp/JRADB/accessU.html?CNAME=pw01dud102020103535%2FD6'), ('2020105049', 'ハヤブサジェット', 'https://www.jra.go.jp/JRADB/accessU.html?CNAME=pw01dud102020105049%2F9B'), ('2021104934', 'シュウズダイヤ', 'https://www.jra.go.jp/JRADB/accessU.html?CNAME=pw01dud102021104934%2FA2')]

OBSERVED += [('2014105681','アメリカズカップ','https://www.jra.go.jp/JRADB/accessU.html?CNAME=pw01dud102014105681%2F2E'),('2015103488','シゲルシイタケ','https://www.jra.go.jp/JRADB/accessU.html?CNAME=pw01dud102015103488%2F9F'),('2018102781','ワンダースキル','https://www.jra.go.jp/JRADB/accessU.html?CNAME=pw01dud102018102781%2FC2'),('2018104096','トーヨーヒヨウ','https://www.jra.go.jp/JRADB/accessU.html?CNAME=pw01dud102018104096%2F98')]

def supplement(s):
 added=0
 for hid,name,url in OBSERVED:
  horse=s.c.execute('SELECT horse_name FROM horses WHERE horse_id=?',(hid,)).fetchone()
  if not horse or horse[0]!=name:continue
  if s.c.execute('SELECT 1 FROM pedigree_receipts WHERE horse_id=?',(hid,)).fetchone():continue
  key='horse_profile_'+hid
  if s.c.execute('SELECT 1 FROM metadata WHERE key=?',(key,)).fetchone():continue
  u=urlparse(url);cname=(parse_qs(u.query).get('CNAME') or [''])[0]
  match=re.fullmatch(r'pw01dud(?:00|10)(\d{10})/[0-9A-F]{2}',cname)
  if u.scheme!='https' or u.hostname!='www.jra.go.jp' or u.path!='/JRADB/accessU.html' or not match or match[1]!=hid:raise ValueError('SUPPLEMENT_PROFILE_URL_ID_MISMATCH')
  with s.c:
   sid=s.source({'source_id':'OFFICIAL_PROFILE_REFERENCE_'+hid,'service':'JRA','role':'DISCOVERED_PROFILE_REFERENCE','url':url,'raw_state':'REFERENCE_ONLY','integrated_at':now(),'discovery_date_jst':'2026-10-02','horse_id':hid,'expected_name':name,'body_validation':'PENDING_GITHUB_FETCH; search text not used as pedigree','observed_via':'web search; site:jra.go.jp horse name'})
   record={'key':key,'value':encode(url)}
   s.put('metadata',['key'],record,sid,'OBSERVED_OFFICIAL_PROFILE_LINK_SUPPLEMENT')
   s.c.execute('INSERT INTO revisions(table_name,item_key,old_json,new_json,source_id,reason,corrected_at) VALUES (?,?,?,?,?,?,?)',('metadata',encode({'key':key}),None,encode(record),sid,'OBSERVED_OFFICIAL_PROFILE_LINK_SUPPLEMENT',now()))
  added+=1
 return added
