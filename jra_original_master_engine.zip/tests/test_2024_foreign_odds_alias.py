"""Regression for the two 2024 official-name vs historical display-name mismatches.

These are deliberately identity-bound aliases; no generic prefix or length rule.
Tests use synthetic odds HTML, not downloaded official pages.
"""
import tempfile
import unittest
from jra_master.racing import _official_odds_name_matches, integrate_odds
from jra_master.store import Store


class ForeignOddsAliases2024(unittest.TestCase):
    cases = [
        ('2018190002', 'ロマンチックウォリアー', 'ロマンチックウォリ'),
        ('2020190004', 'ファンタスティックムーン', 'ファンタスティック'),
    ]

    def test_exact_aliases(self):
        for hid, full, short in self.cases:
            with self.subTest(hid=hid):
                self.assertTrue(_official_odds_name_matches(hid, full, short))
                self.assertTrue(_official_odds_name_matches(hid, full, full))
                self.assertFalse(_official_odds_name_matches(hid + '9', full, short))
                self.assertFalse(_official_odds_name_matches(hid, full, short[:-1]))
                self.assertFalse(_official_odds_name_matches(hid, '別の馬', short))

    @staticmethod
    def html(horses):
        body = '<html><body>最終オッズ 単勝・複勝オッズ <table class="tanpuku"><tbody>'
        body += ''.join(
            f'<tr><td class="num">{num}</td><td class="horse">{name}</td><td class="odds_tan">{odds:.1f}</td></tr>'
            for num, name, odds in horses
        )
        return (body + '</tbody></table></body></html>').encode('cp932')

    def test_integration_accepts_aliases_and_rejects_wrong_identity(self):
        for hid, full, short in self.cases:
            with self.subTest(hid=hid), tempfile.TemporaryDirectory() as d:
                s = Store(d + '/test.sqlite3')
                rid = '2024-06-02-東京-11'
                s.c.execute('INSERT INTO races (race_id,race_date,track,race_number,race_type,payload_json) VALUES (?,?,?,?,?,?)', (rid, '2024-06-02', '東京', 11, 'FLAT', '{}'))
                s.c.execute('INSERT INTO horses (horse_id, horse_name) VALUES (?,?)', (hid, full))
                s.c.execute('INSERT INTO horses (horse_id, horse_name) VALUES (?,?)', ('2024100999', '比較用競走馬'))
                s.c.execute('INSERT INTO runners (race_id,horse_number,horse_id,payload_json) VALUES (?,?,?,?)', (rid, 7, hid, '{}'))
                s.c.execute('INSERT INTO runners (race_id,horse_number,horse_id,payload_json) VALUES (?,?,?,?)', (rid, 8, '2024100999', '{}'))
                s.source({'source_id':'synthetic_2024_odds','service':'TEST','role':'FINAL_WIN_ODDS','raw_state':'SYNTHETIC'})
                s.c.commit()
                valid = self.html([(7, short, 3.6), (8, '比較用競走馬', 8.9)])
                self.assertEqual(integrate_odds(s,valid,'synthetic_2024_odds',rid),2)
                self.assertEqual([x[0] for x in s.c.execute('SELECT win_odds FROM win_odds WHERE race_id=? ORDER BY horse_number',(rid,))], [3.6,8.9])
                wrong = self.html([(7, '別の馬', 3.6), (8, '比較用競走馬', 8.9)])
                with self.assertRaisesRegex(ValueError,'ODDS_HORSE_NAME_MISMATCH: horse_no=7 horse_id='+hid):
                    integrate_odds(s,wrong,'synthetic_2024_odds',rid)
                self.assertEqual(s.c.execute('SELECT count(*) FROM win_odds WHERE race_id=?',(rid,)).fetchone()[0],2)
                s.c.close()

if __name__ == '__main__':
    unittest.main()
