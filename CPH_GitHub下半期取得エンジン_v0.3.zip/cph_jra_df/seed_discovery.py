from __future__ import annotations

import re
from datetime import datetime
from urllib.parse import quote

from .fetcher import fetch, fetch_post_form, read_snapshot_bytes
from .pipeline import now
from .parser import discover_result_urls


class SeedDiscoveryFailure(RuntimeError):
    pass


ENTRY_URL = "https://www.jra.go.jp/JRADB/accessS.html"
ENTRY_FORM = "cname=pw01skl00999999%2FB3"


def decode_html(body: bytes) -> str:
    for encoding in ("cp932", "shift_jis", "utf-8"):
        try:
            return body.decode(encoding)
        except UnicodeDecodeError:
            pass
    raise SeedDiscoveryFailure("RESULT_SEARCH_DECODE_FAILED")


def parse_month_token(body: bytes, year: int, month: int) -> str:
    text = decode_html(body)
    key = f"{year % 100:02d}{month:02d}"
    match = re.search(rf'objParam\["{key}"\]="([0-9A-F]{{2}})"', text)
    if not match:
        raise SeedDiscoveryFailure("RESULT_MONTH_TOKEN_NOT_FOUND")
    return match.group(1)


def result_month_cname(year: int, month: int, token: str) -> str:
    return f"pw01skl10{year:04d}{month:02d}/{token}"


def parse_meeting_cname(body: bytes, race_date: str) -> str:
    text = decode_html(body)
    ymd = race_date.replace("-", "")
    matches = sorted(set(re.findall(rf"(pw01srl[0-9]+{ymd}/[0-9A-F]{{2}})", text)))
    if not matches:
        raise SeedDiscoveryFailure("RESULT_SEED_NOT_FOUND_FOR_DATE")
    return matches[0]


class SeedDiscovery:
    def __init__(self, pipeline):
        self.pipeline = pipeline
        self.conn = pipeline.conn
        self.root = pipeline.root

    def discover(self, race_date: str, cache_only: bool = False) -> dict:
        try:
            date = datetime.strptime(race_date, "%Y-%m-%d")
        except ValueError as exc:
            raise SeedDiscoveryFailure("RACE_DATE_INVALID") from exc
        if date.year * 100 + date.month >= int(datetime.now().strftime("%Y%m")):
            raise SeedDiscoveryFailure("RESULT_MONTH_NOT_HISTORICAL_COMPLETE")
        entry = fetch_post_form(self.conn, self.root, ENTRY_URL, "RESULT_SEARCH_ENTRY",
                                ENTRY_FORM, cache_only)
        token = parse_month_token(read_snapshot_bytes(entry), date.year, date.month)
        month_cname = result_month_cname(date.year, date.month, token)
        index = fetch_post_form(self.conn, self.root, ENTRY_URL, "RESULT_MONTH_INDEX",
                                "cname=" + quote(month_cname, safe=""), cache_only)
        cname = parse_meeting_cname(read_snapshot_bytes(index), race_date)
        selection = fetch_post_form(self.conn, self.root, ENTRY_URL, "RESULT_RACE_SELECTION",
                                    "cname=" + quote(cname, safe=""), cache_only)
        result_urls = discover_result_urls(read_snapshot_bytes(selection), race_date)
        if not result_urls:
            raise SeedDiscoveryFailure("RESULT_DETAIL_URL_NOT_FOUND")
        seed_url = result_urls[sorted(result_urls)[0]]
        self.conn.execute(
            "INSERT OR REPLACE INTO result_seed_urls VALUES(?,?,?,?,?,?,?)",
            (race_date, seed_url, cname, entry.snapshot_id, index.snapshot_id, selection.snapshot_id, now()),
        )
        self.conn.execute(
            "UPDATE year_seed_items SET status='PASS',seed_url=?,completed_at=?,reason_codes_json='[]' "
            "WHERE race_date=?", (seed_url, now(), race_date),
        )
        self.conn.commit()
        return {"status": "PASS", "race_date": race_date, "seed_url": seed_url,
                "meeting_cname": cname, "month_token": token,
                "entry_snapshot_id": entry.snapshot_id, "month_index_snapshot_id": index.snapshot_id,
                "race_selection_snapshot_id": selection.snapshot_id,
                "mode": "CACHE_ONLY" if cache_only else "ONLINE",
                "network_request_count": int(not entry.from_cache) + int(not index.from_cache) + int(not selection.from_cache)}
