import base64,hashlib,tempfile,unittest,zipfile
from pathlib import Path
from jra_master.store import Store
from jra_master.reuse import reuse_embedded_pedigree
from jra_master.cli import export,main
from unittest.mock import patch

class EmbeddedReuseTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
  d=Store(self.root/'d.sqlite3');d.meta('year',2016)
  d.c.execute("insert into horses values ('H','Horse')")
  d.meta('horse_identity_H',{'horse_id':'H','horse_name':'Horse'})
  sid=d.source({'source_id':'S','service':'JRA','role':'JRA_PEDIGREE_FOUR_FIELDS','entity_sha256':'a'*64,'http_status':200,'requested_at':'2026-10-03T01:00:00Z','raw_saved_at':None})
  for p in ['S','M','MS','MM']:d.c.execute('insert into pedigree values (?,?,?,?,?,?,?,?)',('H',p,len(p),None,'Ancestor',None,sid,'KNOWN'))
  d.c.execute("insert into pedigree_receipts values ('H','S',4,'PASS')");d.c.commit();d.c.close()
  z=self.root/'donor.zip'
  with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as f:f.write(self.root/'d.sqlite3','MASTER.sqlite3')
  b=z.read_bytes();self.cache={'zip_sha256':hashlib.sha256(b).hexdigest(),'zip_base64':base64.b64encode(b).decode()}
  self.s=Store(self.root/'t.sqlite3');self.s.meta('year',2015);self.s.meta('embedded_pedigree_donor_2016',self.cache)
 def tearDown(self):self.s.c.close();self.tmp.cleanup()
 def test_observed_only_idempotent_and_times(self):
  self.assertEqual(reuse_embedded_pedigree(self.s),[])
  self.assertEqual(self.s.c.execute('select count(*) from horses').fetchone()[0],0)
  self.s.c.execute("insert into horses values ('H','Horse')");self.s.c.commit()
  self.assertEqual(reuse_embedded_pedigree(self.s)[0]['copied_horses'],1)
  self.assertEqual(reuse_embedded_pedigree(self.s),[])
  self.assertEqual(tuple(self.s.c.execute('select requested_at,raw_saved_at from source_records').fetchone()),('2026-10-03T01:00:00Z',None))
  self.assertEqual(self.s.c.execute('pragma foreign_key_check').fetchall(),[])
 def test_mismatch_and_corrupt_cache(self):
  self.s.c.execute("insert into horses values ('H','Other')");self.s.c.commit()
  self.assertEqual(reuse_embedded_pedigree(self.s)[0]['name_conflicts_skipped'],['H'])
  bad=dict(self.cache);bad['zip_sha256']='bad';self.s.meta('embedded_pedigree_donor_2016',bad)
  with self.assertRaisesRegex(ValueError,'HASH_MISMATCH'):reuse_embedded_pedigree(self.s)
 def test_state_retains_cache_export_omits(self):
  self.s.task('FRESH_MONTH_2015_01_2015-01-01_2015-12-31','PENDING')
  export(self.s,self.root/'out',2015)
  self.assertIsNotNone(self.s.c.execute("select value from metadata where key='embedded_pedigree_donor_2016'").fetchone())
  from jra_master.importer import Archive,bootstrap
  a=Archive(next((self.root/'out').glob('*.zip')))
  self.assertEqual(a.c.execute("select count(*) from metadata where key like 'embedded_pedigree_donor_%'").fetchone()[0],0);a.close()
  with zipfile.ZipFile(self.root/'starter.zip','w') as z:z.write(self.s.path,'MASTER.sqlite3')
  restored=Store(self.root/'restored.sqlite3');bootstrap(restored,self.root/'starter.zip',2015)
  self.assertIsNotNone(restored.c.execute("select value from metadata where key='embedded_pedigree_donor_2016'").fetchone());restored.c.close()
 def test_update_reuses_before_fetching_pedigree(self):
  def collect(s,*args):s.c.execute("insert into horses values ('H','Horse')");s.c.commit();return {}
  def pedigree(s,*args):self.assertEqual(s.c.execute('select count(*) from pedigree_receipts').fetchone()[0],1);return {}
  with patch('jra_master.fresh.collect',side_effect=collect),patch('jra_master.pedigree.collect',side_effect=pedigree):
   self.assertEqual(main(['--year','2015','--db',str(self.s.path),'--mode','update','--with-pedigree','--output',str(self.root/'out')]),0)
