#!/usr/bin/env python3
import argparse
import json
import sqlite3
from pathlib import Path


SCHEMA = """
CREATE TABLE win_odds (
  race_key TEXT NOT NULL, race_date TEXT NOT NULL, track TEXT NOT NULL,
  race_no INTEGER NOT NULL, horse_no INTEGER NOT NULL, horse_name TEXT NOT NULL,
  final_win_odds REAL, status TEXT NOT NULL, result_url TEXT NOT NULL,
  odds_cname TEXT NOT NULL, raw_sha256 TEXT NOT NULL, fetched_at_utc TEXT NOT NULL,
  PRIMARY KEY (race_key, horse_no)
);
CREATE INDEX idx_win_odds_race ON win_odds(race_date, track, race_no);
CREATE TABLE metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL);
"""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", type=Path, required=True)
    ap.add_argument("--output", type=Path, required=True)
    args = ap.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    target = args.output / "2025_JRA全馬単勝最終オッズ.sqlite3"
    if target.exists():
        target.unlink()
    out = sqlite3.connect(target)
    out.executescript(SCHEMA)
    sources = sorted(args.input.rglob("2025_*_単勝最終オッズ.sqlite3"))
    if len(sources) != 12:
        raise SystemExit(f"MONTH_DATABASE_COUNT:{len(sources)}")
    for source in sources:
        src = sqlite3.connect(source)
        rows = src.execute("SELECT * FROM win_odds").fetchall()
        errors = src.execute("SELECT COUNT(*) FROM collection_errors").fetchone()[0]
        if errors:
            raise SystemExit(f"MONTH_HAS_ERRORS:{source}:{errors}")
        out.executemany("INSERT INTO win_odds VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", rows)
        src.close()
    count = out.execute("SELECT COUNT(*) FROM win_odds").fetchone()[0]
    races = out.execute("SELECT COUNT(DISTINCT race_key) FROM win_odds").fetchone()[0]
    numeric = out.execute("SELECT COUNT(*) FROM win_odds WHERE final_win_odds IS NOT NULL").fetchone()[0]
    out.executemany("INSERT INTO metadata VALUES (?,?)", [
        ("year", "2025"), ("source", "JRA official final odds pages"),
        ("scope", "all horses final win odds"),
    ])
    integrity = out.execute("PRAGMA integrity_check").fetchone()[0]
    out.commit(); out.close()
    report = {"status":"PASS", "year":2025, "race_count":races,
              "horse_rows":count, "numeric_odds_rows":numeric, "integrity_check":integrity}
    (args.output / "2025_単勝最終オッズ監査結果.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False))


if __name__ == "__main__":
    main()
