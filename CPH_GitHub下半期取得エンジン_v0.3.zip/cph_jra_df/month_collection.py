from __future__ import annotations

import hashlib
import json

from .pipeline import now
from .seed_discovery import SeedDiscovery
from .year_day_import import YearDayImporter


class MonthCollectionFailure(RuntimeError):
    pass


class MonthCollector:
    """Checkpointed SEED -> full-day IMPORT for one calendar month."""

    def __init__(self, pipeline, max_total_bytes: int = 4 * 1024**3,
                 reserve_free_bytes: int = 256 * 1024**2):
        self.pipeline = pipeline
        self.conn = pipeline.conn
        self.importer = YearDayImporter(pipeline, max_total_bytes, reserve_free_bytes)

    def ensure_plan(self, year: int, month: int) -> str:
        if month < 1 or month > 12:
            raise MonthCollectionFailure("MONTH_OUT_OF_RANGE")
        manifest = self.conn.execute(
            "SELECT manifest_id FROM year_schedule_manifests WHERE year=? ORDER BY created_at DESC LIMIT 1", (year,)
        ).fetchone()
        if manifest is None:
            raise MonthCollectionFailure("YEAR_MANIFEST_NOT_FOUND")
        days = self.conn.execute(
            "SELECT race_date FROM year_race_days WHERE manifest_id=? AND race_date LIKE ? ORDER BY race_date",
            (manifest["manifest_id"], f"{year:04d}-{month:02d}-%"),
        ).fetchall()
        if not days:
            raise MonthCollectionFailure("MONTH_HAS_NO_RACE_DAYS")
        digest = hashlib.sha256(f"{manifest['manifest_id']}|MONTH-COLLECT|{month:02d}".encode()).hexdigest()
        plan_id = f"MONTH-COLLECT-{year}-{month:02d}-{digest[:12]}"
        stamp = now()
        self.conn.execute(
            "INSERT OR IGNORE INTO month_collection_runs VALUES(?,?,?,?,?,?,?,?)",
            (plan_id, year, month, manifest["manifest_id"], stamp, stamp, "PLANNED", len(days)),
        )
        self.conn.executemany(
            "INSERT OR IGNORE INTO month_collection_items"
            "(plan_id,race_date,ordinal,status,phase) VALUES(?,?,?,'PENDING','PENDING')",
            [(plan_id, row["race_date"], i) for i, row in enumerate(days, 1)],
        )
        # Adopt already completed daily imports without fetching or parsing again.
        self.conn.execute(
            "UPDATE month_collection_items SET status='PASS',phase='COMPLETE',completed_at=? "
            "WHERE plan_id=? AND EXISTS (SELECT 1 FROM pipeline_runs p WHERE p.race_date=month_collection_items.race_date "
            "AND p.status='PASS' AND p.stage='AUDIT' AND p.mode IN ('ONLINE','CACHE_ONLY'))",
            (stamp, plan_id),
        )
        self.conn.commit()
        return plan_id

    def run(self, year: int, month: int, max_dates_this_run: int = 1,
            cache_only: bool = False, retry_failed: bool = False) -> dict:
        if max_dates_this_run < 1 or max_dates_this_run > 31:
            raise MonthCollectionFailure("MAX_DATES_THIS_RUN_OUT_OF_RANGE")
        plan_id = self.ensure_plan(year, month)
        stamp = now()
        # The month runner is single-writer. Any RUNNING daily pipeline from a
        # previous invocation is therefore an interrupted attempt, not live work.
        self.conn.execute(
            "UPDATE pipeline_runs SET status='FAIL',completed_at=?,reason_codes_json=? "
            "WHERE status='RUNNING' AND race_date IN "
            "(SELECT race_date FROM month_collection_items WHERE plan_id=?)",
            (stamp, json.dumps(["INTERRUPTED_RUN_RECOVERED"]), plan_id),
        )
        self.conn.execute(
            "UPDATE month_collection_items SET status='PENDING',phase='PENDING',completed_at=?,reason_codes_json=? "
            "WHERE plan_id=? AND status='RUNNING'",
            (stamp, json.dumps(["INTERRUPTED_RUN_RECOVERED"]), plan_id),
        )
        statuses = "'PENDING','FAIL'" if retry_failed else "'PENDING'"
        rows = self.conn.execute(
            f"SELECT race_date FROM month_collection_items WHERE plan_id=? AND status IN ({statuses}) "
            "ORDER BY ordinal LIMIT ?", (plan_id, max_dates_this_run),
        ).fetchall()
        self.conn.execute("UPDATE month_collection_runs SET status='RUNNING',updated_at=? WHERE plan_id=?", (now(), plan_id))
        self.conn.commit()
        passed = failed = 0
        for row in rows:
            race_date = row["race_date"]
            self.conn.execute(
                "UPDATE month_collection_items SET status='RUNNING',phase='SEED',attempts=attempts+1,"
                "started_at=?,completed_at=NULL,reason_codes_json='[]' WHERE plan_id=? AND race_date=?",
                (now(), plan_id, race_date),
            )
            self.conn.commit()
            try:
                if self.conn.execute("SELECT 1 FROM result_seed_urls WHERE race_date=?", (race_date,)).fetchone() is None:
                    SeedDiscovery(self.pipeline).discover(race_date, cache_only=cache_only)
                else:
                    self.conn.execute(
                        "UPDATE year_seed_items SET status='PASS',seed_url=(SELECT seed_url FROM result_seed_urls "
                        "WHERE race_date=?),completed_at=?,reason_codes_json='[]' WHERE race_date=?",
                        (race_date, now(), race_date),
                    )
                    self.conn.commit()
                self.conn.execute(
                    "UPDATE month_collection_items SET phase='IMPORT' WHERE plan_id=? AND race_date=?",
                    (plan_id, race_date),
                )
                self.conn.commit()
                result = self.importer.run(race_date, cache_only=cache_only)
                self.conn.execute(
                    "UPDATE month_collection_items SET status='PASS',phase='COMPLETE',pipeline_run_id=?,"
                    "completed_at=?,reason_codes_json='[]' WHERE plan_id=? AND race_date=?",
                    (result["run_id"], now(), plan_id, race_date),
                )
                self.conn.commit()
                passed += 1
            except Exception as exc:
                reasons = getattr(exc, "reasons", [str(exc) or type(exc).__name__])
                self.conn.execute(
                    "UPDATE month_collection_items SET status='FAIL',completed_at=?,reason_codes_json=? "
                    "WHERE plan_id=? AND race_date=?",
                    (now(), json.dumps(reasons, ensure_ascii=False), plan_id, race_date),
                )
                self.conn.commit()
                failed += 1
        report = self.audit(year, month, plan_id)
        status = "PASS" if report["pass_count"] == report["expected_dates"] else "PARTIAL"
        self.conn.execute("UPDATE month_collection_runs SET status=?,updated_at=? WHERE plan_id=?", (status, now(), plan_id))
        self.conn.commit()
        return {**self.audit(year, month, plan_id), "processed_this_run": len(rows),
                "passed_this_run": passed, "failed_this_run": failed,
                "max_dates_this_run": max_dates_this_run,
                "mode": "CACHE_ONLY" if cache_only else "ONLINE"}

    def audit(self, year: int, month: int, plan_id: str | None = None) -> dict:
        if plan_id is None:
            row = self.conn.execute(
                "SELECT plan_id FROM month_collection_runs WHERE year=? AND month=? ORDER BY created_at DESC LIMIT 1",
                (year, month),
            ).fetchone()
            if row is None:
                raise MonthCollectionFailure("MONTH_PLAN_NOT_FOUND")
            plan_id = row["plan_id"]
        plan = self.conn.execute("SELECT * FROM month_collection_runs WHERE plan_id=?", (plan_id,)).fetchone()
        counts = {r["status"]: r["n"] for r in self.conn.execute(
            "SELECT status,COUNT(*) n FROM month_collection_items WHERE plan_id=? GROUP BY status", (plan_id,))}
        total = sum(counts.values())
        reasons = [] if total == plan["expected_dates"] else ["MONTH_ITEM_COUNT_MISMATCH"]
        return {"status": plan["status"], "audit_status": "PASS" if not reasons else "FAIL",
                "reason_codes": reasons, "plan_id": plan_id, "year": year, "month": month,
                "expected_dates": plan["expected_dates"], "item_count": total,
                "pass_count": counts.get("PASS", 0), "pending_count": counts.get("PENDING", 0),
                "fail_count": counts.get("FAIL", 0), "running_count": counts.get("RUNNING", 0)}
