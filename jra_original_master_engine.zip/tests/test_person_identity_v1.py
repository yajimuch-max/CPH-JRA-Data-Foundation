import unittest
from jra_master.person_identity import build_catalogue,resolve,target_catalogue

class PersonIdentityTests(unittest.TestCase):
 def row(self,name,pid,day='2024-01-01',role='jockey'):return dict(name=name,official_id=pid,race_date=day,role=role)
 def test_fullwidth_names_and_spaced_alias_resolve_to_same_known_id(self):
  c=build_catalogue([self.row('C.デムーロ','5473')],'2025-12-31')
  self.assertEqual(resolve('jockey',None,'Ｃ． デムーロ',c)['key'],'JRA_ID:jockey:5473')
  self.assertIsNone(resolve('jockey',None,'C.デムーロ',c)['official_id'])
 def test_same_id_keeps_name_change_history_together(self):
  c=build_catalogue([self.row('岩崎 翼','1146'),self.row('和田 翼','1146')],'2025-12-31')
  self.assertEqual(resolve('jockey',None,'岩崎翼',c)['key'],resolve('jockey',None,'和田翼',c)['key'])
 def test_multiple_ids_for_one_display_name_do_not_get_guessed(self):
  c=build_catalogue([self.row('A.テスト','1111'),self.row('A.テスト','2222')],'2025-12-31')
  x=resolve('jockey',None,'A.テスト',c);self.assertIsNone(x['key']);self.assertEqual(x['status'],'AMBIGUOUS_NAME')
 def test_foreign_name_only_does_not_invent_official_id(self):
  c=build_catalogue([],'2025-12-31');x=resolve('jockey',None,'R.ムーア',c)
  self.assertEqual(x['status'],'NAME_ONLY');self.assertIsNone(x['official_id'])
 def test_missing_people_do_not_share_a_real_person_key(self):
  c=build_catalogue([],'2025-12-31');self.assertIsNone(resolve('jockey',None,None,c)['key'])
 def test_future_year_is_excluded_from_identity_fit(self):
  c=build_catalogue([self.row('C.デムーロ','5473','2026-01-01')],'2025-12-31')
  self.assertEqual(c['excluded_future_rows'],1);self.assertEqual(resolve('jockey',None,'C.デムーロ',c)['status'],'NAME_ONLY')
 def test_official_id_name_conflict_is_rejected(self):
  c=build_catalogue([self.row('C.デムーロ','5473')],'2025-12-31')
  with self.assertRaisesRegex(ValueError,'PERSON_ID_NAME_CONFLICT'):resolve('jockey','5212','C.デムーロ',c)
 def test_roles_do_not_collide(self):
  c=build_catalogue([],'2025-12-31')
  self.assertNotEqual(resolve('jockey','1111','A',c)['key'],resolve('trainer','1111','A',c)['key'])
 def test_float_or_fabricated_ids_are_rejected(self):
  c=build_catalogue([],'2025-12-31')
  for pid in [5473.0,'NAME:ムーア','5473.0']:
   with self.assertRaises(ValueError):resolve('jockey',pid,'C.デムーロ',c)
 def test_catalogue_ignores_result_fields(self):
  a=self.row('C.デムーロ','5473');b=a|dict(finish_position=17,payout=100000)
  self.assertEqual(build_catalogue([a],'2025-12-31'),build_catalogue([b],'2025-12-31'))
 def test_observed_target_id_can_connect_past_name_only_history(self):
  c=build_catalogue([self.row('C.デムーロ',None)],'2025-12-31')
  target=[dict(jockey_name='C.デムーロ',jockey_id='5473',finish_position=17)]
  d=target_catalogue(c,target,'2026-11-01T14:40:00+09:00','2026-11-01T14:42:00+09:00')
  self.assertEqual(resolve('jockey',None,'C.デムーロ',d)['key'],resolve('jockey','5473','C.デムーロ',d)['key'])
  self.assertNotIn('C.デムーロ',c['aliases']['jockey'])
 def test_late_target_metadata_is_rejected(self):
  c=build_catalogue([],'2025-12-31')
  with self.assertRaisesRegex(ValueError,'PERSON_CARD_NOT_AVAILABLE_AT_DECISION'):target_catalogue(c,[],'2026-11-01T14:43:00+09:00','2026-11-01T14:42:00+09:00')
 def test_target_pair_does_not_erase_historical_name_ambiguity(self):
  c=build_catalogue([self.row('A.テスト','1111'),self.row('A.テスト','2222')],'2025-12-31')
  d=target_catalogue(c,[dict(jockey_name='A.テスト',jockey_id='1111')],'2026-01-01T09:00:00+09:00','2026-01-01T10:00:00+09:00')
  self.assertEqual(resolve('jockey',None,'A.テスト',d)['status'],'AMBIGUOUS_NAME')
