from __future__ import annotations
import argparse
import re
from pathlib import Path

MONTHS = [f"{m:02d}" for m in range(1, 13)]

def fail(msg: str) -> None:
    raise SystemExit("PREFLIGHT_FAIL: " + msg)

def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--repo-root", required=True)
    p.add_argument("--year", required=True)
    a = p.parse_args()
    year = a.year
    root = Path(a.repo_root)

    engine_name = f"cph_jra_{year}_integrated_engine.zip"
    monthly_name = f"jra_monthly_component_{year}.yml"
    annual_name = f"jra_{year}_annual_integrated.yml"

    engine_path = root / engine_name
    monthly_path = root / ".github" / "workflows" / monthly_name
    annual_path = root / ".github" / "workflows" / annual_name
    for path in (engine_path, monthly_path, annual_path):
        if not path.is_file():
            fail(f"required file missing: {path.relative_to(root)}")

    monthly = monthly_path.read_text(encoding="utf-8")
    annual = annual_path.read_text(encoding="utf-8")

    if engine_name not in monthly:
        fail("monthly workflow engine reference does not exactly match engine ZIP name")
    if engine_name not in annual:
        fail("annual workflow engine reference does not exactly match engine ZIP name")
    if monthly_name not in annual:
        fail("annual workflow reusable-workflow reference does not exactly match monthly filename")

    # State chain must be 01 -> 02 -> ... -> 11 with no gaps.
    for month in MONTHS[1:]:
        prev = f"{int(month)-1:02d}"
        expected = f'previous_state: "cph-jra-{year}-{prev}-state"'
        if expected not in annual:
            fail(f"previous-state chain mismatch before month {month}: {expected}")

    expected_annual_base = f"cph-jra-{year}-annual-base"
    monthly_annual_base = "cph-jra-${{ inputs.year }}-annual-base"
    if monthly_annual_base not in monthly or annual.count(expected_annual_base) < 2:
        fail("annual-base artifact producer/consumers are not aligned")

    odds_pattern = f"jra-{year}-win-odds-month-"
    if annual.count(odds_pattern) < 2:
        fail("monthly odds artifact producer/consumer names are not aligned")

    final_artifact = f"{year}_JRA公式データ_年間統合版"
    if final_artifact not in annual:
        fail("final artifact name mismatch")

    # Enforce intended job order/dependencies.
    required_edges = [
        ("february", "january"), ("march", "february"), ("april", "march"),
        ("may", "april"), ("june", "may"), ("july", "june"),
        ("august", "july"), ("september", "august"), ("october", "september"),
        ("november", "october"), ("december", "november"),
    ]
    for job, need in required_edges:
        block = re.search(rf"(?ms)^  {job}:\n(.*?)(?=^  [A-Za-z0-9_-]+:\n|\Z)", annual)
        if not block or f"needs: {need}" not in block.group(1):
            fail(f"job dependency mismatch: {job} must need {need}")

    if "needs: december" not in annual:
        fail("odds collection must wait for December annual-base creation")
    if "needs: [december, collect-odds]" not in annual:
        fail("final integration must wait for annual-base and all odds jobs")

    print("PREFLIGHT_PASS")
    print(f"year={year}")
    print(f"engine={engine_name}")
    print(f"monthly={monthly_name}")
    print(f"annual={annual_name}")
    print(f"final_artifact={final_artifact}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
