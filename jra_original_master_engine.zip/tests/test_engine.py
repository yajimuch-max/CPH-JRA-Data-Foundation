import unittest,tempfile,json,sqlite3,zipfile
from pathlib import Path
from jra_master.store import Store,now
from jra_master.pedigree import parse,FIELDS
from jra_master.racing import integrate_odds
from jra_master.cli import export
from jra_master.network import Client,Deferred,FetchError
class Tests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);self.s=Store(self.root/'MASTER.sqlite3');self.s.c.execute("INSERT INTO races VALUES ('R','2026-01-01','TEST',1,'FLAT','{}')");self.s.c.execute("INSERT INTO horses VALUES ('H','TEST HORSE')");self.s.c.execute("INSERT INTO runners VALUES ('R',1,'H','{}')");self.s.c.execute("INSERT INTO results VALUES ('R',1,'{}')");self.s.c.execute("INSERT INTO win_odds VALUES ('R',1,8.8,'OK',NULL,'{}')");self.s.c.commit()
 def tearDown(self):self.s.c.close();self.tmp.cleanup()
 def odds(self,name='TEST HORSE',no=1):return f'<html><body>最終オッズ 単勝・複勝オッズ<table class="tanpuku"><tbody><tr><td class="num">{no}</td><td class="horse">{name}</td><td class="odds_tan">9.4</td></tr></tbody></table></body></html>'.encode('cp932')
 def profile(self,missing=False):
  body='<title>競走馬情報 JRA</title><h1><span class="txt"><span class="opt">競走馬情報</span>TEST HORSE<span class="name_en">TEST(JPN)</span></span></h1>'
  for label in FIELDS:body+='<dl><dt>'+label+'</dt><dd>'+('不明' if missing and label=='母の母' else '<a href="/JRADB/accessU.html?CNAME=pw01dud102000000001/AA">SYNTHETIC</a>')+'</dd></dl>'
  return body.encode('cp932')
 def test_revision_and_idempotency(self):
  rec={'race_id':'R','horse_number':1,'win_odds':9.4,'odds_status':'OK','source_id':None,'payload_json':'{}'};self.s.put('win_odds',['race_id','horse_number'],rec);self.s.put('win_odds',['race_id','horse_number'],rec);self.assertEqual(self.s.c.execute('SELECT count(*) FROM revisions').fetchone()[0],1)
  self.assertEqual(json.loads(self.s.c.execute('SELECT old_json FROM revisions').fetchone()[0])['win_odds'],8.8)
 def test_odds_name_mismatch_atomic(self):
  with self.assertRaises(ValueError):integrate_odds(self.s,self.odds('OTHER'),None,'R')
  self.assertEqual(self.s.c.execute('SELECT win_odds FROM win_odds').fetchone()[0],8.8)
 def test_odds_number_mismatch(self):
  with self.assertRaises(ValueError):integrate_odds(self.s,self.odds(no=2),None,'R')
 def test_odds_correction(self):
  integrate_odds(self.s,self.odds(),None,'R');self.assertEqual(self.s.c.execute('SELECT win_odds FROM win_odds').fetchone()[0],9.4)
 def test_four_fields(self):
  r,_=parse(self.profile(),'2023000001','TEST HORSE','pw01dud102023000001/AA');self.assertEqual({x['path'] for x in r},{'S','M','MS','MM'});self.assertEqual(len(r),4)
 def test_profile_missing_is_not_zero(self):
  r,_=parse(self.profile(True),'2023000001','TEST HORSE','pw01dud102023000001/AA');mm=next(x for x in r if x['path']=='MM');self.assertIsNone(mm['ancestor_name']);self.assertEqual(mm['status'],'NOT_PROVIDED')
 def test_wrong_profile_id(self):
  with self.assertRaises(ValueError):parse(self.profile(),'2023000001','TEST HORSE','pw01dud102023000002/AA')
 def test_wrong_profile_name(self):
  with self.assertRaises(ValueError):parse(self.profile(),'2023000001','OTHER','pw01dud102023000001/AA')
 def test_incomplete_layout_rejected(self):
  with self.assertRaises(ValueError):parse(b'<title>JRA</title>','2023000001','TEST HORSE','pw01dud102023000001/AA')
 def test_export_data_only(self):
  a=export(self.s,self.root/'out',2026);self.assertEqual(a['status'],'PARTIAL')
  with zipfile.ZipFile(next((self.root/'out').glob('*.zip'))) as z:self.assertEqual(set(z.namelist()),{'MASTER.sqlite3','manifest.json','AUDIT.json','README.txt'})
 def test_resume_skips_completed(self):
  self.s.task('X','PASS');self.s.c.close();self.s=Store(self.root/'MASTER.sqlite3');self.assertTrue(self.s.done('X'))
 def test_unknown_time_stays_null(self):
  sid=self.s.source({'service':'JRA','role':'TEST','raw_state':'NOT_RETAINED'});self.assertIsNone(self.s.c.execute('SELECT raw_saved_at FROM source_records WHERE source_id=?',(sid,)).fetchone()[0])
 def test_non_jra_host_rejected(self):
  c=Client(self.s,self.root/'raw',budget_seconds=1)
  with self.assertRaises(FetchError):c.request('https://www.jbis.or.jp/horse/0000000001/','TEST')
 def test_time_budget_stops_without_network(self):
  self.s.c.execute('INSERT INTO host_budget VALUES (?,?)',('www.jra.go.jp',now()));self.s.c.commit();c=Client(self.s,self.root/'raw',budget_seconds=1)
  with self.assertRaises(Deferred):c.request('https://www.jra.go.jp/JRADB/accessU.html','TEST')
 def test_foreign_key_enforced(self):
  with self.assertRaises(sqlite3.IntegrityError):self.s.c.execute("INSERT INTO runners VALUES ('MISSING',1,'H','{}')")
 def test_same_id_allowed_in_other_year(self):
  other=Store(self.root/'2025'/'MASTER.sqlite3');other.c.execute("INSERT INTO horses VALUES ('H','TEST HORSE')");other.c.commit();self.assertEqual(other.c.execute('SELECT count(*) FROM horses').fetchone()[0],1);other.c.close()
if __name__=='__main__':unittest.main()

class PersistenceTests(unittest.TestCase):
 def test_large_database_survives_process_reopen(self):
  import subprocess,sys
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp)/'MASTER.sqlite3';s=Store(p)
   s.c.executemany('INSERT INTO horses VALUES (?,?)',[(str(i),'馬'+str(i)+'x'*500) for i in range(12000)]);s.c.commit();s.c.close()
   script="from jra_master.store import Store; import sys; s=Store(sys.argv[1]); assert s.c.execute('SELECT count(*) FROM horses').fetchone()[0]==12000; assert s.c.execute('PRAGMA integrity_check').fetchone()[0]=='ok'; s.c.close()"
   subprocess.run([sys.executable,'-c',script,str(p)],check=True)
