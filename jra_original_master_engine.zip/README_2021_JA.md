# JRA ORIGINAL MASTER v0.7.1.3 — 2021年馬場PDF差分修正

**v0.7.1.2を土台にした修正版。既存のレース・オッズ・血統・HTML取得仕様は変えません。**

## 現象と対象
- 2021年のstateはレース3,456件などを保持し、馬場の18開催単位が未完了。
- `hanshin02.pdf`: 表抽出によるクッション値の重複衝突。
- `chukyo06.pdf`: 画像主体のため通常の文字・表抽出では値を読めない。
- 通常PDFは従来の自動パーサを利用。**この2つの公式PDFだけ**、2026-10-11にJRA公式ページで目視確認した数値の限定的な再利用を許可。
- 自動抽出と目視転記を混同しないため、追加行の `archive_format=OFFICIAL_PDF_VISUAL_2021_VERIFIED`、`source_basis=JRA_OFFICIAL_ARCHIVE_PDF_VISUAL_TRANSCRIPTION` と明示。
- HTMLや他年度への補間、レース結果の再取得、A/B/C/Dコース採用は行わない。

## GitHub手順
1. 現行の `jra_original_master_engine.zip` をバックアップ。
2. このセット内の `jra_original_master_engine.zip` で置換してコミット。
3. 既存のGitHub Actions YAMLは変更しない。`year=2021`, `mode=update`, `with_track=true`, `with_official=true`, `reset_from_release=false`, `refresh=false`, `resume_run_id=空欄` で実行。
4. `jra-original-state-2021` は保持。新しいstateは最新runから復元される。
5. `track_audit_2021.json`: `pdf_errors=[]`, `missing_race_track_days=0` を確認し、さらに統合監査 `CERTIFIED` を確認すること。**まだGitHubでの実通信テストは未実施。**

## 安全上の注意
- 自動PDFパーサが十分に読める場合は自動値を優先。
- 限定例外のPDFが更新・書換えされた場合、過去の認証済みハッシュと異なれば値を静かに上書きせず停止。
- 公式PDFのURL・取得時ハッシュ・ページをstateへ記録。中京は画像PDFなので機械解析で正しさを証明したわけではなく、公式画面の**目視転記**による根拠を保存する。
- 2026年以降の週次差分機能には変更なし。未解析の別のPDFを勝手にCERTIFIED扱いにしない。
- 過去年度の生成済みCERTIFIED原本を上書きしない。

JRA公式出典:
- https://www.jra.go.jp/keiba/baba/archive/2021pdf/hanshin02.pdf
- https://www.jra.go.jp/keiba/baba/archive/2021pdf/chukyo06.pdf
