from __future__ import annotations

import argparse
import json
from pathlib import Path

from .audit_report import build_report, write_report
from .pipeline import Pipeline, PipelineFailure
from .batch import BatchRunner, load_plan
from .year_schedule import YearScheduleBuilder
from .seed_discovery import SeedDiscovery
from .year_seed_plan import YearSeedPlanRunner
from .year_day_import import YearDayImporter
from .month_collection import MonthCollector


def main() -> int:
    parser = argparse.ArgumentParser(description="CPH JRA official Data Foundation v0.14.0")
    parser.add_argument("--root", default="data", help="DB and Raw Snapshot root")
    parser.add_argument("--workers", type=int, default=4, choices=range(1, 5), help="bounded parallelism (1-4)")
    sub = parser.add_subparsers(dest="command", required=True)
    for name in ("run", "cache-only"):
        cmd = sub.add_parser(name)
        cmd.add_argument("--date", required=True)
        cmd.add_argument("--bootstrap-url", required=True)
    reparse = sub.add_parser("reparse")
    reparse.add_argument("--date", required=True)
    audit = sub.add_parser("audit")
    audit.add_argument("--date", required=True)
    audit.add_argument("--output")
    batch = sub.add_parser("batch")
    batch.add_argument("--plan", required=True, help="JSON date plan")
    batch.add_argument("--cache-only", action="store_true")
    batch.add_argument("--stop-on-error", action="store_true")
    batch.add_argument("--period", choices=("all", "h1", "h2"), default="all",
                       help="execute the whole annual plan or one half-year segment")
    batch.add_argument("--max-total-mib", type=int, default=4096)
    batch.add_argument("--reserve-free-mib", type=int, default=256)
    year = sub.add_parser("year-discover")
    year.add_argument("--year", type=int, required=True)
    year.add_argument("--cache-only", action="store_true")
    year.add_argument("--output")
    year_audit = sub.add_parser("year-audit")
    year_audit.add_argument("--year", type=int, required=True)
    seed = sub.add_parser("seed-discover")
    seed.add_argument("--date", required=True)
    seed.add_argument("--cache-only", action="store_true")
    seed_plan = sub.add_parser("year-seed-plan")
    seed_plan.add_argument("--year", type=int, required=True)
    seed_plan.add_argument("--period", choices=("all", "h1", "h2"), default="all")
    seed_plan.add_argument("--max-dates-this-run", type=int, default=1,
                           help="safety limit per invocation (1-31; default 1)")
    seed_plan.add_argument("--cache-only", action="store_true")
    seed_plan.add_argument("--retry-failed", action="store_true")
    seed_plan.add_argument("--date-from")
    seed_plan.add_argument("--date-to")
    seed_audit = sub.add_parser("year-seed-audit")
    seed_audit.add_argument("--year", type=int, required=True)
    day_import = sub.add_parser("year-day-import")
    day_import.add_argument("--date", required=True)
    day_import.add_argument("--cache-only", action="store_true")
    day_import.add_argument("--max-total-mib", type=int, default=4096)
    day_import.add_argument("--reserve-free-mib", type=int, default=256)
    month_collect = sub.add_parser("collect-month")
    month_collect.add_argument("--year", type=int, required=True)
    month_collect.add_argument("--month", type=int, required=True)
    month_collect.add_argument("--max-dates-this-run", type=int, default=1)
    month_collect.add_argument("--cache-only", action="store_true")
    month_collect.add_argument("--retry-failed", action="store_true")
    month_collect.add_argument("--max-total-mib", type=int, default=4096)
    month_collect.add_argument("--reserve-free-mib", type=int, default=256)
    month_audit = sub.add_parser("month-audit")
    month_audit.add_argument("--year", type=int, required=True)
    month_audit.add_argument("--month", type=int, required=True)
    args = parser.parse_args()
    root = Path(args.root).resolve()
    pipeline = Pipeline(root, workers=args.workers)
    try:
        if args.command in {"run", "cache-only"}:
            result = pipeline.run(args.date, args.bootstrap_url, cache_only=args.command == "cache-only")
        elif args.command == "reparse":
            result = pipeline.reparse(args.date)
        elif args.command == "audit":
            result = build_report(pipeline.conn, root, args.date)
            if args.output:
                write_report(Path(args.output), result)
        elif args.command == "batch":
            batch_id, plan_sha256, items = load_plan(Path(args.plan))
            runner = BatchRunner(pipeline, args.max_total_mib * 1024 * 1024,
                                 args.reserve_free_mib * 1024 * 1024)
            selected_dates = None
            if args.period == "h1":
                selected_dates = {x.race_date for x in items if int(x.race_date[5:7]) <= 6}
            elif args.period == "h2":
                selected_dates = {x.race_date for x in items if int(x.race_date[5:7]) >= 7}
            result = runner.run(batch_id, items, plan_sha256,
                                cache_only=args.cache_only,
                                continue_on_error=not args.stop_on_error,
                                selected_dates=selected_dates)
            result["requested_period"] = args.period
        elif args.command == "year-discover":
            builder = YearScheduleBuilder(pipeline)
            result = builder.build(args.year, cache_only=args.cache_only)
            if args.output:
                result["export"] = builder.export(args.year, Path(args.output))
        elif args.command == "year-audit":
            result = YearScheduleBuilder(pipeline).audit(args.year)
        elif args.command == "seed-discover":
            result = SeedDiscovery(pipeline).discover(args.date, cache_only=args.cache_only)
        elif args.command == "year-seed-plan":
            result = YearSeedPlanRunner(pipeline).run(
                args.year, period=args.period, max_dates_this_run=args.max_dates_this_run,
                cache_only=args.cache_only, retry_failed=args.retry_failed,
                date_from=args.date_from, date_to=args.date_to)
        elif args.command == "year-seed-audit":
            result = YearSeedPlanRunner(pipeline).audit(args.year)
        elif args.command == "year-day-import":
            result = YearDayImporter(
                pipeline, args.max_total_mib * 1024 * 1024,
                args.reserve_free_mib * 1024 * 1024,
            ).run(args.date, cache_only=args.cache_only)
        elif args.command == "collect-month":
            result = MonthCollector(
                pipeline, args.max_total_mib * 1024 * 1024,
                args.reserve_free_mib * 1024 * 1024,
            ).run(args.year, args.month, args.max_dates_this_run,
                  cache_only=args.cache_only, retry_failed=args.retry_failed)
        else:
            result = MonthCollector(pipeline).audit(args.year, args.month)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except Exception as exc:
        payload = {"status": "FAIL", "error_type": type(exc).__name__, "message": str(exc)}
        if isinstance(exc, PipelineFailure):
            payload |= {"stage": exc.stage, "reason_codes": exc.reasons}
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        return 2
    finally:
        pipeline.close()


if __name__ == "__main__":
    raise SystemExit(main())
