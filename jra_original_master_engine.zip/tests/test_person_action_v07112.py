import unittest,tempfile,os,runpy,json
from pathlib import Path
from unittest.mock import patch
from jra_master.store import Store

class PersonActionTests(unittest.TestCase):
 def test_manual_mode_repairs_state_without_running_normal_collection_or_export(self):
  script=Path(__file__).resolve().parents[1]/'scripts/action_run.py'
  report=dict(status='WORKING_REPAIR_NOT_CERTIFIED',year=2025,pending_races=3,errors=[])
  old=Path.cwd()
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);s=Store(root/'state/2025/MASTER.sqlite3');s.meta('year',2025);s.c.close()
   try:
    os.chdir(root)
    env=dict(TARGET_YEAR='2025',MODE='people_repair',BASE_RELEASE_TAG='',BASE_ASSET_NAME='',RESET_FROM_RELEASE='false',MAX_HTML_PAGES='10')
    with patch.dict(os.environ,env),patch('jra_master.person_repair.run',return_value=report) as repair,patch('jra_master.cli.main') as collect,patch('jra_master.full_update.final_export') as export:
     with self.assertRaises(SystemExit) as stopped:runpy.run_path(str(script),run_name='__main__')
     self.assertEqual(stopped.exception.code,0);repair.assert_called_once();collect.assert_not_called();export.assert_not_called()
     self.assertEqual(json.loads((root/'delivery/person_repair_audit_2025.json').read_text()),report)
   finally:os.chdir(old)
