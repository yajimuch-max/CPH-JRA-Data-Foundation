import unittest,time
from unittest.mock import patch,Mock
from jra_master.pedigree import parse
from jra_master.network import Client,FetchError
class ValueRegression(unittest.TestCase):
 def test_plain_name_with_progeny_button(self):
  b=('<title>競走馬情報</title><h1><span class="txt">フレッチア</span></h1><dl><dt>父</dt><dd>Dansili</dd><dt>母</dt><dd>Blue Bunting<a href="#" onclick="pj01snk">産駒</a></dd><dt>母の父</dt><dd>Medicean</dd><dt>母の母</dt><dd><a href="?pw01dud002000000001">Via Milano</a><a href="#">産駒</a></dd></dl>').encode()
  rows,identity=parse(b,'2015104699','フレッチア','pw01dud102015104699/73')
  self.assertEqual({r['path']:r['ancestor_name'] for r in rows},{'S':'Dansili','M':'Blue Bunting','MS':'Medicean','MM':'Via Milano'})
 def test_transient_retry(self):
  c=Client.__new__(Client);c.deadline=time.monotonic()+100;c._request_once=Mock(side_effect=[FetchError('HTTP_503'),('body','sid','path')])
  with patch('jra_master.network.time.sleep'):self.assertEqual(c.request('u','r'),('body','sid','path'))
  self.assertEqual(c._request_once.call_count,2)
 def test_403_not_retried(self):
  c=Client.__new__(Client);c.deadline=time.monotonic()+100;c._request_once=Mock(side_effect=FetchError('HTTP_403'))
  with self.assertRaises(FetchError):c.request('u','r')
  self.assertEqual(c._request_once.call_count,1)
