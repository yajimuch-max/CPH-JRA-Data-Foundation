import tempfile,sqlite3,json,unittest
from pathlib import Path
from jra_master.official_expansion import (schema,extract_blocks,parse_runner_line,
                                            cancel_notice,apply_report,VERSION)
from jra_master.store import Store

PDF_LINES='''03001 1月28日 晴 良 （29東京1）第1日 第1競走 サラブレッド系3歳 1,400
発走10時10分 （ダート・左）
牝，未勝利；負担重量は，馬齢重量
本 賞 5,000,000円
1 2 プティトシャンティ 牝3青鹿 54 52 △木幡 初也 三野順一郎氏 伊藤 圭三 新ひだか 前田牧場 B450＋ 61：27．3
714 オネスティ 牝3栗54 武士沢友治 叶 哲也氏 浅野洋一郎 日高 豊洋牧場 ― （出走取消）
〔出走取消〕 オネスティ号は，疾病〔右前肢跛行〕のため出走取消。
'''
class TestOfficialExpansion(unittest.TestCase):
 def test_positive_blinker_and_owner_breeder(self):
  r=dict(name='プティトシャンティ',jockey='木幡 初也',trainer='伊藤 圭三',bodyweight=450)
  x=parse_runner_line(PDF_LINES.splitlines()[4],2,r)
  self.assertEqual(x['blinker_observed'],1)
  self.assertEqual(x['owner_text'],'三野順一郎氏')
  self.assertEqual(x['breeder_text'],'前田牧場')
  self.assertEqual(x['birthplace_text'],'新ひだか')
 def test_unknown_blinker_not_false(self):
  r=dict(name='プティトシャンティ',jockey='木幡 初也',trainer='伊藤 圭三',bodyweight=450)
  x=parse_runner_line(PDF_LINES.splitlines()[4].replace('B450','450'),2,r)
  self.assertIsNone(x['blinker_observed'])
 def test_notice_explicit_match(self):
  self.assertEqual(cancel_notice(PDF_LINES.splitlines(),'オネスティ')['cancellation_kind'],'出走取消')
  self.assertEqual(cancel_notice(PDF_LINES.splitlines(),'無関係な馬'),{})
 def test_report_join_and_core_safety(self):
  with tempfile.TemporaryDirectory() as d:
   s=Store(Path(d)/'t.sqlite3'); c=s.c
   with c:
    c.execute("INSERT INTO races VALUES (?,?,?,?,?,?)",('2017-01-28-東京-01','2017-01-28','東京',1,'FLAT',json.dumps({'meeting_label':'1回東京1日','surface':'ダート'})))
    c.execute("INSERT INTO horses VALUES (?,?)",('H','プティトシャンティ'))
    c.execute("INSERT INTO horses VALUES (?,?)",('H2','オネスティ'))
    r={'horse_name':'プティトシャンティ','jockey_name':'木幡 初也','trainer_name':'伊藤 圭三','body_weight_kg':450}
    c.execute('INSERT INTO runners VALUES (?,?,?,?)',('2017-01-28-東京-01',2,'H',json.dumps(r,ensure_ascii=False)))
    c.execute('INSERT INTO runners VALUES (?,?,?,?)',('2017-01-28-東京-01',14,'H2',json.dumps({'horse_name':'オネスティ'},ensure_ascii=False)))
    schema(c)
   before=[tuple(x) for x in c.execute('select * from runners')]
   pages=[(1,PDF_LINES)]
   url='https://www.jra.go.jp/datafile/seiseki/report/2017/2017-1tokyo1.pdf'
   with c:count,horses,w=apply_report(c,2017,'東京',url,'sha123',pages)
   self.assertEqual(count,1);self.assertEqual(horses,2)
   self.assertEqual(before,[tuple(x) for x in c.execute('select * from runners')])
   self.assertEqual(c.execute("select blinker_observed from official_expansion_runners where horse_number=2").fetchone()[0],1)
   self.assertEqual(c.execute("select cancellation_kind from official_expansion_runners where horse_number=14").fetchone()[0],'出走取消')
   self.assertIn('未勝利',c.execute('select class_official_text from official_expansion_races').fetchone()[0])
   s.c.close()

if __name__=='__main__':unittest.main()
