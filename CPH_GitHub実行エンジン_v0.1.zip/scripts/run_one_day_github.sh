#!/usr/bin/env bash
set -Eeuo pipefail

if [[ $# -ne 1 || ! "$1" =~ ^[0-9]{4}-[0-9]{2}-[0-9]{2}$ ]]; then
  echo "Usage: $0 YYYY-MM-DD" >&2
  exit 64
fi

race_date="$1"
race_year="${race_date:0:4}"
workspace_root="${GITHUB_WORKSPACE:-$(pwd)}"
engine_root="$(cd "$(dirname "$0")/.." && pwd)"
data_root="$workspace_root/run_data"
reports_root="$workspace_root/run_reports"
delivery_root="$workspace_root/delivery"
status="FAIL"

mkdir -p "$data_root" "$reports_root" "$delivery_root"

finalize() {
  exit_code=$?
  if [[ $exit_code -eq 0 ]]; then
    status="PASS"
  fi
  python "$engine_root/scripts/package_result.py" \
    --date "$race_date" \
    --status "$status" \
    --data-root "$data_root" \
    --reports-root "$reports_root" \
    --delivery-root "$delivery_root" || true
}
trap finalize EXIT

cd "$engine_root"

manifest_exists="$(python - "$data_root/cph_jra_df.sqlite3" "$race_year" <<'PY'
import sqlite3
import sys
from pathlib import Path

db_path = Path(sys.argv[1])
if not db_path.exists():
    print(0)
    raise SystemExit
try:
    conn = sqlite3.connect(db_path)
    found = conn.execute(
        "SELECT COUNT(*) FROM year_schedule_manifests WHERE year=?", (int(sys.argv[2]),)
    ).fetchone()[0]
    conn.close()
    print(1 if found else 0)
except sqlite3.Error:
    print(0)
PY
)"

if [[ "$manifest_exists" == "1" ]]; then
  python run_data_foundation.py --root "$data_root" year-audit \
    --year "$race_year" | tee "$reports_root/01_year_audit_existing.json"
  python scripts/check_report.py year "$reports_root/01_year_audit_existing.json"
else
  python run_data_foundation.py --root "$data_root" --workers 4 year-discover \
    --year "$race_year" --output "$reports_root/JRA_${race_year}_年次開催日Manifest.json" \
    | tee "$reports_root/01_year_discover.json"
  python scripts/check_report.py year "$reports_root/01_year_discover.json"
fi

python run_data_foundation.py --root "$data_root" --workers 4 year-seed-plan \
  --year "$race_year" --period all --date-from "$race_date" --date-to "$race_date" \
  --max-dates-this-run 1 \
  | tee "$reports_root/02_seed_discovery.json"
python scripts/check_report.py seed "$reports_root/02_seed_discovery.json"

python run_data_foundation.py --root "$data_root" --workers 4 year-day-import \
  --date "$race_date" \
  | tee "$reports_root/03_day_import.json"
python scripts/check_report.py day "$reports_root/03_day_import.json"

python run_data_foundation.py --root "$data_root" --workers 4 year-day-import \
  --date "$race_date" --cache-only \
  | tee "$reports_root/04_cache_only.json"
python scripts/check_report.py day "$reports_root/04_cache_only.json"

python run_data_foundation.py --root "$data_root" --workers 4 reparse \
  --date "$race_date" \
  | tee "$reports_root/05_reparse.json"
python scripts/check_report.py reparse "$reports_root/05_reparse.json"

python run_data_foundation.py --root "$data_root" audit \
  --date "$race_date" --output "$reports_root/06_race_audit.json" \
  | tee "$reports_root/06_race_audit_stdout.json"
python scripts/check_report.py audit "$reports_root/06_race_audit_stdout.json"

python run_data_foundation.py --root "$data_root" year-seed-audit \
  --year "$race_year" | tee "$reports_root/07_year_seed_audit.json"
python scripts/check_report.py plan "$reports_root/07_year_seed_audit.json"

python - "$data_root/cph_jra_df.sqlite3" <<'PY' | tee "$reports_root/08_sqlite_audit.json"
import json
import sqlite3
import sys

path = sys.argv[1]
conn = sqlite3.connect(path)
integrity = conn.execute("PRAGMA integrity_check").fetchone()[0]
foreign_keys = conn.execute("PRAGMA foreign_key_check").fetchall()
conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
conn.close()
result = {
    "integrity_check": integrity,
    "foreign_key_violation_count": len(foreign_keys),
    "status": "PASS" if integrity == "ok" and not foreign_keys else "FAIL",
}
print(json.dumps(result, ensure_ascii=False, indent=2))
if result["status"] != "PASS":
    raise SystemExit(2)
PY
