"""Offline regression: weekly update must automatically execute pedigree + track."""
import os
import runpy
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch


class UnifiedUpdateTests(unittest.TestCase):
    def test_update_runs_both_stages_with_single_action(self):
        with tempfile.TemporaryDirectory() as tmp:
            env={
                'TARGET_YEAR':'2026','MODE':'update','BASE_RELEASE_TAG':'',
                'BASE_ASSET_NAME':'','MONTHS':'','START_DATE':'','END_DATE':'',
                'MAX_HORSES':'12000','MAX_SOURCES':'12000',
                'WITH_PEDIGREE':'true','WITH_TRACK':'true','REFRESH':'false'
            }
            script=Path(__file__).resolve().parents[1]/'scripts'/'action_run.py'
            calls=[]
            def core(argv):
                calls.append(('core',argv))
                return 0
            def track(*args,**kwargs):
                calls.append(('track',args,kwargs))
                return 0
            import jra_master.cli
            import jra_master.track_action
            with patch.dict(os.environ,env), patch.object(jra_master.cli,'main',side_effect=core), patch.object(jra_master.track_action,'run_track',side_effect=track):
                with self.assertRaises(SystemExit) as exit_:
                    runpy.run_path(str(script),run_name='__main__')
            self.assertEqual(exit_.exception.code,0)
            self.assertEqual([x[0] for x in calls],['core','track'])
            self.assertIn('--with-pedigree',calls[0][1])
            self.assertEqual(calls[1][1][0],2026)
            self.assertFalse(calls[1][2]['refresh_all'])

    def test_partial_core_status_not_hidden(self):
        env={'TARGET_YEAR':'2026','MODE':'update','WITH_PEDIGREE':'true','WITH_TRACK':'true',
             'BASE_RELEASE_TAG':'','BASE_ASSET_NAME':'','REFRESH':'false'}
        script=Path(__file__).resolve().parents[1]/'scripts'/'action_run.py'
        import jra_master.cli
        import jra_master.track_action
        with patch.dict(os.environ,env), patch.object(jra_master.cli,'main',return_value=2),patch.object(jra_master.track_action,'run_track',return_value=0) as t:
            with self.assertRaises(SystemExit) as exit_:
                runpy.run_path(str(script),run_name='__main__')
        self.assertEqual(exit_.exception.code,2)
        t.assert_called_once()

    def test_track_opt_out(self):
        env={'TARGET_YEAR':'2026','MODE':'update','WITH_PEDIGREE':'true','WITH_TRACK':'false',
             'BASE_RELEASE_TAG':'','BASE_ASSET_NAME':'','REFRESH':'false'}
        script=Path(__file__).resolve().parents[1]/'scripts'/'action_run.py'
        import jra_master.cli
        import jra_master.track_action
        with patch.dict(os.environ,env), patch.object(jra_master.cli,'main',return_value=0),patch.object(jra_master.track_action,'run_track') as t:
            with self.assertRaises(SystemExit) as exit_:
                runpy.run_path(str(script),run_name='__main__')
        self.assertEqual(exit_.exception.code,0)
        t.assert_not_called()


if __name__=='__main__':unittest.main()
