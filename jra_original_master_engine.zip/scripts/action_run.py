import os,subprocess,json,tempfile,sqlite3
from jra_master.importer import Archive,bootstrap
from jra_master.store import Store
from pathlib import Path
from datetime import datetime,timezone,timedelta
from jra_master.cli import main
Y=int(os.environ['TARGET_YEAR']);mode=os.environ['MODE'];release=os.environ.get('BASE_RELEASE_TAG','').strip();base=os.environ.get('BASE_ASSET_NAME','').strip();start=os.environ.get('START_DATE','');end=os.environ.get('END_DATE','');months=os.environ.get('MONTHS','');limit=os.environ.get('MAX_HORSES','500')
if not 2010<=Y<=2100:raise SystemExit('Invalid year (2010 or later required)')
if os.environ.get('RESET_FROM_RELEASE','false').lower()=='true' and (not release or not base):
 raise SystemExit('RESET_FROM_RELEASE_REQUIRES_BASE_RELEASE_TAG_AND_ASSET_NAME')
db=Path('state')/str(Y)/'MASTER.sqlite3';input_path=None
if release and mode not in ['diagnose','cardprobe'] and (mode in ['bootstrap','reaudit'] or not db.exists()):
 if not base or Path(base).name!=base:raise SystemExit('Exact baseline asset filename required')
 Path('inputs').mkdir(exist_ok=True)
 # Show exact effective tag/asset so future failures are diagnosable, while
 # never printing credentials or unrelated environment variables.
 print('RELEASE_BASELINE_RESOLVED',json.dumps({'tag':release,'asset':base,'repository':os.environ['GITHUB_REPOSITORY']},ensure_ascii=False),flush=True)
 cmd=['gh','release','download',release,'--repo',os.environ['GITHUB_REPOSITORY'],'--pattern',base,'--dir','inputs','--clobber']
 result=subprocess.run(cmd,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 if result.returncode:
  print('RELEASE_BASELINE_DOWNLOAD_FAILED',json.dumps({'tag':release,'asset':base,'exit_code':result.returncode},ensure_ascii=False),flush=True)
  print('GH_RELEASE_DOWNLOAD_ERROR:',(result.stderr or result.stdout or 'No diagnostic output')[-2500:],flush=True)
  raise SystemExit(1)

 input_path=Path('inputs')/base
common=['--year',str(Y),'--db',str(db),'--output','delivery']
if mode=='preflight':raise SystemExit(main(common+['--mode','preflight']))
# Explicit bootstrap with a compact original MASTER adopts the reviewed file,
# even when an older Actions state was restored. Legacy RAW inputs keep prior behavior.
if mode=='bootstrap' and input_path:
 archive=Archive(input_path)
 try:
  names={r[0] for r in archive.c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
  compact='source_records' in names and 'pedigree_receipts' in names
 finally:archive.close()
 if compact:
  db.parent.mkdir(parents=True,exist_ok=True)
  with tempfile.TemporaryDirectory(dir=db.parent,prefix='reviewed_import_') as stage:
   candidate=Path(stage)/'MASTER.sqlite3';store=Store(candidate)
   try:
    bootstrap(store,input_path,Y)
    audit=store.audit()
    if audit['integrity']!='ok' or audit['foreign_keys']:raise ValueError('REVIEWED_MASTER_INVALID')
   finally:store.c.close()
   # The previous state remains in its original Actions artifact.
   for suffix in ['-journal','-wal','-shm']:
    if Path(str(db)+suffix).exists():raise ValueError('STATE_SIDECAR_PRESENT')
   os.replace(candidate,db)
  print('REVIEWED_COMPACT_MASTER_ADOPTED',flush=True)
if not db.exists() and input_path:
 # Compact official MASTER: adopt the reviewed SQLite byte-for-byte. This is much
 # faster than re-inserting hundreds of thousands of already completed rows.
 # RAW-format historical archives still use the original bootstrap parser.
 import zipfile,shutil,hashlib
 adopted=False
 with zipfile.ZipFile(input_path) as archive:
  names=archive.namelist()
  candidates=[n for n in names if n=='MASTER.sqlite3']
  if len(candidates)==1:
   db.parent.mkdir(parents=True,exist_ok=True)
   with tempfile.TemporaryDirectory(dir=db.parent,prefix='verified_adopt_') as stage:
    temp=Path(stage)/'MASTER.sqlite3'
    with archive.open('MASTER.sqlite3') as src,temp.open('wb') as out:
     shutil.copyfileobj(src,out,1024*1024)
    check=sqlite3.connect(temp)
    try:
     names_sql={x[0] for x in check.execute("SELECT name FROM sqlite_master WHERE type='table'")}
     valid={'races','runners','results','win_odds','pedigree_receipts','source_records','metadata'}.issubset(names_sql)
     row=check.execute("SELECT value FROM metadata WHERE key='year'").fetchone() if valid else None
     correct=bool(row and json.loads(row[0])==Y)
     integrity=check.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
     fk=not check.execute('PRAGMA foreign_key_check').fetchall()
     year_matches=not check.execute("SELECT 1 FROM races WHERE race_date NOT LIKE ? LIMIT 1",(f'{Y}-%',)).fetchone() if valid else False
     if not (valid and correct and integrity and fk and year_matches):
      raise ValueError('REVIEWED_MASTER_ADOPTION_VALIDATION_FAILED')
    finally:check.close()
    if 'manifest.json' in names:
     manifest=json.loads(archive.read('manifest.json'))
     expected=manifest.get('master_sha256')
     if expected and hashlib.sha256(temp.read_bytes()).hexdigest()!=expected:
      raise ValueError('REVIEWED_MASTER_MANIFEST_SHA256_MISMATCH')
    os.replace(temp,db)
    adopted=True
 if adopted:print('REVIEWED_MASTER_FAST_ADOPTED',flush=True)
 else:main(common+['--mode','bootstrap','--input',str(input_path)])
if mode=='update' and not db.exists():
 raise SystemExit('BASELINE_REQUIRED: No saved state and no valid year Release MASTER ZIP. Never silently start a full new collection.')
if mode=='bootstrap':
 if not db.exists():raise SystemExit('Baseline release asset or prior state required')
 raise SystemExit(main(common+['--mode','export']))
if mode=='track':
 from jra_master.track_action import run_track
 raise SystemExit(run_track(Y,db,'delivery',refresh_all=os.environ.get('REFRESH')=='true'))
if mode in ('official_enrich','html_enrich'):
 from jra_master.html_first import run
 from jra_master.full_update import final_export
 report=run(Y,db,'delivery',refresh=os.environ.get('REFRESH')=='true',budget_seconds=12000,max_pages=int(os.environ.get('MAX_HTML_PAGES','4000')))
 final_export(Y,db,'delivery',{'official_html':{'status':report['status'],'remaining':report['remaining']}})
 raise SystemExit(0 if report['known_official_html_urls'] and not report.get('stopped_for_safety',False) and report['failed_this_run']<100 else 2)
args=common+['--mode',mode,'--max-horses',limit,'--max-sources',os.environ.get('MAX_SOURCES','500'),'--budget-seconds','3600' if mode=='update' else '8400']
if input_path:args+=['--input',str(input_path)]
# Optional explicit local donor ZIP, e.g. materialized by a custom workflow.
if os.environ.get('PEDIGREE_FROM'):args+=['--pedigree-from',os.environ['PEDIGREE_FROM']]
if mode=='reaudit' and not input_path:raise SystemExit('Reaudit requires baseline release asset (saved RAW)')
if mode in ['update','diagnose']:
 if start:args+=['--start',start]
 if end:args+=['--end',end]
 if months:args+=['--months',months]
 if os.environ.get('REFRESH')=='true':args+=['--refresh']
if os.environ.get('WITH_PEDIGREE')=='true':args+=['--with-pedigree']
if mode=='update':
 # Core data, JRA race-day track archive, and official results evidence are
 # independent incremental stages. The last stage builds ONE final master ZIP.
 from jra_master.full_update import run_full_update
 raise SystemExit(run_full_update(year=Y,db=db,output='delivery',
     core_args=args,core_main=main,
     with_track=os.environ.get('WITH_TRACK','true').lower()=='true',
     with_official=os.environ.get('WITH_OFFICIAL','true').lower()=='true',
     refresh=os.environ.get('REFRESH')=='true'))
raise SystemExit(main(args))
