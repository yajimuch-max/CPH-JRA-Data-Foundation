from __future__ import annotations
import argparse, json
from pathlib import Path
from cph_jra_df.pipeline import Pipeline

def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--data-root", required=True)
    p.add_argument("--year", type=int, default=2019)
    a = p.parse_args()

    pipe = Pipeline(Path(a.data_root).resolve(), workers=1)
    try:
        days = pipe.conn.execute(
            "SELECT d.race_date,s.seed_url FROM year_race_days d "
            "LEFT JOIN result_seed_urls s ON s.race_date=d.race_date "
            "WHERE substr(d.race_date,1,4)=? ORDER BY d.race_date",
            (str(a.year),),
        ).fetchall()

        reused, repaired, failures = [], [], []
        for row in days:
            race_date = row["race_date"]
            current_pass = pipe.conn.execute(
                "SELECT run_id FROM pipeline_runs WHERE race_date=? "
                "AND status='PASS' AND stage='AUDIT' "
                "AND mode IN ('ONLINE','CACHE_ONLY') "
                "ORDER BY completed_at DESC LIMIT 1",
                (race_date,),
            ).fetchone()
            if current_pass is not None:
                reused.append(race_date)
                continue

            if not row["seed_url"]:
                failures.append({"date": race_date, "error": "SEED_MISSING"})
                continue

            try:
                # These dates previously stopped while parsing the schedule,
                # before race-result snapshots were cached. Refetch ONLY the
                # unresolved date; existing PASS dates are never re-imported.
                result = pipe.run(race_date, row["seed_url"], cache_only=False)
                repaired.append({
                    "date": race_date,
                    "run_id": result["run_id"],
                    "flat_race_count": result["flat_race_count"],
                })
            except Exception as exc:
                failures.append({"date": race_date, "error": str(exc)})

        if failures:
            print(json.dumps({
                "status": "FAIL",
                "existing_pass_dates_reused": len(reused),
                "repaired_dates": len(repaired),
                "failures": failures,
            }, ensure_ascii=False, indent=2))
            return 1

        # Once every date has a PASS import, verify every stored result page
        # through the parser with zero network requests.
        reparse_pass = 0
        reparse_failures = []
        for row in days:
            try:
                r = pipe.reparse(row["race_date"])
                if r.get("status") == "PASS":
                    reparse_pass += 1
                else:
                    reparse_failures.append({"date": row["race_date"], "result": r})
            except Exception as exc:
                reparse_failures.append({"date": row["race_date"], "error": str(exc)})

        report = {
            "status": "PASS" if not reparse_failures else "FAIL",
            "year": a.year,
            "race_days": len(days),
            "existing_pass_dates_reused": len(reused),
            "failed_dates_refetched_and_repaired": len(repaired),
            "reparse_pass": reparse_pass,
            "reparse_failures": reparse_failures,
            "history_policy": "old FAIL/PARTIAL audit rows retained",
        }
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 0 if not reparse_failures else 1
    finally:
        pipe.close()

if __name__ == "__main__":
    raise SystemExit(main())
