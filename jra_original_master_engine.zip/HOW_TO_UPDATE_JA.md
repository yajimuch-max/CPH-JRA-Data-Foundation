# JRA MASTER v0.4.0 — スマホからの簡単手順

## GitHubに置くのは2ファイル
- `jra_original_master_engine.zip` → リポジトリ直下。そのままZIPで保存・上書き。
- `jra_original_master.yml` → `.github/workflows/jra_original_master.yml` として上書き。

## 2017年の公式情報を補完する
1. GitHub Releasesの `inputs-2017` に `2017_JRA_MASTER.zip` を置く（前にアップロード済みならやり直し不要）。
2. Actions → `JRA 原本MASTER・公式情報まとめて差分補完 v0.4.0` → `Run workflow`。
3. `year=2017`、`mode=official_enrich`、`base_release_tag=inputs-2017`、`base_asset_name=2017_JRA_MASTER.zip`、`resume_run_id`空欄、`refresh=OFF`。
4. 完了後、Artifactsの `jra-original-master-2017`、`jra-original-state-2017`、`jra-official-expansion-audit-2017` を保存。
5. AUDITを見て`PASS`か`PARTIAL`か確認。PARTIALのままでも確認できた値だけは保存される。公式照合に失敗した値は埋めない。

## 再開
- 同じ年、同じモード、`resume_run_id`空欄で繰り返す。
- `jra-original-state-YYYY` のArtifactが期限内にあり正常なら自動復元。
- 失敗/途中終了でも「state」がアップロードされていれば続きを引き継げる。強制3時間タイムアウトではアップロードに到達しない場合もある。
- stateが無い場合、Releasesの原本を使う。途中進捗を維持したいなら**最新版MASTER**をReleaseに置く必要がある。
- 既に処理できた公式PDFはチェックポイントでスキップ。`refresh=ON`は公式訂正などの再調査時だけ。

## 次の年
- 2018年なら `year=2018`, `base_release_tag=inputs-2018`, `base_asset_name=2018_JRA_MASTER.zip`。
- 2023年のレース・血統の途中更新を続ける場合は `mode=update`、`year=2023`、その他2023用Release設定、`resume_run_id`空欄。2017年のバックフィルとは独立。

## 注意
- 旧データの勝手な再取得・推測埋めはしない。
- JRA公式成績PDFは開催後資料。掲載事項が当時の発走前に公開されていた時刻は証明できない。観測時刻不明と保存。
- `official_enrich`は通常のレース・オッズ・血統を更新しない。毎週は従来どおり`update`。
- 2010年はPDF形式の違いにより使用コース中心のPARTIALになることがある。
- 自動取得のGitHub本番結果・全項目の網羅性は未検証。最初は2017年を1回走らせ監査ファイルを確認。
- 年間50MBの制約なし。JRA公式PDFのバイナリ自体はMASTER ZIPに含めない。
