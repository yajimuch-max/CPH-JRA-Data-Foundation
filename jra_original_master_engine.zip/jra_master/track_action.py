"""2026+ incremental official JRA track enrichment for the existing Github state.
No PDF bytes in the exported master. Fail-closed for conflicts, partial for unreadable PDFs.
"""
import datetime as dt
import hashlib
import json
import sqlite3
import time
from pathlib import Path
from urllib.parse import urlparse


def sync_year(year, db_path, cache_root=Path('jra_pdf_cache'), throttle=0.8, offline=False, refresh_all=False):
    if 2010 <= year <= 2017:
        from .legacy_track import sync_year as sync_legacy
        return sync_legacy(year, db_path, cache_root=cache_root, offline=offline, refresh_all=refresh_all)
    import requests
    from .track_enrichment import (get_archive_links, extract_observations, schema, upsert_obs, populate_context)
    cache_root=Path(cache_root)/str(year)
    cache_root.mkdir(parents=True,exist_ok=True)
    session=requests.Session()
    session.headers['User-Agent']='Mozilla/5.0 (compatible; JRA research provenance capture)'
    db_path=Path(db_path)
    if not db_path.is_file():
        raise RuntimeError('MASTER state not found. Run bootstrap first or supply a baseline Release ZIP.')
    c=sqlite3.connect(str(db_path));c.execute('PRAGMA busy_timeout=30000')
    before={t:c.execute('SELECT count(*) FROM '+t).fetchone()[0] for t in ('races','runners','results','win_odds','pedigree')}
    try:
        with c:schema(c)
        if year >= 2018:
            if offline:
                index=cache_root/'archive_index.json'
                if not index.exists():raise RuntimeError('offline archive_index.json not available')
                entries=json.loads(index.read_text())
                links=[(e['track'],e['url']) for e in entries]
            else:
                links=get_archive_links(year,session)
                if not links:raise RuntimeError(f'JRA archive index had no PDFs for {year}')
                (cache_root/'archive_index.json').write_text(json.dumps([{'track':t,'url':u} for t,u in links],ensure_ascii=False,indent=2))
        else:links=[]
        # Fully parsed historical PDFs stay checkpointed in the master database.
        # Recheck the latest TWO publications per racecourse each run to catch
        # updated post-meeting PDFs. `refresh_all` opts into complete rechecking.
        latest_by_track={}
        for track,url in links:
            latest_by_track.setdefault(track,[]).append(url)
        recent_urls={u for urls in latest_by_track.values() for u in urls[-2:]}
        errors=[];processed=0;skipped=0;checkpoint_skipped=0;revisions=0
        for track,url in links:
            name=Path(urlparse(url).path).name;file=cache_root/name
            existing=c.execute('SELECT source_sha256,parse_status FROM official_track_pdf_receipts WHERE source_url=?',(url,)).fetchone()
            if existing and existing[1]=='PASS' and not offline and not refresh_all and url not in recent_urls:
                checkpoint_skipped+=1
                continue
            try:
                # Current-year PDFs are updated after a meeting. Re-download to detect
                # revisions/new dates; cache is a fallback ONLY in explicit offline mode.
                if not offline:
                    response=session.get(url,timeout=50)
                    response.raise_for_status()
                    if not response.content.startswith(b'%PDF'):
                        raise ValueError('JRA returned non-PDF content')
                    incoming=response.content
                    checksum=hashlib.sha256(incoming).hexdigest()
                    if not file.exists() or hashlib.sha256(file.read_bytes()).hexdigest()!=checksum:
                        file.write_bytes(incoming)
                    time.sleep(throttle)
                else:
                    if not file.is_file():raise RuntimeError('offline PDF missing')
                    checksum=hashlib.sha256(file.read_bytes()).hexdigest()
                if existing==(checksum,'PASS'):
                    skipped+=1;continue
                obs=extract_observations(track,url,file)
                obs=[x for x in obs if x['date'].startswith(str(year)+'-')]
                if not obs:raise RuntimeError('no dated rows for target year')
                seen={}
                for x in obs:
                    key=x['date'],x['track']
                    if key in seen and seen[key]!=x:raise ValueError('duplicate conflicting rows: '+str(key))
                    seen[key]=x
                with c:
                    revisions+=upsert_obs(c,list(seen.values()))
                    c.execute("""INSERT INTO official_track_pdf_receipts VALUES (?,?,?,?,?,?,?)
                        ON CONFLICT(source_url) DO UPDATE SET
                        track=excluded.track,source_sha256=excluded.source_sha256,
                        parse_status=excluded.parse_status,parsed_rows=excluded.parsed_rows,
                        checked_at=excluded.checked_at,error=NULL""",
                        (url,track,checksum,'PASS',len(seen),dt.datetime.now(dt.timezone.utc).isoformat(),None))
                processed+=1
            except Exception as exc:
                message=f'{name}: {type(exc).__name__}: {exc}'
                errors.append(message)
                with c:
                    c.execute("""INSERT INTO official_track_pdf_receipts VALUES (?,?,?,?,?,?,?)
                        ON CONFLICT(source_url) DO UPDATE SET
                        parse_status=excluded.parse_status,checked_at=excluded.checked_at,error=excluded.error""",
                        (url,track,existing[0] if existing else None,'FAILED',0,dt.datetime.now(dt.timezone.utc).isoformat(),message))
        with c:populate_context(c)
        check=c.execute('PRAGMA integrity_check').fetchone()[0]
        fk=c.execute('PRAGMA foreign_key_check').fetchall()
        after={t:c.execute('SELECT count(*) FROM '+t).fetchone()[0] for t in before}
        if check!='ok' or fk or after!=before:
            raise RuntimeError(f'Core integrity changed: {check}, fk={len(fk)}, counts={after}')
        # JRA historical publication starts in mid-2018. Never invent values
        # for earlier dates, and explicitly audit missing currently published
        # race-day/track combinations instead of declaring zero rows PASS.
        first_eligible=f'{year}-01-01' if year>=2019 else '2018-07-27'
        eligible={tuple(r) for r in c.execute(
            'SELECT DISTINCT race_date,track FROM races WHERE race_date>=? AND race_date<=?',
            (first_eligible,f'{year}-12-31'))}
        observed={tuple(r) for r in c.execute(
            'SELECT race_date,track FROM official_track_daily WHERE race_date>=?',
            (first_eligible,))}
        missing=sorted(eligible-observed)
        stats={'status':'PASS' if not errors and not missing and year>=2018 else 'PARTIAL','year':year,
               'pdf_total':len(links),'pdf_parsed':processed,'pdf_unchanged':skipped,'pdf_checkpoint_skipped':checkpoint_skipped,
               'pdf_errors':errors,'revision_count_this_run':revisions,
               'eligible_race_track_days':len(eligible),'missing_race_track_days':len(missing),
               'missing_race_track_day_examples':missing[:25],
               'archive_track_days':c.execute('SELECT count(*) FROM official_track_daily').fetchone()[0],
               'races_with_used_course':c.execute('SELECT count(*) FROM official_race_track_context WHERE used_turf_course IS NOT NULL').fetchone()[0],
               'races_with_official_result_going':c.execute('SELECT count(*) FROM official_race_track_context WHERE going_from_official_result IS NOT NULL').fetchone()[0],
               'note':'Archive reconstructed. Past PDFs are NOT evidence of actual 09:30 publication; going is official result, NOT 09:30 going. Fully parsed older PDFs skipped except the two most recent per track unless refresh_all.',
               'integrity':check,'original_table_counts':after,
               'checked_at':dt.datetime.now(dt.timezone.utc).isoformat()}
        return stats
    finally:c.close()

def refresh_context_if_present(conn):
    row=conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='official_track_daily'").fetchone()
    if row:
        from .track_enrichment import populate_context
        with conn:populate_context(conn)


def run_track(year,db_path,out,refresh_all=False):
    from .cli import main
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    try:
        audit=sync_year(year,db_path,refresh_all=refresh_all)
    except Exception as exc:
        audit={'status':'ERROR','year':year,'error':f'{type(exc).__name__}: {exc}',
               'checked_at':dt.datetime.now(dt.timezone.utc).isoformat(),
               'note':'The prior core update checkpoint is preserved. Track enrichment could not complete.'}
        (out/f'track_audit_{year}.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
        print('TRACK_SYNC_ERROR',json.dumps(audit,ensure_ascii=False),flush=True)
        # The core update has already exported a checkpoint. Do not cover up
        # a failed track stage with a successful-looking combined master.
        return 2
    c=sqlite3.connect(str(db_path))
    try:
        c.execute('INSERT OR REPLACE INTO metadata(key,value) VALUES (?,?)',
                  ('track_enrichment_audit',json.dumps(audit,ensure_ascii=False)))
        c.commit()
    finally:c.close()
    (out/f'track_audit_{year}.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    print('TRACK_SYNC_AUDIT',json.dumps(audit,ensure_ascii=False),flush=True)
    # Still export verified partial data for checkpointing; audit says PARTIAL.
    return main(['--year',str(year),'--db',str(db_path),'--output',str(out),'--mode','export'])
