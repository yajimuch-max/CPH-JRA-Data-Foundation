# JRA MASTER v0.7.1.11 — 2026年開始・手動更新／未公開PDF保留

2026-10-11。土台: v0.7.1.10。**自動LIVE取得は無効化**。以前の馬名照合修正、公式HTML、オッズ・血統、2025年以降PDF解析、差分state復元は維持。

## 利用する年度

- **2026年から開始**。Actionsフォームの `year` は `2026` を選択。
- エンジンが `TARGET_YEAR` を受け取らない場合のデフォルトも `2026`。
- **GitHub Actionsのフォームで別の `year` が渡されたら、その指定が優先**。フォームの初期表示を2026に変更したい場合のみ既存YMLの `workflow_dispatch.inputs.year.default` を2026に変更する必要がある。エンジンZIPだけではフォームの初期値は変わらない。
- 2010〜2025年の認証済み原本には触れない。**今回の利用は2026年stateから**。

## 手動実行

Actions → 既存のワークフロー → **Run workflow**。毎週または必要時に手動で開始。

| 項目 | 設定 |
|---|---|
| year | `2026` |
| mode | `update` |
| start_date | `2026-01-01` |
| end_date | 最後に取得したい開催日（例 `2026-10-04`、後で更新可） |
| months | 空欄 |
| with_track / with_official / with_pedigree | `true` |
| refresh / reset_from_release | `false` |
| resume_run_id | 空欄（最新のstateから再開） |

- JRA公式レース・結果・オッズ・血統・HTMLは現行どおり**差分取得**し、stateに保存する。
- 公式馬場PDFがまだ公開されていなければ、当該開催日の含水率・クッション値は**欠損のまま `PARTIAL`**。後日の手動更新でPDFアーカイブの掲載を検知したら追加取得する。
- PDFリンク掲載済みでも404/410・ネットワーク失敗・PDFでないページは `PENDING` として記録し、次の更新で再試行。**値を推測しない**。壊れたPDFの解析異常は従来どおりエラーとして記録。
- 既に`PASS`のPDFは原則取り直さない。公式が後からPDFを訂正したと判明したときのみ `refresh=true` 等で再取得・比較。
- **当日馬場HTMLの自動取得は行わない**。`mode=track_live` は無効。新たなcronは追加しない。

## 出力と判定

- `jra-original-state-2026`：次回への再開用、最重要。絶対削除しない。
- `2026_JRA_WEEKLY_SNAPSHOT.zip`：PDF未公開でも出力する暫定データ。`PROVISIONAL_NOT_CERTIFIED`／共通6ビュー。欠損馬場値はNULL。**再開用stateの代わりにしない**。
- `2026_JRA_MASTER.zip`：認証条件を満たしたときのみ正式出力。
- `track_audit_2026.json`：`missing_race_track_days`, `pdf_pending_count`, `pdf_pending_downloads`, `archive_index_unavailable` を確認。

**公開待ち ≠ 取得失敗 ≠ 完成**。PDFが未公開の間は状態を保持し、正式 `CERTIFIED` と偽らない。

2010〜2025年の原本・既存の22テーブルと共通6ビューの互換性、A/B/C/Dコース除外方針は維持。2026年10月3・4日の東京・京都の未収録4開催単位も公式PDF公開後に補完する対象。

## 検証の範囲

テストはローカルの模擬HTTP応答・既存stateを使い実施。**GitHub上での実際のJRA PDF公開後の取得成功は、初回手動更新で確認が必要**。
