from __future__ import annotations
import argparse, sqlite3
from pathlib import Path

def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--db", required=True)
    a = p.parse_args()
    db = Path(a.db)
    con = sqlite3.connect(db)
    con.execute("PRAGMA foreign_keys=ON")

    # Preserve already-collected 2019 win odds without their FK dependency.
    con.execute("DROP TABLE IF EXISTS repair_win_odds_backup")
    con.execute("""
      CREATE TABLE repair_win_odds_backup AS
      SELECT race_key,horse_no,final_win_odds,status,result_url,odds_cname,raw_sha256,fetched_at_utc
      FROM win_odds
    """)
    count = con.execute("SELECT COUNT(*) FROM repair_win_odds_backup").fetchone()[0]

    # These tables depend on race/entry rows and are rebuilt/restored after re-audit.
    con.execute("DROP TABLE IF EXISTS win_odds")
    con.execute("DROP TABLE IF EXISTS race_market_popularity")
    con.execute("DROP TABLE IF EXISTS race_payouts")
    con.commit()

    integrity = con.execute("PRAGMA integrity_check").fetchone()[0]
    fk = con.execute("PRAGMA foreign_key_check").fetchall()
    con.close()
    if integrity != "ok" or fk:
        raise SystemExit(f"PREPARE_INTEGRITY_FAIL:{integrity}:{len(fk)}")
    print(f"backup_win_odds_rows={count}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
