from __future__ import annotations

from .batch import BatchRunner


class YearDayImportFailure(RuntimeError):
    pass


class YearDayImporter:
    """Import one complete JRA flat-race day from a discovered official seed."""

    def __init__(self, pipeline, max_total_bytes: int = 4 * 1024**3,
                 reserve_free_bytes: int = 256 * 1024**2):
        self.pipeline = pipeline
        self.conn = pipeline.conn
        self.capacity = BatchRunner(pipeline, max_total_bytes, reserve_free_bytes)

    def run(self, race_date: str, cache_only: bool = False) -> dict:
        existing_pass = self.conn.execute(
            "SELECT run_id FROM pipeline_runs WHERE race_date=? AND status='PASS' "
            "AND stage='AUDIT' AND mode IN ('ONLINE','CACHE_ONLY') "
            "ORDER BY completed_at DESC LIMIT 1",
            (race_date,),
        ).fetchone()
        if existing_pass is not None:
            # Do not rewrite already-valid rows during resume/re-audit.  This
            # preserves FK relationships, avoids duplicate registration, and
            # leaves prior audit/failure history untouched.
            return {
                "status": "PASS",
                "run_id": existing_pass["run_id"],
                "mode": "EXISTING_PASS_REUSED",
                "race_date": race_date,
                "reimported": False,
            }

        seed = self.conn.execute(
            "SELECT seed_url FROM result_seed_urls WHERE race_date=?", (race_date,)
        ).fetchone()
        if seed is None:
            raise YearDayImportFailure("RESULT_SEED_NOT_DISCOVERED")
        item = self.conn.execute(
            "SELECT status FROM year_seed_items WHERE race_date=? ORDER BY plan_id DESC LIMIT 1", (race_date,)
        ).fetchone()
        if item is not None and item["status"] != "PASS":
            raise YearDayImportFailure("YEAR_SEED_ITEM_NOT_PASS")
        before = self.capacity.capacity_check()
        if not before["pass"]:
            raise YearDayImportFailure("CAPACITY_PREFLIGHT_STOP:" + ",".join(before["reason_codes"]))
        result = self.pipeline.run(race_date, seed["seed_url"], cache_only=cache_only)
        after = self.capacity.capacity_check()
        return {**result, "seed_source": "result_seed_urls", "capacity_before": before,
                "capacity_after": after}
