"""Regression: GitHub's artifacts API may contain workflow_run=null."""
import contextlib
import io
import json
import os
import runpy
import sqlite3
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch


RESTORE = Path(__file__).resolve().parents[1] / 'scripts' / 'restore_state.py'


class RestoreStateNullRunTests(unittest.TestCase):
    def make_zip(self):
        with tempfile.TemporaryDirectory() as td:
            db = Path(td) / 'MASTER.sqlite3'
            with sqlite3.connect(db) as c:
                c.execute('CREATE TABLE tasks(status TEXT)')
                c.execute("INSERT INTO tasks VALUES('PASS')")
                c.execute('CREATE TABLE pedigree_receipts(horse_id TEXT)')
                c.execute("INSERT INTO pedigree_receipts VALUES('H')")
            stream = io.BytesIO()
            with zipfile.ZipFile(stream, 'w', compression=zipfile.ZIP_DEFLATED) as z:
                z.write(db, 'MASTER.sqlite3')
            return stream.getvalue()

    def run_restore(self, artifacts, *, wanted='', this_run='900'):
        zbytes = self.make_zip()
        calls = []

        def fake_gh(cmd):
            self.assertEqual(cmd[0], 'gh')
            url = cmd[2]
            calls.append(url)
            if url.endswith('/zip'):
                self.assertEqual(url.rsplit('/', 2)[-2], '102')
                return zbytes
            return json.dumps({'artifacts': artifacts}).encode()

        with tempfile.TemporaryDirectory() as td:
            oldcwd = os.getcwd()
            try:
                os.chdir(td)
                argv = ['restore_state.py', '--year', '2022']
                if wanted:
                    argv.extend(['--run-id', wanted])
                with patch.object(sys, 'argv', argv), patch.dict(os.environ, {
                    'GITHUB_REPOSITORY': 'org/repo', 'GITHUB_RUN_ID': this_run
                }), patch('subprocess.check_output', side_effect=fake_gh):
                    out = io.StringIO()
                    with contextlib.redirect_stdout(out):
                        runpy.run_path(str(RESTORE), run_name='__main__')
                self.assertTrue((Path(td) / 'state/2022/MASTER.sqlite3').exists())
                self.assertIn('Restored task counts', out.getvalue())
                self.assertIn('artifact 102', out.getvalue())
                return out.getvalue(), calls
            finally:
                os.chdir(oldcwd)

    def test_workflow_run_none_keeps_latest_valid_artifact(self):
        out, _ = self.run_restore([
            {'id': 101, 'name': 'jra-original-state-2022', 'expired': False,
             'created_at': '2026-10-09T00:00:00Z', 'workflow_run': {'id': 500}},
            {'id': 102, 'name': 'jra-original-state-2022', 'expired': False,
             'created_at': '2026-10-11T00:00:00Z', 'workflow_run': None}
        ])
        self.assertIn('metadata unavailable', out)

    def test_omitted_workflow_run(self):
        self.run_restore([{'id': 102, 'name': 'jra-original-state-2022',
                           'expired': False, 'created_at': '2026-10-11'}])

    def test_current_run_skipped(self):
        self.run_restore([
            {'id': 110, 'name': 'jra-original-state-2022', 'expired': False,
             'created_at': '2026-10-12', 'workflow_run': {'id': 900}},
            {'id': 102, 'name': 'jra-original-state-2022', 'expired': False,
             'created_at': '2026-10-11', 'workflow_run': None}
        ])

    def test_explicit_run_with_null_metadata(self):
        out, calls = self.run_restore([{'id': 102, 'name': 'jra-original-state-2022',
            'expired': False, 'created_at': '2026-10-11', 'workflow_run': None}], wanted='899')
        self.assertIn('/actions/runs/899/artifacts?', calls[0])

    def test_corrupt_download_does_not_overwrite_existing_state(self):
        # Main tests exercise the happy path. This guards the safety promise:
        # corrupted downloads must not replace an existing checkpoint.
        with tempfile.TemporaryDirectory() as td:
            oldcwd = os.getcwd()
            try:
                os.chdir(td)
                state = Path('state/2022/MASTER.sqlite3')
                state.parent.mkdir(parents=True)
                state.write_bytes(b'KEEP_EXISTING')
                item = {'id': 102, 'name': 'jra-original-state-2022',
                        'expired': False, 'created_at': '2026-10-11', 'workflow_run': None}
                def fake_gh(cmd):
                    if cmd[2].endswith('/zip'):
                        stream = io.BytesIO()
                        with zipfile.ZipFile(stream, 'w') as z:
                            z.writestr('MASTER.sqlite3', b'NOT_SQLITE')
                        return stream.getvalue()
                    return json.dumps({'artifacts': [item]}).encode()
                with patch.object(sys, 'argv', ['restore_state.py','--year','2022']), patch.dict(os.environ, {'GITHUB_REPOSITORY':'org/repo','GITHUB_RUN_ID':'900'}), patch('subprocess.check_output', side_effect=fake_gh):
                    with self.assertRaises(sqlite3.DatabaseError):
                        runpy.run_path(str(RESTORE), run_name='__main__')
                self.assertEqual(state.read_bytes(),b'KEEP_EXISTING')
                self.assertFalse(state.with_suffix('.restore-tmp').exists())
            finally:
                os.chdir(oldcwd)


if __name__ == '__main__':
    unittest.main()
