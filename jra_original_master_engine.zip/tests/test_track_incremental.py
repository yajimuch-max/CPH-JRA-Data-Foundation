import json
import sqlite3
import tempfile
import zipfile
import unittest
from pathlib import Path
from unittest.mock import patch

from jra_master.store import Store
from jra_master.cli import export
try:
    from jra_master.track_enrichment import schema, upsert_obs, populate_context, modern_table
    TRACK_DEPS_AVAILABLE=True
except ImportError:
    TRACK_DEPS_AVAILABLE=False

@unittest.skipUnless(TRACK_DEPS_AVAILABLE, 'track PDF dependencies not installed in a normal update run')
class TrackIntegrationTests(unittest.TestCase):
    def test_modern_2026_pdf_row(self):
        vals=[['第 4日','4月 5日','日曜日','B','07:00','7.9','06:00','13.7','14.6','13.5','15.1']]
        result=modern_table(vals,2026,'中山','https://www.jra.go.jp/keiba/baba/archive/2026pdf/nakayama03.pdf','hash',1)
        self.assertEqual(result[0]['date'],'2026-04-05')
        self.assertEqual(result[0]['cushion'],7.9)
        self.assertEqual(result[0]['used_course'],'B')

    def _observation(self,hash='source1',cushion=9.4):
        return {'date':'2026-01-04','track':'中山','source_url':'https://www.jra.go.jp/keiba/baba/archive/2026pdf/nakayama01.pdf',
                'source_sha256':hash,'source_page':1,'raw_format':'MODERN_ROW','used_course':'B',
                'cushion_time':'07:00','cushion':cushion,'moisture_time':'05:00',
                'turf_goal':12.5,'turf_fourth':13.6,'dirt_goal':7.1,'dirt_fourth':8.6}

    def test_one_source_idempotent_and_revision(self):
        with tempfile.TemporaryDirectory() as td:
            c=sqlite3.connect(Path(td)/'test.sqlite3')
            c.execute('CREATE TABLE races(race_id TEXT PRIMARY KEY,race_date TEXT,track TEXT,payload_json TEXT)')
            c.execute('INSERT INTO races VALUES(?,?,?,?)',('race1','2026-01-04','中山',json.dumps({'surface':'芝','track_condition_turf':'良'})))
            schema(c)
            self.assertEqual(upsert_obs(c,[self._observation()]),0)
            self.assertEqual(upsert_obs(c,[self._observation()]),0)
            self.assertEqual(upsert_obs(c,[self._observation('source2',8.9)]),1)
            self.assertEqual(c.execute('select count(*) from official_track_revisions').fetchone()[0],1)
            populate_context(c)
            self.assertEqual(c.execute('select used_turf_course,going_from_official_result,going_at_0930 from official_race_track_context').fetchone(),('B','良',None))
            c.close()

    def test_export_retains_track_tables(self):
        with tempfile.TemporaryDirectory() as td:
            store=Store(Path(td)/'state.sqlite3')
            schema(store.c)
            upsert_obs(store.c,[self._observation()])
            store.c.commit()
            # Export can be partial on an empty MASTER; enrichment tables must survive.
            export(store,Path(td)/'output',2026)
            store.c.close()
            files=list((Path(td)/'output').glob('*.zip'))
            self.assertEqual(len(files),1)
            with zipfile.ZipFile(files[0]) as z:
                manifest=json.loads(z.read('manifest.json'))
                self.assertEqual(manifest['schema_version'],'2.1.0')
                db=Path(td)/'read.sqlite3';db.write_bytes(z.read('MASTER.sqlite3'))
            c=sqlite3.connect(db)
            self.assertEqual(c.execute('SELECT count(*) FROM official_track_daily').fetchone()[0],1)
            c.close()

if __name__=='__main__': unittest.main()
