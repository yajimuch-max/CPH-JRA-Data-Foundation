from __future__ import annotations
import argparse, hashlib, json, sqlite3, zipfile
from datetime import datetime, timezone
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from integrate_market_data import extract_annual

def sha256(path: Path) -> str:
    h=hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda:f.read(1024*1024),b""):
            h.update(block)
    return h.hexdigest()

def main() -> int:
    p=argparse.ArgumentParser()
    p.add_argument("--root", required=True)
    p.add_argument("--repair-odds-root", required=True)
    p.add_argument("--annual-audit", required=True)
    p.add_argument("--output", required=True)
    a=p.parse_args()
    root=Path(a.root)
    db_path=root/"data"/"cph_jra_df.sqlite3"
    con=sqlite3.connect(db_path)
    con.execute("PRAGMA foreign_keys=ON")

    # Merge only newly collected missing-race odds.
    for source in sorted(Path(a.repair_odds_root).rglob("*.sqlite3")):
        src=sqlite3.connect(source)
        errs=src.execute("SELECT COUNT(*) FROM collection_errors").fetchone()[0]
        if errs:
            raise SystemExit(f"REPAIR_ODDS_ERRORS:{source}:{errs}")
        rows=src.execute(
            "SELECT race_key,horse_no,final_win_odds,status,result_url,odds_cname,raw_sha256,fetched_at_utc FROM win_odds"
        ).fetchall()
        src.close()
        con.executemany("INSERT OR REPLACE INTO win_odds VALUES(?,?,?,?,?,?,?,?)",rows)

    con.execute("DROP TABLE IF EXISTS repair_win_odds_backup")
    con.commit()
    con.close()

    # Rebuild popularity and all payout tables from official result snapshots.
    market=extract_annual(root,2019)

    con=sqlite3.connect(db_path)
    counts={
      "race_count":con.execute("SELECT COUNT(*) FROM races_pre_race").fetchone()[0],
      "entry_count":con.execute("SELECT COUNT(*) FROM race_entries_pre_race").fetchone()[0],
      "result_count":con.execute("SELECT COUNT(*) FROM race_results").fetchone()[0],
      "odds_race_count":con.execute("SELECT COUNT(DISTINCT race_key) FROM win_odds").fetchone()[0],
      "odds_rows":con.execute("SELECT COUNT(*) FROM win_odds").fetchone()[0],
      "entries_without_odds":con.execute(
          "SELECT COUNT(*) FROM race_entries_pre_race e LEFT JOIN win_odds o USING(race_key,horse_no) WHERE o.race_key IS NULL"
      ).fetchone()[0],
      "odds_without_entries":con.execute(
          "SELECT COUNT(*) FROM win_odds o LEFT JOIN race_entries_pre_race e USING(race_key,horse_no) WHERE e.race_key IS NULL"
      ).fetchone()[0],
      "duplicate_odds_keys":con.execute(
          "SELECT COUNT(*) FROM (SELECT race_key,horse_no,COUNT(*) n FROM win_odds GROUP BY race_key,horse_no HAVING n>1)"
      ).fetchone()[0],
      "integrity_check":con.execute("PRAGMA integrity_check").fetchone()[0],
      "foreign_key_violations":len(con.execute("PRAGMA foreign_key_check").fetchall()),
    }
    con.execute("PRAGMA wal_checkpoint(TRUNCATE)")
    con.commit()
    con.close()

    annual=json.loads(Path(a.annual_audit).read_text(encoding="utf-8"))
    ok=(annual.get("audit_status")=="PASS"
        and counts["race_count"]==counts["odds_race_count"]
        and counts["entry_count"]==counts["result_count"]==counts["odds_rows"]
        and counts["entries_without_odds"]==0
        and counts["odds_without_entries"]==0
        and counts["duplicate_odds_keys"]==0
        and counts["integrity_check"]=="ok"
        and counts["foreign_key_violations"]==0
        and market["status"]=="PASS")
    if not ok:
        raise SystemExit("FINAL_REPAIR_AUDIT_FAILED:"+json.dumps(
            {"annual":annual,"counts":counts,"market":market},ensure_ascii=False))

    audit={
      "asset":"2019_JRA公式データ_年間統合版",
      "status":"PASS",
      "audited_at_utc":datetime.now(timezone.utc).isoformat(),
      "repair":"legacy schedule surface parser corrected; full 110-day cache-only/reparse audit",
      "annual_audit_status":"PASS",
      "market":market,
      "odds":counts,
    }
    (root/"2019_統合監査結果.json").write_text(json.dumps(audit,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    (root/"00_最初に読んでください.txt").write_text(
        "2019 JRA公式データ 年間統合版\\n===============================\\n\\n"
        "最終監査: PASS\\n\\n"
        "2019年旧レーシングカレンダーの条件欄解析を修正後、全110開催日を"
        "CACHE_ONLY再監査＋REPARSEし、年間監査、全馬単勝最終オッズ、人気、"
        "全券種払戻、SQLite整合性を再確認した完成版です。\\n",
        encoding="utf-8"
    )

    out=Path(a.output); out.mkdir(parents=True,exist_ok=True)
    zip_path=out/"2019_JRA公式データ_年間統合版.zip"
    top=Path("2019_JRA公式データ_年間統合版")
    with zipfile.ZipFile(zip_path,"w",zipfile.ZIP_DEFLATED,compresslevel=6,allowZip64=True) as z:
        for path in sorted(p for p in root.rglob("*") if p.is_file()):
            z.write(path, top/path.relative_to(root))
    digest=sha256(zip_path)
    sha_path=out/"2019_JRA公式データ_年間統合版_SHA256.txt"
    sha_path.write_text(f"{digest}  {zip_path.name}\\n",encoding="utf-8")
    print(json.dumps({"status":"PASS","zip":str(zip_path),"sha256":digest,
                      "counts":counts,"market":market},ensure_ascii=False,indent=2))
    return 0

if __name__=="__main__":
    raise SystemExit(main())
