"""Incremental JRA-only PDF evidence enrichment.

Guardrails: never rewrite original race/runner/results/odds/pedigree tables;
record positive observations with strict race+runner matches; missing is UNKNOWN,
not False. Post-event official PDFs are NOT 09:30 observation timestamps.
"""
from __future__ import annotations
import datetime as dt
import hashlib
import json
import re
import sqlite3
import time
import unicodedata
from pathlib import Path
from urllib.parse import urlparse
from . import legacy_track as legacy

VERSION='JRA_OFFICIAL_EXPANSION_0.5.2'
CORE=('races','runners','results','win_odds','payouts','laps','corners','pedigree')
GOING=('良','稍重','重','不良')
ORIGINS=('新ひだか','新冠','浦河','日高','千歳','白老','平取','様似','静内','三石','門別',
         'むかわ','えりも','浦臼','厚真','安平','新得','大樹','音更','青森','栃木','千葉',
         '北海道','米国','英国','愛国','仏国','加国','豪州','独国','日高町')
ROW=re.compile(r'^\s*(?P<frame>[1-8])\s*(?P<number>1[0-8]|[1-9])\s*(?P<body>.+)$')
SECT=re.compile(r'〔\s*(出走取消|競走除外|騎手変更|負担重量変更)\s*〕')
CLASS_NAMES=('新馬','未勝利','3勝クラス','2勝クラス','1勝クラス','オープン',
             '500万円以下','1000万円以下','1600万円以下','500万下','1000万下','1600万下',
             'ＧⅠ','ＧⅡ','ＧⅢ','GⅠ','GⅡ','GⅢ','G1','G2','G3','リステッド')

def now():return dt.datetime.now(dt.timezone.utc).isoformat()
def norm(x):return unicodedata.normalize('NFKC',str(x or '')).replace('\u3000',' ').strip()
def compact(x):return re.sub(r'\s+','',norm(x))
def digest(data):return hashlib.sha256(data).hexdigest()

def schema(c):
    c.executescript('''
    CREATE TABLE IF NOT EXISTS official_expansion_receipts (
      source_url TEXT PRIMARY KEY, year INTEGER NOT NULL, track TEXT NOT NULL,
      parser_version TEXT NOT NULL, source_sha256 TEXT, status TEXT NOT NULL,
      verified_races INTEGER NOT NULL DEFAULT 0, verified_runner_rows INTEGER NOT NULL DEFAULT 0,
      warnings_json TEXT NOT NULL DEFAULT '[]', checked_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS official_expansion_races (
      race_id TEXT PRIMARY KEY REFERENCES races(race_id),
      race_date TEXT NOT NULL, track TEXT NOT NULL, race_number INTEGER NOT NULL,
      condition_text TEXT, class_official_text TEXT,
      source_url TEXT NOT NULL, source_sha256 TEXT NOT NULL, source_page INTEGER NOT NULL,
      availability TEXT NOT NULL DEFAULT 'POST_EVENT_PDF_TIME_UNVERIFIED', verified_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS official_expansion_runners (
      race_id TEXT NOT NULL, horse_number INTEGER NOT NULL, horse_id TEXT NOT NULL,
      owner_text TEXT, breeder_text TEXT, birthplace_text TEXT, blinker_observed INTEGER,
      cancellation_kind TEXT, cancellation_notice TEXT, change_notice TEXT,
      source_url TEXT NOT NULL, source_sha256 TEXT NOT NULL, source_page INTEGER NOT NULL,
      availability TEXT NOT NULL DEFAULT 'POST_EVENT_PDF_TIME_UNVERIFIED', verified_at TEXT NOT NULL,
      PRIMARY KEY(race_id,horse_number),
      FOREIGN KEY(race_id,horse_number) REFERENCES runners(race_id,horse_number));
    CREATE TABLE IF NOT EXISTS official_expansion_revisions (
      id INTEGER PRIMARY KEY, target_table TEXT NOT NULL, item_key TEXT NOT NULL,
      old_json TEXT NOT NULL, new_json TEXT NOT NULL, source_sha256 TEXT NOT NULL,
      recorded_at TEXT NOT NULL);
    CREATE INDEX IF NOT EXISTS idx_expansion_race_day ON official_expansion_races(race_date,track);
    ''')

# The old JRA daily PDF layout can place two race reports on one PDF page.
# pdfplumber occasionally concatenates a second header to an earlier text line.
# Parse *all* verified meeting/race markers, rather than only the first full
# date header on each line.  This is still a conservative positive-only join.
MEETING_HEADER = re.compile(
    r'\(\s*(?P<era>\d{1,2})\s*(?P<track>札幌|函館|福島|新潟|東京|中山|中京|京都|阪神|小倉)\s*'
    r'(?P<meeting>\d{1,2})\s*\)\s*第\s*(?P<dayno>\d{1,2})\s*日\s*第\s*(?P<race>\d{1,2})\s*競走')
DATE_IN_HEADER = re.compile(r'(?P<month>\d{1,2})\s*月\s*(?P<day>\d{1,2})\s*日')

def extract_blocks(pages,year,track,meeting=None,meeting_day=None):
    """Return race blocks from JRA PDF, fail closed on ambiguous dates.

    A race header needs an *explicit* official meeting+day+race marker. A
    full JRA date must also appear on at least one such header in the PDF;
    undated headers are joined to that unique verified day only.  Repeated
    markers, mixed dates, other meetings and out-of-range race numbers fail.
    """
    events=[];explicit_days=set()
    for pn,text in pages:
        for rawline in (text or '').splitlines():
            line=norm(rawline)
            matches=list(MEETING_HEADER.finditer(line))
            if not matches:
                events.append((pn,None,line))
                continue
            last=0
            for index,match in enumerate(matches):
                # Any preceding prose belongs to the previous race, never to
                # the newly detected header.
                beginning=line[last:match.start()]
                if beginning:events.append((pn,None,beginning))
                following=line[match.end():matches[index+1].start() if index+1<len(matches) else len(line)]
                full=line[max(0,match.start()-95):match.end()]
                # Use date directly printed before this meeting marker; do not
                # mistake historic dates in the middle of ordinary prose.
                prefix=full[:full.rfind(match.group(0))]
                dates=list(DATE_IN_HEADER.finditer(prefix))
                day=None
                if dates:
                    date=dates[-1]
                    try:day=dt.date(year,int(date['month']),int(date['day'])).isoformat()
                    except ValueError:day=None
                if day:explicit_days.add(day)
                info={'track':match['track'],'meeting':int(match['meeting']),
                      'meeting_day':int(match['dayno']),'no':int(match['race']),
                      'date':day,'page':pn}
                events.append((pn,info,full if day else match.group(0)))
                if following:events.append((pn,None,following))
                last=matches[index+1].start() if index+1<len(matches) else len(line)
            # All fragments of this source line were consumed.
    if not events or len(explicit_days)!=1:return []
    verified_day=next(iter(explicit_days))
    blocks=[];current=None;seen=set()
    for pn,header,line in events:
        if header is not None:
            if header['track']!=track or header['date'] not in (None,verified_day):
                raise ValueError('OFFICIAL_HEADER_TRACK_OR_DATE_CONFLICT')
            if meeting is not None and header['meeting']!=meeting:
                raise ValueError('OFFICIAL_HEADER_MEETING_CONFLICT')
            if meeting_day is not None and header['meeting_day']!=meeting_day:
                raise ValueError('OFFICIAL_HEADER_DAY_CONFLICT')
            no=header['no']
            if not 1<=no<=12:raise ValueError('OFFICIAL_HEADER_RACE_OUT_OF_RANGE')
            if no in seen:raise ValueError('REPEATED_RACE_HEADER')
            seen.add(no)
            if current:blocks.append(current)
            current={'date':verified_day,'no':no,'page':pn,'lines':[line]}
        elif current:
            current['lines'].append(line)
    if current:blocks.append(current)
    return blocks

def known_runner_map(c,rid):
    out={}
    for no,hid,body in c.execute('SELECT horse_number,horse_id,payload_json FROM runners WHERE race_id=?',(rid,)):
        x=json.loads(body)
        out[int(no)]={'horse_id':hid,'name':x.get('horse_name') or c.execute('SELECT horse_name FROM horses WHERE horse_id=?',(hid,)).fetchone()[0],
                      'jockey':x.get('jockey_name'), 'trainer':x.get('trainer_name'),
                      'bodyweight':x.get('body_weight_kg')}
    return out

def conditions(lines):
    """Only exact text adjacent to JRA start time; never infer missing class."""
    section=[];started=False
    for line in lines[1:9]:
        if line.startswith('本 賞') or re.search(r'本\s*賞',line):break
        if '発走' in line:started=True;continue
        if started:section.append(line)
    text=norm(' '.join(section))[:550] if section else None
    # Small-class name, only if visibly printed. NOT prediction inferred grade.
    cls=next((x for x in CLASS_NAMES if text and x in text),None)
    return text,cls

def _official_row(line,no,r):
    m=ROW.match(norm(line))
    if not m or int(m['number'])!=no:return None
    if compact(r['name']) not in compact(m['body']):return None
    return m['body']

def parse_runner_line(line,no,r):
    """Return only observations uniquely anchored to known runner + printed body weight.
    Missing B is not proof of no blinkers.  Owner/breeder are conservative candidates.
    """
    body=_official_row(line,no,r)
    if body is None:return None
    flat=compact(body)
    name=compact(r['name'])
    start=flat.find(name)+len(name)
    if flat.count(name)!=1:return None
    weight=r['bodyweight']
    positive=None
    if weight is not None and isinstance(weight,(int,float)) and float(weight).is_integer():
        w=str(int(weight))
        if re.search(r'B'+re.escape(w)+r'(?=[+\-±＋－―\d])',flat[start:]):positive=1
    jockey=compact(r['jockey']);trainer=compact(r['trainer'])
    info={'blinker_observed':positive}
    if not jockey or not trainer:return info
    ji=flat.find(jockey,start);ti=flat.find(trainer,ji+len(jockey)) if ji>=0 else -1
    if ji<0 or ti<0 or flat.count(trainer)!=1:return info
    owner=flat[ji+len(jockey):ti]
    if 2<=len(owner)<=75 and not re.search(r'\d{2}',owner):info['owner_text']=owner
    after=flat[ti+len(trainer):]
    origins=[s for s in ORIGINS if after.startswith(s)]
    if len(origins)==1:
        loc=origins[0];info['birthplace_text']=loc
        breeder=after[len(loc):]
        if weight and isinstance(weight,(int,float)) and float(weight).is_integer():
            wm=re.search(r'B?'+str(int(weight))+r'(?=[+\-±＋－―\d])',breeder)
            if wm:breeder=breeder[:wm.start()]
            else:breeder=''
        if 2<=len(breeder)<=85 and not re.search(r'\d{3}',breeder):info['breeder_text']=breeder
    return info

def cancel_notice(lines,horse):
    name=compact(horse)
    for line in lines:
        m=SECT.search(line)
        if not m:continue
        if name+'号' not in compact(line):continue
        # A line may mention multiple horses. In that case do not attribute it.
        if compact(line).count('号')!=1:continue
        statement=norm(line[m.start():]).split('。')[0][:500]
        if m.group(1) in ('出走取消','競走除外'):
            return {'cancellation_kind':m.group(1),'cancellation_notice':statement}
        return {'change_notice':statement}
    return {}

def _merge(c,table,key_cols,record,hashval,allow_reparse=False):
    row=c.execute(f"SELECT * FROM {table} WHERE "+' AND '.join(f'{k}=?' for k in key_cols),[record[k] for k in key_cols]).fetchone()
    cols=[v[1] for v in c.execute(f'PRAGMA table_info({table})')]
    if row:
        old=dict(zip(cols,row));new=dict(old)
        # Never overwrite an existing observation with empty/unknown.
        for k,v in record.items():
            if k in key_cols:continue
            if v is not None and v!='':new[k]=v
        if all(new[k]==old[k] for k in cols):return 0
        fact_cols=[k for k in cols if k not in ('source_sha256','verified_at')]
        if all(new[k]==old[k] for k in fact_cols):
            # Same observed facts; a new PDF hash or retrieval timestamp alone
            # is a provenance refresh, not a substantive official correction.
            c.execute(f"UPDATE {table} SET source_sha256=?,verified_at=? WHERE "+
                      ' AND '.join(f'{k}=?' for k in key_cols),
                      [hashval,new['verified_at']]+[record[k] for k in key_cols])
            return 0
        if old['source_sha256']==hashval and not allow_reparse:
            raise ValueError('CONFLICT_SAME_PDF '+table+' '+str([record[k] for k in key_cols]))
        c.execute('''INSERT INTO official_expansion_revisions(target_table,item_key,old_json,new_json,source_sha256,recorded_at)
                     VALUES(?,?,?,?,?,?)''',(table,json.dumps({k:record[k] for k in key_cols},ensure_ascii=False),
                     json.dumps(old,ensure_ascii=False),json.dumps(new,ensure_ascii=False),hashval,now()))
        c.execute(f"UPDATE {table} SET "+','.join(f'{k}=?' for k in cols if k not in key_cols)+' WHERE '+
                  ' AND '.join(f'{k}=?' for k in key_cols),[new[k] for k in cols if k not in key_cols]+[record[k] for k in key_cols]);return 1
    c.execute(f"INSERT INTO {table} ({','.join(record)}) VALUES ({','.join(['?']*len(record))})",list(record.values()))
    return 1

def apply_report(c,year,track,url,hashval,pages):
    src=legacy.NAME_RE.fullmatch(Path(urlparse(url).path).name)
    if not src or int(src['year'])!=year or legacy.TRACK_ROMAN.get(src['roman'].lower())!=track:
        raise ValueError('OFFICIAL_DAILY_PDF_FILENAME_MISMATCH')
    existing=c.execute('SELECT parser_version,source_sha256 FROM official_expansion_receipts WHERE source_url=?',(url,)).fetchone()
    allow_reparse=bool(existing and existing[0]!=VERSION and existing[1]==hashval)
    blocks=extract_blocks(pages,year,track,int(src['meeting']),int(src['day']))
    if not blocks:raise ValueError('NO_REPORT_RACE_BLOCKS')
    if len({b['date'] for b in blocks})!=1:raise ValueError('MULTIPLE_DAYS_REPORT')
    day=blocks[0]['date']
    expected={int(no):(rid,raw) for rid,no,raw in c.execute('SELECT race_id,race_number,payload_json FROM races WHERE race_date=? AND track=?',(day,track))}
    if not expected:raise ValueError('NO_MASTER_DATE_TRACK '+day+' '+track)
    if len(blocks)!=len({b['no'] for b in blocks}):raise ValueError('REPEATED_RACE_HEADER')
    race_count=0;horses=0;warnings=[]
    for b in blocks:
        no=b['no']
        if no not in expected:raise ValueError('RACE_NOT_IN_MASTER '+day+' '+str(no))
        rid,raw=expected[no];record=json.loads(raw)
        label=record.get('meeting_label')
        expected_label=f"{int(src['meeting'])}回{track}{int(src['day'])}日"
        if label and label!=expected_label:raise ValueError('MEETING_LABEL_CONFLICT '+str(no))
        page=b['page'];cond,cls=conditions(b['lines']);surf=record.get('surface')
        head=' '.join(b['lines'][:4]);surfaces=set(re.findall(r'[(（]\s*(芝|ダート|障害)',head))
        if len(surfaces)==1 and surf and next(iter(surfaces))!=surf:
            raise ValueError('SURFACE_CONFLICT '+str(no))
        if cond or cls:
            _merge(c,'official_expansion_races',['race_id'],
                   {'race_id':rid,'race_date':day,'track':track,'race_number':no,
                    'condition_text':cond,'class_official_text':cls,'source_url':url,
                    'source_sha256':hashval,'source_page':page,
                    'availability':'POST_EVENT_PDF_TIME_UNVERIFIED','verified_at':now()},hashval,allow_reparse=allow_reparse)
            race_count+=1
        runners=known_runner_map(c,rid)
        found={}
        for line in b['lines']:
            match=ROW.match(line)
            if not match:continue
            horse_no=int(match['number']);r=runners.get(horse_no)
            if not r:continue
            parsed=parse_runner_line(line,horse_no,r)
            if parsed is not None:
                if horse_no in found:raise ValueError('DUPLICATE_PDF_RUNNER '+rid+' '+str(horse_no))
                found[horse_no]=(parsed,line)
        for horse_no,r in runners.items():
            piece=found.get(horse_no);rowvals=piece[0] if piece else {}
            notice=cancel_notice(b['lines'],r['name'])
            updates={**rowvals,**notice}
            if not any(v is not None for v in updates.values()):continue
            record={'race_id':rid,'horse_number':horse_no,'horse_id':r['horse_id'],
                    'owner_text':updates.get('owner_text'),'breeder_text':updates.get('breeder_text'),
                    'birthplace_text':updates.get('birthplace_text'),
                    'blinker_observed':updates.get('blinker_observed'),
                    'cancellation_kind':updates.get('cancellation_kind'),
                    'cancellation_notice':updates.get('cancellation_notice'),
                    'change_notice':updates.get('change_notice'),'source_url':url,
                    'source_sha256':hashval,'source_page':page,
                    'availability':'POST_EVENT_PDF_TIME_UNVERIFIED','verified_at':now()}
            _merge(c,'official_expansion_runners',['race_id','horse_number'],record,hashval,allow_reparse=allow_reparse)
            horses+=1
    if set(b['no'] for b in blocks)!=set(expected):warnings.append(f'PARTIAL_RACE_COVERAGE:{len(blocks)}/{len(expected)}')
    return race_count,horses,warnings

def sync_year(year,db_path,cache_root=Path('jra_pdf_cache'),offline=False,refresh=False,budget_seconds=8700,throttle=1.2):
    """Each PDF is a transaction. The deadline stops *before* Actions timeout.
    A PASS receipt is never re-fetched unless refresh=true. PDF bytes are cache-only,
    excluded from exported MASTER.
    """
    if year<2010:raise ValueError('2010+ year required')
    import requests
    deadline=time.monotonic()+budget_seconds
    db_path=Path(db_path)
    if not db_path.is_file():raise ValueError('STATE_MISSING: Release baseline or saved state required')
    c=sqlite3.connect(db_path);c.execute('PRAGMA busy_timeout=30000')
    before={t:c.execute('SELECT count(*) FROM '+t).fetchone()[0] for t in CORE}
    if c.execute('SELECT count(*) FROM races WHERE race_date NOT LIKE ?',(str(year)+'-%',)).fetchone()[0]:
        c.close();raise ValueError('STATE_RACE_YEAR_MISMATCH')
    with c:
        schema(c)
        from .track_enrichment import schema as track_schema
        track_schema(c);legacy.schema(c)
    cache=Path(cache_root)/str(year)/'official_reports';cache.mkdir(parents=True,exist_ok=True)
    session=requests.Session();session.headers['User-Agent']='Mozilla/5.0 (compatible; archival provenance verification)'
    idx=cache/'index.json'
    if offline:
        if not idx.is_file():raise ValueError('OFFLINE_INDEX_MISSING')
        links=[(x['track'],x['url']) for x in json.loads(idx.read_text(encoding='utf8'))]
    else:
        links=legacy.official_report_links(year,session)
        if not links:raise ValueError('EMPTY_OFFICIAL_REPORT_INDEX')
        idx.write_text(json.dumps([{'track':t,'url':u} for t,u in links],ensure_ascii=False,indent=2),encoding='utf8')
    summary={'year':year,'source':'JRA_OFFICIAL_ANNUAL_RESULTS_PDF','parser_version':VERSION,
             'pdf_index_count':len(links),'downloaded':0,'parsed':0,'skipped':0,
             'failed_this_run':[],'deferred_due_to_budget':0,'verified_races_this_run':0,
             'verified_runners_this_run':0,'official_course_and_going':'ENABLED_FROM_2011',
             '2010_note':'2010 official meeting PDF has a different structure; only validated meeting course is imported.'}
    try:
        for i,(track,url) in enumerate(links):
            if time.monotonic()>deadline-150:
                summary['deferred_due_to_budget']=len(links)-i;break
            old=c.execute('SELECT parser_version,status FROM official_expansion_receipts WHERE source_url=?',(url,)).fetchone()
            if old and old[0]==VERSION and old[1] in ('PASS','PARTIAL') and not refresh:
                summary['skipped']+=1;continue
            filename=Path(urlparse(url).path).name
            file=cache/(digest(url.encode())[:16]+'_'+filename)
            # Reuse previous track-run's JRA PDF cache for a new parser version.
            legacy_cached=Path(cache_root)/str(year)/'legacy_reports'/filename
            if not file.exists() and legacy_cached.is_file() and not refresh:
                import shutil
                shutil.copyfile(legacy_cached,file)
            try:
                if not file.exists() or (refresh and not offline):
                    if offline:raise ValueError('OFFLINE_PDF_MISSING')
                    response=session.get(url,timeout=(20,55));response.raise_for_status()
                    raw=response.content
                    if not raw.startswith(b'%PDF'):raise ValueError('NON_PDF_CONTENT')
                    temp=file.with_suffix('.partial');temp.write_bytes(raw);temp.replace(file)
                    summary['downloaded']+=1
                    time.sleep(throttle)
                raw=file.read_bytes()
                if not raw.startswith(b'%PDF'):raise ValueError('INVALID_CACHED_PDF')
                hashval=digest(raw)
                import pdfplumber
                with pdfplumber.open(file) as pdf:
                    pages=[(n,page.extract_text() or '') for n,page in enumerate(pdf.pages,1)]
                warnings=[];verified_races=0;verified_horses=0
                with c:
                    if year==2010:
                        # validated opening section and meeting identity, never invented race going
                        lo,hi,meet,course=legacy.parse_2010_meeting_courses(pages,year,track,url)
                        count=legacy._apply_2010_course(c,lo,hi,meet,track,course,url,hashval)
                        warnings.append('2010_FIELD_PARSER_NOT_SUPPORTED:course_only')
                        verified_races=count
                        c.execute('''INSERT INTO official_legacy_report_receipts
                            (source_url,track,race_date,source_sha256,parse_status,matched_races,error,checked_at)
                            VALUES (?,?,?,?,?,?,?,?) ON CONFLICT(source_url) DO UPDATE SET
                            source_sha256=excluded.source_sha256,parse_status=excluded.parse_status,
                            matched_races=excluded.matched_races,checked_at=excluded.checked_at''',
                            (url,track,None,hashval,'PARTIAL',count,'2010_COURSE_ONLY',now()))
                    else:
                        try:
                            day,rows,course=legacy.parse_report_pages(pages,year,track,url,hashval)
                            count,complete,expected=legacy._apply(c,day,track,rows,course,url,hashval)
                            if not complete:warnings.append(f'GOING_COURSE_PARTIAL:{count}/{expected}')
                            c.execute('''INSERT INTO official_legacy_report_receipts
                                (source_url,track,race_date,source_sha256,parse_status,matched_races,error,checked_at)
                                VALUES (?,?,?,?,?,?,?,?) ON CONFLICT(source_url) DO UPDATE SET
                                race_date=excluded.race_date,source_sha256=excluded.source_sha256,
                                parse_status=excluded.parse_status,matched_races=excluded.matched_races,
                                error=excluded.error,checked_at=excluded.checked_at''',
                                (url,track,day,hashval,'PASS' if complete else 'PARTIAL',count,
                                 None if complete else f'PARTIAL:{count}/{expected}',now()))
                        except ValueError as exc:
                            warnings.append('GOING_COURSE_SKIPPED:'+str(exc)[:120])
                        verified_races,verified_horses,w=apply_report(c,year,track,url,hashval,pages)
                        warnings.extend(w)
                    status='PARTIAL' if warnings else 'PASS'
                    c.execute('''INSERT INTO official_expansion_receipts
                    (source_url,year,track,parser_version,source_sha256,status,verified_races,
                      verified_runner_rows,warnings_json,checked_at)
                    VALUES(?,?,?,?,?,?,?,?,?,?)
                    ON CONFLICT(source_url) DO UPDATE SET year=excluded.year,track=excluded.track,
                      parser_version=excluded.parser_version,source_sha256=excluded.source_sha256,
                      status=excluded.status,verified_races=excluded.verified_races,
                      verified_runner_rows=excluded.verified_runner_rows,
                      warnings_json=excluded.warnings_json,checked_at=excluded.checked_at''',
                    (url,year,track,VERSION,hashval,status,verified_races,verified_horses,
                     json.dumps(warnings,ensure_ascii=False),now()))
                summary['parsed']+=1;summary['verified_races_this_run']+=verified_races
                summary['verified_runners_this_run']+=verified_horses
            except Exception as exc:
                message=f'{url}: {type(exc).__name__}: {exc}'
                summary['failed_this_run'].append(message[:400])
                with c:
                    c.execute('''INSERT INTO official_expansion_receipts
                    (source_url,year,track,parser_version,source_sha256,status,warnings_json,checked_at)
                    VALUES(?,?,?,?,?,?,?,?)
                    ON CONFLICT(source_url) DO UPDATE SET parser_version=excluded.parser_version,
                      status=excluded.status,warnings_json=excluded.warnings_json,checked_at=excluded.checked_at''',
                    (url,year,track,VERSION,None,'FAILED',json.dumps([message],ensure_ascii=False),now()))
        with c:legacy.overlay_context(c)
        integrity=c.execute('PRAGMA integrity_check').fetchone()[0]
        fk=c.execute('PRAGMA foreign_key_check').fetchall()
        after={t:c.execute('SELECT count(*) FROM '+t).fetchone()[0] for t in CORE}
        if integrity!='ok' or fk or before!=after:raise RuntimeError('CORE_INTEGRITY_FAILURE')
        counts={t:c.execute('SELECT COUNT(*) FROM '+t).fetchone()[0] for t in
                ('official_expansion_races','official_expansion_runners','official_legacy_race_values')}
        receipts=c.execute('SELECT status,count(*) FROM official_expansion_receipts GROUP BY status').fetchall()
        summary.update({'receipt_status_counts':dict(receipts),'stored_counts':counts,
                        'integrity':integrity,'core_unchanged_counts':True,
                        'pending_pdfs':len(links)-sum(x[1] for x in receipts if x[0] in ('PASS','PARTIAL')),
                        'checked_at':now(),
                        'publication_time_policy':'POST_EVENT_PDF_NOT_PRE_RACE_SNAPSHOT'})
        summary['status']='PASS' if summary['pending_pdfs']==0 and not dict(receipts).get('PARTIAL',0) and year!=2010 else 'PARTIAL'
        return summary
    finally:c.close()

def export_official_patch(year,db_path,out,report):
    """Fast, lossless export of existing original plus only append-only official tables.
    Unlike rebuilding a master, never normalize or replace the base payload_json.
    """
    import tempfile,zipfile
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='official_patch_export_') as temp_dir:
        stage=Path(temp_dir);copy=stage/'MASTER.sqlite3'
        source=sqlite3.connect(db_path);dest=sqlite3.connect(copy)
        try:
            source.backup(dest,pages=2000)
            dest.commit()
        finally:dest.close();source.close()
        check=sqlite3.connect(copy)
        try:
            if check.execute('PRAGMA integrity_check').fetchone()[0]!='ok':
                raise ValueError('EXPORT_DB_INTEGRITY_FAILED')
            if check.execute('PRAGMA foreign_key_check').fetchall():
                raise ValueError('EXPORT_DB_FOREIGN_KEY_FAILED')
            counts={t:check.execute('SELECT count(*) FROM '+t).fetchone()[0] for t in CORE}
            statuses={a:b for a,b in check.execute('SELECT status,count(*) FROM official_expansion_receipts GROUP BY status')}
            row=check.execute("SELECT value FROM metadata WHERE key='year'").fetchone()
            if not row or json.loads(row[0])!=year:raise ValueError('EXPORT_YEAR_MISMATCH')
        finally:check.close()
        audit={'status':'PARTIAL' if report['status']!='PASS' else 'PASS',
               'year':year,'integrity':'ok','foreign_keys':[],
               'core_table_counts':counts,'official_expansion':report,
               'receipt_status_counts':statuses,'verified_at':now(),
               'method':'LOSSLESS_SQLITE_SNAPSHOT_NO_CORE_REBUILD'}
        manifest={'schema_version':'2.1.0','purpose':'ENGINE_INDEPENDENT_ORIGINAL_MASTER',
                  'year':year,'built_at':now(),'audit_status':audit['status'],
                  'data_format':'JRA_UNIFIED_CURRENT_V1','official_expansion':VERSION,
                  'master_sha256':digest(copy.read_bytes()),'raw_included':False,
                  'counts':counts,'historic_pdf_not_actual_pre_race_observation':True}
        (stage/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
        (stage/'AUDIT.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
        (stage/'README.txt').write_text('JRA official-only incremental enrichment. Original race/result/odds/pedigree tables preserved; historical post-event PDF fields are separately stored; consult AUDIT.json for partial coverage.\n',encoding='utf8')
        name=f'{year}_JRA_MASTER.zip';output=out/name
        with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
            for n in ('MASTER.sqlite3','manifest.json','AUDIT.json','README.txt'):
                z.write(stage/n,n)
        with zipfile.ZipFile(output) as z:
            if z.testzip() is not None:raise ValueError('EXPORT_ZIP_CORRUPT')
        (out/(name+'.sha256')).write_text(digest(output.read_bytes())+'  '+name+'\n',encoding='utf8')
        print('OFFICIAL_EXPANSION_MASTER_EXPORTED',str(output),output.stat().st_size,flush=True)
        return audit

def run(year,db_path,out='delivery',refresh=False,budget_seconds=8700,offline=False,export_master=True):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    try:
        report=sync_year(year,db_path,refresh=refresh,budget_seconds=budget_seconds,offline=offline)
    except Exception as exc:
        report={'year':year,'status':'ERROR','error':f'{type(exc).__name__}: {exc}','checked_at':now()}
    (out/f'official_expansion_audit_{year}.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    print('OFFICIAL_EXPANSION_AUDIT',json.dumps(report,ensure_ascii=False),flush=True)
    if db_path and Path(db_path).exists():
        c=sqlite3.connect(db_path)
        try:
            if report['status']!='ERROR':
                with c:c.execute('INSERT OR REPLACE INTO metadata(key,value) VALUES (?,?)',('official_expansion_audit',json.dumps(report,ensure_ascii=False)))
        finally:c.close()
        if export_master:export_official_patch(year,db_path,out,report)
    return 2 if report['status']=='ERROR' else 0
