"""2026-09-06 Hanshin 11R canonical name vs JRA final-odds truncation.

Fixtures are synthetic; identity values are from the submitted state, not an
independent live JRA fetch. This test deliberately rejects prefix acceptance.
"""
import tempfile
import unittest
from jra_master.racing import _official_odds_name_matches,integrate_odds
from jra_master.store import Store

HID='2020190007'
CANON='ファストネットワーク'
SHORT='ファストネットワー'
RACE='2026-09-06-阪神-11'

class Odds2026NameV0719(unittest.TestCase):
 def test_exact_horse_identity_required(self):
  self.assertTrue(_official_odds_name_matches(HID,CANON,SHORT))
  self.assertTrue(_official_odds_name_matches(HID,CANON,CANON))
  for hid, full, short in [(HID+'1',CANON,SHORT),(HID,'別の馬',SHORT),(HID,CANON,'ファストネット'),(HID,CANON,'ファストネットワーク２')]:
   with self.subTest(hid=hid,full=full,short=short):
    self.assertFalse(_official_odds_name_matches(hid,full,short))

 @staticmethod
 def body(horse):
  s='<html><body>最終オッズ 単勝・複勝オッズ <table class="tanpuku"><tbody>'
  s+='<tr><td class="num">8</td><td class="horse">'+horse+'</td><td class="odds_tan">7.2</td></tr>'
  s+='<tr><td class="num">9</td><td class="horse">比較用</td><td class="odds_tan">3.6</td></tr>'
  return (s+'</tbody></table></body></html>').encode('cp932')

 def test_target_race_writes_odds_then_idempotent(self):
  with tempfile.TemporaryDirectory() as tmp:
   s=Store(tmp+'/master.sqlite3')
   s.c.execute('INSERT INTO races VALUES (?,?,?,?,?,?)',(RACE,'2026-09-06','阪神',11,'FLAT','{}'))
   s.c.execute('INSERT INTO horses VALUES (?,?)',(HID,CANON))
   s.c.execute('INSERT INTO horses VALUES (?,?)',('another','比較用'))
   s.c.execute('INSERT INTO runners VALUES (?,?,?,?)',(RACE,8,HID,'{}'))
   s.c.execute('INSERT INTO runners VALUES (?,?,?,?)',(RACE,9,'another','{}'))
   s.source({'source_id':'test_source','service':'TEST','role':'FINAL_WIN_ODDS','raw_state':'SYNTHETIC'})
   s.c.commit()
   self.assertEqual(integrate_odds(s,self.body(SHORT),'test_source',RACE),2)
   self.assertEqual(integrate_odds(s,self.body(SHORT),'test_source',RACE),2)
   self.assertEqual(s.c.execute('SELECT COUNT(*) FROM win_odds WHERE race_id=?',(RACE,)).fetchone()[0],2)
   for bad in ['別の馬','ファストネット','ファストネットワー２']:
    with self.subTest(bad=bad),self.assertRaisesRegex(ValueError,'ODDS_HORSE_NAME_MISMATCH'):
     integrate_odds(s,self.body(bad),'test_source',RACE)
   self.assertEqual(s.c.execute('SELECT COUNT(*) FROM win_odds WHERE race_id=?',(RACE,)).fetchone()[0],2)
   self.assertEqual(s.c.execute('PRAGMA integrity_check').fetchone()[0],'ok')
   s.c.close()

if __name__ == '__main__':unittest.main()
